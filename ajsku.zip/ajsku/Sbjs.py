# -*- coding: utf-8 -*- 
from linepy import *
from threading import Thread
from akad.ttypes import *
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib3, urllib, urllib.parse
import urllib, urllib3
from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from humanfriendly import format_timespan, format_size, format_number, format_length
#from gtts_token.gtts_token import Token
from googletrans import Translator
from urllib.parse import urlencode
import requests.packages.urllib3.exceptions as urllib3_exceptions
from multiprocessing import Pool,Process
from random import randint
from shutil import copyfile
from thrift.protocol import TCompactProtocol,TMultiplexedProtocol,TProtocol
from thrift.transport import TTransport,TSocket,THttpClient,TTransport,TZlibTransport
from akad.ttypes import IdentityProvider, LoginResultType, LoginRequest, LoginType
from Naked.toolshed.shell import execute_js
#cl = LINE("barongpea123@gmail.com","anu24barong")



cl = LINE("email","passwd",appName="DESKTOPWIN\t5.21.3\tWindows\t10")
sw = LINE("email","passwd",appName="DESKTOPWIN\t5.21.3\tWindows\t10")
#sw = LINE("Linek1.2019@gmail.com","11223344Yy",appName="DESKTOPWIN\t5.21.3\tWindows\t10")
#sw = LINE("lineb6.2019@gmail.com","11223344Ll",appName="DESKTOPWIN\t5.21.3\tWindows\t10")
#cl = LINE("F8bWqyddeu5yvaTPNQYd.UGC074FnY77h6ZE96mBttq.SZegB1KEN1ju3q8X0oV69C0Gs6bBmN+YOoi2HLIRk44=",appName="DESKTOPWIN\t5.21.3\tWindows\t10")
#cl = LINE("keikorajendra126@gmail.com","nf2926syah")|
cl.log("Auth Token : " + str(cl.authToken))


poll = OEPoll(cl)
#call = Call(cl)
creator = ["u7d23fdf500bf52356ddb34f610425a81"]
owner = ["u7d23fdf500bf52356ddb34f610425a81"]
admin = ["tarok mid mu"]
staff = ["tarok mid mu"]
tumbal = ["u270f1ccb4365bfccddccd3ea6dc6e840","ub60d24e8d212840bb3b279db33264ea4","u5425db48e71b79d0ca94b4ed87833f24","u479b1417c849efa99c569fa8b3127de2","u8dc253a3d06c4d4f7d0a8cd75344301c","u59b624ffc181c342f60091d9ffef186d","u8774b4b385e41a64f272c67a5b6bf545","ud9ee89cdc7d92fc1f9ce3b20e4c6adcf","uacb26c019e023cc15553704f973998b2","u53dee2c3be7cc3ba035b92e0c9d9c5b8","u10a8b33b67f3d068e1b81efc59b9288a","u41ade075fd8930f6a5bed67a73d7f48a","u863f5cf42e48a88a2a223a02358ad7c0","u2382816ba0900518fbab6f1bd5094ab0","u2f8b16f0a58ede0bce9675cf341ac3b6","u0a7c185b63f26d79c97389d658072698","u0a7c185b63f26d79c97389d658072698","u6f9b233ca539172e2960170f763f5af7","u632b981b837a3198bed7f66a53ea2cad","uca729dad627e5f8fd7193168a6acc0c0","uf8abaaeb4c4f14f162cd2b9835379269","ub549e39b74314ba2769280aaf5083bca","u5995d61ec220c9dc14af21b16f73e2a4","u3155acd029c06508802e7dca00a7765e","u4a5bc8be10d0b131991c1394a8442e57","u68b5da91f28a211122541fee48d7c0a6","uc70b92cc558a0cb2f6165d92c2b3742b","ubc2e6d6d20941160edf77fa90c4301bb","u3faa60ef88209e786dee09ce766e9681","u28b5ff0f1cf5e157b01f1cafbf88edc9","u83d46b2eec1bfe5949e2342209d993c1","ue5b9240fa3a5290a3cdbca5221fbb009","u6a3b5395165687cf10d785cc308e2c0c","ucb1166b174e5cc7754264c627164ca4e","uc7afc7f269214e3eb8a44179c56dbfe8","u4d1cbd160fe69f2c1201132701c93ef9","u64817d87ab88edbabf015992b2c48e72","u13a4d93bc2a83597e040a1700df18f14","u759f6a4094387bb8f40abcfa084624e1","u58ae79ec523d0f8504932c463e16b8e8","u5c2239ddeeb3be4f15b1972ef00ce309","ub6fd80737e9387b121f837acfaffc38d","u88ed01e0e92f3505aef820d68a6b9587","u09984afbbcef86cd3bc04453031afded","ua471b2732ad1fd9f2de43ab9d3d3b780","ud0f194a6e36ab62989808bf8666624f5","u4023b1dc12d4e500d9455e82759fd8c7","u6625449d13c12bb90d5d114f894954d7","u6a603a4e7cc47ca35cfa304a50554938","ud5017b5b016d89657378df63b3a94e00","u7be6c5b1eb1ffc567f756ff6d198bbd0","u06f09cf10ffdf885bf578a595846f17f","uaae0e269316d1c7bb06404c9f61c9096","u63c40b29b9a062280ea5c82cfa529748","u5760c336ba360376e1420f2cc7c9645b","u2326021180603dd396f2ffe134f67999","u08dc1459b86b5d6529c2c72090f1a624","u51d2463721b863793aad13a703ec63cf","u4d9540898c730134f012832711115e19","u535c481fb98ee55402e7673e44282aea","uf69ddef50b4b23183b9598f1924c5f44","uf47d94234cedd7f71a9b223b4ebb331d","u4cab563c98978dd5c8bc5781fbb73bae"]
mid = cl.getProfile().mid
Zmid = sw.getProfile().mid
ABC = [cl]
Saint = [cl]
Bots = [mid,Zmid]
Saints = admin + staff

protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
protectantijs= []
ghost = []
welcome = []
leave = []


settings = {
    "Picture":False, 
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "changeProfileVideo":False,
    "changeFoto":False,
    "autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}
msg_dict1 = {}
msg_dict = {}
wait = {
    "limit": 1, 
    "owner":{},
    "admin":{},
    "detectAll":False,
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "LikeOn":True,
    "bots":{},
    "like":4,
    "autoLike":True,
    "invite":False,
    "likeStat":True,
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "unsendMessage": False,
    "contact":False,
    'autoJoin':True,
    'autoAdd':True,
    'mcleave':False,
    'autoBlock':False,
    'autoLeave':False,
    'leaveOn':False,
    'autoLeft':False,
    "detectMention":False,
    "Mentionkick":False,
    "welcomeOn":False,
    "sticker":False,
    "unsend":True,
    "selfbot":True,
    "mention":"",
    "leave":"Selamat jalan kawan",
    "Respontag":"YANG NGETAG2 GAK JELAS TENGGELAMKAN -_-",
    "welcome":"Selamat datang & semoga betah n bahagia",
    "comment":"Like by BangLan ,Zanda Bot",
    "message":"Thanks for add me.\n☆ BangLan\n 0pen Order zanda\n.http://line.me/ti/p/dnuQNA56e8",
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
#with open('Sss.json', 'r') as fp:
	#Sss = json.load(fp)
with open('owner.json', 'r') as fp:
    owner = json.load(fp)

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)

def cloneProfile(mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        cl.updateProfilePicture(pict)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)
def backupProfile():
    profile = cl.getContact(clMID)
    if settingss['myProfile']['videoProfile'] == None:
        settingss['myProfile']['displayName'] = profile.displayName
        settingss['myProfile']['pictureStatus'] = profile.pictureStatus
        settingss['myProfile']['statusMessage'] = profile.statusMessage
        coverId = cl.getProfileDetail()['result']['objectId']
        settingss['myProfile']['coverId'] = str(coverId)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + profile.pictureStatus, saveAs="tmp/pict.bin")
        cl.updateProfilePicture(pict)
    else:
        settingss['myProfile']['displayName'] = profile.displayName
        settingss['myProfile']['pictureStatus'] = profile.pictureStatus
        settingss['myProfile']['statusMessage'] = profile.statusMessage
        settingss['myProfile']['videoProfile'] = profile.videoProfile
        coverId = indonesiandefacer.getProfileDetail()['result']['objectId']
        settingss['myProfile']['coverId'] = str(coverId)
        
def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def sendMention1(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "Total Mention User「{}」\n\n  [ Mention ]\n1. ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "「 Respon Leave 」\nBaper Ya Kak ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["leave"]
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        contact = cl.getContact(op.param2).picturePath
        image = 'https://obs-sg.line-apps.com'+contact
        cl.sendImageWithURL(op.param1, image)
        cl.sendMessage(to, None, contentMetadata={"STKID":"52002742","STKPKGID":"11537","STKVER":"1"}, contentType=7)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"] #+"\n\n✒Group name: "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        contact = cl.getContact(op.param2).picturePath
        cl.sendMessage(to, None, contentMetadata={"STKID":"68138712","STKPKGID":"4226946","STKVER":"1"}, contentType=7)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "Total Member Masuk「{}」\nHaii  ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+"\nNama grup : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        contact = cl.getContact(op.param2).picturePath
        image = 'https://obs-sg.line-apps.com'+contact
        cl.sendImageWithURL(op.param1, image)
        cl.sendMessage(to, None, contentMetadata={"STKID":"52002742","STKPKGID":"11537","STKVER":"1"}, contentType=7)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def CHROMEOS():
    Headers = {
    'User-Agent': "Line/8.14.2",
    'X-Line-Application': "CHROMEOS\t1.4.17\tPEOPLE\t1",
    "x-lal": "ja-US_US",
    }
    return Headers
def token(to,nametoken,msg_id,sender):
    try:
        a = nametoken
        a.update({'x-lpqs' : '/api/v4/TalkService.do'})
        transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4/TalkService.do')
        transport.setCustomHeaders(a)
        protocol = TCompactProtocol.TCompactProtocol(transport)
        clienttoken = LineService.Client(protocol)
        qr = clienttoken.getAuthQrcode(keepLoggedIn=1, systemName='PEOPLE')
        link = "line://au/q/" + qr.verifier
        cl.sendMessage(to, link)
        a.update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
        json.loads(requests.session().get('https://gd2.line.naver.jp/Q', headers=a).text)
        a.update({'x-lpqs' : '/api/v4p/rs'})
        transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4p/rs')
        transport.setCustomHeaders(a)
        protocol = TCompactProtocol.TCompactProtocol(transport)
        clienttoken = LineService.Client(protocol)
        req = LoginRequest()
        req.type = 1
        req.verifier = qr.verifier
        req.e2eeVersion = 1
        res = clienttoken.loginZ(req)
        try:
            token = res.authToken
            contact = cl.getContact(sender)
            url = requests.get("https://api.moe.team/generateToken?apikey=CBcecW8zbMBX6PR4OsrslaBBcMAF1ATyUtG24fQ3ASr4CzOhEOMJsHiWQT9AqL8F&auth={}:{}".format(contact.mid,token))
            data = url.text
            data = json.loads(data)
            ret_ = "INI TOKEN PRIMARY NYA BOSKU"
            ret_ += "\n{}".format(str(data["result"]["token"]))
            cl.sendMessage(to, str(ret_))
        except Exception as e:
            cl.sendMessage(to, str(e))
    except Exception as error:
        cl.sendMessage(to, "ʟᴏɢɪɴ ɢᴀɢᴀʟ")

def restoreProfile():
    profile = cl.getProfile()
    profile.displayName = settingss['myProfile']['displayName']
    profile.statusMessage = settingss['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settingss['myProfile']['pictureStatus']
        cl.updateProfileAttribute(8, profile.pictureStatus)
        cl.updateProfile(profile)
    else:
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + settingss['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settingss['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settingss['myProfile']['coverId']
    cl.updateProfileCoverById(coverId)
    
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = cl.genOBSParams({'oid': clMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        cl.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def help():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "〔𝗕𝗮𝗻𝗴𝗟𝗮𝗻〕\n│Using key「 " + key + " \n" + \
                  "● " + key + "𝗠e\n" + \
                  "● " + key + "𝗠𝗶𝗱「@」\n" + \
                  "● " + key + "𝗦 (𝘀𝗶𝗱𝗲𝗿 𝗼𝗻)\n" + \
                  "● " + key + "𝗙 (𝘀𝗶𝗱𝗲𝗿 𝗼𝗳𝗳)\n" + \
                  "●" + key + "𝗧𝗮𝗴\n" + \
                  "● " + key + "𝗔𝘂𝘁𝗼𝗷𝗼𝗶𝗻 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝗔𝘂𝘁𝗼𝗹𝗲𝗮𝘃𝗲 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝗔𝘂𝘁𝗼𝗯𝗹𝗼𝗰𝗸 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝙒𝙚𝙡𝙘𝙤𝙢𝙚 𝙤𝙣/𝙤𝙛𝙛\n" + \
                  "● " + key + "𝙍𝙚𝙨𝙥𝙤𝙣 𝙤𝙣/𝙤𝙛𝙛\n" + \
                  "● " + key + "𝗔𝘂𝘁𝗼𝗮𝗱𝗱 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝗔𝗱𝗺𝗶𝗻𝗮𝗱𝗱 @\n" + \
                  "● " + key + "𝗔𝗱𝗺𝗶𝗻𝗮𝗱𝗱 @\n" + \
                  "● " + key + "𝗔𝗱𝗺𝗶𝗻𝗱𝗲𝗹𝗹 @\n" + \
                  "● " + key + "𝗜𝗻𝘃𝗶𝘁𝗲 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝗕𝗹𝗰\n" + \
                  "● " + key + "𝗖𝗹𝗲𝗮𝗿𝗯𝗮𝗻\n" + \
                 "𝗕𝗮𝗻𝗴𝗟𝗮𝗻 https://line.me/ti/p/~buana241"
    return helpMessage

def helpbot():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "〔𝗕𝗮𝗻𝗴𝗟𝗮𝗻〕\n│Using key「 " + key + " \n" + \
                  "● " + key + "𝗛𝗲𝗹𝗽\n" + \
                  "● " + key + "𝗠e\n" + \
                  "● " + key + "𝗠𝗶𝗱「@」\n" + \
                  "● " + key + "𝗦 (𝘀𝗶𝗱𝗲𝗿 𝗼𝗻)\n" + \
                  "● " + key + "𝗙 (𝘀𝗶𝗱𝗲𝗿 𝗼𝗳𝗳)\n" + \
                  "●" + key + "𝗧𝗮𝗴\n" + \
                  "● " + key + "𝗔𝘂𝘁𝗼𝗷𝗼𝗶𝗻 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝗔𝘂𝘁𝗼𝗹𝗲𝗮𝘃𝗲 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝗜𝗻𝘃𝗶𝘁𝗲 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝗔𝘂𝘁𝗼𝗯𝗹𝗼𝗰𝗸 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝙒𝙚𝙡𝙘𝙤𝙢𝙚 𝙤𝙣/𝙤𝙛𝙛\n" + \
                  "● " + key + "𝙍𝙚𝙨𝙥𝙤𝙣 𝙤𝙣/𝙤𝙛𝙛\n" + \
                  "● " + key + "𝗔𝘂𝘁𝗼𝗮𝗱𝗱 𝗼𝗻/𝗼𝗳𝗳\n" + \
                  "● " + key + "𝗔𝗱𝗺𝗶𝗻𝗮𝗱𝗱 @\n" + \
                  "● " + key + "𝗔𝗱𝗺𝗶𝗻𝗱𝗲𝗹𝗹 @\n" + \
                  "● " + key + "𝗖𝗹𝗲𝗮𝗿𝗯𝗮𝗻\n" + \
                  "● " + key + "𝗕𝗹𝗰\n" + \
                 "𝗕𝗮𝗻𝗴𝗟𝗮𝗻 https://line.me/ti/p/~buana241"
                 ## " BangLan http://line.me/ti/p/dnuQNA56e8"
                  
    return helpMessage1

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 32:
           if op.param3 in tumbal:
           #if op.param1 in protectantijs:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                      #  if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                           # cl.inviteIntoGroup(op.param1,[tumbal])
                          #  cl.sendMessage(op.param1,"tumbal]")
                    except:
                            try:
                                sw.acceptGroupInvitation(op.param1)
                                sw.kickoutFromGroup(op.param1,[op.param2])
                                sw.leaveGroup(op.param1)
                                cl.inviteIntoGroup(op.param1,[Zmid])
                                #cl.sendMessage(op.param1,"Close")
                            except:
                                pass
        
        if op.type == 11:
            if op.param1 in protectqr:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            #cl.reissueGroupTicket(op.param1)
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            cl.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                except:
                    pass
                    
        if op.type == 11:
            if op.param2 in wait["blacklist"]:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            #cl.reissueGroupTicket(op.param1)
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            cl.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                except:
                    pass
                        
        if op.type == 13:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Hai " + str(ginfo.name))

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Haii " +str(ginfo.name))
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Haii " + str(ginfo.name))
        
        if op.type == 13:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        group = cl.getCompactGroup(op.param1)
                        gPendingMid = [contact.mid for contact in group.invitee]
                        for targets in gPendingMid:
                            if targets in op.param3:cl.cancelGroupInvitation(op.param1, [targets])
                            cl.kickoutFromGroup(op.param1, [op.param2])              
                    except:       
                       pass
                       
        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        group = cl.getCompactGroup(op.param1)
                        gPendingMid = [contact.mid for contact in group.invitee]
                        for targets in gPendingMid:
                            if targets in op.param3:cl.cancelGroupInvitation(op.param1, [targets])
                            cl.kickoutFromGroup(op.param1, [op.param2])              
                    except:       
                       pass
                       
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass
        
        if op.type == 22:
            if wait["mcleave"] == True:
                #cl.sendMessage(op.param1,"Duh malas mc2an")
                cl.leaveRoom(op.param1)
        if op.type == 15:
            if op.param1 in leave:
                if op.param2 in Bots:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2).picturePath
                image = 'https://obs-sg.line-apps.com'+contact
                leaveMembers(op.param1, [op.param2])
              #  cl.sendImageWithURL(op.param1, image)
            #    cl.sendMessage(to, None, contentMetadata={"STKID":"52002742","STKPKGID":"11537","STKVER":"1"}, contentType=7)
        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2).picturePath
                image = 'https://obs-sg.line-apps.com'+contact
                welcomeMembers(op.param1, [op.param2])
              #  cl.sendImageWithURL(op.param1, image)
               # cl.sendMessage(to, None, contentMetadata={"STKID":"52002742","STKPKGID":"11537","STKVER":"1"}, contentType=7)
        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
                            
                return

        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, wait["message"])

        if op.type == 5:
            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
            if wait["autoBlock"] == True:
                cl.sendMessage(op.param1,"Tapi Maaf Auto Block Saya Aktif........")
                cl.blockContact(op.param1)
                #cl.sendMessage(op.param1,"Tapi Maaf Auto Block Saya Aktif........")

        if op.type == 19:
            if op.param1 in protectkick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass
        
        if op.type == 19:
            if op.param3 in Zmid:
             if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:                 
                try:
                    cl.kickoutFromGroup(op.param1,[op.param2])
                  #  cl.findAndAddContactsByMid(op.param3)
                    cl.inviteIntoGroup(op.param1,[op.param3])
                except:
                    pass
                    
        if op.type == 19:
            if op.param3 in staff:
             if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:                 
                try:
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    cl.findAndAddContactsByMid(op.param3)
                    cl.inviteIntoGroup(op.param1,[op.param3])
                except:
                    pass

                return
        if op.type == 32:
            if op.param3 in mid:
             if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                wait["blacklist"][op.param2] = True
                try:
                    sw.acceptGroupInvitation(op.param1)
                    sw.kickoutFromGroup(op.param1,[op.param2])
                    #cl.findAndAddContactsByMid(op.param3)
                    sw.inviteIntoGroup(op.param1,[mid])
                    cl.acceptGroupInvitation(op.param1)
                    sw.leaveGroup(op.param1)
                    cl.inviteIntoGroup(op.param1,[Zmid])
                except:
                    try:
                        sw.kickoutFromGroup(op.param1,[op.param2])
                        sw.inviteIntoGroup(op.param1,[mid])
                        cl.acceptGroupInvitation(op.param1)
                        sw.leaveGroup(op.param1)
                        cl.inviteIntoGroup(op.param1,[Zmid])
                    except:
                        pass
        
        if op.type == 19:
            if op.param3 in mid:
             if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                wait["blacklist"][op.param2] = True
                try:
                    sw.acceptGroupInvitation(op.param1)
                    sw.kickoutFromGroup(op.param1,[op.param2])
                    #cl.findAndAddContactsByMid(op.param3)
                    sw.inviteIntoGroup(op.param1,[mid])
                    cl.acceptGroupInvitation(op.param1)
                    sw.leaveGroup(op.param1)
                    cl.inviteIntoGroup(op.param1,[Zmid])
                except:
                    try:
                        sw.acceptGroupInvitation(op.param1)
                        x = sw.getGroup(op.param1)
                        x.preventedJoinByTicket = False
                        sw.updateGroup(x)
                        invsend = 0
                        Ti = sw.reissueGroupTicket(op.param1)
                        cl.acceptGroupInvitationByTicket(op.param1,Ti)
                        Ti = sw.reissueGroupTicket(op.param1)
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        G = sw.getGroup(op.param1)
                        G.preventedJoinByTicket = True
                        sw.updateGroup(G)
                        sw.leaveGroup(op.param1)
                        cl.inviteIntoGroup(op.param1,[Zmid])
                       # cl.sendMessage(op.param1,"Close")
                    except:
                        pass
#-------------------------------------------------------------------------------     
        
        if op.type == 32:
           if op.param3 in Zmid:
           #if op.param1 in protectantijs:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                      #  if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.inviteIntoGroup(op.param1,[Zmid])
                         #   cl.sendMessage(op.param1,"=AntiJS Invited=")
                    except:
                            pass

#-------------------------------------------------------------------------------     

        if op.type == 32:
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.inviteIntoGroup(op.param1,[Zmid])
                    except:
                        pass
                            
                return               

        

        if op.type == 55:
            try:
                if op.param1 in Setmain["RAreadPoint"]:
                   if op.param2 in Setmain["RAreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["RAreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass
        
        
        if op.type == 65:
            if wait["unsendMessage"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = cl.getGroup(at)
                                Aditmadzs = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "「 Gambar Dihapus 」\n• Pengirim : "
                                ret_ = "• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(Aditmadzs.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':Aditmadzs.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = cl.getGroup(at)
                                Aditmadzs = cl.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "「 Pesan Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(Aditmadzs.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n• Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                cl.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if wait["unsendMessage"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getGroup(at)
                                Aditmadzs = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "「 Sticker Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(Aditmadzs.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                cl.sendMessage(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)

        
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          cl.kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              cl.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              cl.kickoutFromGroup(msg.to, [msg._from])
               
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"「Cek ID Sticker」\n✒ STKID : " + msg.contentMetadata["STKID"] + "\n✒ STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n✒ STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
            #   if wait["autoLike"] == True:
                  # url = msg.contentMetadata["postEndUrl"]
                 #  cl.likePost(url[25:58], url[66:], likeType=1001)
                  # cl.createComment(url[25:58], url[66:], "Auto Like by: Leo >> https://line.me/ti/p/~banglan241")

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"✒ Nama : " + msg.contentMetadata["displayName"] + "\n✒ MID : " + msg.contentMetadata["mid"] + "\n✒ Status Msg : " + contact.statusMessage + "\n✒ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
#ADD Bots
               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = cl.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            cl.sendMessage(msg.to, "Di Bl boss\nClearban dulu Jepit lagi..")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  cl.findAndAddContactsByMid(target)
                                  cl.inviteIntoGroup(msg.to,[target])
                                  ipunk = cl.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  "ʙᴇʀʜᴀsɪʟ ᴊᴇᴘɪᴛ.. \nNama "
                                  ret_ = "Ketik invite off jika sudah masuk"
                                  ry = str(veza.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':veza.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  cl.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                  cl.sendText(msg.to,"Done boss.....")
                                  wait["invite"] = False
                                  break
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        cl.sendMessage(msg.to,"Contact itu sudah jadi anggota bot")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke anggota bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Berhasil menghapus dari anggota bot")
                    else:
                        wait["dellbots"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan anggota bot saints")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        cl.sendMessage(msg.to,"Contact itu sudah jadi staff")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke staff")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Berhasil menghapus dari staff")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        cl.sendMessage(msg.to,"Contact itu sudah jadi admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke admin")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Berhasil menghapus dari admin")
                    else:
                        wait["delladmin"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan admin")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke blacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Berhasil menghapus dari blacklist user")
                    else:
                        wait["dblacklist"] = True
                        cl.sendMessage(msg.to,"Contact itu tidak ada di blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        cl.sendMessage(msg.to,"Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Berhasil menghapus dari Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        cl.sendMessage(msg.to,"Contact itu tidak ada di Talkban")
#UPDATE FOTO
               if msg.contentType == 1:
                   if settings["changeProfileVideo"] == True:
                       cl.downloadObjectMsg(msg_id, saveAs="image.jpeg")
                       settings["changeProfileVideo"] = False
                       cl.sendMessage(to, "Foto done, Send your video Boss..")
                   if settings["changeFoto"] == True:
                       path = cl.downloadObjectMsg(msg_id)
                       settings["changeFoto"] = False
                       cl.updateProfilePicture(path)
                       cl.sendMessage(to, "Berhasil mengubah foto profile")
               if settings["changeProfileVideo"] == True:
                       cl.downloadObjectMsg(msg_id, saveAs="video.mp4")
                       settings["changeProfileVideo"] = False
                       pict = "image.jpeg"
                       vids = "video.mp4"
                      # cl.updateProfilePicture(pict, vids)
                       changeVideoAndPictureProfile(pict, vids)
                       #ChangeVideoProfile(pict, vids)
                       cl.sendMessage(to, "Berhasil ppVideos...")

               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = cl.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            cl.sendMessage(msg.to, "Berhasil menambahkan gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     cl.sendMessage(msg.to, "Berhasil mengubah foto group")
               
               if msg.contentType == 1:
                 if msg._from in admin:
                        if mid in Setmain["VAfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["VAfoto"][mid]
                            cl.updateProfileCover(path)
                            cl.sendMessage(msg.to,"Foto berhasil dirubah")
                            
               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["RAfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            cl.updateProfilePicture(path)
                            cl.sendMessage(msg.to,"Foto berhasil dirubah")

               if msg.contentType == 1:
                 if msg._from in admin:
                        if Zmid in Setmain["RAfoto"]:
                            path = sw.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Zmid]
                            sw.updateProfilePicture(path)
                            sw.sendMessage(msg.to,"Foto berhasil dirubah")
               
               
               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = sw.downloadObjectMsg(msg_id)
                     path2 = kk.downloadObjectMsg(msg_id)
                     path3 = kc.downloadObjectMsg(msg_id)
                     #path4 = sw.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     sw.updateProfilePicture(path1)
                     sw.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
               #      kk.updateProfilePicture(path2)
                 #    kk.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
              #       kc.updateProfilePicture(path3)
              #       kc.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                   #  sw.updateProfilePicture(path4)
                     #sw.sendMessage(msg.to, "Berhasil mengubah foto profile bot")

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                               cl.sendMessage(msg.to, str(helpMessage))
                                                                                       
                        if cmd == "self on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                cl.sendMessage(msg.to, "Selfbot diaktifkan")
                                
                        elif cmd == "self off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                cl.sendMessage(msg.to, "Selfbot dinonaktifkan")
                                            
                        elif cmd == "help2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage1 = helpbot()
                               cl.sendMessage(msg.to, str(helpMessage1))    
                                        
                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "╭─〔BANG LAN〕──\n│Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n│Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]\n╰───────────────\n    •─{Protect Status}─•\n╭───────────────\n"
                                if wait["sticker"] == True: md+="│ Sticker「🔒」\n"
                                else: md+="│ Sticker「🔓」\n"
                                if wait["contact"] == True: md+="│ Contact「🔒」\n"
                                else: md+="│ Contact「🔓」\n"
                                if wait["talkban"] == True: md+="│ Talkban「🔒」\n"
                                else: md+="│ Talkban「🔓」\n"
                                if wait["Mentionkick"] == True: md+="│ Notag「🔒」\n"
                                else: md+="│ Notag「🔓」\n"
                                if wait["detectMention"] == True: md+="│ Respon「🔒」"
                                else: md+="│ Respon「🔓」\n"
                                if wait["autoJoin"] == True: md+="│ Autojoin「🔒」\n"
                                else: md+="│ Autojoin「🔓」\n"
                                if wait["autoAdd"] == True: md+="│ Autoadd「🔒」\n"
                                else: md+="│ Autoadd「🔓」\n"
                                if msg.to in welcome: md+="│ Welcome「🔒」\n"
                                else: md+="│ Welcome「🔓」\n"
                                if wait["autoLeave"] == True: md+="│ Autoleave「🔒」\n"
                                else: md+="│ Autoleave「🔓」\n"
                                if msg.to in protectqr: md+="│ Protecturl「🔒」\n"
                                else: md+="│ Protecturl「🔓」\n"
                                if msg.to in protectjoin: md+="│ Protectjoin「🔒」\n"
                                else: md+="│ Protectjoin「🔓」\n"
                                if msg.to in protectkick: md+="│ Protectkick「🔒」\n"
                                else: md+="│ Protectkick「🔓」\n"
                                if msg.to in protectcancel: md+="│ Protectcancel「??」\n╰───────────────"
                                else: md+="│ Protectcancel「🔓」\n╰───────────────"
                                cl.sendMessage(msg.to, md)
                        
                        elif cmd == "sss" or text.lower() == 'sss':
                            if msg._from in admin:
                                cl.sendMessage(msg.to,"Tolong add ")
                                ma = ""
                                for i in Sss:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                                    
                        elif cmd == "creator" or text.lower() == 'creator':
                            if msg._from in admin:
                                cl.sendMessage(msg.to,"Creator BangLan Bot Plindung Zanda ")
                                ma = ""
                                for i in creator:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "about" or cmd == "informasi":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendMention1(msg.to, sender, "「 Type Selfbot 」\n")
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': mid}, contentType=13)
                        
                        elif cmd == "me" or text.lower() == 'aku':
                          if wait["selfbot"] == True:
                            if msg._from in admin:                    
                                contact = cl.getContact(sender)                               
                                contentMetadata={'previewUrl': "http://dl.profile.line-cdn.net/"+contact.pictureStatus, 'i-installUrl': 'http://itunes.apple.com/app/linemusic/id966142320', 'type': 'mt', 'subText': contact.statusMessage, 'a-installUrl': 'market://details?id=jp.linecorp.linemusic.android', 'a-packageName': 'jp.linecorp.linemusic.android', 'countryCode': 'JP', 'a-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'i-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'text': contact.displayName, 'id': 'mt000000000d69e2db', 'linkUri': 'https://music.me.me/launch?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1','MSG_SENDER_ICON': "https://os.me.naver.jp/os/p/"+sender,'MSG_SENDER_NAME':  contact.displayName,}
                                cl.sendMessage(msg.to, contact.displayName, contentMetadata, 19)
                                cl.sendContact(to, mid)
                        

                        elif text.lower() == "mid":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, msg._from)

                        elif ("Mid " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "✒ Nama : "+str(mi.displayName)+"\n✒ Mid : " +key1+"\n✒ Status Msg"+str(mi.statusMessage))
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'https://os.line.naver.jp/os/p/{mid}'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'https://os.line.naver.jp/os/p/{mid}'+str(mi.picturePath))
                        
                        elif cmd == "myajs":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               #cl.sendContact(to, mid)
                               #cl.sendContact(to, mid)
                            #   cl.sendContact(to, Cmid)
                               cl.sendContact(to, Zmid)
                        elif cmd == "mybot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               #cl.sendContact(to, mid)
                               cl.sendContact(to, mid)
                            #   cl.sendContact(to, Cmid)
                               cl.sendContact(to, Zmid)
                               #cl.sendContact(to, Amid)

                        elif text.lower() == "hapus chat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                               except:
                                   pass
                                                
                        elif text.lower() == "remove chat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   sw.removeAllMessages(op.param2)         
                                   sw.sendMessage(msg.to,"Chat dibersihkan...")
                               except:
                                   pass

                        elif cmd.startswith("broadcast: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   cl.sendMessage(group,"" + str(pesan))

                        elif msg.text in ["Salam"]:
                              cl.sendMessage(msg.to,"السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ")
                        elif msg.text in ["Jawab"]:
                              cl.sendMessage(msg.to,"وَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِوَبَرَكَاتُهُ")
                        elif msg.text in ["Login"]:
                              cl.sendMessage(msg.to,"LOGIN:\nTANGALL:10_07_2018")
                        elif msg.text in ["Adel"]:
                              cl.sendMessage(msg.to,"Yapz Hadir")
                          #    cl.sendMessage(msg.to,"AKU HANYA BAYANGAN")
                              cl.sendContact(to, mid)
                        elif msg.text in ["Payment"]:
                              cl.sendMessage(msg.to,"Bank:\nBRI  704201024050537 RusLan Gani\nPULSA:\n081281931897")
                             # cl.sendMessage(msg.to,
                        elif msg.text in ["Respoggggn","Agggbsen"]:
                              cl.sendMessage(msg.to,"Aku Bukan Asistmu")
                        elif msg.text in ["Responsename"]:
                              cl.sendMessage(msg.to,"Aku Bukan Asistmu")
                        elif msg.text in ["Speeed"]:
                              cl.sendMessage(msg.to,"Sabar Babang.....")
                              cl.sendMessage(msg.to,"00000,00001279976007Second")
                               
                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Mykey」\nSetkey bot mu「 " + str(Setmain["keyCommand"]) + " 」")

                        elif cmd.startswith('scal '):
                           if msg._from in admin:
                            sep = text.split(" ")
                           # strnum = text.replace(sep[0] + " ","")
                          #  num = int(strnum)
                            num = int(sep[1])
                            try:
                                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                #if 'MENTION' in msg.contentMetadata()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        for var in range(0,num):
                                            group = cl.getGroup(to)
                                            members = [ls]
                                            kunkun = cl.getContact("ud3c03018f0d84ce959dabe029ef6d008").displayName
                                            cl.acquireGroupCallRoute(to)
                                            cl.inviteIntoGroupCall(to, contactIds=members)
                                        cl.sendMessage(to, "Berhasil mengundang kepanggilan group.")
                            except Exception as error:
                                cl.sendMessage(to, str(error))
                        
                        elif cmd.startswith('//reject '):
                            if msg._from in admin:
                                ng = msg.text.replace('//reject ','')
                                cl.sendMessage(to,"Jangan chat sampai ada notife sukses")
                                def reject():
                                    gid = cl.getGroupIdsInvited()
                                    for i in gid:
                                        h = cl.getGroup(i).name
                                        if h == ng:
                                            time.sleep(0.8)
                                            cl.rejectGroupInvitation(i)
                                    cl.sendMessage(to,"Succes reject groups {}".format(ng))
                                th = threading.Thread(target=reject)
                                th.start()
                                th.join()
                        elif cmd.startswith('xup '):
                              if msg.toType == 2:
                               if msg._from in admin:
                                  sep = text.split(" ")
                                  strnum = text.replace(sep[0] + " ","")
                                  num = int(strnum)
                                  cl.sendMessage(to, "Berhasil mengundang kedalam panggilan group")
                              for var in range(0,num):
                                  group = cl.getGroup(to)
                                  members = [mem.mid for mem in group.members]
                                  #client.acquireGroupCallRoute(to)
                                  cl.inviteIntoGroupCall(to, contactIds=members)

                        elif cmd.startswith("it "):
                           if msg._from in admin:                        	
                            sep = text.split(" ")
                            textnya = text.replace(sep[0] + " ","")
                            url = "http://chart.apis.google.com/chart?chs=480x80&cht=p3&chtt=" + textnya + "&chts=FFFFFF,70&chf=bg,s,000000"
                            cl.sendImageWithURL(msg.to, url)
                               
                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   cl.sendMessage(msg.to, "「Setkey」\nSetkey diganti jadi「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               cl.sendMessage(msg.to, "「Setkey」\nSetkey mu kembali ke awal")

                        elif cmd == "restart":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "Tunggu sebentar...")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               cl.sendMessage(msg.to, "Silahkan gunakan seperti semula...")
                            
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "Aktif " +waktu(eltime)
                               cl.sendMessage(msg.to,bot)

                        elif cmd == "cek":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:cl.inviteIntoGroup(to, ["u3529bce86ebac075d621966ef16486f3"]);has = "OK"
                               except:has = "NOT"
                               try:cl.kickoutFromGroup(to, ["u3529bce86ebac075d621966ef16486f3"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "OKE ✔"
                               else:sil = "BANAD"
                               if has1 == "OK":sil1 = "OKE ✔"
                               else:sil1 = "BANAD"
                               cl.sendMessage(to, "ᴋɪᴄᴋ : {} \nɪɴᴠɪᴛᴇ : {}\n".format(sil1,sil))

                        elif cmd == "cekbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:cl.inviteIntoGroup(to, ["u3529bce86ebac075d621966ef16486f3"]);has = "OK"
                               except:has = "NOT"
                               try:cl.kickoutFromGroup(to, ["u3529bce86ebac075d621966ef16486f3"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "OKE ✔"
                               else:sil = "BANAD"
                               if has1 == "OK":sil1 = "OKE ✔"
                               else:sil1 = "BANAD"
                               cl.sendMessage(to, "ᴋɪᴄᴋ : {} \nɪɴᴠɪᴛᴇ : {}\n".format(sil1,sil))
                               try:sw.inviteIntoGroup(to, ["u7d4e23945e41b5274455b95ffd8af1f1"]);has = "OK"
                               except:has = "NOT"
                               try:sw.kickoutFromGroup(to, ["u7d4e23945e41b5274455b95ffd8af1f1"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "OKE✔"
                               else:sil = "BANAD"
                               if has1 == "OK":sil1 = "OKE✔"
                               else:sil1 = "BANAD"
                               sw.sendMessage(to, "ᴋɪᴄᴋ : {} \nɪɴᴠɪᴛᴇ : {}\n".format(sil1,sil))

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                cl.sendMessage(msg.to, "✒ ReyPro Grup Info\n\n✒ Nama Group : {}".format(G.name)+ "\n✒ ID Group : {}".format(G.id)+ "\n✒ Pembuat : {}".format(G.creator.displayName)+ "\n✒ Waktu Dibuat : {}".format(str(timeCreated))+ "\n✒ Jumlah Member : {}".format(str(len(G.members)))+ "\n✒ Jumlah Pending : {}".format(gPending)+ "\n✒ Group Qr : {}".format(gQr)+ "\n✒ Group Ticket : {}".format(gTicket))
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                cl.sendMessage(msg.to, str(e))

                        elif cmd.startswith("infogrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "✒ Zandabot Grup Info\n"
                                ret_ += "\n✒ Nama Group : {}".format(G.name)
                                ret_ += "\n✒ ID Group : {}".format(G.id)
                                ret_ += "\n✒ Pembuat : {}".format(gCreator)
                                ret_ += "\n✒ Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n✒ Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n✒ Jumlah Pending : {}".format(gPending)
                                ret_ += "\n✒ Group Qr : {}".format(gQr)
                                ret_ += "\n✒ Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(to, str(ret_))
                            except:
                                pass
                        
                        elif cmd.startswith("ggrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = sw.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = sw.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "✒ Zandabot Grup Info\n"
                                ret_ += "\n✒ Nama Group : {}".format(G.name)
                                ret_ += "\n✒ ID Group : {}".format(G.id)
                                ret_ += "\n✒ Pembuat : {}".format(gCreator)
                                ret_ += "\n✒ Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n✒ Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n✒ Jumlah Pending : {}".format(gPending)
                                ret_ += "\n✒ Group Qr : {}".format(gQr)
                                ret_ += "\n✒ Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                sw.sendMessage(to, str(ret_))
                            except:
                                pass
                                
                        elif cmd.startswith("infomem "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "✒ "+ str(no) + ". " + mem.displayName
                                cl.sendMessage(to,"✒ Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\n「Total %i Members」" % len(G.members))
                            except: 
                                pass

                        elif cmd == "fiendlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               cl.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                        
                        elif cmd == "sgp":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = sw.getGroupIdsInvited()
                               for i in gid:
                                   G = sw.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               sw.sendMessage(msg.to,"╔══[ GROUP PENDINGABLIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」PENDINGAN Groups ]")
                        elif cmd == "//gp":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsInvited()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ GROUP PENDINGANLIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」PENDINGAN Groups ]")

                        elif cmd == "gruplist2":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = sw.getGroupIdsJoined()
                               for i in gid:
                                   G = sw.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               sw.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "url grup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = cl.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      cl.updateGroup(x)
                                   gurl = cl.reissueGroupTicket(msg.to)
                                   cl.sendMessage(msg.to, "Nama : "+str(x.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)
                            
                        elif cmd == "invitationlist":
                           if msg._from in admin:
                            gids = cl.getGroupIdsInvited()
                            gnames = []
                            ress = []
                            res = '╭───「 Invitation List 」'
                            res += '\n├ List:'
                            if gids:
                                groups = cl.getGroups(gids)
                                no = 0
                                if len(groups) > 200:
                                    parsed_len = len(groups)//200+1
                                    for point in range(parsed_len):
                                        for group in groups[point*200:(point+1)*200]:
                                            no += 1
                                            res += '\n│ %i. %s//%i' % (no, group.name, len(group.members))
                                            gnames.append(group.name)
                                        if res:
                                            if res.startswith('\n'): res = res[1:]
                                            if point != parsed_len - 1:
                                                ress.append(res)
                                        if point != parsed_len - 1:
                                            res = ''
                                else:
                                    for group in groups:
                                        no += 1
                                        res += '\n│ %i. %s//%i' % (no, group.name, len(group.members))
                                        gnames.append(group.name)
                            else:
                                res += '\n│ Nothing'
                            res += '\n├ Usage : '
                            res += '\n│ • {key}InvitationList'
                            res += '\n│ • {key}InvitationList Accept <num/name/all>'
                            res += '\n│ • {key}InvitationList Reject <num/name/all>'
                            res += '\n╰───「 XxxxX」'
                            ress.append(res)
                            if cmd == 'invitationlist':
                                for res in ress:
                                	cl.sendMessage(to, parsingRes(res))
                                   # cl.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            
                        elif cmd == "allreject":
                            if msg._from in admin:
                                ginvited = cl.getGroupIdsInvited()
                                if ginvited != [] and ginvited != None:
                                   for gid in ginvited:
                                       cl.rejectGroupInvitation(gid)
                                       time.sleep(0.5)
                                   cl.sendMessage(to, "Succes reject {} ".format(str(len(ginvited))))
                                else:
                                    cl.sendMessage(to, "Success reject all invite")
#===========BOT UPDATE============#
                        elif cmd == "sfoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                cl.sendMessage(msg.to,"Send your images.....")
                        elif cmd == "upcover":
                            if msg._from in admin:
                                Setmain["VAfoto"][mid] = True
                                cl.sendMessage(msg.to,"Send your images.....")
                        elif cmd == "1up":
                            if msg._from in admin:
                                Setmain["RAfoto"][Zmid] = True
                                sw.sendMessage(msg.to,"Send your images.....")

                        elif cmd.startswith("sname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith("ghostname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = sw.getProfile()
                                profile.displayName = string
                                sw.updateProfile(profile)
                                sw.sendMessage(msg.to,"Nama diganti jadi " + string + "")

#===========BOT UPDATE============#
                        elif cmd == "tag" or text.lower() == 'ehm':
                           if wait["selfbot"] == True:
                            if msg._from in admin:
                             group = cl.getGroup(msg.to)
                            nama = [contact.mid for contact in group.members]
                            k = len(nama)//20
                            for a in range(k+1):
                                txt = u''
                                s=0
                                b=[]
                                for i in group.members[a*20 : (a+1)*20]:
                                    b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                    s += 7
                                    txt += u'@Zero \n'
                                cl.sendMessage(msg.to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)

                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"✒ zandabot\n\n"+ma+"\nTotal「%s」Bots" %(str(len(Bots))))

                        elif cmd == "listadmin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"✒ Zanda admin\n\nSuper admin:\n"+ma+"\nAdmin:\n"+mb+"\nStaff:\n"+mc+"\nTotal「%s」Leo staff" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "listprotect":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                me = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                e = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectkick
                                for group in gid:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectinvite
                                for group in gid:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectjoin
                                for group in gid:
                                    e = e + 1
                                    end = '\n'
                                    me += str(e) + ". " +cl.getGroup(group).name + "\n"
                                cl.sendMessage(msg.to,"✒ Zanda Protection\n\n✒ PROTECT QR :\n"+ma+"\n✒ PROTECT KICK :\n"+mb+"\n✒ PROTECT INVITE :\n"+mc+"\n✒ PROTECT CANCEL :\n"+md+"\n✒ PROTECT JOIN :\n"+me+"\nTotal「%s」Grup yg dijaga" %(str(len(protectqr)+len(protectkick)+len(protectinvite)+len(protectcancel+len(protectjoin))))

                        elif cmd == "addbot":
                            if msg._from in admin:
                        	#if wait["selfbot"] == True:                    
                                  try:
                                      cl.findAndAddContactsByMid(Zmid)                                                                                                                      
                                      cl.sendMessage(to,"added from friendlist.")
                                      sw.findAndAddContactsByMid(mid)                                                                                                                      
                                      sw.sendMessage(to,"added from friendlist.")                                                                                        
                                  except:
                                      pass

                        elif cmd == "s stay":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Zmid])
                                #    cl.sendMessage(msg.to,"Grup 「"+str(ginfo.name)+"」 Aman Dari Js")
                                except:
                                    pass
                        
                        elif cmd == "corona":
                              req = requests.get('https://api.kawalcorona.com/indonesia')
                              data = json.loads(req.text)
                              ret_ = "╭──[ Info Corona ]"
                              ret_ += "\n├⋄ Title : " +str(data["title"])
                              ret_ += "\n├⋄ Date : " +str(data["date"])
                            #  ret_ += "\n├⋄ Dunia :"
                           #   ret_ += "\n│       Negara : " +str(data["dunia"]["negara"])
                            #  ret_ += "\n│       Kasus : " +str(data["dunia"]["kasus"]) 
                            #  ret_ += "\n│       Sembuh : " +str(data["dunia"]["sembuh"])
                             # ret_ += "\n│       Kematian : " +str(data["dunia"]["kematian"])
                              ret_ += "\n├⋄ Indonesia :"
                              ret_ += "\n│       Positif : " +str(data["indonesia"]["positif"])
                              ret_ += "\n│       Sembuh : " +str(data["indonesia"]["sembuh"]) 
                              ret_ += "\n│       Meninggal : " +str(data["indonesia"]["meninggal"])
                              ret_ += "\n╰──[ Selesai ]"
                              cl.sendReplyMessage(msg.id, to, str(ret_))
                        
                        elif cmd == "bot in":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, ["u3599016062a2fcd0b75e0c69634f218d","u30720eebbce32fc169cc5e2a25cacf55","uc489446365a6a4864edd884c2487def6","u50fb0f34487e7dceae755b8e9379befe","u219d9b0773b7e8ddae4aa049805aa869","ud1024612d1f24ddc5d2d8bb067a892d3","ub65f39b6164f4013f2bab29c1cc2d6e1","u73b0f82482eb31e37e8af6b54cb8f672","uce7cc4c10dff88cd4d1f8eea88304261","u60d27d4c8ef5d5c97d1fbbbeeefacd9d"])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                              #      cl.sendMessage(msg.to,"Grup 「"+str(ginfo.name)+"」 Aman Dari zanda")
                                except:
                                    pass
                        elif cmd == "stt":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, ["u3599016062a2fcd0b75e0c69634f218d","u270f1ccb4365bfccddccd3ea6dc6e840","ub60d24e8d212840bb3b279db33264ea4","u5425db48e71b79d0ca94b4ed87833f24","u479b1417c849efa99c569fa8b3127de2","u8dc253a3d06c4d4f7d0a8cd75344301c","u59b624ffc181c342f60091d9ffef186d","u8774b4b385e41a64f272c67a5b6bf545","ud9ee89cdc7d92fc1f9ce3b20e4c6adcf","uacb26c019e023cc15553704f973998b2","u53dee2c3be7cc3ba035b92e0c9d9c5b8","u10a8b33b67f3d068e1b81efc59b9288a","u41ade075fd8930f6a5bed67a73d7f48a","u863f5cf42e48a88a2a223a02358ad7c0","u2382816ba0900518fbab6f1bd5094ab0","u2f8b16f0a58ede0bce9675cf341ac3b6","u0a7c185b63f26d79c97389d658072698","u0a7c185b63f26d79c97389d658072698","u6f9b233ca539172e2960170f763f5af7","u632b981b837a3198bed7f66a53ea2cad","uca729dad627e5f8fd7193168a6acc0c0","uf8abaaeb4c4f14f162cd2b9835379269","ub549e39b74314ba2769280aaf5083bca","u5995d61ec220c9dc14af21b16f73e2a4","u3155acd029c06508802e7dca00a7765e","u4a5bc8be10d0b131991c1394a8442e57","u68b5da91f28a211122541fee48d7c0a6","uc70b92cc558a0cb2f6165d92c2b3742b","ubc2e6d6d20941160edf77fa90c4301bb","u3faa60ef88209e786dee09ce766e9681","u28b5ff0f1cf5e157b01f1cafbf88edc9","u83d46b2eec1bfe5949e2342209d993c1","ue5b9240fa3a5290a3cdbca5221fbb009","u6a3b5395165687cf10d785cc308e2c0c","ucb1166b174e5cc7754264c627164ca4e","uc7afc7f269214e3eb8a44179c56dbfe8","u4d1cbd160fe69f2c1201132701c93ef9","u64817d87ab88edbabf015992b2c48e72","u13a4d93bc2a83597e040a1700df18f14","u759f6a4094387bb8f40abcfa084624e1","u58ae79ec523d0f8504932c463e16b8e8","u5c2239ddeeb3be4f15b1972ef00ce309","ub6fd80737e9387b121f837acfaffc38d","u88ed01e0e92f3505aef820d68a6b9587","u09984afbbcef86cd3bc04453031afded","ua471b2732ad1fd9f2de43ab9d3d3b780","ud0f194a6e36ab62989808bf8666624f5","u4023b1dc12d4e500d9455e82759fd8c7","u6625449d13c12bb90d5d114f894954d7","u6a603a4e7cc47ca35cfa304a50554938","ud5017b5b016d89657378df63b3a94e00","u7be6c5b1eb1ffc567f756ff6d198bbd0","u06f09cf10ffdf885bf578a595846f17f","uaae0e269316d1c7bb06404c9f61c9096","u63c40b29b9a062280ea5c82cfa529748","u5760c336ba360376e1420f2cc7c9645b","u2326021180603dd396f2ffe134f67999","u08dc1459b86b5d6529c2c72090f1a624","u51d2463721b863793aad13a703ec63cf","u4d9540898c730134f012832711115e19","u535c481fb98ee55402e7673e44282aea","uf69ddef50b4b23183b9598f1924c5f44","uf47d94234cedd7f71a9b223b4ebb331d","u4cab563c98978dd5c8bc5781fbb73bae"])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                                    #cl.inviteIntoGroup(msg.to, [""])
                              #      cl.sendMessage(msg.to,"Grup 「"+str(ginfo.name)+"」 Aman Dari zanda")
                                except:
                                    pass
     
                        elif cmd == "sjoin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Zmid])
                                    sw.acceptGroupInvitation(msg.to)
                                    #s1.acceptGroupInvitation(msg.to)
                                #    cl.sendMessage(msg.to,"Grup 「"+str(ginfo.name)+"」 Aman Dari Js")
                                except:
                                    pass
                        
                        elif cmd == ".bye":
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                cl.leaveGroup(msg.to)

                        elif cmd == "sbye":
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                sw.leaveGroup(msg.to)
                                #cl.inviteIntoGroup(msg.to,[Zmid])

                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               start = time.time()
                               cl.sendMessage(msg.to, "Progres speed...")
                               elapsed_time = time.time() - start
                               cl.sendMessage(msg.to, "{} detik".format(str(elapsed_time)))

                        elif cmd == "s":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  #cl.sendMessage(msg.to, "Cek sider diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "f":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  #cl.sendMessage(msg.to, "Cek sider dinonaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                              else:
                                  cl.sendMessage(msg.to, "Sudak tidak aktif")	
                    
                      #  elif cmd == "promo":
                       #   if msg._from in admin:
                            # cl.sendMessage(msg.to,"──────┅❇͜͡❇͜͡☆͜͡❇͜͡❇┅──────\nᴼᴾᴱᴺ ᴼᴿᴰᴱᴿ\n────────┅┅───────\n➣ꜱᴇʟꜰʙᴏᴛ ᴏɴʟʏ\n➣ꜱᴇʟꜰʙᴏᴛ + ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 2 ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 3 ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 4 ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 5 ᴀꜱɪꜱᴛ\n➣ʙᴏᴛᴘʀᴏᴛᴇᴄᴛ 3-30 ʙᴏᴛ ᴀꜱɪꜱᴛ\n➣ɴᴇᴡ ꜱᴄʀɪᴘᴛ\n➣ʜʀɢᴀ ʙɪꜱᴀ ɴᴇɢᴏ\n─────────┅┅─────────\n  ✯❇͜͡❇͜͡C͜͡r͜͡e͜͡a͜͡t͜͡o͜͡r✯͜͡$͜͡ë͜͡I͜͡F͜͡-͜͡฿͜͜͡͡o͜͡t͜͡ ͜͡❇͜͡❇✯\nline.me/ti/p/~usro.timplaktimplung\nline.me/ti/p/~ery240489\n➣ѕєʟғвот κɪcκєʀ_+_ᴘʀᴏᴛᴇᴄᴛ\n────────┅❇͜͡❇͜͡☆͜͡❇͜͡❇┅────────")
                           #  msg.contentType = 13
                            # msg.contentMetadata = {'mid': admin}
                           #  tanya = msg.text.replace("promo ","")
                           #  jawab = ("──────┅❇͜͡❇͜͡☆͜͡❇͜͡❇┅──────\nᴼᴾᴱᴺ ᴼᴿᴰᴱᴿ\n────────┅┅───────\n➣ꜱᴇʟꜰʙᴏᴛ ᴏɴʟʏ\n➣ꜱᴇʟꜰʙᴏᴛ + ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 2 ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 3 ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 4 ᴀꜱɪꜱᴛ\n➣1 ᴀᴋᴜɴ ᴜᴛᴀᴍᴀ + 5 ᴀꜱɪꜱᴛ\n➣ʙᴏᴛᴘʀᴏᴛᴇᴄᴛ 3-30 ʙᴏᴛ ᴀꜱɪꜱᴛ\n➣ɴᴇᴡ ꜱᴄʀɪᴘᴛ\n➣ʜʀɢᴀ ʙɪꜱᴀ ɴᴇɢᴏ\n─────────┅┅─────────\n  ✯❇͜͡❇͜͡C͜͡r͜͡e͜͡a͜͡t͜͡o͜͡r✯͜͡$͜͡ë͜͡I͜͡F͜͡-͜͡฿͜͜͡͡o͜͡t͜͡ ͜͡❇͜͡❇✯\nline.me/ti/p/~usro.timplaktimplung\nline.me/ti/p/~ery240489\n➣ѕєʟғвот κɪcκєʀ_+_ᴘʀᴏᴛᴇᴄᴛ\n────────┅❇͜͡❇͜͡☆͜͡❇͜͡❇┅────────")
                             #jawaban = random.choice(jawab)
                             #tts = gTTS(text=jawaban, lang='id')
                          #   tts.save('tts.mp3')
                         #    cl.sendAudio(msg.to,'tts.mp3')
                            # cl.sendMessage(msg)         
                            # cl.sendMessage(msg.to,"Jika Berminat Langsung Hubungi Kami Ya Trima Kasih😊😊")        

#===========Hiburan============#
                        elif cmd.startswith("swinv "):
                          if msg._from in admin:
                            if msg.toType == 2:
                                separate = text.split(" ")
                                number = text.replace(separate[0] + " ","")
                                group = sw.getGroupIdsJoined()
                                try:
                                    target = group[int(number)-1]
                                    G = sw.getGroup(target)
                                    #for x in SupOwn:
                                    sw.findAndAddContactsByMid(sender)
                                    sw.inviteIntoGroup(target,[sender])
                                    #cl.sendMessage(msg.to, str(ret_))
                                except:
                                    sw.sendMessage(to, "berhasil invite")
                                    
                        elif cmd.startswith("invto "):
                          if msg._from in admin:
                            if msg.toType == 2:
                                separate = text.split(" ")
                                number = text.replace(separate[0] + " ","")
                                group = cl.getGroupIdsJoined()
                                try:
                                    target = group[int(number)-1]
                                    G = cl.getGroup(target)
                                    #for x in SupOwn:
                                    cl.findAndAddContactsByMid(sender)
                                    cl.inviteIntoGroup(target,[sender])
                                    #cl.sendMessage(msg.to, str(ret_))
                                except:
                                    cl.sendMessage(to, "berhasil invite")
                                 
                        elif cmd.startswith("lokasi: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            location = msg.text.replace(separate[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                r = web.get("http://api.corrykalam.net/apiloc.php?lokasi={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                if data[0] != "" and data[1] != "" and data[2] != "":
                                    link = "https://www.google.co.id/maps/@{},{},15z".format(str(data[1]), str(data[2]))
                                    ret_ = "「Info Lokasi」"
                                    ret_ += "\n✒ Location : " + data[0]
                                    ret_ += "\n✒ Google Maps : " + link
                                else:
                                    ret_ = "[Details Location] Error : Location not found"
                                cl.sendMessage(msg.to,str(ret_))
                        elif msg.text.lower().startswith("musrik "):
                          if msg._from in admin:
                            try:
                                proses = msg.text.split(" ")
                                urutan = msg.text.replace(proses[0] + " ","")
                                m = requests.get("https://beta.beapi.me//joox?search=maria")
                                data = m.text
                                data = json.loads(m.text)
                                cl.sendMessage(to,data["result"][0]["title"])
                                cl.sendAudioWithURL(to,data["result"][0]["mp3Url"])
                              #  r = requests.get("https://mnazria.herokuapp.com/api/joox?search={}".format(str(urllib.parse.quote(urutan))))
                              #  data = r.text
                                #data = json.loads(data)
                               # cl.sendAudioWithURL(to,data["mp3"])
                            except Exception as error:
                                cl.sendMessage(to, "error\n" + str(error))
                                logError(error)
                        elif 'ID line: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              msgs = msg.text.replace('ID line: ','')
                              conn = cl.findContactsByUserid(msgs)
                              if True:
                                  cl.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  cl.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)
                        elif msg.text.lower().startswith("alibi|"):
                        #  if msg._from in admin:
                           sep = text.replace("alibi|","")
                           bctext = text.split("|")
                           dan = bctext[1]
                           anu = bctext[2]
                           req = requests.get("https://api.moe.team/photofunia/neon?text1={}&text2={}&apikey=CBcecW8zbMBX6PR4OsrslaBBcMAF1ATyUtG24fQ3ASr4CzOhEOMJsHiWQT9AqL8F".format(dan, anu))
                           data = req.json()
                           cl.sendImageWithURL(to,str(data["response"]["images"]["large"]["url"]))

#===========Protection============#
                        elif 'Left ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Left ','')
                              if spl == 'on':
                                  if msg.to in leave:
                                       msgs = "Baper Msg sudah aktif"
                                  else:
                                       leave.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Baper Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in leave:
                                         leave.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Baper Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Baper Msg sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Welcome Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Welcome Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Welcome Msg sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protecturl ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protecturl ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "Protect url sudah aktif"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect url diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect url dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect url sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Cek ' in msg.text:
                          #  if msg._from in admin:
                               name = msg.text.replace("Cek ","")
                               cl.sendContact(to, name)
                            
                        elif 'Protectkick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectkick ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "Protect kick sudah aktif"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect kick diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect kick dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect kick sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectjoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectjoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "Protect join sudah aktif"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect join diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect join dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect join sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectcancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectcancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "Protect cancel sudah aktif"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect cancel diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect cancel dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect cancel sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    
                        elif 'Protectinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectinvite ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "Protect invite sudah aktif"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect invite diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect invite dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect invite sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)                                    
#-------------------------------------------------------------------------------      
#-------------------------------------------------------------------------------      
#-------------------------------------------------------------------------------     

                        elif 'S ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('S ','')
                              if spl == 'on':
                                  if msg.to in protectantijs:
                                       msgs = " sudah aktif"
                                  else:
                                       protectantijs.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectantijs:
                                         protectantijs.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Sudah Tidak Aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Semua pro ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Semua pro ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectjoin:
                                      msgs = ""
                                  else:
                                      protectjoin.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Semua protect sudah on\nDi Group : " +str(ginfo.name)
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Berhasil mengaktifkan semua protect\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Berhasil menonaktifkan semua protect\nDi Group : " +str(ginfo.name)
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Semua protect sudah off\nDi Group : " +str(ginfo.name)
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

#===========KICKOUT============#
                        elif ("Nk " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           G = cl.getGroup(msg.to)
                                           G.preventedJoinByTicket = False
                                           cl.updateGroup(G)
                                           invsend = 0
                                           Ticket = cl.reissueGroupTicket(msg.to)
                                           sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                           sw.kickoutFromGroup(msg.to, [target])
                                           sw.leaveGroup(msg.to)
                                           cl.inviteIntoGroup(msg.to, [Zmid])
                                           X = cl.getGroup(msg.to)
                                           X.preventedJoinByTicket = True
                                           cl.updateGroup(X)
                                       except:
                                           pass
                        
                        elif cmd.startswith("ultii "):
                           if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        cl.kickoutFromGroup(to, [ls])
                                        cl.findAndAddContactsByMid(ls)
                                        cl.inviteIntoGroup(to, [ls])
                                        cl.cancelGroupInvitation(to, [ls])
                                        #cl.inviteIntoGroup(to, [ls])
                                    except:
                                       cl.sendMessage(to, "Limited !")
                                       
                        elif cmd.startswith("ulti "):
                           if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        cl.kickoutFromGroup(to, [ls])
                                        cl.findAndAddContactsByMid(ls)
                                        cl.inviteIntoGroup(to, [ls])
                                        cl.cancelGroupInvitation(to, [ls])
                                        cl.inviteIntoGroup(to, [ls])
                                    except:
                                       cl.sendMessage(to, "Limited !")
                                       
             #           elif "Cleanse" in msg.text:
              #             if msg._from in Bots:
              #              if msg.toType == 2:
                             #  print "Otw cleanse"
            #                   _name = msg.text.replace("Cleanse","")
            #                   gs = ki.getGroup(msg.to)
             #                  gs = kk.getGroup(msg.to)
             #                  gs = kc.getGroup(msg.to)                  
             #                  ki.sendMessage(msg.to,"Maap maap")
            #                   targets = []
           #                    for g in gs.members:
           #                        if _name in g.displayName:
           #                            targets.append(g.mid)
            #                   if targets == []:
            #                      ki.sendMessage(msg.to,"Not found")
                              #    else:
            #                   for target in targets:
             #                        if target not in Bots:
             #                         try:
            #                              klist=[ki,kk,kc]
            #                              kicker=random.choice(klist)
           #                               kicker.kickoutFromGroup(msg.to,[target])
           #                               print (msg.to,[g.mid])
           #                           except:
           #                               ki.sendMessage(msg.to,"wkwkwkwkwk")
                        
                        elif cmd == "tabok":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in staff:targets.append(x)
                               if targets:
                                   imnoob = 'simple.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                        
                        elif text.startswith('/sepak '):
                            if msg._from in admin:
                                number = msg.text.replace("/sepak ","")
                                groups = cl.getGroupIdsJoined()
                                group = groups[int(number)-1]
                                x = cl.getGroup(group)
                                anu = x.id
                                if x.invitee == None:nama = []
                                else:nama = [contact.mid for contact in x.invitee]
                                targets = []
                                for a in nama:
                                    if a not in admin:
                                        targets.append(a)
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                cms = 'dual.js gid={} token={}'.format(anu,cl.authToken)
                                for a in nami:
                                    if a not in admin:
                                        targetk.append(a)
                                for y in targets:
                                    cms += ' uid={}'.format(y)
                                for y in targetk:
                                    cms += ' uik={}'.format(y)
                                cl.sendMessage(msg_id,to,'Lodding...')
                                print(cms)
                                success = execute_js(cms)
                                cl.sendMessage(msg_id,to,'Succes ..')

                        elif cmd == "dupak":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               if xyz.invitee == None:pends = []
                               else:pends = [c.mid for c in xyz.invitee]
                               targp = []
                               for x in pends:
                                   if x not in admin and x not in owner:targets.append(x)
                               mems = [c.mid for c in xyz.members]
                               targk = []
                               for x in mems:
                                  if x not in admin and x not in owner:targets.append(x)
                               imnoob = 'dual.js gid={} token={}'.format(to, cl.authToken)
                               for x in targp:imnoob += ' uid={}'.format(x)
                               for x in targk:imnoob += ' uik={}'.format(x)
                               execute_js(imnoob)
  
                        elif cmd.startswith('/js: '):
                         #if settings["kick"] == True:
                            if msg._from in admin:
                               text = text.split(" ")
                               number =msg.text.replace(text[0] + " ","")
                               if number.isdigit():
                                   groups = cl.getGroupIdsJoined()
                                   if int(number) < len(groups) and int(number) >= 0:
                                       groupid = groups[int(number)-1]
                                       try:
                                           #projoin.append(groupid)
                                           x = cl.getGroup(groupid)
                                           anu = x.id
                                           if x.invitee == None:nama = []
                                           else:nama = [contact.mid for contact in x.invitee]
                                           targets = []
                                           for a in nama:
                                               if a not in admin:
                                                   targets.append(a)
                                           nami = [contact.mid for contact in x.members]
                                           targetk = []
                                           cms = 'simple.js gid={} token={}'.format(anu,cl.authToken)
                                           for a in nami:
                                               if a not in admin:
                                                   targetk.append(a)
                                           for y in targets:
                                               cms += ' uid={}'.format(y)
                                           for y in targetk:
                                               cms += ' uik={}'.format(y)
                                           success = execute_js(cms)
                                           if success:
                                               cl.sendMessage(to,"Succes Js \n " + str(x.name))
                                           else:
                                               cl.sendMessage(to,"Limit Bose")
                                       except:pass
 
                        elif cmd.startswith('/bypass: '):
                         #if settings["kick"] == True:
                            if msg._from in admin:
                               text = text.split(" ")
                               number =msg.text.replace(text[0] + " ","")
                               if number.isdigit():
                                   groups = cl.getGroupIdsJoined()
                                   if int(number) < len(groups) and int(number) >= 0:
                                       groupid = groups[int(number)-1]
                                       try:
                                           #projoin.append(groupid)
                                           x = cl.getGroup(groupid)
                                           anu = x.id
                                           if x.invitee == None:nama = []
                                           else:nama = [contact.mid for contact in x.invitee]
                                           targets = []
                                           for a in nama:
                                               if a not in admin:
                                                   targets.append(a)
                                           nami = [contact.mid for contact in x.members]
                                           targetk = []
                                           cms = 'dual.js gid={} token={}'.format(anu,cl.authToken)
                                           for a in nami:
                                               if a not in admin:
                                                   targetk.append(a)
                                           for y in targets:
                                               cms += ' uid={}'.format(y)
                                           for y in targetk:
                                               cms += ' uik={}'.format(y)
                                           success = execute_js(cms)
                                           if success:
                                               cl.sendMessage(to,"Succes Baypass \n " + str(x.name))
                                           else:
                                               cl.sendMessage(to,"Limit Bose")
                                       except:pass
                               
                        elif ("Kick " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           cl.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

#===========ADMIN ADD============#
                        elif ("Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           cl.sendMessage(msg.to,"Berhasil menambahkan admin")
                                       except:
                                           pass

                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           cl.sendMessage(msg.to,"Berhasil menambahkan staff")
                                       except:
                                           pass

                        elif cmd.startswith("deladd "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    cl.deletecontact(ls)
                                cl.sendMessage(msg.to, "Success menghapus pertemanan")
                                
                        elif ("Add " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        try:
                                            cl.findAndAddContactsByMid(str(ls))
                                            cl.sendMessage(msg.to, "sucse add.. "+cl.getContact(str(ls)).displayName)
                                        except:
                                            pass

                        elif ("Botadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Bots.append(target)
                                           cl.sendMessage(msg.to,"Berhasil menambahkan bot")
                                       except:
                                           pass

                        elif ("Admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           admin.remove(target)
                                           cl.sendMessage(msg.to,"Berhasil menghapus admin")
                                       except:
                                           pass

                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           staff.remove(target)
                                           cl.sendMessage(msg.to,"Berhasil menghapus admin")
                                       except:
                                           pass

                        elif ("Botdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           Bots.remove(target)
                                           cl.sendMessage(msg.to,"Berhasil menghapus admin")
                                       except:
                                           pass

                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif cmd == "admin:repeat" or text.lower() == 'admin:repeat':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            if msg._from in admin:
                                wait["addstaff"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif cmd == "staff:repeat" or text.lower() == 'staff:repeat':
                            if msg._from in admin:
                                wait["dellstaff"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if msg._from in admin:
                                wait["addbots"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif cmd == "bot:repeat" or text.lower() == 'bot:repeat':
                            if msg._from in admin:
                                wait["dellbots"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif cmd == "refresh" or text.lower() == 'refresh':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                cl.sendMessage(msg.to,"Berhasil di Refresh...")

                        elif cmd == "contact admin" or text.lower() == 'contact admin':
                            if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact staff" or text.lower() == 'contact staff':
                            if msg._from in admin:
                                ma = ""
                                for i in staff:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact bot" or text.lower() == 'contact bot':
                            if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                cl.sendMessage(msg.to,"Notag diaktifkan")

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["MentionKick"] = False
                                cl.sendMessage(msg.to,"Notag dinonaktifkan")
                        
                        elif cmd == "invite sek" or text.lower() == 'invite on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = True
                                sendMention1(msg.to, sender, "", "\nSilahkan kirim kontaknya za.. ")

                        elif cmd == "invite wes" or text.lower() == 'invite off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = False
                                sendMention1(msg.to, sender, "", " \nInvite via contact dinonaktifkan")
                                
                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                cl.sendMessage(msg.to,"Deteksi contact diaktifkan")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                cl.sendMessage(msg.to,"Deteksi contact dinonaktifkan")

                        elif cmd == "unsend on" or text.lower() == 'unsend on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["unsendMessage"] = True
                                cl.sendMessage(msg.to,"Unsend pesan diaktifkan")
                        
                        elif cmd == "unsend off" or text.lower() == 'unsend off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["unsendMessage"] = False
                                cl.sendMessage(msg.to,"Deteksi unsend dinonaktifkan")

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                cl.sendMessage(msg.to,"Auto respon diaktifkan")
                                
                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                cl.sendMessage(msg.to,"Auto respon dinonaktifkan")
                        
                        elif cmd == "leavemc on" or text.lower() == 'leavemc on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["mcleave"] = True
                                cl.sendMessage(msg.to,"Leave mc aktif")

                        elif cmd == "leavemc off" or text.lower() == 'leavemc off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["mcleave"] = False
                                cl.sendMessage(msg.to,"Leave mc non aktif")
                                
                        elif cmd == "autoblock on" or text.lower() == 'autoblock on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                cl.sendMessage(msg.to,"「 Status AutoBlock 」\nAutoblock telah diaktifkan")

                        elif cmd == "autoblock off" or text.lower() == 'autoblock off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                cl.sendMessage(msg.to,"「 Status AutoBlock 」\nAutoblock telah dinonaktifkan")
  
                        elif cmd == "talkban on" or text.lower() == 'talkban on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["talkban"] = True
                                cl.sendMessage(msg.to,"Talk Ban diaktifkan")

                        elif cmd == "talkban off" or text.lower() == 'talkban off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["talkban"] = False
                                cl.sendMessage(msg.to,"Talk Ban dinonaktifkan")

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                cl.sendMessage(msg.to,"Autojoin diaktifkan")

                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                cl.sendMessage(msg.to,"Autojoin dinonaktifkan")

                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                cl.sendMessage(msg.to,"Autoleave diaktifkan")

                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                cl.sendMessage(msg.to,"Autoleave dinonaktifkan")
                        elif cmd == "leave on" or text.lower() == 'leave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["leave"] = True
                                cl.sendMessage(msg.to,"Autobaper diaktifkan")

                        elif cmd == "leave off" or text.lower() == 'leave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["leave"] = False
                                cl.sendMessage(msg.to,"Autobaper dinonaktifkan")
                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                cl.sendMessage(msg.to,"Auto add diaktifkan")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                cl.sendMessage(msg.to,"Auto add dinonaktifkan")

                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                cl.sendMessage(msg.to,"Deteksi sticker diaktifkan")

                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                cl.sendMessage(msg.to,"Deteksi sticker dinonaktifkan")
                                
                        elif cmd == "detect on" or text.lower() == 'detect on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectAll"] = True
                                cl.sendMessage(msg.to,"Chat berbau anu segera di Anukan")

                        elif cmd == "detect off" or text.lower() == 'detect off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectAll"] = False
                                cl.sendMessage(msg.to,"Filter chat jones dinonaktifkan")

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = True
                                cl.sendMessage(msg.to,"Join ticket diaktifkan")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = False
                                cl.sendMessage(msg.to,"Notag dinonaktifkan")

#===========COMMAND BLACKLIST============#
                        elif ("Talkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           cl.sendMessage(msg.to,"Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif ("Untalkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           cl.sendMessage(msg.to,"Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           cl.sendMessage(msg.to,"Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           cl.sendMessage(msg.to,"Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                cl.sendMessage(msg.to,"Please send to contact...")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                cl.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"✒ Rey Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                cl.sendMessage(msg.to,"Tidak ada Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"✒ Rey Talkban User\n\n"+ma+"\nTotal「%s」Talkban User" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == "blc" or text.lower() == 'bl':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    cl.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "clearban" or text.lower() == 'cban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = cl.getContacts(wait["blacklist"])
                              mc = "「%i」User Blacklist" % len(ragets)
                              cl.sendMessage(msg.to,"Sukses membersihkan " +mc)
#===========COMMAND SET============#
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  cl.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  cl.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)))
                       
                        elif 'Set leave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set leave: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti leave Msg")
                              else:
                                  wait["leave"] = spl
                                  cl.sendMessage(msg.to, "「Baper Msg」\nBaper Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  cl.sendMessage(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set spam: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set spam: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Spam")
                              else:
                                  Setmain["RAmessage1"] = spl
                                  cl.sendMessage(msg.to, "「Spam Msg」\nSpam Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  cl.sendMessage(msg.to, "「Sider Msg」\nSider Msg diganti jadi :\n\n「{}」".format(str(spl)))

                      #  elif cmd.startswith("!"):
                         # if wait["detectAll"] == True:
                               #txt = text.replace('!','')
                               #cl.kickoutFromGroup(msg.to,

                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg mu :\n\n「 " + str(wait["message"]) + " 」")

                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")
                        elif text.lower() == "cek leave":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Baper Msg」\nBaper Msg mu :\n\n「 " + str(wait["leave"]) + " 」")

                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")

                        elif text.lower() == "cek spam":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Spam Msg」\nSpam Msg mu :\n\n「 " + str(Setmain["RAmessage1"]) + " 」")

                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Sider Msg」\nSider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")

#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     cl.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group1 = ki.findGroupByTicket(ticket_id)
                                     ki.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                     ki.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group2 = kk.findGroupByTicket(ticket_id)
                                     kk.acceptGroupInvitationByTicket(group2.id,ticket_id)
                                     kk.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group3 = kc.findGroupByTicket(ticket_id)
                                     kc.acceptGroupInvitationByTicket(group3.id,ticket_id)
                                     kc.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     
                        
                                    
                      

    except Exception as error:
        print (error)


while True:
  try:
      Ops = cl.poll.fetchOperations(cl.revision, 50)
      for op in Ops:
        if op.type != 0:
          cl.revision = max(cl.revision, op.revision)
          bot(op)
  except Exception as E:
    E = str(E)
    if "reason=None" in E:
      print (E)
      time.sleep(60)
      restart_program()
