# -*- coding: utf-8 -*- 
from linepy import *
from threading import Thread
from akad.ttypes import *
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib3, urllib, urllib.parse
import urllib, urllib3
from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from humanfriendly import format_timespan, format_size, format_number, format_length
#from gtts_token.gtts_token import Token
from googletrans import Translator
from urllib.parse import urlencode
import requests.packages.urllib3.exceptions as urllib3_exceptions
from multiprocessing import Pool,Process
from random import randint
from shutil import copyfile
from thrift.protocol import TCompactProtocol,TMultiplexedProtocol,TProtocol
from thrift.transport import TTransport,TSocket,THttpClient,TTransport,TZlibTransport
from akad.ttypes import IdentityProvider, LoginResultType, LoginRequest, LoginType
from Naked.toolshed.shell import execute_js

#==================================================================#
#cl = LINE("lianadafazaki@gmail.com","Nela1234",appName="DESKTOPWIN\t7.16.1\tWindows\t10")

cl = LINE("lenapbm77@gmail.com","abeng13",appName="DESKTOPWIN\t7.16.1\tWindows\t10")

#==================================================================#
#zw = LINE("lenapbm77@gmail.com","abeng13",appName="DESKTOPWIN\t7.16.1\tWindows\t10")

zw = LINE("lianadafazaki@gmail.com","Nela1234",appName="DESKTOPWIN\t7.16.1\tWindows\t10")

#==================================================================#

print("========= [ ✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎 AJS ] =========")

poll = OEPoll(cl)
#call = Call(cl)
creator = ["u139a99ccb7916b95af2f27e80847fde2","u8ef4badd6c2bd9af1fab10adf9b95db2"]
owner = ["u139a99ccb7916b95af2f27e80847fde2","u8ef4badd6c2bd9af1fab10adf9b95db2"]
admin = ["u139a99ccb7916b95af2f27e80847fde2","u8ef4badd6c2bd9af1fab10adf9b95db2"]
staff = ["u139a99ccb7916b95af2f27e80847fde2","u8ef4badd6c2bd9af1fab10adf9b95db2"]
Leo = ["u139a99ccb7916b95af2f27e80847fde2","u8ef4badd6c2bd9af1fab10adf9b95db2"]
tumbal = ["u270f1ccb4365bfccddccd3ea6dc6e840","ub60d24e8d212840bb3b279db33264ea4","u5425db48e71b79d0ca94b4ed87833f24","u479b1417c849efa99c569fa8b3127de2","u8dc253a3d06c4d4f7d0a8cd75344301c","u59b624ffc181c342f60091d9ffef186d","u8774b4b385e41a64f272c67a5b6bf545","ud9ee89cdc7d92fc1f9ce3b20e4c6adcf","uacb26c019e023cc15553704f973998b2","u53dee2c3be7cc3ba035b92e0c9d9c5b8","u10a8b33b67f3d068e1b81efc59b9288a","u41ade075fd8930f6a5bed67a73d7f48a","u863f5cf42e48a88a2a223a02358ad7c0","u2382816ba0900518fbab6f1bd5094ab0","u2f8b16f0a58ede0bce9675cf341ac3b6","u0a7c185b63f26d79c97389d658072698","u0a7c185b63f26d79c97389d658072698","u6f9b233ca539172e2960170f763f5af7","u632b981b837a3198bed7f66a53ea2cad","uca729dad627e5f8fd7193168a6acc0c0","uf8abaaeb4c4f14f162cd2b9835379269","ub549e39b74314ba2769280aaf5083bca","u5995d61ec220c9dc14af21b16f73e2a4","u3155acd029c06508802e7dca00a7765e","u4a5bc8be10d0b131991c1394a8442e57","u68b5da91f28a211122541fee48d7c0a6","uc70b92cc558a0cb2f6165d92c2b3742b","ubc2e6d6d20941160edf77fa90c4301bb","u3faa60ef88209e786dee09ce766e9681","u28b5ff0f1cf5e157b01f1cafbf88edc9","u83d46b2eec1bfe5949e2342209d993c1","ue5b9240fa3a5290a3cdbca5221fbb009","u6a3b5395165687cf10d785cc308e2c0c","ucb1166b174e5cc7754264c627164ca4e","uc7afc7f269214e3eb8a44179c56dbfe8","u4d1cbd160fe69f2c1201132701c93ef9","u64817d87ab88edbabf015992b2c48e72","u13a4d93bc2a83597e040a1700df18f14","u759f6a4094387bb8f40abcfa084624e1","u58ae79ec523d0f8504932c463e16b8e8","u5c2239ddeeb3be4f15b1972ef00ce309","ub6fd80737e9387b121f837acfaffc38d","u88ed01e0e92f3505aef820d68a6b9587","u09984afbbcef86cd3bc04453031afded","ua471b2732ad1fd9f2de43ab9d3d3b780","ud0f194a6e36ab62989808bf8666624f5","u4023b1dc12d4e500d9455e82759fd8c7","u6625449d13c12bb90d5d114f894954d7","u6a603a4e7cc47ca35cfa304a50554938","ud5017b5b016d89657378df63b3a94e00","u7be6c5b1eb1ffc567f756ff6d198bbd0","u06f09cf10ffdf885bf578a595846f17f","uaae0e269316d1c7bb06404c9f61c9096","u63c40b29b9a062280ea5c82cfa529748","u5760c336ba360376e1420f2cc7c9645b","u2326021180603dd396f2ffe134f67999","u08dc1459b86b5d6529c2c72090f1a624","u51d2463721b863793aad13a703ec63cf","u4d9540898c730134f012832711115e19","u535c481fb98ee55402e7673e44282aea","uf69ddef50b4b23183b9598f1924c5f44","uf47d94234cedd7f71a9b223b4ebb331d","u4cab563c98978dd5c8bc5781fbb73bae"]

mid = cl.getProfile().mid
Zmid = zw.getProfile().mid
Saint = [cl]
Bots = [mid,Zmid]
Saints = owner + creator + admin + staff

settings = {
    "Picture":False, 
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "changeProfileVideo":False,
    "changeFoto":False,
    "autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}
msg_dict1 = {}
msg_dict = {}
wait = {
    "limit": 1, 
    "owner":{},
    "admin":{},
    "Bots":{},
    "bypass":False,
    "js":False,
    "gantibypass":"bypass",
    "gantinoox":"js",
    "tumbal":True,
    "detectAll":False,
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "invite":False,
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wl":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "contact":False,
    'autoJoin':True,
    'autoAdd':False,
    'autoBlock':False,
    'autoLeave':False,
    'autoLeft':False,
    "selfbot":True,
    "mention":"Tuh Yang Ngintip Colok Aja",
    "leave":"Selamat jalan kawan",
    "Respontag":"TAG2 VAKUM ORANGNYAn/n/📞 n/       Panggilan/chatn/               Di WA n/n/n/   ____________________n/            Bergabung",
    "welcome":"Selamat datang & semoga betah n bahagia",
    "comment":"Like by ✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎 𝒕𝒆???? ,Zanda Bot",
    "message":"Thanks for add me.\n☆ ✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎 𝒕𝒆𝒂𝒎\n 0pen Order zanda\n.http://line.me/ti/p/~pawang",
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
protectantijs= []
targets = []
warmode = []

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
with open('owner.json', 'r') as fp:
    owner = json.load(fp)

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)

def cloneProfile(mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        cl.updateProfilePicture(pict)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)

def backupProfile():
    profile = cl.getContact(clMID)
    if settingss['myProfile']['videoProfile'] == None:
        settingss['myProfile']['displayName'] = profile.displayName
        settingss['myProfile']['pictureStatus'] = profile.pictureStatus
        settingss['myProfile']['statusMessage'] = profile.statusMessage
        coverId = cl.getProfileDetail()['result']['objectId']
        settingss['myProfile']['coverId'] = str(coverId)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + profile.pictureStatus, saveAs="tmp/pict.bin")
        cl.updateProfilePicture(pict)
    else:
        settingss['myProfile']['displayName'] = profile.displayName
        settingss['myProfile']['pictureStatus'] = profile.pictureStatus
        settingss['myProfile']['statusMessage'] = profile.statusMessage
        settingss['myProfile']['videoProfile'] = profile.videoProfile
        coverId = indonesiandefacer.getProfileDetail()['result']['objectId']
        settingss['myProfile']['coverId'] = str(coverId)
        
def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def sendMention1(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "Total Mention User「{}」\n\n  [ Mention ]\n1. ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"] #+"\n\n✒Group name: "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#        contact = cl.getContact(op.param2).picturePath
#        cl.sendMessage(to, None, contentMetadata={"STKID":"68138712","STKPKGID":"4226946","STKVER":"1"}, contentType=7)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def restoreProfile():
    profile = cl.getProfile()
    profile.displayName = settingss['myProfile']['displayName']
    profile.statusMessage = settingss['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settingss['myProfile']['pictureStatus']
        cl.updateProfileAttribute(8, profile.pictureStatus)
        cl.updateProfile(profile)
    else:
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + settingss['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settingss['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settingss['myProfile']['coverId']
    cl.updateProfileCoverById(coverId)

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def help():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "🔰✯͜͡ 𝐉∆πD∆ BöT$ ͜͡ ✍🔰\n│Using key「 " + key + " \n" + \
                  "● " + key + "Me\n" + \
                  "● " + key + "Refresh\n" + \
                  "● " + key + "Mybot\n" + \
                  "● " + key + "Bot1 (klau ajs blum slng add)\n" + \
                  "● " + key + "Bot2 (klau ajs blum slng add)\n" + \
                  "● " + key + "Help js\n" + \
                  "● " + key + "Menu pro\n" + \
                  "● " + key + "Mid「@」\n" + \
                  "● " + key + ".bye lena (induk left)\n" + \
                  "● " + key + "lena stay\n" + \
                  "●" + key + "lena masuk\n" + \
                  "● " + key + "lena pulang\n" + \
                  "● " + key + "Autojoin on/off\n" + \
                  "● " + key + "Autoadd on/off\n" + \
                  "● " + key + "Autoblock on/off\n" + \
                  "● " + key + "Zkontak on/off (undng mmber)\n" + \
                  "● " + key + "Zinvite on/off (undng mmber)\n" + \
                  "● " + key + "Lena cipok @\n" + \
                  "● " + key + "Lena bantai @\n" + \
                  "● " + key + "Admin @\n" + \
                  "● " + key + "Admindel @\n" + \
                  "● " + key + "Staff @\n" + \
                  "● " + key + "Staffdel @\n" + \
                  "● " + key + "Botdel @\n" + \
                  "● " + key + "Bot @\n" + \
                  "● " + key + "Lena on/off (Buat Cctv)\n" + \
                  "● " + key + "Lbot\n" + \
                  "● " + key + "Ladmin\n" + \
                  "● " + key + "Glist\n" + \
                  "● " + key + "Gpending\n" + \
                  "● " + key + "Bl (cek blacklist)\n" + \
                  "● " + key + "Cban\n" + \
                  "● " + key + "Goceng\n" + \
                  "● " + key + "Sampah\n" + \
                  "● " + key + "Us 20 (Urngi chat)\n" + \
                  "● " + key + "Rlena @ (gnti nma orng)\n" + \
                  "● " + key + "Lena foto (gnti fto bot)\n" + \
                  "● " + key + "Lena ajs1 (gnti fto ajs)\n" + \
                  "● " + key + "Lena: (Nama Akun Utama)\n" + \
                  "● " + key + "Lena1: (Nama ajs)\n" + \
                 "𝗟𝗲𝗼_𝗕𝗼𝘁𝗦 𝒕𝒆𝒂𝒎 https://line.me/ti/p/~Pawang"
    return helpMessage

def helpbot():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage1 = "🔰✯͜͡ 𝐉∆πD∆ BöT$ ͜͡ ✍🔰\n│Using key「 " + key + " \n" + \
                  "● " + key + "∆ 𝗠𝗲𝗻𝘂 𝗽𝗿𝗼𝘁𝗲𝗰𝘁 ∆\n" + \
                  "● " + key + "Protectinvite on/off\n" + \
                  "● " + key + "Protectkick on/off\n" + \
                  "● " + key + "Protectcancel on/off\n" + \
                  "● " + key + "Protectjoin on/off\n" + \
                  "● " + key + "Semua pro on/off\n" + \
                  "𝗟𝗲𝗼_𝗕𝗼𝘁𝗦 𝒕𝒆𝒂𝒎 https://line.me/ti/p/~Pawang"
                  
    return helpMessage1

def bot(op):
    global time
    global ast
    global groupParam
 #   global multiprocessing
  #  global subprocess
 #   global threading
    try:
        if op.type == 0:
            return
        if op.type == 32 or op.type== 126:
           if op.param3 in tumbal:
           #if op.param1 in protectantijs:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                      #  if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                           # cl.inviteIntoGroup(op.param1,[tumbal])
                          #  cl.sendMessage(op.param1,"tumbal]")
                    except:
                            try:
                                zw.acceptGroupInvitation(op.param1)
                                zw.kickoutFromGroup(op.param1,[op.param2])
                                zw.leaveGroup(op.param1)
                                cl.findAndAddContactsByMid(op.param3)
                                cl.inviteIntoGroup(op.param1,[Zmid])
                                #cl.sendMessage(op.param1,"Close")
                            except:
                                pass

        if op.type == 11 or op.type== 122:
            if op.param1 in protectqr:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            #cl.reissueGroupTicket(op.param1)
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            cl.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                except:
                    pass
                    
        if op.type == 11 or op.type== 122:
            if op.param2 in wait["blacklist"]:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            #cl.reissueGroupTicket(op.param1)
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            cl.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                except:
                    pass
                        
        if op.type == 13 or op.type== 124:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)

        if op.type == 13 or op.type== 124:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
 #                       cl.sendMessage(op.param1,"Haii " +str(ginfo.name))
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
#                        cl.sendMessage(op.param1,"Haii " + str(ginfo.name))

        if op.type == 13 or op.type== 124:
            if op.param2 in Leo:
                cl.acceptGroupInvitation(op.param1)
            else:pass

        if op.type == 13 or op.type== 124:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        group = cl.getCompactGroup(op.param1)
                        gPendingMid = [contact.mid for contact in group.invitee]
                        for targets in gPendingMid:
                            if targets in op.param3:cl.cancelGroupInvitation(op.param1, [targets])
                            cl.kickoutFromGroup(op.param1, [op.param2])              
                    except:       
                       pass

        if op.type == 13 or op.type== 124:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        group = cl.getCompactGroup(op.param1)
                        gPendingMid = [contact.mid for contact in group.invitee]
                        for targets in gPendingMid:
                            if targets in op.param3:cl.cancelGroupInvitation(op.param1, [targets])
                            cl.kickoutFromGroup(op.param1, [op.param2])              
                    except:       
                       pass

#        if op.type == 13 or op.type== 124:
#            if op.param2 in wait["blacklist"]:
#                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
#                    wait["blacklist"][op.param2] = True
#                    try:
#                        group = cl.getCompactGroup(op.param1)
#                        gPendingMid = [contact.mid for contact in group.invitee]
#                        for targets in gPendingMid:
#                            if targets in op.param3:cl.cancelGroupInvitation(op.param1, [targets])
#                            cl.kickoutFromGroup(op.param1, [op.param2])              
#                    except:       
#                       pass

#        if op.type == 13 or op.type == 124:
#            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:pass
#            else:
#                leo1 = op.param3.replace('\x1e',',')
#                leo2 = leo1.split(',')
#                for i in leo2:
#                  if i in wait["blacklist"]:
#                    try:
#                        cl.cancelGroupInvitation(op.param1,[i])
#                    except:
#                        pass
#                    try:
#                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
#                            cl.kickoutFromGroup(op.param1,[op.param2])
#                            wait["blacklist"][op.param2] = True
#                    except:
#                        pass
#            if op.param2 not in wait["blacklist"]:pass
#            else:
#                leo1 = op.param3.replace('\x1e',',')
#                leo2 = leo1.split(',')
#                for i in leo2:
#                    wait["blacklist"][i] = True
#                    try:
#                        cl.cancelGroupInvitation(op.param1,[i])
#                    except:pass
#                    try:
#                        cl.kickoutFromGroup(op.param1,[op.param2])
#                    except:
#                        pass

        if op.type == 17 or op.type== 130:
            if op.param2 in wait["blacklist"]:
                cl.kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

#        if op.type == 22 or op.type== 124:
 #           if wait["mcleave"] == True:
                #cl.sendMessage(op.param1,"Duh malas mc2an")
#                cl.leaveRoom(op.param1)

        if op.type == 17 or op.type== 130:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
                            
                return

        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, wait["message"])

        if op.type == 5:
            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
            if wait["autoBlock"] == True:
                cl.sendMessage(op.param1,"Tapi Maaf Auto Block Saya Aktif........")
                cl.blockContact(op.param1)
                #cl.sendMessage(op.param1,"Tapi Maaf Auto Block Saya Aktif........")

        if op.type == 19 or op.type== 133:
            if op.param1 in protectkick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    cl.kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

        if op.type == 19 or op.type== 133:
            if op.param3 in creator:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for leo in ownX:
                        try:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.findAndAddContactsByMid(op.param3)
                            cl.inviteIntoGroup(op.param1 ,[leo])
                        except:
                            pass

        if op.type == 19 or op.type== 133:
            if op.param3 in admin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    own = op.param3.replace("",',')
                    ownX = own.split(",")
                    wait["blacklist"][op.param2] = True
                    for leo in ownX:
                        try:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.findAndAddContactsByMid(op.param3)
                            cl.inviteIntoGroup(op.param1 ,[leo])
                        except:
                            pass

        if op.type == 19 or op.type== 133:
            if op.param3 in staff:
             if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:                 
                try:
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    cl.findAndAddContactsByMid(op.param3)
                    cl.inviteIntoGroup(op.param1,[op.param3])
                except:
                    pass

                return
        if op.type == 32 or op.type== 126:
            if op.param3 in mid:
             if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                wait["blacklist"][op.param2] = True
                try:
                    zw.acceptGroupInvitation(op.param1)
                    zw.kickoutFromGroup(op.param1,[op.param2])
                    zw.findAndAddContactsByMid(op.param3)
                    zw.inviteIntoGroup(op.param1,[mid])
                    cl.acceptGroupInvitation(op.param1)
                    zw.leaveGroup(op.param1)
                    cl.findAndAddContactsByMid(op.param3)
                    cl.inviteIntoGroup(op.param1,[Zmid])
                except:
                    try:
                        zw.kickoutFromGroup(op.param1,[op.param2])
                        zw.findAndAddContactsByMid(op.param3)
                        zw.inviteIntoGroup(op.param1,[mid])
                        cl.acceptGroupInvitation(op.param1)
                        zw.leaveGroup(op.param1)
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[Zmid])
                    except:
                        pass

#        if op.type == 19 or op.type== 133:
#            if op.param3 in mid:
#            	if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
#                    wait["blacklist"][op.param2] = True
 #                   try:
#                        sw.acceptGroupInvitation(op.param1)   
#                        bll = str(sw.getContact(op.param1, op.param2))
#                        cms = 'simple.js gid={} token={} app={}'.format(to, sw.authToken,"DESTKTOPWIN\t7.9.1\tFareel_OS\t10")
#                        for yy in bll:
#                            wait["blacklist"][yy] = True
#                            cms += ' uid={}'.format(yy)
#                        success = execute_js(cms)
#                        sw.kickoutFromGroup(op.param1,[op.param2])
 #                       sw.inviteIntoGroup(op.param1,[mid])
#                        sw.leaveGroup(op.param1)
#                        cl.inviteIntoGroup(op.param1,[Zmid])
#                    except:pass

        if op.type == 19 or op.type== 133:
            if op.param3 in mid:
             if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                wait["blacklist"][op.param2] = True
                try:
                    zw.acceptGroupInvitation(op.param1)
                    zw.kickoutFromGroup(op.param1,[op.param2])
                    zw.findAndAddContactsByMid(op.param3)
                    zw.inviteIntoGroup(op.param1,[mid])
                    cl.acceptGroupInvitation(op.param1)
                    zw.leaveGroup(op.param1)
                    cl.findAndAddContactsByMid(op.param3)
                    cl.inviteIntoGroup(op.param1,[Zmid])
                except:
                    try:
                        zw.acceptGroupInvitation(op.param1)
                        x = zw.getGroup(op.param1)
                        x.preventedJoinByTicket = False
                        zw.updateGroup(x)
                        invsend = 0
                        Ti = zw.reissueGroupTicket(op.param1)
                        cl.acceptGroupInvitationByTicket(op.param1,Ti)
                        Ti = zw.reissueGroupTicket(op.param1)
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        G = zw.getGroup(op.param1)
                        G.preventedJoinByTicket = True
                        zw.updateGroup(G)
                        zw.leaveGroup(op.param1)
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[Zmid])
                       # cl.sendMessage(op.param1,"Close")
                    except:
                        pass

#-------------------------------------------------------------------------------     
        
        if op.type == 32 or op.type== 126:
           if op.param3 in Zmid:
           #if op.param1 in protectantijs:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                      #  if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.findAndAddContactsByMid(op.param3)
                            cl.inviteIntoGroup(op.param1,[Zmid])
                         #   cl.sendMessage(op.param1,"=AntiJS Invited=")
                    except:
                            pass

#-------------------------------------------------------------------------------     

        if op.type == 32 or op.type== 126:
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.findAndAddContactsByMid(op.param3)
                            cl.inviteIntoGroup(op.param1,[Zmid])
                    except:
                        pass
                            
                return

#-------------------------------------------------------------------------------


        if op.type == 55:
            try:
                if op.param1 in Setmain["RAreadPoint"]:
                   if op.param2 in Setmain["RAreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["RAreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

  #      if op.type == 65:
#            if wait["unsendMessage"] == True:
#                try:
 #                   at = op.param1
 #                   msg_id = op.param2
#                    if msg_id in msg_dict:
#                        if msg_dict[msg_id]["from"]:
#                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
#                                ginfo = cl.getGroup(at)
#                                Aditmadzs = cl.getContact(msg_dict[msg_id]["from"])
#                                zx = ""
#                                zxc = ""
#                                zx2 = []
#                                xpesan =  "「 Gambar Dihapus 」\n• Pengirim : "
#                                ret_ = "• Nama Grup : {}".format(str(ginfo.name))
#                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
#                                ry = str(Aditmadzs.displayName)
#                                pesan = ''
#                                pesan2 = pesan+"@x \n"
#                                xlen = str(len(zxc)+len(xpesan))
#                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
#                                zx = {'S':xlen, 'E':xlen2, 'M':Aditmadzs.mid}
#                                zx2.append(zx)
#                                zxc += pesan2
#                                text = xpesan + zxc + ret_ + ""
#                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
 #                               cl.sendImage(at, msg_dict[msg_id]["data"])
#                           else:
#                                ginfo = cl.getGroup(at)
#                                Aditmadzs = cl.getContact(msg_dict[msg_id]["from"])
 #                               ret_ =  "「 Pesan Dihapus 」\n"
 #                               ret_ += "• Pengirim : {}".format(str(Aditmadzs.displayName))
#                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
#                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
#                                ret_ += "\n• Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
#                                cl.sendMessage(at, str(ret_))
#                        del msg_dict[msg_id]
#                except Exception as e:
#                    print(e)

#        if op.type == 65:
#            if wait["unsendMessage"] == True:
#                try:
#                    at = op.param1
 #                   msg_id = op.param2
#                    if msg_id in msg_dict1:
#                        if msg_dict1[msg_id]["from"]:
#                                ginfo = cl.getGroup(at)
#                                Aditmadzs = cl.getContact(msg_dict1[msg_id]["from"])
#                                ret_ =  "「 Sticker Dihapus 」\n"
#                                ret_ += "• Pengirim : {}".format(str(Aditmadzs.displayName))
#                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
 #                               ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
#                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
#                                cl.sendMessage(at, str(ret_))
#                                cl.sendImage(at, msg_dict1[msg_id]["data"])
#                        del msg_dict1[msg_id]
#                except Exception as e:
#                    print(e)
        
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                cl.kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          cl.kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              cl.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              cl.kickoutFromGroup(msg.to, [msg._from])

        if op.type == 25 or op.type == 26:
            if op.type == 25: print ("[ 25 ] 𝐉∆πD∆ BöT$")
            else: print ("[ 26 ] 𝐉∆πD∆ BöT$")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
     #          if msg.contentType == 7:
       #          if wait["sticker"] == True:
     #               msg.contentType = 0
     #               cl.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])

               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"✒ Nama : " + msg.contentMetadata["displayName"] + "\n✒ MID : " + msg.contentMetadata["mid"] + "\n✒ Status Msg : " + contact.statusMessage + "\n✒ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)

               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = cl.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            cl.sendMessage(msg.to, "Di Bl boss\nClearban dulu Jepit lagi..")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  cl.findAndAddContactsByMid(target)
                                  cl.inviteIntoGroup(msg.to,[target])
                                  leo = cl.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  "ʙᴇʀʜᴀsɪʟ ᴊᴇᴘɪᴛ.. \nNama "
                                  ret_ = "Ketik Kontak off/Invite off jika sudah masuk"
                                  ry = str(leo.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':leo.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  cl.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                  cl.sendMessage(msg.to,"Done boss.....")
                                  wait["invite"] = False
                                  break
#ADD Bots

               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        cl.sendMessage(msg.to,"Contact itu sudah jadi anggota bot")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke anggota bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Berhasil menghapus dari anggota bot")
                    else:
                        wait["dellbots"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan anggota bot saints")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        cl.sendMessage(msg.to,"𝑆𝑢𝑑𝑎ℎ 𝐽𝑎𝑑𝑖 𝑆𝑡𝑎𝑓𝑓.")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke staff")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Berhasil menghapus dari staff")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        cl.sendMessage(msg.to,"Contact itu sudah jadi admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke admin")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Berhasil menghapus dari admin")
                    else:
                        wait["delladmin"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan admin")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke blacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Berhasil menghapus dari blacklist user")
                    else:
                        wait["dblacklist"] = True
                        cl.sendMessage(msg.to,"Contact itu tidak ada di blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        cl.sendMessage(msg.to,"Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Berhasil menghapus dari Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        cl.sendMessage(msg.to,"Contact itu tidak ada di Talkban")
#UPDATE FOTO
               if msg.contentType == 1:
                   if settings["changeProfileVideo"] == True:
                       cl.downloadObjectMsg(msg_id, saveAs="image.jpeg")
                       settings["changeProfileVideo"] = False
                       cl.sendMessage(msg.to, "Foto done, Send your video Boss..")
                   if settings["changeFoto"] == True:
                       path = cl.downloadObjectMsg(msg_id)
                       settings["changeFoto"] = False
                       cl.updateProfilePicture(path)
                       cl.sendMessage(msg.to, "Berhasil mengubah foto profile")
               if settings["changeProfileVideo"] == True:
                       cl.downloadObjectMsg(msg_id, saveAs="video.mp4")
                       settings["changeProfileVideo"] = False
                       pict = "image.jpeg"
                       vids = "video.mp4"
                      # cl.updateProfilePicture(pict, vids)
                       changeVideoAndPictureProfile(pict, vids)
                       #ChangeVideoProfile(pict, vids)
                       cl.sendMessage(msg.to, "Berhasil ppVideos...")

               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = cl.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            cl.sendMessage(msg.to, "Berhasil menambahkan gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["RAGroupPicture"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["RAGroupPicture"][mid]
                            cl.updateGroupPicture(path)
                            cl.sendMessage(msg.to,"Foto group berhasil dirubah")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["RAfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            cl.updateProfilePicture(path)
                            cl.sendMessage(msg.to,"Foto berhasil dirubah")

               if msg.contentType == 1:
                 if msg._from in admin:
                        if Zmid in Setmain["RAfoto"]:
                            path1 = zw.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Zmid]
                            zw.updateProfilePicture(path1)
                            zw.sendMessage(msg.to,"Foto berhasil dirubah")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["RAvideo"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["RAvideo"][mid]
                            cl.updateProfilePicture(path)
                            cl.sendMessage(msg.to,"Video berhasil dirubah")

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "komen":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                               cl.sendMessage(msg.to, str(helpMessage))

                        if cmd == "self1 on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                cl.sendMessage(msg.to, "Selfbot diaktifkan")
                                
                        elif cmd == "self1 off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                cl.sendMessage(msg.to, "Selfbot dinonaktifkan")
                                            
                        elif cmd == "menu pro":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage1 = helpbot()
                               cl.sendMessage(msg.to, str(helpMessage1))    

                        elif cmd == "helpjs1":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                cl.sendMessage(msg.to, "🔴 JS ✯͜͡ 𝗟𝗲𝗼_𝗕𝗼𝘁𝗦 𝒕𝒆𝒂𝒎 ♨\n====================\n\n✯͜͡ 𝗸𝙤𝙢𝙚𝗻 𝗯y𝙥𝗮𝘀𝘀\n🔜 Dupak\n🔜 /dupak\n🔜 Sepak\n🔜 /sepak\n🔜 Tabok\n🔜 /tabok\n🔜 /bypass (no group)\n\n✯͜͡ 𝗸𝙤𝙢𝙚𝗻 𝗷𝘀\n🔜 Bantai \n🔜 /bantai \n🔜 Selow \n🔜 /selow \n🔜 /js (no group) \n\n✯͜͡ 𝗸𝙤𝙢𝙚𝗻 Batalin\n🔜 Mbatal (Cncl Mmber)\n\n✯͜͡ 𝗟𝗲𝗼_𝗕𝗼𝘁𝗦 𝒕𝒆𝒂𝒎\n 💯 Gunakn dngan bijak\n💯 No Bacot 🙂🙂🙂")

                        elif cmd == "creator" or text.lower() == 'owner':
                            if msg._from in admin:
                                cl.sendMessage(msg.to,"Creator ✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎 Bot Plindung Zanda ")
                                ma = ""
                                for i in creator:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "me" or text.lower() == 'aku':
                          if wait["selfbot"] == True:
                            if msg._from in admin:                    
                 #               contact = cl.getContact(sender)                               
                 #               contentMetadata={'previewUrl': "http://dl.profile.line-cdn.net/"+contact.pictureStatus, 'i-installUrl': 'http://itunes.apple.com/app/linemusic/id966142320', 'type': 'mt', 'subText': contact.statusMessage, 'a-installUrl': 'market://details?id=jp.linecorp.linemusic.android', 'a-packageName': 'jp.linecorp.linemusic.android', 'countryCode': 'JP', 'a-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'i-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'text': contact.displayName, 'id': 'mt000000000d69e2db', 'linkUri': 'https://music.me.me/launch?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1','MSG_SENDER_ICON': "https://os.me.naver.jp/os/p/"+sender,'MSG_SENDER_NAME':  contact.displayName,}
                 #               cl.sendMessage(msg.to, contact.displayName, contentMetadata, 19)
                                cl.sendMessage(msg.to, "🔰✯͜͡ 𝐉∆πD∆ BöT$ ͜͡ ✍🔰")
                                cl.sendContact(to, mid)
                        
                        elif cmd == "asslamualaikum" or text.lower() == 'aslamualaikum':
                            cl.sendMessage(msg.to, "﷽𑜞᭄𝑾𝒂'𝒂𝒍𝒂𝒊𝒌𝒖𝒎𝒔𝒂𝒍𝒂𝒎,𝑾𝒓,𝑾𝒃")
                        elif cmd == "assalamualaikum wr.wb" or text.lower() == 'asalamualaikum wr.wb':
                            cl.sendMessage(msg.to, "﷽𑜞᭄𝑾𝒂'𝒂𝒍𝒂𝒊𝒌𝒖𝒎𝒔𝒂𝒍𝒂𝒎,𝑾𝒓,𝑾𝒃")
                        elif cmd == "assalamualaikum wr wb" or text.lower() == 'asalamualaikum wr wb':
                            cl.sendMessage(msg.to, "﷽𑜞᭄𝑾𝒂'𝒂𝒍𝒂𝒊𝒌𝒖𝒎𝒔𝒂𝒍𝒂𝒎,𝑾𝒓,𝑾𝒃")
                        elif cmd == "assalamualaikum" or text.lower() == 'asalamualaikum':
                            cl.sendMessage(msg.to, "﷽𑜞᭄𝑾𝒂'𝒂𝒍𝒂𝒊𝒌𝒖𝒎𝒔𝒂𝒍𝒂𝒎,𝑾𝒓,𝑾𝒃")
                        elif cmd == "assalamu'alaikum" or text.lower() == "assalamu'alaikum":
                            cl.sendMessage(msg.to, "﷽𑜞᭄𝑾𝒂'𝒂𝒍𝒂𝒊𝒌𝒖𝒎𝒔𝒂𝒍𝒂𝒎,𝑾𝒓,𝑾𝒃")
                        elif cmd == "assalamualaikm" or text.lower() == 'assalamualaikm':
                            cl.sendMessage(msg.to, "﷽𑜞᭄𝑾𝒂'𝒂𝒍𝒂𝒊𝒌𝒖𝒎𝒔𝒂𝒍𝒂𝒎,𝑾𝒓,𝑾𝒃")
                        elif cmd == "asslamualaikum" or text.lower() == 'asslamualaikum':
                            cl.sendMessage(msg.to, "﷽𑜞᭄𝑾𝒂'𝒂𝒍𝒂𝒊𝒌𝒖𝒎𝒔𝒂𝒍𝒂𝒎,𝑾𝒓,𝑾𝒃")
                        elif cmd == "sayang" or text.lower() == 'sayang':
                            cl.sendMessage(msg.to, "Hadir syang bawell dih 😘😘😘")
                        elif cmd == "syang" or text.lower() == 'syang':
                            cl.sendMessage(msg.to, "Hadir syang bawell dih 😘😘😘")
                        elif cmd == "ayang" or text.lower() == 'ayang':
                            cl.sendMessage(msg.to, "Hadir syang bawell dih 😘😘😘")
                        elif cmd == "syg" or text.lower() == 'syg':
                            cl.sendMessage(msg.to, "Hadir syang bawell dih 😘😘😘")
                        elif cmd == "ayank" or text.lower() == 'ayank':
                            cl.sendMessage(msg.to, "Hadir syang bawell dih 😘😘😘")
                        elif cmd == "sayangku" or text.lower() == 'sayangkuh':
                            cl.sendMessage(msg.to, "Hadir syang bawell dih 😘😘😘")
                        elif cmd == "beb" or text.lower() == 'beby':
                            cl.sendMessage(msg.to, "Hadir syang bawell dih 😘😘😘")
                        elif cmd == "bebz" or text.lower() == 'bebz':
                            cl.sendMessage(msg.to, "Hadir syang bawell dih 😘😘??")
                        elif cmd == "leo" or text.lower() == 'syanggggg':
                            cl.sendMessage(msg.to, "Hadir sayang ku,bawell ku cium nich 😘😘😘")
                        elif msg.text in ["Salam"]:
                              cl.sendMessage(msg.to,"السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ")
                        elif msg.text in ["Jawab"]:
                              cl.sendMessage(msg.to,"وَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِوَبَرَكَاتُهُ")
                        elif msg.text in ["Login"]:
                              cl.sendMessage(msg.to,"LOGIN:\nTANGALL:10_07_2018")
         #               elif msg.text in ["Leo"]:
          #                    cl.sendMessage(msg.to,"Yapz Hadir Sory Boss Lgi Sbuk")
         #                     cl.sendContact(to, mid)
                        elif msg.text in ["Dana"]:
                              cl.sendMessage(msg.to,"NO DANA: 085926054142\nNAMA: Sugianto Leowindra\nNO WA: 085926054142\nID LINE: pawang\n Creator : Leo_Bots")
                        elif msg.text in ["Respon","Absen"]:
                              cl.sendMessage(msg.to,"Aku Bukan Asistmu")
                        elif msg.text in ["Responsename"]:
                              cl.sendMessage(msg.to,"Aku Bukan Asistmu")
                        elif msg.text in ["Speeed"]:
                              cl.sendMessage(msg.to,"Sabar Sayang.....")
                              cl.sendMessage(msg.to,"00000,00001279976007Second")

                        elif text.lower() == "mid":
                               cl.sendMessage(msg.to, msg._from)

                        elif ("Mid " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif cmd == "mybot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               #cl.sendContact(to, mid)
                               cl.sendContact(to, mid)
                               cl.sendContact(to, Zmid)
                        #       cl.sendContact(to, Xmid)
                          #     cl.sendContact(to, Tmid)

                        elif text.lower() == "rechat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                                   cl.sendMessage(msg.to,"Chat dibersihkan...")
                               except:
                                   pass
                            if msg._from in admin:
                               try:
                                   zw.removeAllMessages(op.param2)         
                                   zw.sendMessage(msg.to,"Chat dibersihkan...")
                               except:
                                   pass

                        elif cmd.startswith('naik '):
                              if msg.toType == 2:
                               if msg._from in admin:
                                  sep = text.split(" ")
                                  strnum = text.replace(sep[0] + " ","")
                                  num = int(strnum)
                                  cl.sendMessage(msg.to, "Berhasil mengundang kedalam panggilan group")
                              for var in range(0,num):
                                  group = cl.getGroup(to)
                                  members = [mem.mid for mem in group.members]
                                  #cl.acquireGroupCallRoute(to)
                                  cl.inviteIntoGroupCall(to, contactIds=members)

                        elif cmd == "res":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               am = "ʀᴇʙᴏᴏᴛɪɴɢs sᴇʟғʙᴏᴛ"
                               cl.sendMessage(to,"{}".format(str(am)))
                               restartBot()

                        elif cmd == "cek":
                            try:
                                cl.kickoutFromGroup(to,["u6e4534dd63e82642f29205d2c993c642"]);has ="Fresh Boss"
                            except:has ="Limit Boss"
                            try:
                                cl.inviteIntoGroup(to,["u6e4534dd63e82642f29205d2c993c642"]);has1 ="Fresh Boss"
                            except:has1 ="Limit Boss"
                            try:
                                cl.cancelGroupInvitation(to,["u6e4534dd63e82642f29205d2c993c642"]);has2 ="Fresh Boss"
                            except:has2 ="Limit Boss"
                            cl.sendMessage(to,"⌈ Status Self ⌋\n\n🛑 Kick:  "+has+"\n🛑 Invite:  "+has1+"\n🛑 Cancel:  "+has2)
#                        elif cmd == "cekbot":
#                            try:
#                                cl.kickoutFromGroup(to,["u6e4534dd63e82642f29205d2c993c642"]);has ="Fresh Boss"
#                            except:has ="Limit Boss"
#                            try:
#                                cl.inviteIntoGroup(to,["u6e4534dd63e82642f29205d2c993c642"]);has1 ="Fresh Boss"
#                            except:has1 ="Limit Boss"
#                            try:
#                                cl.cancelGroupInvitation(to,["u6e4534dd63e82642f29205d2c993c642"]);has2 ="Fresh Boss"
#                            except:has2 ="Limit Boss"
#                            cl.sendMessage(to,"⌈ Status Self ⌋\n\n🛑 Kick:  "+has+"\n🛑 Invite:  "+has1+"\n🛑 Cancel:  "+has2)
#                            try:
#                                sw.kickoutFromGroup(to,["u6e4534dd63e82642f29205d2c993c642"]);has ="Fresh Boss"
#                            except:has ="Limit Boss"
#                            try:
#                                sw.inviteIntoGroup(to,["u6e4534dd63e82642f29205d2c993c642"]);has1 ="Fresh Boss"
#                            except:has1 ="Limit Boss"
#                            try:
#                                sw.cancelGroupInvitation(to,["u6e4534dd63e82642f29205d2c993c642"]);has2 ="Fresh Boss"
#                            except:has2 ="Limit Boss"
#                            sw.sendMessage(to,"⌈ Status Self ⌋\n\n🛑 Kick:  "+has+"\n🛑 Invite:  "+has1+"\n🛑 Cancel:  "+has2)

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                cl.sendMessage(msg.to, "✒ Leo_Bots Grup Info\n\n✒ Nama Group : {}".format(G.name)+ "\n✒ ID Group : {}".format(G.id)+ "\n✒ Pembuat : {}".format(G.creator.displayName)+ "\n✒ Waktu Dibuat : {}".format(str(timeCreated))+ "\n✒ Jumlah Member : {}".format(str(len(G.members)))+ "\n✒ Jumlah Pending : {}".format(gPending)+ "\n✒ Group Qr : {}".format(gQr)+ "\n✒ Group Ticket : {}".format(gTicket))
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                cl.sendMessage(msg.to, str(e))

                        elif cmd == "glist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "gpending":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsInvited()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ GROUP PENDINGABLIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」PENDINGAN Groups ]")

                        elif cmd == "url grup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = cl.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      cl.updateGroup(x)
                                   gurl = cl.reissueGroupTicket(msg.to)
                                   cl.sendMessage(msg.to, "Nama : "+str(x.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)

                        elif cmd == "allreject":
                            if msg._from in admin:
                                ginvited = cl.getGroupIdsInvited()
                                if ginvited != [] and ginvited != None:
                                   for gid in ginvited:
                                       cl.rejectGroupInvitation(gid)
                                       time.sleep(0.5)
                                   cl.sendMessage(msg.to, "Succes reject {} ".format(str(len(ginvited))))
                                else:
                                    cl.sendMessage(msg.to, "Success reject all invite")
#===========BOT UPDATE============#
                        elif cmd == "lena foto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                cl.sendMessage(msg.to,"Kirim Foto Lo.....")

                        elif cmd == "lena ajs1":
                            if msg._from in admin:
                                Setmain["RAfoto"][Zmid] = True
                                zw.sendMessage(msg.to,"Kirim Foto Lo.....")

                        elif cmd.startswith("lena: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith("lena1: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = zw.getProfile()
                                profile.displayName = string
                                zw.updateProfile(profile)
                                zw.sendMessage(msg.to,"Nama diganti jadi " + string + "")

#===========BOT UPDATE============#
                        elif cmd == "tagall" or text.lower() == 'mention':
                           if wait["selfbot"] == True:
                            if msg._from in admin:
                             group = cl.getGroup(msg.to)
                            nama = [contact.mid for contact in group.members]
                            k = len(nama)//20
                            for a in range(k+1):
                                txt = u''
                                s=0
                                b=[]
                                for i in group.members[a*20 : (a+1)*20]:
                                    b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                    s += 7
                                    txt += u'@Zero \n'
                                cl.sendMessage(msg.to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)

                        elif cmd == "lbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"✒ 𝗟𝗲𝗼_𝗕𝗼𝘁𝗦 𝒕𝒆𝒂𝒎\n\n"+ma+"\nTotal「%s」Bots" %(str(len(Bots))))

                        elif cmd == "ladmin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"🔰✯͜͡ 𝐉∆πD∆ BöT$ ͜͡ ✍🔰 \n\n🛑 Owner:\n"+ma+"\n🛑 Admin:\n"+mb+"\n🛑 Staff:\n"+mc+"\nTotal「%s」𝗟𝗲𝗼_𝗕𝗼𝘁𝗦 𝘁eam" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "bot1":
                            if msg._from in admin:
                        	#if wait["selfbot"] == True:                    
                                  try:
                                      cl.findAndAddContactsByMid(Zmid)                                                                                                                      
                                      cl.sendMessage(msg.to,"added from friendlist.")
                                  except:
                                      pass

                        elif cmd == "bot2":
                            if msg._from in admin:
                        	#if wait["selfbot"] == True:                    
                                  try:
                                      zw.findAndAddContactsByMid(mid)                                                                                                                      
                                      zw.sendMessage(msg.to,"added from friendlist.")
                                  except:
                                      pass

                        elif cmd == "lena stay":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Zmid])
                                #    cl.sendMessage(msg.to,"Grup 「"+str(ginfo.name)+"」 Aman Dari Js")
                                except:
                                    pass

                        elif cmd == "lena masuk":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Zmid])
                                    zw.acceptGroupInvitation(msg.to)
                                except:
                                    pass

                        elif cmd == ".bye lena":
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                cl.leaveGroup(msg.to)

                        elif cmd == "lena pulang":
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                zw.leaveGroup(msg.to)

                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               start = time.time()
                               cl.sendMessage(msg.to, "Progres speed...")
                               elapsed_time = time.time() - start
                               cl.sendMessage(msg.to, "{} detik".format(str(elapsed_time)))

                        elif cmd == "lena on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cl.sendMessage(msg.to, "Cek sider diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "lena off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  cl.sendMessage(msg.to, "Cek sider dinonaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                              else:
                                  cl.sendMessage(msg.to, "Sudak tidak aktif")	

#===========Hiburan============#

                        elif cmd.startswith("invto "):
                          if msg._from in admin:
                            if msg.toType == 2:
                                separate = text.split(" ")
                                number = text.replace(separate[0] + " ","")
                                group = cl.getGroupIdsJoined()
                                try:
                                    target = group[int(number)-1]
                                    G = cl.getGroup(target)
                                    #for x in SupOwn:
                                    cl.findAndAddContactsByMid(sender)
                                    cl.inviteIntoGroup(target,[sender])
                                    #cl.sendMessage(msg.to, str(ret_))
                                except:
                                    cl.sendMessage(msg.to, "berhasil invite")

#===========Protect Group============#

                        elif 'Protectkick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectkick ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "Protect kick sudah aktif"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect kick diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect kick dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect kick sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectjoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectjoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "Protect join sudah aktif"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect join diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect join dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect join sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protectcancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectcancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "Protect cancel sudah aktif"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect cancel diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect cancel dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect cancel sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    
                        elif 'Protectinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectinvite ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "Protect invite sudah aktif"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect invite diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect invite dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect invite sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)                                    

                        elif 'Semua pro ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Semua pro ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectinvite:
                                      msgs = ""
                                  else:
                                      protectinvite.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Semua protect sudah on\nDi Group : " +str(ginfo.name)
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Berhasil mengaktifkan semua protect\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Berhasil menonaktifkan semua protect\nDi Group : " +str(ginfo.name)
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Semua protect sudah off\nDi Group : " +str(ginfo.name)
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

#===========Auto Js/Bypads============#

                        elif cmd == "/sepak":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                        elif cmd == "sepak":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, zl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                        elif cmd == "/tabok":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                        elif cmd == "tabok":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                        elif cmd == "dupak":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                        elif cmd == "/dupak":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)

                        elif cmd == "bantai":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'simple.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'celjs.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                        elif cmd == "/bantai":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'simple.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'simple.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                        elif cmd == "/selow":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'simple.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'simple.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                        elif cmd == "selow":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'simple.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)
                            if msg._from in admin:
                               xyz = zw.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'simple.js gid={} token={}'.format(to, zw.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)

#===============================================#

                        elif cmd == "Mbatal":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               xyz = cl.getGroup(to)
                               mem = [c.mid for c in xyz.members]
                               targets = []
                               for x in mem:
                                   if x not in admin and x not in owner:targets.append(x)
                               if targets:
                                   imnoob = 'cancel.js gid={} token={}'.format(to, cl.authToken)
                                   for target in targets:
                                       imnoob += ' uid={}'.format(target)
                                   success = execute_js(imnoob)

                        elif ("Lena cipok " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in admin:
                                       try:
                                           cl.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Lena bantai " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in admin:
                                       try:
                                           cl.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif cmd.startswith("us "):
                          if msg._from in owner or msg._from in admin or msg._from in staff or msg._from in mid:
                            args = cmd.replace("us ","")
                            mes = 0
                            try:
                                mes = int(args[1])
                            except:
                                mes = 1
                            M = cl.getRecentMessagesV2(to, 1001)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == cl.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                cl.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                            #cl.sendMessage(msg.to, "Success unsend {} message".format(len(MId)))
                            cl.unsendMessage(msg.id) 

                        elif cmd.startswith("block "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.blockContact(ls)
                                cl.sendReplyMessage(msg.id, to,"Succes block {}".format(str(contact.displayName)))

                        elif ("Rlena " in msg.text):
                            if msg._from in admin:
                                try:
                                    sep = text.split(" ")
                                    if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                        names = re.findall(r'@(\w+)', text)
                                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                        mentionees = mention['MENTIONEES']
                                        lists = []
                                        for mention in mentionees:
                                            if mention["M"] not in lists:
                                                lists.append(mention["M"])
                                        for ls in lists:
                                            cl.findAndAddContactsByMid(ls)
                                            cl.renameContact(ls,sep[1])
                                        cl.sendReplyMessage(msg.id, to, "Succesfully rname to: {}".format(sep[1]))
                                except Exception as error:sendReplyMessage(to, f"> Error : {error}")

                        elif cmd.startswith("token: "):
                            if msg._from in admin:
                               Saya ={"FRIEND":""}
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "Gagal masukan mid")
                               else:
                                   Saya["FRIEND"] = str(key)
                                   cl.sendContact(to,Saya["FRIEND"])

                        elif cmd.startswith("mid "):
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                ret_ = "「 Mid User 」"
                                for ls in lists:
                                    ret_ += "\n{}".format(str(ls))
                                cl.sendMessage(to,"{}".format(str(ret_)))

#===========ADMIN ADD============#
                        elif ("Admin " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           cl.sendMessage(msg.to, "Berhasil menambahkan admin")
                                       except:
                                           pass

                        elif ("Staff " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           cl.sendMessage(msg.to, "Berhasil menambahkan staff")
                                       except:
                                           pass

                        elif cmd.startswith("deladd "):
                          if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    cl.deletecontact(ls)
                                cl.sendMessage(msg.to, "Success menghapus pertemanan")
                                
                        elif ("Add " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        try:
                                            cl.findAndAddContactsByMid(str(ls))
                                            cl.sendMessage(msg.to, "sucse add.. "+cl.getContact(str(ls)).displayName)
                                        except:
                                            pass

                        elif ("Botadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Bots.append(target)
                                           cl.sendMessage(msg.to, "Berhasil menambahkan bot")
                                       except:
                                           pass

                        elif ("Admindel " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           admin.remove(target)
                                           cl.sendMessage(msg.to, "Berhasil menghapus admin")
                                       except:
                                           pass

                        elif ("Staffdel " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           staff.remove(target)
                                           cl.sendMessage(msg.to, "Berhasil menghapus admin")
                                       except:
                                           pass

                        elif ("Botdel " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           Bots.remove(target)
                                           cl.sendMessage(msg.to, "Berhasil menghapus admin")
                                       except:
                                           pass

                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif cmd == "admin:off" or text.lower() == 'admin:off':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            if msg._from in admin:
                                wait["addstaff"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif cmd == "staff:off" or text.lower() == 'staff:off':
                            if msg._from in admin:
                                wait["dellstaff"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if msg._from in admin:
                                wait["addbots"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif cmd == "bot:off" or text.lower() == 'bot:off':
                            if msg._from in admin:
                                wait["dellbots"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif cmd == "refresh" or text.lower() == 'refresh':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                cl.sendMessage(msg.to, "Berhasil di Refresh...")

                        elif cmd == "kontak admin" or text.lower() == 'kontak admin':
                            if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "kontak staff" or text.lower() == 'kontak staff':
                            if msg._from in admin:
                                ma = ""
                                for i in staff:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "kontak bot" or text.lower() == 'kontak bot':
                            if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#

                        elif cmd == "zkontak on" or text.lower() == 'zinvite on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = True
                                sendMention1(msg.to, sender, "", "\nSilahkan kirim kontaknya za.. ")

                        elif cmd == "zkontak off" or text.lower() == 'zinvite off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = False
                                sendMention1(msg.to, sender, "", " \nInvite via contact dinonaktifkan")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                cl.sendMessage(msg.to, "Deteksi contact diaktifkan")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                cl.sendMessage(msg.to, "Deteksi contact dinonaktifkan")

                        elif cmd == "autoblock on" or text.lower() == 'autoblock on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                cl.sendMessage(msg.to, "「 Status AutoBlock 」\nAutoblock telah diaktifkan")

                        elif cmd == "autoblock off" or text.lower() == 'autoblock off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                cl.sendMessage(msg.to, "「 Status AutoBlock 」\nAutoblock telah dinonaktifkan")
  
                        elif cmd == "talkban on" or text.lower() == 'talkban on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["talkban"] = True
                                cl.sendMessage(msg.to, "Talk Ban diaktifkan")

                        elif cmd == "talkban off" or text.lower() == 'talkban off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["talkban"] = False
                                cl.sendMessage(msg.to, "Talk Ban dinonaktifkan")

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                cl.sendMessage(msg.to, "Autojoin diaktifkan")

                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                cl.sendMessage(msg.to, "Autojoin dinonaktifkan")

                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                cl.sendMessage(msg.to, "Autoleave diaktifkan")

                        elif cmd == "autoleave1 off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                cl.sendMessage(msg.to, "Autoleave dinonaktifkan")

                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                cl.sendMessage(msg.to, "Auto add diaktifkan")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                cl.sendMessage(msg.to, "Auto add dinonaktifkan")

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = True
                                cl.sendMessage(msg.to, "Join ticket diaktifkan")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = False
                                cl.sendMessage(msg.to, "Notag dinonaktifkan")

#===========COMMAND BLACKLIST============#
                        elif ("Talkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           cl.sendMessage(msg.to, "Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif ("Untalkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           cl.sendMessage(msg.to, "Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           cl.sendMessage(msg.to, "Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           cl.sendMessage(msg.to, "Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif cmd == "unban1:on" or text.lower() == 'unban1:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                cl.sendMessage(msg.to, "Please send to contact...")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                cl.sendMessage(msg.to, "Tidak ada blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to, "✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎 Blacklist\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                cl.sendMessage(msg.to, "Tidak ada Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to, "✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎 Talkban User\n\n"+ma+"\nTotal「%s」Talkban User" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == "bl" or text.lower() == 'bl':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    cl.sendMessage(msg.to, "Tidak ada blacklist")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "bl1" or text.lower() == 'bl1':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    cl.sendMessage(msg.to, "Tidak ada blacklist")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                cl.sendMessage(msg.to, "Tidak ada blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to, "✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎 Blacklist\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))

                        elif cmd == "goceng" or text.lower() == 'goceng':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = cl.getContacts(wait["blacklist"])
                              mc = "「%i」User Blacklist" % len(ragets)
                              cl.sendMessage(msg.to, "✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎\n\n✒Sukses Buang Blaclist " +mc)

                        elif cmd == "cban" or text.lower() == 'cban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = cl.getContacts(wait["blacklist"])
                              mc = "「%i」User Blacklist" % len(ragets)
                              cl.sendMessage(msg.to, "✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎\n\n✒Sukses Buang Blaclist " +mc)

                        elif cmd == "sampah" or text.lower() == 'sampah':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = cl.getContacts(wait["blacklist"])
                              mc = "「%i」User Blacklist" % len(ragets)
                              cl.sendMessage(msg.to, "✯͜͡Ĺɛö ͜͡ ✍ 𝒕𝒆𝒂𝒎\n\n✒Sukses Buang Blaclist " +mc)

#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     cl.sendMessage(msg.to, "Masuk : %s" % str(group.name))


                                    
                      

    except Exception as error:
        print (error)

while True:
  try:
      Ops = cl.poll.fetchOperations(cl.revision, 50)
      for op in Ops:
        if op.type != 0:
          cl.revision = max(cl.revision, op.revision)
          bot(op)
  except Exception as E:
    E = str(E)
    if "reason=None" in E:
      print (E)
      time.sleep(60)
      restart_program()


