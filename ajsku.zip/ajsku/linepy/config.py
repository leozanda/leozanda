# -*- coding: utf-8 -*-
from akad.ttypes import ApplicationType
import re

class Config(object):
    LINE_HOST_DOMAIN            = "https://gw.line.naver.jp"#"https://legy-jp.line.naver.jp"#'https://gd2.line.naver.jp'
    LINE_OBS_DOMAIN             = 'https://obs-sg.line-apps.com'
    LINE_TIMELINE_API           = 'https://gw.line.naver.jp/mh/api'
    LINE_TIMELINE_MH            = 'https://gw.line.naver.jp/mh'
    LINE_OBJECT_URL             = 'https://obs.line-scdn.net/'
    LINE_LOGIN_QUERY_PATH       = '/api/v4p/rs'
    LINE_AUTH_QUERY_PATH        = '/api/v4/TalkService.do'

    LINE_API_QUERY_PATH_FIR     = '/S4'
    LINE_POLL_QUERY_PATH_FIR    = '/P4'
    LINE_CALL_QUERY_PATH        = '/V4'
    LINE_CERTIFICATE_PATH       = '/Q'
    LINE_CHAN_QUERY_PATH        = '/CH4'
    LINE_SQUARE_QUERY_PATH      = '/SQS1'
    LINE_SHOP_QUERY_PATH        = '/SHOP4'
    LINE_LIFF_QUERY_PATH        = '/LIFF1'

    CHANNEL_ID = {
        'LINE_TIMELINE': '1341209850',
        'LINE_WEBTOON': '1401600689',
        'LINE_TODAY': '1518712866',
        'LINE_STORE': '1376922440',
        'LINE_MUSIC': '1381425814',
        'LINE_SERVICES': '1459630796'
    }
    APP_TYPE    = ApplicationType._VALUES_TO_NAMES[96]
    APP_VER     = "7.16.1"
    CARRIER     = '51089,1-0'
    SYSTEM_NAME = 'Leo_bots'
    SYSTEM_VER  = '10'
    IP_ADDR     = '8.8.8.8'
    EMAIL_REGEX = re.compile(r"[^@]+@[^@]+\.[^@]+")
    URL_REGEX   = re.compile(r'^(?:http|ftp)s?://' r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|' r'localhost|' r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})' r'(?::\d+)?' r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    MID_REGEX   = re.compile(r'u\w{32}')
    GID_REGEX   = re.compile(r'c\w{32}')
    RID_REGEX   = re.compile(r'r\w{32}')
    ALLIDS_REGEX= re.compile(r'(?:u\w{32}|c\w{32}|r\w{32})')

    def __init__(self):
        self.APP_NAME = '%s\t%s\t%s\t%s' % (self.APP_TYPE, self.APP_VER, self.SYSTEM_NAME, self.SYSTEM_VER)
        self.USER_AGENT = 'Line/%s' % self.APP_VER
    

    def getheader(self):
      if self.numb == 1:
        UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
        LA = "CHROMEOS 1.4.1 1"
      elif self.numb == 2:
        UA = "Line/8.14.2"
        LA = "IOSIPAD\t8.14.2\tIphone OS\t8.1.0"
      elif self.numb == 3:
        #UA = "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)"
        #LA = "DESKTOPMAC 10.9.4-MAVERICKS-x64 MAC 5.1.2"
        UA = "DESKTOP:MAC:10.12.6-MAVERICKS-x64(5.3.0)"
        LA = "DESKTOPMAC 10.12.6-MAVERICKS-x64 5.3.0 MAC"

      elif self.numb == 4:
        UA = "ANDROID  7.14.0  Android OS  7.0"
        LA = "Line/7.14.0"
      elif self.numb == 5:
        LA="TIZEN 1.4.3 Line 6.8.2" #TIZEN 1.0.3 Line 6.8.2 | TIZEN 2.3 Tizen_OS 1.0.3
        UA="Mozilla/5.0 (Linux; Tizen 2.3; SAMSUNG SM-Z130H) AppleWebKit/537.3 (KHTML, like Gecko) Version/2.3 Mobile Safari/537.3"
      elif self.numb == 6:
        LA='ANDROID 7.5.0 Android OS 6.0'
        UA = "Line/7.5.0 (Linux; U; Android 4.4.4; en-US; 2014817 Build/KTU84P)"
      elif self.numb == 7:
        UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/58.0.3029.110 Safari/537.36"
        LA = "FIREFOXOS 1.4.11 Firefox_OS 1"
      elif self.numb == 8:
        UA = "Line/2017.0731.2132.CFNetwork/758.1.6 Darwin/15.0.0"
        LA = "WIN10 7.5.0 iPhone OS 1"
      elif self.numb == 9:
        UA = "Line/2017.0731.2132.CFNetwork/758.1.6 Darwin/15.0.0"
        LA = "WEB 7.5.0 iPhone OS 1"
      elif self.numb == 10:
      #need repin to keep logged in
        UA = "Line/2017.0731.2132.CFNetwork/758.1.6 Darwin/15.0.0"
        LA = "BIZWEB 7.5.0 iPhone OS 1"
      elif self.numb == 11:
        UA = "Line/2017.0731.2132.CFNetwork/758.1.6 Darwin/15.0.0"
        LA = "WIN10 7.5.0 iPhone OS 1"
      elif self.numb == 12:
        UA = "Line/2017.0731.2132.CFNetwork/758.1.6 Darwin/15.0.0"
        LA = "WIN10_RC 7.5.0 iPhone OS 1"
      elif self.numb == 13:
        UA = "Line/2017.0731.2132.CFNetwork/758.1.6 Darwin/15.0.0"
        LA = "DESKTOPWIN 7.5.0 iPhone OS 1"
      elif self.numb == 14:
        UA = "Line/2017.0731.2132.CFNetwork/758.1.6 Darwin/15.0.0"
        LA = "DESKTOPWIN 7.5.0 iPhone OS 1"

      return LA, UA
