# -*- coding: utf-8 -*-
from linepy import *
from linepy.liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import OpType
from akad.ttypes import *
from akad.ttypes import ChatRoomAnnouncementContents
from akad import ttypes
from akad.ttypes import Message, Location
from akad.ttypes import LoginRequest
from akad import ChannelService,TalkService,AuthService,AccountSupervisorService,BotService
from akad.AccountSupervisorService import *
from simplify import *
#from plugins import *
#from plugins.util import hook, exec, execute, http, text, timesince, urlnorm, web
from difflib import SequenceMatcher
import unicodedata as udd
import livejson, requests
from io import BytesIO
from googletrans import Translator
from collections import OrderedDict
import urllib.request
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil import parser
from random import randint
from bs4 import BeautifulSoup
from gtts import gTTS
from archimed import Archimed
from PIL import Image, ImageDraw, ImageFont
from ffmpy import FFmpeg
from multiprocessing import Pool, Process
from subprocess import Popen, PIPE
from ffmpy import FFmpeg
from youtube_dl import YoutubeDL
import youtube_dl
import threading
import wikipedia
import wiki, timeit
import platform
import pafy, shutil, calendar, tempfile
from urllib.request import urlretrieve
from urllib.request import urlopen
from urllib.parse import urlencode,quote,urlparse,parse_qs,parse_qsl,urlunparse,urlsplit,urljoin,urldefrag,quote_plus,unquote
import html5lib, tempfile, goslate
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from Naked.toolshed.shell import execute_js
import timeago,LineService
from humanfriendly import format_timespan, format_size, format_number, format_length
from threading import Thread
import time, base64, random, sys, json, codecs, threading, subprocess, glob, re, string, os, requests, six, ast, pytz, urllib, urllib3, urllib.parse, traceback, atexit, random, importlib, asyncio, humanize
_session = requests.session()

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

add = {"img": {},"save": False,}

class selfbot():
    uid = None
    name = None
    client = None
    anu = None
    db = None
    db1 = None
    awit = None
    mode = None
    master = ["u3ccd7738062f0302614a06aac37b7b1f"]
    help = "________________________________\t\n˜”*°• 𝕽𝖌 𝖘𝖊𝖑𝖋𝖇𝖔𝖙 𝓥.1.14 •°*”˜\n________________________________"
    duedate = None
    imgcmd = None
    vidcmd = None
    audiocmd = None
    rename = None
    pdfcmd = None
    musiccmd = None
    filecmd = None
    renamecon = False
    rcon = []
    rtext = ""
    mcon = []
    mtext = ""
    mmcox = None
    rimage = False
    notagg = False
    backtagg = False
    imgprofile = False
    imgcover = False
    tempbots = []
    tempnames = []
    welcomeimage = False
    wcsticker = False
    stickerban = False
    stickertagg = False
    staggpm = False
    stickernook = False
    stickerbye = False
    replykick = False
    leavesticker = False
    imgsender = ''
    invites = []
    stickercommand = ""
    stickercmd = ""
    addcmd = ""
    ceks = []
    yt = []
    stkcomand=""
    addstk=False
    stickertemp = False
    addsticker = False
    addcommand = False
    cctvSTICKER = False
    rsticker = False
    botoff = False
    duedate = None
    imgsender = ''
    gtn = False
    gtnn = 0
    sider = {
        'readPoint':{},
        'readMember':{},
        'setTime':{},
        'ROM':{}}
    setTime = {}
    setTime = sider['setTime']
    sider2 = {
        'readPoint':{},
        'readMember':{},
        'setTime':{},
        'ROM':{}}
    setTime = {}
    setTime = sider2['setTime']
    with open("Cmd_data.json","r",encoding="utf_8_sig") as f:
        datas = json.loads(f.read(),object_pairs_hook=OrderedDict)
    reply = Simplify(client,datas=datas)

    def __init__(self,uid=None,name=None,client=None,anu=None,db=None,db1=None,db2=None,mode=None,awit=None,cover=None):
        self.uid = uid
        self.name = name
        self.client = client
        self.dxName = anu
        self.mode = mode
        self.db = db
        self.db1 = db1
        self.awit = awit
        self.cover = cover
        self.tempban = []
        self.invban = []
        self.sasaran = []
        self.spamname = ''
        self.spam = False
        self.bye = 0
        self.pro = 0
        self.adc = False
        self.point = time.time()
        self.settings = self.db['settings']
        self.stats = self.db['stats']
        self.wait = self.db1['wait']
        self.commands = self.db['commands']
        self.duedate = parser.parse(self.stats["duedate"])
        self.loop = asyncio.get_event_loop()
        self.pm = self.stats['pmID']
        self.listpm = list(self.pm)
        self.commands = self.db["commands"]
        self.perintah = self.db["perintah"]
        self.imgcmds = self.db["imgcmds"]
        self.musiccmds = self.db["musiccmds"]
        self.audiocmds = self.db["audiocmds"]
        self.vidcmds = self.db["vidcmds"]
        self.temp_db = livejson.File('nuker/%s.json'%self.dxName)
        self.st = livejson.File('unsend/%s.json'%self.dxName)
        self.set = {"mids":False,"detectunsend":{"unsend": {},"likesticker": {},"tagsticker": {},"bcaudio": {},"bcvideo": {},"unsendaudio": {},"unsendchat": {},"unsendcontact": {},"unsendfile": {},"unsendlocation": {},"unsendstiker": {},"unsendtwin": {},"unsendvideo": {}}}
        self.album = {"albumpro":[False],"mute":[False]}
        #self.tagkick = {"mentionKick":False}
        if not "set" in self.st:self.st['set'] = self.set;self.set = self.st["set"]
        else:self.set = self.st["set"]
        if not 'device' in self.temp_db:
            self.temp_db['device'] = self.headersios()
        if not 'appName' in self.temp_db:
            self.temp_db['appName'] = 'IOSIPAD\t10.2.1\tiPhone 8\t12.1.1'
        if 'rsticker' not in self.db:
            self.db['rsticker'] = {}
        if 'rimage' not in self.db:
            self.db['rimage'] = []
        if 'notagg' not in self.db:
            self.db['notagg'] = []
        if 'backtagg' not in self.db:
            self.db['backtagg'] = []
        if 'stickerban' not in self.stats:
            self.stats['stickerban'] = {}
#        if 'stickertagg' not in self.db:
#            self.db['stickertagg'] = {}
        if 'stickernook' not in self.db:
            self.db['stickernook'] = {}
        if 'enabled' not in self.commands:
            self.commands['enabled'] = True
        if 'enabled2' not in self.commands:
            self.commands['enabled2'] = True
        if 'enabled3' not in self.commands:
            self.commands['enabled3'] = True
        if 'enabled4' not in self.commands:
            self.commands['enabled4'] = True
        if 'enabled5' not in self.stats:
            self.stats['enabled5'] = True
        if 'enabled6' not in self.commands:
            self.commands['enabled6'] = True
        if 'enabled7' not in self.commands:
            self.commands['enabled7'] = True
        if 'silentsb' not in self.db:
            self.db['silentsb'] = False
        if 'autoreject' not in self.db:
            self.db['autoreject'] = False
        if 'intip' not in self.db:
            self.db['intip'] = {'on':[],'txt':'Cctv aja chat napa'}

    def updateCover(self,msg):
        path = self.client.downloadObjectMsg(msg.id)
        try:
            path = self.client.downloadObjectMsg(msg.id)
            coms.updateProfileCover(path)
            self.client.sendMessage(msg.to, 'Success updating profile cover.')
        except:
          try:
            path = self.client.downloadObjectMsg(msg.id)
            self.client.updateProfileCover(path)
            self.client.sendMessage(msg.to, 'Success updating profile cover.')
          except:
            try:
              path = self.client.downloadObjectMsg(msg.id)
              self.client.updateProfileCover(path)
              self.client.sendMessage(msg.to, 'Success updating profile cover.')
            except Exception as e:
              self.client.sendMessage(msg.to,str(e))
    def async_receive_message(self,op):
        return self.loop.run_until_complete(self.receive_message(op))
    def async_send_message(self,op):
        return self.send_message(op)
    def async_notified_accept_group_invitation(self,op):
        return self.loop.run_until_complete(self.notified_accept_group_invitation(op))
    def async_notified_add_contact(self,op):
        return self.loop.run_until_complete(self.notified_add_contact(op))
    def async_add_contact(self,op):
        return self.loop.run_until_complete(self.add_contact(op))
    def async_cancel_invitation_group(self,op):
        return self.loop.run_until_complete(self.cancel_invitation_group(op))
    def async_notified_cancel_invitation_group(self,op):
        return self.loop.run_until_complete(self.notified_cancel_invitation_group(op))
    def async_invite_into_group(self,op):
        return self.loop.run_until_complete(self.invite_into_group(op))
    def async_notified_invite_into_group(self,op):
        return self.loop.run_until_complete(self.notified_invite_into_group(op))
    def async_kickout_from_group(self,op):
        return self.loop.run_until_complete(self.kickout_from_group(op))
    def async_notified_kickout_from_group(self,op):
        return self.loop.run_until_complete(self.notified_kickout_from_group(op))
    def async_notified_leave_group(self,op):
        return self.loop.run_until_complete(self.notified_leave_group(op))
    def async_notified_read_message(self,op):
        return self.loop.run_until_complete(self.notified_read_message(op))
    def async_notified_reject_group_invitation(self,op):
        return self.loop.run_until_complete(self.notified_reject_group_invitation(op))
    def async_notified_unregister_user(self,op):
        return self.loop.run_until_complete(self.notified_unregister_user(op))
    def async_notified_update_group(self,op):
        return self.loop.run_until_complete(self.notified_update_group(op))
    def async_update_profile(self,op):
        return self.loop.run_until_complete(self.update_profile(op))
    def async_notified_update_profile(self,op):
        return self.loop.run_until_complete(self.notified_update_profile(op))
    def async_accept_group_invitation(self,op):
        return self.loop.run_until_complete(self.accept_group_invitation(op))
    def async_notified_destroy_message(self,op):
        return self.loop.run_until_complete(self.notified_destroy_message(op))
    def async_destroy_message(self,op):
        return self.loop.run_until_complete(self.destroy_message(op))
    def async_auto(self):
        return self.loop.run_until_complete(self.auto())

    def backupData(self):
        with open('settings/'+self.dxName+'.json', 'w') as fp:
            json.dump(self.db, fp, sort_keys=True, indent=4)

    def cctvData(self):
        with open('cctv/'+self.dxName+'.json', 'w') as fp:
            json.dump(self.db1, fp, sort_keys=True, indent=4)

    def backupnuker():
        with open('nuker/{}.json'.format(self.dxName), 'w') as fp:
            json.dump(self.bangsat, fp, sort_keys=True, indent=4)

############################
##############H O O K
############################
    
    def get_spsd(self,url,header):
        return BeautifulSoup(urllib.request.urlopen(urllib.request.Request(url,headers=header)), "html.parser")

    def sendSticker(self, to, packageId, stickerId):
        contentMetadata = {
            'STKVER': '100',
            'STKPKGID': packageId,
            'STKID': stickerId
        }
        self.client.sendMessage(to, '', contentMetadata, 7)
    def clear(self):
        self.stats["ban"] = False
        self.stats["unban"] = False
        self.stats["staff"] = False
        self.stats["expel"] = False
        self.stats["mute"] = False
        self.stats["unmute"] = False
        self.stats["bot"] = False
        self.stats["locate"] = False
        self.stats["info"] = False
        self.set["mids"] = False
        self.stats["clone"] = False
        self.stats["invitespam"] = False
        self.stats["profilevid"] = False
        self.stats["profilepic"] = False
        self.backupData()

    def headersios(self):
        Headers = {
        'User-Agent': "Line/10.2.1",
        'X-Line-Application': 'IOSIPAD\t10.2.1\tiPhone 8\t12.1.1',
        "x-lal": "ja-US_US",
        }
        return Headers
    def headerswin(self):
        Headers = {
        'User-Agent': "Line/5.9.0",
        'X-Line-Application': 'DESKTOPWIN\t5.9.0\t10.9.4-MAVERICKS-x64',
        "x-lal": "ja-US_US",
        }
        return Headers
    def headerschrome(self):
        Headers = {
        'User-Agent': "Mozilla/5.0 Chrome/77.0.3865.120",
        'X-Line-Application': 'CHROMEOS\t2.3.0\tChrome_OS\t1',
        "x-lal": "ja-US_US",
        }
        return Headers
    def headerswin10(self):
        Headers = {
        'User-Agent': "Line/5.5.5",
        'X-Line-Application': 'WIN10\t5.5.5\tpsd\tBot\t12.1.1',
        "x-lal": "ja-US_US",
        }
        return Headers
    def headersmac(self):
        Headers = {
        'User-Agent': "Line/5.8.0",
        'X-Line-Application': 'DESKTOPMAC\t5.8.0\t10.9.4-psd-BOT-x64',
        "x-lal": "ja-US_US",
        }
        return Headers
    def headerstizen(self):
        Headers = {
        'User-Agent': 'line/5.11.2',#'Mozilla/5.0 (Linux; Tizen 2.3; SAMSUNG SM-Z130H) AppleWebKit/537.3 (KHTML, like Gecko) Version/2.3 Mobile Safari/537.3',#"Line 6.8.2",
        'X-Line-Application': 'TIZEN\t2.3.2\tpsd\tBot\t12.1.1',#'TIZEN\t1.4.3\tpsd\tBot\t12.1.1',
        "x-lal": "ja-US_US",
        }
        return Headers
    def headersfir(self):
        Headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/58.0.3029.110 Safari/537.36",
        'X-Line-Application': 'FIREFOXOS 1.4.11 Firefox_OS 1',
        "x-lal": "ja-US_US",
        }
        return Headers

    def loginjs(self,to,msg):
        try:
            nama = "RgBots"
            self.temp_db['device'].update({'x-lpqs' : '/api/v4/TalkService.do'})
            transport = THttpClient.THttpClient('https://ga.line.naver.jp/api/v4/TalkService.do')
            transport.setCustomHeaders(self.temp_db['device'])
            protocol = TCompactProtocol.TCompactProtocol(transport)
            cl = TalkService.Client(protocol)
            qr = cl.getAuthQrcode(keepLoggedIn=1, systemName=nama)
            link = "line://au/q/" + qr.verifier
            self.client.sendText(to,"Click link below in 2 minutes before expired \n"+str(link))
            self.temp_db['device'].update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
            json.loads(requests.session().get('https://ga.line.naver.jp/Q', headers=self.temp_db['device']).text)
            self.temp_db['device'].update({'x-lpqs' : '/api/v4p/rs'})
            transport = THttpClient.THttpClient('https://ga.line.naver.jp/api/v4p/rs')
            transport.setCustomHeaders(self.temp_db['device'])
            protocol = TCompactProtocol.TCompactProtocol(transport)
            cl = AuthService.Client(protocol)
            req = LoginRequest()
            req.type = 1
            req.verifier = qr.verifier
            req.e2eeVersion = 1
            temp_client = cl.loginZ(req)
            self.temp_db['token'] = temp_client.authToken
            self.client.sendText(to,"Success login Antijs")
        except Exception as e:self.client.sendText(to,"Maaf anda di banned login\ntunggu 24 jam br anda bisa login lagi.");traceback.print_exc()

    def sendTagProfile(self, to, mid, firstmessage, lastmessage, senderIcon="", senderName=""):
        try:
            arrData = ""
            text = "%s " %(str(firstmessage))
            arr = []
            mention = "@x "
            slen = str(len(text))
            elen = str(len(text) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':mid}
            arr.append(arrData)
            text += mention + str(lastmessage)
            self.client.sendMessage(to,"{}".format(str(text)),{'MSG_SENDER_ICON': senderIcon, 'MSG_SENDER_NAME': senderName, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')})
        except Exception as error:
            print(error)

    def restart_program(self):
        python = sys.executable
        os.execl(python, python, * sys.argv)

    def Tagall1(self, to, nama):
        aa = ""
        bb = ""
        strt = int(19)
        akh = int(19)
        nm = nama
        for mm in nm:
          akh = akh + 2
          aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
          strt = strt + 6
          akh = akh + 4
          bb += "⌬ @x \n"
        aa = (aa[:int(len(aa)-1)])
        msg = Message()
        msg.to = to
        tst = u'Tagall members :\n\n'
        msg.text = "「Mention All」   \n"+bb + "    「 Total: " + str(len(nm)) +  " Mention 」"
        msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
        try:
           self.client.sendMessage(to,msg.text,msg.contentMetadata)
        except Exception as error:
           print(error)

    def logError(self,text):
      try:
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        timeHours = datetime.strftime(timeNow,"(%H:%M)")
        day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
        hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
        bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
        inihari = datetime.now(tz=tz)
        hr = inihari.strftime('%A')
        bln = inihari.strftime('%m')
        for i in range(len(day)):
            if hr == day[i]: hasil = hari[i]
        for k in range(0, len(bulan)):
            if bln == str(k): bln = bulan[k-1]
        time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
        with open("log/{}".format(self.dxName),"a") as error:
            error.write("\n[ {} ] {}".format(str(time), text))
      except Exception as e:
        traceback.print_tb(e.__traceback__)
    def cTime_to_datetime(unixtime):
        return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
    def dt_to_str(dt):
        return dt.strftime('%H:%M:%S')
    def sendMention(self, to, txt="", mids=[]):
        arrData = ""
        arr = []
        mention = "@satstiesfi "
        if mids == []:
            raise Exception("Invalid mids")
        elif "@!" in txt:
            if txt.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = txt.split("@!")
            textx = ""
            for mid in mids:
                textx += str(texts[mids.index(mid)])
                slen = len(textx)
                elen = len(textx) + 15
                arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ""
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(txt)
        self.client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

    def sendtag(self, to, text="",eto="", mids=[], isUnicode=False):
        arrData = ""
        arr = []
        mention = "@Sats ExpPs "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ""
            unicode = ""
            if isUnicode:
                for mid in mids:
                    unicode += str(texts[mids.index(mid)].encode('unicode-escape'))
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx) if unicode == textx else len(textx) + unicode.count('U0')
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            else:
                for mid in mids:
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx)
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            textx += str(texts[len(mids)])
        else:
            raise Exception("Invalid mention position")
        self.client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    def listdata(self,to,stats,text='',ps='',data=[]):
        k = len(data)//20
        for aa in range(k+1):
            if aa == 0:dd = ' 「 {} 」'.format(text,ps);no=aa
            else:dd = ' 「 {} 」'.format(text,ps);no=aa*20
            msgas = dd
            for i in data[aa*20 : (aa+1)*20]:
                no+=1
                if no == len(data):msgas+='\n{}• @!'.format(no)
                else:msgas+='\n{}• @!'.format(no)
            if data == []:pass
            else:self.sendtag(to, msgas,' 「 {} 」'.format(ps), data[aa*20: (aa+1)*20])

    def abortz(self,to):
        self.spam = False
        self.adc = False
        self.spamname = ''
        self.sasaran = []
        self.client.sendMessage(to,"Command abort")
    def abort(self,to):
        self.stats["repeat"] = False
        if self.stats["ban"]:
            self.stats["ban"] = False
            self.client.sendMessage(to,"Banned aborted.")
        elif self.stats["mute"]:
            self.stats["mute"] = False
            self.client.sendMessage(to,"Muted aborted.")
        elif self.stats["locate"]:
            self.stats["locate"] = False
            self.client.sendMessage(to,"Location aborted.")
        elif self.stats["info"]:
            self.stats["info"] = False
            self.client.sendMessage(to,"Info aborted.")
        elif self.set["mids"]:
            self.set["mids"] = False
            self.client.sendMessage(to,"Mids aborted.")
        elif self.stats["invite"]:
            self.stats["invite"] = False
            self.client.sendMessage(to,"Invite aborted.")
        elif self.stats["kick"]:
            self.stats["kick"] = False
            self.client.sendMessage(to,"Kick aborted.")
        elif self.stats["unban"]:
            self.stats["unban"] = False
            self.client.sendMessage(to,"Unban aborted.")
        elif self.stats["unmute"]:
            self.stats["unmute"] = False
            self.client.sendMessage(to,"Unmute aborted.")
        elif self.stats["staff"]:
            self.stats["staff"] = False
            self.client.sendMessage(to,"Staff aborted.")
        elif self.stats["expel"]:
            self.stats["expel"] = False
            self.client.sendMessage(to,"Expel aborted.")
        elif self.stats["bot"]:
            self.stats["bot"] = False
            self.client.sendMessage(to,"Bot aborted.")
        elif self.stats["gift"]:
            self.stats["gift"] = False
            self.client.sendMessage(to,"Gift aborted.")
        elif self.stats["clone"]:
            self.stats["clone"] = False
            self.client.sendMessage(to,"Clone aborted.")
        elif self.imgsender != '':
            self.imgsender = ''
            self.client.sendMessage(to,"Image aborted.")
        else:
            self.client.sendMessage(to,"Nothing to abort")
        self.backupData()

    def mention(self,msg,targets):
        if "MENTION" in msg.contentMetadata:
            msg.contentMetadata["MENTION"] = json.loads(msg.contentMetadata["MENTION"])
            for m in msg.contentMetadata["MENTION"]["MENTIONEES"]:
                targets.append(m["M"])

    def listcon(self,to,msg,num,stats,data=[]):
        if data == []:
            self.client.sendMessage(to, " 「 Empty List 」")
        else:
            nama = data
            no = 0
            targets = []
            selection = Archimed(num,range(1,len(nama)+1))
            for i in selection.parse():
                targets.append(nama[i-1])
            for target in targets:
                try:
                    self.client.sendContact(msg.to,target)
                except Exception as e:traceback.print_exc()

    def nameUpdate():
        while True:
            try:
            #while a2():
                #pass
                if wait["clock"] == True:
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"(%H:%M)")
                    profile = cl.getProfile()
                    profile.displayName = wait["cName"] + nowT
                    cl.updateProfile(profile)
                time.sleep(600)
            except:
                pass
    thread2 = threading.Thread(target=nameUpdate)
    thread2.daemon = True
    thread2.start()
    def listinv(self,to,msg,num,stats,data=[]):
        if data == []:
            self.client.sendMessage(to, " 「 Empty List 」")
        else:
            nama = data
            no = 0
            targets = []
            selection = Archimed(num,range(1,len(nama)+1))
            for i in selection.parse():
                targets.append(nama[i-1])
            for target in targets:
                try:
                    self.client.inviteIntoGroup(msg.to,[target])
                except Exception as e:traceback.print_exc()
    def gcon(self,to,msg):
        data = msg.text.replace('.gcon',"")
        text = data.split(' ')
        com = str(text[1])
        gid = self.client.getGroupIdsJoined()
        gs = self.client.getGroup(to)
        nama = [contact.mid for contact in gs.members]
        no = 0
        targets = []
        selection = Archimed(com,range(1,len(nama)+1))
        for i in selection.parse():
            targets.append(nama[i-1])
        for target in targets:
            try:
                self.client.sendContact(msg.to,target)
            except Exception as e:print(e)

    def mentionmention(self,to,stats, text, dataMid=[], pl='', ps='',pg='',pt=[]):
        arr = []
        list_text=ps
        i=0
        no=pl
        if pg == 'MENTIONALLME':
            for l in dataMid:
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text+text
        if pg == 'DELFL':
            for l in dataMid:
                try:
                    self.client.deleteContact(l)
                    a = 'Remove Friend'
                except:
                    a = 'Not Friend User'
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=text+list_text
        if pg == 'ADDFL':
            lss = self.client.refreshContacts()
            for l in dataMid:
                if not l in self.uid and l not in lss:
                   self.client.findAndAddContactsByMid(l)
                no+=1
                list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDST':
            for l in dataMid:
              if not l in self.uid:
                if l in stats["stafflist"]:
                    a = 'Already Staff'
                else:
                    a = 'Add staff'
                    stats["stafflist"].append(l)
                    self.client.findAndAddContactsByMid(l)
                    self.backupData()
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELST':
            for l in dataMid:
                if l not in stats["stafflist"]:
                    a = 'Not staff'
                else:
                    a = 'Remove staff'
                    stats["stafflist"].remove(l)
                    self.backupData()
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDBOT':
            for l in dataMid:
              if not l in self.uid:
                if l in stats["botlist"]:
                    a = 'Already Bot'
                else:
                    a = 'Add Bot'
                    stats["botlist"].append(l)
                    self.client.findAndAddContactsByMid(l)
                    self.backupData()
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELBOT':
            for l in dataMid:
                if l not in stats["botlist"]:
                    a = 'Not Bot'
                else:
                    a = 'Remove Bot'
                    stats["botlist"].remove(l)
                    self.backupData()
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDMUTE':
            for l in dataMid:
              if not l in self.uid:
                if l in stats["mutelist"]:
                    a = 'Already Mute'
                else:
                    a = 'Add Mute'
                    stats["mutelist"].append(l)
                    self.backupData()
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELMUTE':
            for l in dataMid:
                if l not in stats["mutelist"]:
                    a = 'Not Mute'
                else:
                    a = 'Remove Mute'
                    stats["mutelist"].remove(l)
                    self.backupData()
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDBAN':
            for l in dataMid:
              if not l in self.uid:
                if l in stats["banned"]:
                    a = 'Already Banned'
                else:
                    a = 'Add Banned'
                    stats["banned"].append(l)
                    self.backupData()
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELBAN':
            for l in dataMid:
                if l not in stats["banned"]:
                    a = 'Not Banned'
                else:
                    a = 'Remove Banned'
                    stats["banned"].remove(l)
                    self.backupData()
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[psd-'+str(i)+'] '
                i=i+1
            text=list_text
        i=0
        for l in dataMid:
            if l not in self.uid:
                mid=l
                name='@[psd-'+str(i)+']'
                ln_text=text.replace('\n',' ')
                if ln_text.find(name):
                    line_s=int( ln_text.index(name) )
                    line_e=(int(line_s)+int( len(name) ))
                arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
                arr.append(arrData)
                i=i+1
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        if pg == 'MENTIONALLUNSED':self.client.unsendMessage(self.client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}).id)
        else:self.client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')})

    def issueLiffView(self, to):
        az = LiffChatContext(to)
        ax = LiffContext(chat=az)
        #lf = LiffViewRequest('1646011835-9MXEx20v', ax)
        lf = LiffViewRequest('1646011835-9MXEx20v', ax)
        return self.client.issueLiffView(lf)

    #def issueLiff(to, liff="1562242036-RW04okm"):
    def issueLiff(to, liff="1562242036-RW04okm"):
       anu = LiffContext(chat=LiffChatContext(to))
       itu = LiffViewRequest(liffId=liff, context=anu)
       lol = self.client.liff.issueLiffView(itu)
       token = lol.accessToken
       return token

    def m_exec_thread(self,msg):
        try:
            if msg.toType == 0: msg.to = msg.to
            sys.stdout = open("tmp/temp.txt","w")
            exec(msg.text.replace("!run","").replace("import os",""))
            sys.stdout.close()
            sys.stdout = sys.__stdout__
        except Exception as e:
            self.client.sendMessage(msg.to, str(e))
    

    def sendTemplate(self, to, data):
        token = self.issueLiffView(to)
        url = 'https://api.line.me/message/v3/share'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer %s' % token.accessToken
        }
        data = {
            'messages': [data]
        }
        res = requests.post(url, headers=headers, data=json.dumps(data))
        print(res.text)

    def sendTemplate4(to, data):
        xyz = LiffChatContext(to)
        xyzz = LiffContext(chat=xyz)
        view = LiffViewRequest('1646011835-9MXEx20v', xyzz)
        token = self.client.liff.issueLiffView(view)
        url = 'https://api.line.me/message/v3/share'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer %s' % token.accessToken
        }
        data = {"messages":[data]}
        requests.post(url, headers=headers, data=json.dumps(data))
#=======================  
    def footer(self, to, text):
       contact = self.client.getContact(uid)
       iconlink = "line://nv/profilePopup/mid=u3ccd7738062f0302614a06aac37b7b1f"#/0heyBKtQBnOlZ_Mhd984FFAUN3NDsIHDweBwAmNVNhbGAABCgJEAByM1IxYTRUAX0FSwNzMFMyZzNb"
       url = "http://line.me/ti/p/~teamhackbots"
       name = "THB"
       data = {"messages":[{"type":"text","text": text,"sentBy":{"label":name,"iconUrl":iconlink,"linkUrl":url}}]}
       sendTemplate0(to, data)
    def Footerlimbz(self, to ,text):
        data = {"type":"text","text":text,"sentBy":{"label":"ᴛʜʙ ᴛᴇᴀᴍ","iconUrl":"https://i.postimg.cc/bJX97vqP/178551.jpg","linkUrl":"line://nv/profilePopup/mid=u3ccd7738062f0302614a06aac37b7b1f"}};self.sendTemplate(to,data)
    def sendTemplate0(self, to,data):
       data = json.dumps(data)
       xyz = LiffChatContext(to)
       xyzz = LiffContext(chat=xyz)
       view = LiffViewRequest('1646011835-9MXEx20v', xyzz)
       token = self.client.liff.issueLiffView(view)
       url = 'https://api.line.me/message/v3/share'
       headers = {
           'Content-Type': 'application/json',
           'Authorization': 'Bearer %s' % token.accessToken
       }
       return requests.post(url, data=data, headers=headers)
    def issueLiffView(self, to):
        az = LiffChatContext(to)
        ax = LiffContext(chat=az)
        lf = LiffViewRequest('1646011835-9MXEx20v', ax)
        return self.client.issueLiffView(lf)
    def sendTemplate1(self, to, data):
        token = issueLiffView(to)
        url = 'https://api.line.me/message/v3/share'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer %s' % token.accessToken
        }
        data = {
            'messages': [data]
        }
        res = requests.post(url, headers=headers, data=json.dumps(data))
        print(res.text)   
    def mycmd(self,text):
        cmd = ''
        txt = text
        if ' & ' in text:
            cmd = txt.split(' & ')
        else:
            cmd = [txt]
        return cmd

    def translate(self, to_translate, to_language="auto", language="auto"):
        agent = {'user-Agent': "Mozilla/4.0(compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50/27; .NET CLR 3.0.04506.0)"}
        user_agent = "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)","Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0","Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0","Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5","Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0","Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0","Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0","Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
        base_link="http://translate.google.com/m?hl=%s&sl=%s&q=%s"
        if(six.PY2):
            link = base_link % (to_language, language, urllib.pathname2url(to_translate))
            request = urllib2.Request(link, headers=agent)
            page = urllib2.urlopen(request).read()
        else:
            link = base_link % (to_language, language, urllib.parse.quote(to_translate))
            request = urllib.request.Request(link, headers=agent)
            page = urllib.request.urlopen(request).read().decode('utf-8')
        expr = r'class="t0">(.*?)<'
        result = re.findall(expr,page)
        if(len(result)==0):
            return("")
        return(result[0])

    def changeVideoAndPictureProfile(self, pict, vids):
        try:
            files = {'file': open(vids, 'rb')}
            obs_params = self.client.genOBSParams({'oid': self.uid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
            data = {'params': obs_params}
            r_vp = self.client.server.postContent('{}/talk/vp/upload.nhn'.format(str(self.client.server.LINE_OBS_DOMAIN)), data=data, files=files)
            if r_vp.status_code != 201:
                return "Failed update profile"
            self.client.updateProfilePicture(pict, 'vp')
            return "Success update profile"
        except Exception as e:
            raise Exception("Error change video and picture profile {}".format(str(e)))

    def sendTagg(self, to, mid, firstmessage, lastmessage):
        try:
            arrData = ""
            text = "%s " %(str(firstmessage))
            arr = []
            mention = "@x "
            slen = str(len(text))
            elen = str(len(text) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':mid}
            arr.append(arrData)
            text += mention + str(lastmessage)
            self.client.sendMessage(to,"{}".format(str(text)),contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')})
        except Exception as error:
            print(error)

    def changeProfileVideo(self, to):
        if self.stats['changeProfileVideo']['picture'] == None:
            return self.client.sendText(to, "Foto tidak ditemukan")
        elif self.stats['changeProfileVideo']['video'] == None:
            return self.client.sendText(to, "Video tidak ditemukan")
        else:
            path = self.stats['changeProfileVideo']['video']
            files = {'file': open(path, 'rb')}
            obs_params = self.client.genOBSParams({'oid': self.client.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
            data = {'params': obs_params}
            r_vp = self.client.server.postContent('{}/talk/vp/upload.nhn'.format(str(self.client.server.LINE_OBS_DOMAIN)), data=data, files=files)
            if r_vp.status_code != 201:
                return self.client.sendText(to, "Gagal update profile")
            path_p = self.stats['changeProfileVideo']['picture']
            self.stats['changeProfileVideo']['status'] = False
            self.backupData()
            self.client.updateProfilePicture(path_p, 'vp')

    def cloneProfile(self, mid):
        contact = self.client.getContact(mid)
        if contact.videoProfile == None:
            self.client.cloneContactProfile(mid)
        else:
            profile = self.client.getProfile()
            profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
            self.client.updateProfile(profile)
            pict = self.client.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
            vids = self.client.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
            self.changeVideoAndPictureProfile(pict, vids)
        coverId = self.client.getProfileDetail(mid)['result']['objectId']
        self.client.updateProfileCoverById(coverId)

    def backupProfile():
        profile = self.client.getContact(uid)
        #self.stats['displayName'] = profile.displayName
        self.stats['picture'] = profile.pictureStatus
        self.stats['status'] = profile.statusMessage
        coverId = self.client.getProfileDetail()['result']['objectId']
        self.stats['cover'] = str(coverId)

    def restoreProfile():
        profile = self.client.getProfile()
        profile.displayName = self.stats['displayName']
        profile.statusMessage = self.stats['status']
        self.client.updateProfile(profile)
        if self.stats['picture']:
            pict = self.client.downloadFileURL('http://dl.profile.line-cdn.net/' + self.stats['picture'])
            self.client.updateProfilePicture(pict)
        coverId = self.stats['cover']
        self.client.updateProfileCoverById(coverId)
    def sendFakeContact(self, to, mid):
        contact = self.getContact(mid)
        pict = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
        name = "{}".format(contact.displayName)
        contentMetadata={'mid' : mid,'MSG_SENDER_NAME': name,'MSG_SENDER_ICON': pict}
        return self.sendMessage(to, '', contentMetadata, 13)
    def profileText(self,to,text,korban,nama):
        ris = {
              'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+korban,
              'MSG_SENDER_NAME':  '{}'.format(nama),
                 }
        self.sendMessage(to, '{}'.format(text), contentMetadata=ris)
    def ytmp4(self, msg, to, separate):
        try:
            no = msg.text.replace(separate[0] + " ","")
            na = int(no)-1
            subprocess.getoutput('youtube-dl --format mp4 --output video.mp4 {}'.format(self.yt[na]))
            self.client.sendVideo(to, "video.mp4")
            time.sleep(1)
            os.remove("video.mp4")
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    def ytmp3(self, msg, to, separate):
        try:
            no = msg.text.replace(separate[0] + " ","")
            na = int(no)-1
            subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output audio.mp3 {}'.format(self.yt[na]))
            self.client.sendAudio(to, "audio.mp3")
            time.sleep(1)
            os.remove("audio.mp3")
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    def updateDual(self, msg, to, separate):
        try:
            no = msg.text.replace(separate[0] + " ","")
            na = int(no)-1
            self.client.sendReplyMessage(msg.id,to, "Downloading Video...")
            subprocess.getoutput('youtube-dl --format mp4 --output video.mp4 {}'.format(self.yt[na]))
            picture = self.client.downloadFileURL("http://dl.profile.line-cdn.net/"+self.client.getProfile().picturePath, saveAs="image.bin")
            video = "video.mp4"
            self.anuankamu(picture, video)
            self.client.sendReplyMessage(msg.id,to, "Success Change Video Profile")
            os.remove("video.mp4")
        except:
            e = traceback.format_exc()
            self.client.sendMessage(to,str(e))
    def updateDual2(self, msg, to, separate):
        try:
            no = msg.text.replace(separate[0] + " ","")
            self.client.sendReplyMessage(msg.id,to, "Downloading Video...")
            subprocess.getoutput('youtube-dl --format mp4 --output video.mp4 {}'.format(no))
            picture = self.client.downloadFileURL("http://dl.profile.line-cdn.net/"+self.client.getProfile().picturePath, saveAs="image.bin")
            video = "video.mp4"
            self.anuankamu(picture, video)
            self.client.sendReplyMessage(msg.id,to, "Success Change Video Profile")
            os.remove("video.mp4")
        except:
            e = traceback.format_exc()
            self.client.sendMessage(to,str(e))
    def anuankamu(self, pict, vids):
        try:
            files = {'file': open(vids, 'rb')}
            obs_params = self.client.genOBSParams({'oid': self.uid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'video.mp4'})
            data = {'params': obs_params}
            r_vp = self.client.server.postContent('{}/talk/vp/upload.nhn'.format(str(self.client.server.LINE_OBS_DOMAIN)), data=data, files=files)
            if r_vp.status_code != 201:
                return "Failed update profile"
            self.client.updateProfilePicture(pict, 'vp')
            return "Success update profile"
        except:
            pass
    def mysticker(self,msg):
        a = self.client.shop.getActivePurchases(start=0, size=1000, language='ID', country='ID').productList
        c = "List Purchased Sticker:"
        no = 0
        for b in a:
            no +=1
            c += "\n"+str(no)+". "+b.title+" ID:"+str(b.packageId)
        k = len(c)//10000
        for aa in range(k+1):
            self.client.sendMessage(msg.to,'{}'.format(c[aa*10000 : (aa+1)*10000]))

    def ymp4(self, to, quer):
        try:
            query = urllib.parse.quote(quer)
            url = "https://www.youtube.com/results?search_query=" + query;response = urllib.request.urlopen(url)
            html = response.read()
            spsd = BeautifulSoup(html, "html.parser")
            results = spsd.find(attrs={'class':'yt-uix-tile-link'})
            dl=("https://www.youtube.com" + results['href'])
            splitin = dl.split("?v=")[1]
            vid = pafy.new(dl);stream = vid.streams
            for s in stream:
                vin = s.url;hasil = vid.title
                #hasil += '\n⌬ author : ' + str(vid.author) + '\n⌬ duration : ' + str(vid.duration) + '\n⌬ likes : ' + str(vid.likes) + '\n⌬ viewcount : ' + str(vid.viewcount) + '\n⌬ rating : ' + str(vid.rating) + '\n⌬ published : ' + str(vid.published)
                data = {"type": "flex","altText": "Youtube-Mp4","contents": {"type": "bubble","styles": {"body": {"backgroundColor": "#0000ff", "separator": True, "separatorColor": "#FFFFFF"},"footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},"hero": {"type": "image","url": "https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(splitin),"size": "full","aspectRatio": "20:13","aspectMode": "cover","action": {"type": "uri","uri": "line://ti/p/~"+self.client.profile.userid}},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": 'Youtube-Mp4',"weight": "bold","size": "xl"},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Author :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.author)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Duration :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.duration)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Likes :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.likes)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ View :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.viewcount)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Rating :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.rating)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Publis :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": "{}".format(str(vid.published if vid.published != '' else dl)),"color": "#ffffff","wrap": True,"size": "sm","flex": 2}]}]}]}]}]}]}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "YOUTUBE","uri": dl}},{"type": "spacer","size": "sm",}],"flex": 0}}}
            #self.client.sendText(to,hasil);self.client.sendVideoWithURL(to,vin);print (" Yt-mp4 Succes")
            self.sendTemplate(to,data);self.client.sendVideoWithURL(to,vin);print (" Yt-mp4 Succes")
        except Exception as e:self.client.sendText(to,str(e))

    def ymp3(self, to, quer):
        try:
            query = urllib.parse.quote(quer)
            url = "https://www.youtube.com/results?search_query=" + query;response = urllib.request.urlopen(url)
            html = response.read()
            spsd = BeautifulSoup(html, "html.parser")
            results = spsd.find(attrs={'class':'yt-uix-tile-link'})
            dl=("https://www.youtube.com" + results['href'])
            splitin = dl.split("?v=")[1]
            vid = pafy.new(dl);stream = vid.streams
            for s in stream:
                vin = s.url;hasil = vid.title
                data = {"type": "flex","altText": "Youtube-Mp3","contents": {"type": "bubble","styles": {"body": {"backgroundColor": "#0000ff", "separator": True, "separatorColor": "#FFFFFF"},"footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},"hero": {"type": "image","url": "https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(splitin),"size": "full","aspectRatio": "20:13","aspectMode": "cover","action": {"type": "uri","uri": "line://ti/p/~"+self.client.profile.userid}},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": 'Youtube-Mp3',"weight": "bold","size": "xl"},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Author :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.author)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Duration :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.duration)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Likes :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.likes)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ View :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.viewcount)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "vertical","margin": "sm","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Rating :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(vid.rating)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬ Publis :","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": "{}".format(str(vid.published if vid.published != '' else dl)),"color": "#ffffff","wrap": True,"size": "sm","flex": 2}]}]}]}]}]}]}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "YOUTUBE","uri": dl}},{"type": "spacer","size": "sm",}],"flex": 0}}}
                #hasil += '\n⌬ author : ' + str(vid.author) + '\n⌬ duration : ' + str(vid.duration) + '\n⌬ likes : ' + str(vid.likes) + '\n⌬ viewcount : ' + str(vid.viewcount) + '\n⌬ rating : ' + str(vid.rating) + '\n⌬ published : ' + str(vid.published)
            #self.client.sendText(to,hasil);self.client.sendAudioWithURL(to,vin);print (" Yt-mp4 Succes")
            self.sendTemplate(to,data);self.client.sendAudioWithURL(to,vin);print (" Yt-mp3 Succes")
        except Exception as e:self.client.sendText(to,str(e))

    def pangkat(self, userr):
        u = self.master
        if userr in u:
            return 0
        u = self.client.profile.mid
        if userr in u:
            return 1
        u = self.stats["stafflist"]
        if userr in u:
            return 2
        u = self.stats["botlist"]
        if userr in u:
            return 3
        return 1000
    def divisi(self, userr):
        u = self.master
        if userr in u:
            return 0
        u = self.stats["stafflist"]
        if userr in u:
            return 1
        u = self.stats["botlist"]
        if userr in u:
            return 2
        return 1000

    def addbl(self,user):
        if user in self.stats["banned"]:
            pass
        else:
            self.stats["banned"].append(user)
            self.backupData()
        return 1
###################################START
###################################START
###################################START
###################################START
###################################START
###################################START
    async def auto(self):
        if self.invban != [] or self.tempban != []:
            if time.time() - self.point >= 30:
                self.invban = []
                self.tempban = []
                self.point = time.time()

    async def notified_accept_group_invitation(self,op):
        try:
            if op.param1 in self.stats["welcomemsg"].keys():
                if self.stats["welcomemsg"][op.param1][0]:
                    if op.param2 not in self.stats["botlist"]:
                        Text = self.stats["welcomemsg"][op.param1][1]
                        data = {
                                             "messages": [
                                                {
                                                     "type": "flex",
                                                     "altText": "ᴛʜʙ ʀᴇsᴘᴏɴᴛᴀɢ",
                                                     "contents": {
                                                         "type": "bubble",
                                                         "styles": {
                                                         "body": {"backgroundColor": "#434951"}},
                                                         "hero": {
                                                                 "type": "image",
                                                                 "url": "https://i.postimg.cc/hvPBHb5d/welcome.png",
                                                                 "size": "full",
                                                                 "aspectRatio": "1.51:1",
                                                                 "aspectMode": "cover",
                                                         },
                                                         "body": {
                                                                 "type": "box",
                                                                 "layout": "vertical",
                                                                 "contents": [
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "baseline",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": " 𝒲𝐸𝐿𝒞𝒪𝑀𝐸 𝑅𝐸𝒮𝒫𝒪𝒩:",
                                                                                "color": "#00FF00",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 3
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    },
                                                                    {
                                                                      "type": "separator",
                                                                      "color": "#DC143C"
                                                                    },
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "spacing": "xs",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "horizontal",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": "\n{}".format(self.stats["welcomemsg"][op.param1][1]),
                                                                                "color": "#FFFFFF",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 4
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    }
                                                                 ]
                                                         },
                                                         "footer": {
                                                                 "type": "box",
                                                                 "layout": "horizontal",
                                                                 "spacing": "md",
                                                                 "contents": [
                                                                    {
                                                                      "type": "button",
                                                                      "style": "primary",
                                                                      "color": "#0072ff",
                                                                      "action": {
                                                                          "type": "uri",
                                                                          "label": "ᴄʀᴇᴀᴛᴏʀ",
                                                                          "uri": "https://line.me/ti/p/~regathb1",
                                                                       }
                                                                    }
                                                                 ]
                                                         }
                                                     }
                                                }
                                             ]
                                           }
                        self.sendTemplate0(op.param1,data)

            if op.param1 in self.stats["welcome"].keys():
                if self.stats["welcome"][op.param1][0]:
                    if op.param2 not in self.stats["botlist"]:
                        Text = self.stats["welcome"][op.param1][1]
                        data = {
                            "type": "flex",
                            "altText": "Welcome msg",
                            "contents": {
                              "type": "bubble",
                              "size": "kilo",
                              "body": {
                                  "type": "box",
                                  "layout": "vertical",
                                  "contents": [
                                    {
                                      "type": "image",
                                      "url": "https://1.bp.blogspot.com/-DKuuOTRlJz0/XogbgXhFT_I/AAAAAAAABdU/EsXI1drAnvke5kafHWjlMfpvjr13yqnlgCLcBGAsYHQ/s1600/images%2B%252812%2529.jpeg",
                                      "position": "absolute",
                                      "aspectMode": "cover",
                                      "size": "full"
                                    },
                                    {
                                      "type": "box",
                                      "layout": "vertical",
                                      "contents": [
                                        {
                                          "type": "image",
                                          "url": "https://obs.line-scdn.net/{}".format(self.client.getContact(op.param2).pictureStatus), 
                                          "size": "full",
                                          "aspectMode": "cover"
                                        }
                                      ],
                                      "position": "absolute",
                                      "width": "80px",
                                      "cornerRadius": "15px",
                                      "borderColor": "#FFBBDA",
                                      "offsetStart": "10px",
                                      "borderWidth": "2px",
                                      "offsetTop": "2px"
                                    },
                                    {
                                      "type": "box",
                                      "layout": "vertical",
                                      "contents": [
                                        {
                                          "type": "image",
                                          "url": "https://3.bp.blogspot.com/-Ani_c6nnTDI/XogaWfuh-2I/AAAAAAAABc8/f9NzYMU7pzo-g7EVhhIRtPuEf9x2EJCOwCLcBGAsYHQ/s1600/20200404_111750.png",
                                          "position": "absolute",
                                          "size": "xl",
                                          "offsetStart": "50px",
                                          "offsetTop": "-50px"
                                        },
                                        {
                                          "type": "image",
                                          "url": "https://i.postimg.cc/kG12hMny/thb.jpg",
                                          "size": "xxl",
                                          "offsetBottom": "23px",
                                          "offsetStart": "40px"
                                        },
                                        {
                                          "type": "text",
                                          "text": "  {}".format(self.stats["welcome"][op.param1][1]),
                                          "position": "absolute",
                                          "size": "xxs",
                                          "weight": "bold",
                                          "offsetStart": "95px",
                                          "offsetTop": "50px",
                                          "wrap": True,
                                          "style": "italic",
                                          "offsetEnd": "10px",
                                          "maxLines": 2
                                        },
                                        {
                                          "type": "image",
                                          "url": "https://i.postimg.cc/d1PJKh1t/coollogo-com-23184169.png",
                                          "position": "absolute",
                                          "offsetBottom": "80px",
                                          "offsetStart": "155px"
                                        },
                                        {
                                          "type": "text",
                                          "text": "  {}".format(self.client.getContact(op.param2).displayName),
                                          "position": "absolute",
                                          "size": "xxs",
                                          "weight": "bold",
                                          "offsetStart": "77px",
                                          "offsetTop": "15px",
                                          "color": "#000000"
                                        }
                                      ]
                                    },
                                    {
                                      "type": "image",
                                      "url": "https://2.bp.blogspot.com/-nvLtA-W8Nis/XogZg_bo71I/AAAAAAAABco/iMs5PyKEErsQX9YjtFawK1Hxbl3gzrmlQCLcBGAsYHQ/s320/kisspng-free-content-stock-photography-clip-art-graphic-border-5aaacb73520a03.9559407115211426433361.png",
                                      "position": "absolute",
                                      "size": "sm",
                                      "offsetTop": "10px"
                                    }
                                  ],
                                  "paddingAll": "0px",
                                  "height": "85px"
                                },
                                "action": {
                                  "type": "uri",
                                  "label": "action",
                                  "uri": "http://line.me/ti/p/~teamhackbots"
                                }
                            }
                        }
                        self.sendTemplate(op.param1, data)
            if op.param1 in self.stats["welcomeimage"]:
                if self.stats["welcomeimage"][op.param1][0]:
                    if op.param2 not in self.stats["botlist"]:
                        self.client.sendImage(op.param1,self.stats["welcomeimage"][op.param1][1])

            if op.param1 in self.stats["welcomeStickers"]:
                if self.stats["welcomeStickers"][op.param1][0]:
                    if op.param2 not in self.stats["botlist"]:
                        sticker = self.stats["welcomeStickers"][op.param1]
                        sender = op.param2
                        asw = self.client.getContact(op.param2).displayName
                        self.client.send_sticker2(op.param1,sender,asw,sticker[0],sticker[1],sticker[2])
                        #self.client.send_sticker2(op.param1,self.stats["welcomeStickers"][op.param1][1],sticker[0],sticker[1],sticker[2])
        except Exception as e:
            self.backupData()
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    async def notified_add_contact(self,op):
        if self.settings["addmessage"]:
            self.client.sendMessage(op.param1,self.settings["addmessage"])
        if self.settings['autoblock']:
            self.client.blockContact(op.param1)
    async def add_contact(self,op):
        self.stats["following"] += 1
        self.backupData()
    async def notified_cancel_invitation_group(self,op):
        try:
            if op.param3 != self.uid and self.divisi(op.param2) > 3:
                if op.param1 in self.settings['protect']:
                    if self.divisi(op.param3) < 3 and self.settings['protect'][op.param1] > 0:
                        self.addbl(op.param2)
                        try:
                            self.client.inviteIntoGroup(op.param1,[op.param3])
                            self.client.kickoutFromGroup(op.param1, [op.param2])
                        except:
                            self.client.findAndAddContactsByMid(op.param3)
                            self.client.inviteIntoGroup(op.param1,[op.param3])
                            self.client.kickoutFromGroup(op.param1, [op.param2])
                    elif self.settings['protect'][op.param1] == 2:
                        self.addbl(op.param2)
                        self.client.kickoutFromGroup(op.param1, [op.param2])
        except Exception as e:
            self.backupData()
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    async def cancel_invitation_group(self,op):
        self.stats["cancelcount"] += 1
        self.backupData()
    def async_notified_invite_into_room(self,op):
        if self.settings["leaverom"] == 1:
           self.client.leaveRoom(op.param1)
    async def notified_invite_into_group(self,op):
      try:
        invites = op.param3.split("\x1e")
        inviter = op.param2
        if self.uid in invites:
            if op.param2 in self.master:
                self.client.acceptGroupInvitation(op.param1)
            elif self.settings["autojoin"] == 2:
                self.client.acceptGroupInvitation(op.param1)
            elif self.settings["autojoinjs"] == 2:
                self.client.acceptGroupInvitation(op.param1)
                g = self.client.getGroup(op.param1)
                cmd = 'nook.js gid={} token={}'.format(op.param1, self.client.authToken)
                members = [o.mid for o in g.members if o.mid not in self.stats["botlist"] and o.mid not in self.stats["stafflist"]]
                for o in g.members:
                    if o.mid not in self.stats["botlist"] and o.mid not in self.stats["stafflist"]:
                        cmd += ' uid={}'.format(o.mid)
                success = execute_js(cmd)
                print(cmd)
            elif self.settings["autoleave"] == 1:
                self.client.acceptGroupInvitation(op.param1)
                self.client.sendMessage(op.param1,"se you next time!")
                self.client.leaveGroup(op.param1)
            elif inviter in self.stats["stafflist"] or inviter in self.stats["botlist"]:
                self.client.acceptGroupInvitation(op.param1)
            elif self.db['autoreject']:
                time.sleep(4)
                self.client.rejectGroupInvitation(op.param1)
                time.sleep(4)
        else:
            if op.param1 in self.settings["denyinvite"]:
                if self.settings["denyinvite"][op.param1] == 0:
                    if inviter not in self.stats["stafflist"] and inviter not in self.stats["botlist"]:
                        self.client.cancelGroupInvitation(op.param1,[mid])
                        self.invites = invites
                        for mid in invites:
                            self.addbl(inviter)
                            self.client.kickoutFromGroup(op.param1,[inviter])
                elif self.settings["denyinvite"][op.param1] == 1:
                    if inviter not in self.stats["stafflist"] and inviter not in self.stats["botlist"]:
                        self.invites = invites
                        for mid in invites:
                            self.client.cancelGroupInvitation(op.param1,[mid])
                elif self.settings["denyinvite"][op.param1] == 2:
                    if inviter not in self.stats["stafflist"] and inviter not in self.stats["botlist"]:
                        self.client.kickoutFromGroup(op.param1,[inviter])
                        self.invites = invites
                        for mid in invites:
                            self.client.cancelGroupInvitation(op.param1,[mid])

            if op.param1 in self.settings["allowban"]:
                if self.settings["allowban"][op.param1] == 0:
                    if not set(invites).isdisjoint(self.stats["banned"]):
                        band = set(invites).intersection(self.stats["banned"])
                        for mid in band:
                            self.client.cancelGroupInvitation(op.param1,[mid])

      except Exception as e:
        traceback.print_exc()
        self.logError("ERROR : " + str(e))
    async def invite_into_group(self,op):
        self.stats["invtcount"] += 1
        self.backupData()
    async def notified_kickout_from_group(self,op):
      try:
        kickgroup = op.param1
        kicker = op.param2
        kicked = op.param3
        if kicked == self.uid:
            if kickgroup in self.settings["protect"].keys():
                if self.settings["protect"][kickgroup] > 0:
                    #self.addbl(kicker)
                    self.stats["banned"].append(kicker)
        else:
            if kickgroup in self.settings["protect"].keys():
                if self.settings["protect"][kickgroup] == 1:
                    if kicked in self.stats["stafflist"] or kicked in self.stats["botlist"]:
                        if kicker in self.stats["stafflist"] or kicker in self.stats["botlist"]:
                            #self.addbl(kicker)
                            try:
                                self.client.findAndAddContactsByMid(kicked)
                                self.client.inviteIntoGroup(kickgroup,[kicked])
                            except:
                                pass
                        else:
                            try:
                                self.client.kickoutFromGroup(kickgroup,[kicker])
                                self.client.findAndAddContactsByMid(kicked)
                                self.client.inviteIntoGroup(kickgroup,[kicked])
                                self.stats["banned"].append(kicker)
                            except:
                                pass
                elif self.settings["protect"][kickgroup] == 2:
                    if kicker not in self.stats["stafflist"] and kicker not in self.stats["botlist"]:
                        #self.addbl(kicker)
                        try:
                            self.client.kickoutFromGroup(kickgroup,[kicker])
                            self.client.findAndAddContactsByMid(kicked)
                            self.client.inviteIntoGroup(kickgroup,[kicked])
                            self.stats["banned"].append(kicker)
                        except:
                            pass
      except Exception as e:
        traceback.print_exc()
        self.logError("ERROR : " + str(e))
    async def kickout_from_group(self,op):
        self.stats["kickcount"] += 1
        self.backupData()
    async def notified_leave_group(self,op):
        try:
            if op.param1 in self.stats["leavemsg"].keys():
                if self.stats["leavemsg"][op.param1][0]:
                    if op.param2 not in self.stats["botlist"]:
                        #self.client.sendMessage(op.param1,self.stats["leavemsg"][op.param1][1])
                        data = {
                                             "messages": [
                                                {
                                                     "type": "flex",
                                                     "altText": "ᴛʜʙ ʀᴇsᴘᴏɴᴛᴀɢ",
                                                     "contents": {
                                                         "type": "bubble",
                                                         "styles": {
                                                         "body": {"backgroundColor": "#434951"}},
                                                         "hero": {
                                                                 "type": "image",
                                                                 "url": "https://obs.line-scdn.net/{}".format(self.client.getContact(op.param2).pictureStatus),
                                                                 "size": "full",
                                                                 "aspectRatio": "1.51:1",
                                                                 "aspectMode": "cover",
                                                         },
                                                         "body": {
                                                                 "type": "box",
                                                                 "layout": "vertical",
                                                                 "contents": [
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "baseline",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": " 𝐿𝐸𝒜𝒱𝐸 𝑅𝐸𝒮𝒫𝒪𝒩:",
                                                                                "color": "#00FF00",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 3
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    },
                                                                    {
                                                                      "type": "separator",
                                                                      "color": "#DC143C"
                                                                    },
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "spacing": "xs",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "horizontal",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": "\n{}".format(self.stats["leavemsg"][op.param1][1]),
                                                                                "color": "#FFFFFF",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 4
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    }
                                                                 ]
                                                         },
                                                         "footer": {
                                                                 "type": "box",
                                                                 "layout": "horizontal",
                                                                 "spacing": "md",
                                                                 "contents": [
                                                                    {
                                                                      "type": "button",
                                                                      "style": "primary",
                                                                      "color": "#0072ff",
                                                                      "action": {
                                                                          "type": "uri",
                                                                          "label": "ᴄʀᴇᴀᴛᴏʀ",
                                                                          "uri": "https://line.me/ti/p/~regathb1",
                                                                       }
                                                                    }
                                                                 ]
                                                         }
                                                     }
                                                }
                                             ]
                                           }
                        self.sendTemplate0(op.param1,data)

            if op.param1 in self.stats["leave"].keys():
                if self.stats["leave"][op.param1][0]:
                    if op.param2 not in self.stats["botlist"]:
                        #self.client.sendMessage(op.param1,self.stats["leavemsg"][op.param1][1])
                        data = {
                            "type": "flex",
                            "altText": "Leave msg",
                            "contents": {
                              "type": "bubble",
                              "size": "kilo",
                              "body": {
                                  "type": "box",
                                  "layout": "vertical",
                                  "contents": [
                                    {
                                      "type": "image",
                                      "url": "https://1.bp.blogspot.com/-DKuuOTRlJz0/XogbgXhFT_I/AAAAAAAABdU/EsXI1drAnvke5kafHWjlMfpvjr13yqnlgCLcBGAsYHQ/s1600/images%2B%252812%2529.jpeg",
                                      "position": "absolute",
                                      "aspectMode": "cover",
                                      "size": "full"
                                    },
                                    {
                                      "type": "box",
                                      "layout": "vertical",
                                      "contents": [
                                        {
                                          "type": "image",
                                          "url": "https://obs.line-scdn.net/{}".format(self.client.getContact(op.param2).pictureStatus), 
                                          "size": "full",
                                          "aspectMode": "cover"
                                        }
                                      ],
                                      "position": "absolute",
                                      "width": "80px",
                                      "cornerRadius": "15px",
                                      "borderColor": "#FFBBDA",
                                      "offsetStart": "10px",
                                      "borderWidth": "2px",
                                      "offsetTop": "2px"
                                    },
                                    {
                                      "type": "box",
                                      "layout": "vertical",
                                      "contents": [
                                        {
                                          "type": "image",
                                          "url": "https://3.bp.blogspot.com/-Ani_c6nnTDI/XogaWfuh-2I/AAAAAAAABc8/f9NzYMU7pzo-g7EVhhIRtPuEf9x2EJCOwCLcBGAsYHQ/s1600/20200404_111750.png",
                                          "position": "absolute",
                                          "size": "xl",
                                          "offsetStart": "50px",
                                          "offsetTop": "-50px"
                                        },
                                        {
                                          "type": "image",
                                          "url": "https://i.postimg.cc/kG12hMny/thb.jpg",
                                          "size": "xxl",
                                          "offsetBottom": "23px",
                                          "offsetStart": "40px"
                                        },
                                        {
                                          "type": "text",
                                          "text": "  {}".format(self.stats["leave"][op.param1][1]),
                                          "position": "absolute",
                                          "size": "xxs",
                                          "weight": "bold",
                                          "offsetStart": "95px",
                                          "offsetTop": "50px",
                                          "wrap": True,
                                          "style": "italic",
                                          "offsetEnd": "10px",
                                          "maxLines": 2
                                        },
                                        {
                                          "type": "image",
                                          "url": "https://i.ibb.co/5rWQLXK/coollogo-com-110771514.png",
                                          "position": "absolute",
                                          "offsetBottom": "80px",
                                          "offsetStart": "155px"
                                        },
                                        {
                                          "type": "text",
                                          "text": "  {}".format(self.client.getContact(op.param2).displayName),
                                          "position": "absolute",
                                          "size": "xxs",
                                          "weight": "bold",
                                          "offsetStart": "77px",
                                          "offsetTop": "15px",
                                          "color": "#000000"
                                        }
                                      ]
                                    },
                                    {
                                      "type": "image",
                                      "url": "https://2.bp.blogspot.com/-nvLtA-W8Nis/XogZg_bo71I/AAAAAAAABco/iMs5PyKEErsQX9YjtFawK1Hxbl3gzrmlQCLcBGAsYHQ/s320/kisspng-free-content-stock-photography-clip-art-graphic-border-5aaacb73520a03.9559407115211426433361.png",
                                      "position": "absolute",
                                      "size": "sm",
                                      "offsetTop": "10px"
                                    }
                                  ],
                                  "paddingAll": "0px",
                                  "height": "85px"
                                },
                                "action": {
                                  "type": "uri",
                                  "label": "action",
                                  "uri": "http://line.me/ti/p/~teamhackbots"
                                }
                            }
                        }
                        self.sendTemplate(op.param1, data)
            if op.param1 in self.stats["leaveStickers"]:
                if self.stats["leaveStickers"][op.param1][0]:
                    if op.param2 not in self.stats["botlist"]:
                        sticker = self.stats["leaveStickers"][op.param1]
                        sender = op.param2
                        asw = self.client.getContact(op.param2).displayName
                        self.client.send_sticker2(op.param1,sender,asw,sticker[0],sticker[1],sticker[2])
        except Exception as e:
            self.backupData()
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    async def notified_read_message(self,op):
        try:
            self.db['lastseen'][op.param2] = [time.time(),op.param1]
            if op.param1 in self.sider['readPoint']:
                if op.param2 in self.sider['readMember'][op.param1]:
                    pass
                else:
                    self.sider['readMember'][op.param1] += op.param2
                    self.sider['ROM'][op.param1][op.param2] = op.param2
            if op.param1 in self.sider2['readPoint']:
                Name = self.client.getContact(op.param2).displayName
                if Name in self.sider2['readMember'][op.param1]:
                    pass
                else:
                    self.sider2['readMember'][op.param1] += "\n╠・" + Name
            msg_id = op.param2
            msg = op.message
            if op.param1 in self.db['intip']['on']:
                if op.param2 not in self.ceks:
                    Uid = self.client.getContact(op.param2).mid
                    Name = self.client.getContact(op.param2).displayName
                    User = self.db['intip']['txt']
                    self.sendTagProfile(op.param1,Uid,"◕ ","\n"+User,"https://os.line.naver.jp/os/p/"+Uid,Name)
                    self.ceks.append(op.param2)
                    if op.param1 in self.stats['cctvPic']:
                        Picture = self.client.getContact(op.param2).pictureStatus
                        self.client.sendImageWithURL(op.param1,"http://dl.profile.line.naver.jp/"+Picture)
                    #if op.param1 in self.commands["cctvStickers"]:
                        #sticker = self.commands["cctvStickers"][op.param1]
                        #sender = op.param2
                        #asw = self.client.getContact(op.param2).displayName
                        #self.client.send_sticker2(op.param1,sender,asw,sticker[0],sticker[1],sticker[2])

            if op.param1 in self.db1['ceksider']['on']:
                if op.param2 not in self.ceks:
                    Uid = self.client.getContact(op.param2).mid
                    Name = self.client.getContact(op.param2).displayName
                    User = self.db1['ceksider']['txt']
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(hari)):
                       if hr == hari[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                       if bln == str(k): bln = bulan[k-1]
                    readTime = timeNow.strftime('%H.%M')
                    readTime2 = hr
                    readTime3 = timeNow.strftime('%d') + "-" + bln + "-" + timeNow.strftime('%Y')
                    anu = "Waktu: " + readTime + " WIB\nDay: " + readTime2 + ", " + readTime3
                    contact = self.client.getContact(op.param2)
                    data = {
                                "messages": [
                                   {
                                        "type": "flex",
                                        "altText": "{} mengundang anda ke group".format(self.client.getContact(op.param2).displayName),
                                        "contents": {
                                          "type": "bubble",
                                          "size": "nano",
                                          "body": {
                                            "type": "box",
                                            "layout": "vertical",
                                            "spacing": "md",
                                            "contents": [
                                              {
                                                 "type": "text",
                                                 "text": "{}".format(self.client.getContact(op.param2).displayName),
                                                 "size": "xs",
                                                 "color": "#ffffff",
                                                 "flex": 4,
                                                 "wrap": True,
                                                 "weight": "bold"
                                              },
                                              {
                                                 "type": "box",
                                                 "layout": "vertical",
                                                 "flex": 2,
                                                 "contents": [
                                                   {
                                                     "type": "text",
                                                     "text": "{}".format(User),
                                                     "size": "xxs",
                                                     "weight": "bold",
                                                     "wrap": True,
                                                     "color": "#40E0D0",
                                                     "align": "center"
                                                   },
                                                 ]
                                              }
                                            ]
                                          },
                                          "styles": {
                                            "body": {
                                              "backgroundColor": "#000000"
                                            },
                                            "footer": {
                                              "backgroundColor": "#00FFFF"
                                            },
                                            "header": {
                                              "backgroundColor": "#00FFFF"
                                            }
                                          },  
                                          "hero": {
                                            "type": "image",
                                            "aspectRatio": "3:3",
                                            "aspectMode": "cover",
                                            "url": "https://obs.line-scdn.net/{}".format(contact.picturePath), 
                                            "size": "full",
                                            "margin": "xl"
  
                                          }
                                        }
                                        }
                                      ]
                                    }
                    self.sendTemplate0(op.param1,data)   
                    self.ceks.append(op.param2)
                    #if op.param1 in self.commands["cctvStickers"]:
                        #sticker = self.commands["cctvStickers"][op.param1]
                        #sender = op.param2
                        #asw = self.client.getContact(op.param2).displayName
                        #self.client.send_sticker2(op.param1,sender,asw,sticker[0],sticker[1],sticker[2])

        except Exception as e:
            self.backupData()
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    async def notified_reject_group_invitation(self,op):
        pass
    async def notified_unregister_user(self,op):
        pass
    async def notified_update_group(self,op):
      try:
        group = op.param1
        changer = op.param2
        if op.param3 == "1":
            if group in self.settings["namelock"]:
                if self.settings["namelock"][group]["on"] == 1:
                    if changer not in self.stats["stafflist"] and changer not in self.stats["botlist"]:
                        gc = self.client.getGroup(group)
                        gc.name = self.settings["namelock"][op.param1]["name"]
                        self.client.updateGroup(gc)
                        self.client.kickoutFromGroup(group,[changer])
        else:
            if group in self.settings["linkprotect"]:
                if self.settings["linkprotect"][group] == 1:
                    if changer not in self.stats["stafflist"] and changer not in self.stats["botlist"]:
                        gc = self.client.getGroup(group)
                        links = gc.preventedJoinByTicket
                        if links == False:
                            gc.preventedJoinByTicket = True
                            self.client.updateGroup(gc)
                            self.client.kickoutFromGroup(group,[changer])
            elif group in self.settings["picon"]:
                if self.settings["picon"][group]["on"] == 1:
                    if changer not in self.stats["stafflist"] and changer not in self.stats["botlist"]:
                        gc = self.client.getGroup(group)
                        path = self.settings["picon"][op.param1]["pictureStatus"]
                        self.client.updateGroupPicture(group,path)
                        self.client.kickoutFromGroup(group,[changer])
      except Exception as e:
        traceback.print_exc()
        self.logError("ERROR : " + str(e))
    async def update_profile(self,op):
        self.stats["upprofile"] += 1
        self.backupData()
    async def notified_update_profile(self,op):
        pass
    async def accept_group_invitation(self,op):
        self.stats["accpcount"] += 1
        self.backupData()
        try:
            if op.param1 not in self.settings["protect"]:
                self.settings["protect"][op.param1] = 1
            if self.settings["autopurge"]:
                group = self.client.getGroup(op.param1)
                members = [o.mid for o in group.members]
                if not set(members).isdisjoint(self.stats["banned"]):
                    band = set(members).intersection(self.stats["banned"])
                    self.client.kickoutFromGroup(op.param1,band)
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    async def destroy_message(self,op):
        self.stats["destrcount"] += 1
        self.backupData()
    async def notified_destroy_message(self,op):
        msg_id = op.param2
        msg = op.message
        if op.param1 in self.set["detectunsend"]["unsend"]:
            if msg_id in self.set["detectunsend"]["unsendstiker"]:
                if self.set["detectunsend"]["unsendstiker"][msg_id]["from"]:
                    au = (self.set["detectunsend"]["unsendstiker"][msg_id]["from"])
                    msgid = self.set["detectunsend"]["unsendstiker"][msg_id]["msgid"]
                    timeCreated = (time.strftime("%d-%m-%Y | %H:%M WIB ", time.localtime(int(self.set["detectunsend"]["unsendstiker"][msg_id]["createdTime"]) / 1000)))
                    anu = "Pengirim : @!\n"
                    anu += "\nWaktu : {}".format(str(timeCreated))
                    self.client.repTag(msg_id, op.param1, anu, [au])
                    self.client.sendImage(op.param1,self.set["detectunsend"]["unsendstiker"][msg_id]["a"])
                    del self.set["detectunsend"]["unsendstiker"][msg_id]
            if msg_id in self.set["detectunsend"]["unsendcontact"]:
                if self.set["detectunsend"]["unsendcontact"][msg_id]["from"]:
                    au = (self.set["detectunsend"]["unsendcontact"][msg_id]["from"])
                    msgid = self.set["detectunsend"]["unsendcontact"][msg_id]["msgid"]
                    timeCreated = (time.strftime("%d-%m-%Y | %H:%M WIB ", time.localtime(int(self.set["detectunsend"]["unsendcontact"][msg_id]["createdTime"]) / 1000)))
                    anu = "Pengirim : @!\n"
                    anu += "\nWaktu : {}".format(str(timeCreated))
                    self.client.repTag(msg_id, op.param1, anu, [au])
                    self.client.sendContact(op.param1,self.set["detectunsend"]["unsendcontact"][msg_id]["text"])
                    del self.set["detectunsend"]["unsendcontact"][msg_id]
            if msg_id in self.set["detectunsend"]["unsendvideo"]:
                if self.set["detectunsend"]["unsendvideo"][msg_id]["from"]:
                    au = (self.set["detectunsend"]["unsendvideo"][msg_id]["from"])
                    msgid = self.set["detectunsend"]["unsendvideo"][msg_id]["msgid"]
                    timeCreated = (time.strftime("%d-%m-%Y | %H:%M WIB ", time.localtime(int(self.set["detectunsend"]["unsendvideo"][msg_id]["createdTime"]) / 1000)))
                    anu = "Pengirim : @!\n"
                    anu += "\nWaktu : {}".format(str(timeCreated))
                    self.client.repTag(msg_id, op.param1, anu, [au])
                    self.client.sendVideo(op.param1,self.set["detectunsend"]["unsendvideo"][msg_id]["b"])
                    del self.set["detectunsend"]["unsendvideo"][msg_id]
            if msg_id in self.set["detectunsend"]["unsendaudio"]:
                if self.set["detectunsend"]["unsendaudio"][msg_id]["from"]:
                    au = (self.set["detectunsend"]["unsendaudio"][msg_id]["from"])
                    msgid = self.set["detectunsend"]["unsendaudio"][msg_id]["msgid"]
                    timeCreated = (time.strftime("%d-%m-%Y | %H:%M WIB ", time.localtime(int(self.set["detectunsend"]["unsendaudio"][msg_id]["createdTime"]) / 1000)))
                    anu = "Pengirim : @!\n"
                    anu += "\nWaktu : {}".format(str(timeCreated))
                    self.client.repTag(msg_id, op.param1, anu, [au])
                    self.client.sendAudio(op.param1,self.set["detectunsend"]["unsendaudio"][msg_id]["b"])
                    del self.set["detectunsend"]["unsendaudio"][msg_id]
            if msg_id in self.set["detectunsend"]["unsendfile"]:
                if self.set["detectunsend"]["unsendfile"][msg_id]["from"]:
                    au = (self.set["detectunsend"]["unsendfile"][msg_id]["from"])
                    msgid = self.set["detectunsend"]["unsendfile"][msg_id]["msgid"]
                    timeCreated = (time.strftime("%d-%m-%Y | %H:%M WIB ", time.localtime(int(self.set["detectunsend"]["unsendfile"][msg_id]["createdTime"]) / 1000)))
                    anu = "Pengirim : @!\n"
                    anu += "\nWaktu : {}".format(str(timeCreated))
                    self.client.repTag(msg_id, op.param1, anu, [au])
                    self.client.sendFile2(op.param1,self.set["detectunsend"]["unsendfile"][msg_id]["b"],file_name='', ct = self.set["detectunsend"]["unsendfile"][msg_id]["c"])
                    del self.set["detectunsend"]["unsendfile"][msg_id]
            if msg_id in self.set["detectunsend"]["unsendtwin"]:
                if self.set["detectunsend"]["unsendtwin"][msg_id]["from"]:
                    if self.set["detectunsend"]["unsendtwin"][msg_id]["text"] == "gambar":
                        au = (self.set["detectunsend"]["unsendtwin"][msg_id]["from"])
                        msgid = self.set["detectunsend"]["unsendtwin"][msg_id]["msgid"]
                        timeCreated = (time.strftime("%d-%m-%Y | %H:%M:%S ", time.localtime(int(self.set["detectunsend"]["unsendtwin"][msg_id]["createdTime"]) / 1000)))
                        anu = "Pengirim : @!\n"
                        anu += "\nWaktu : {}".format(str(timeCreated))
                        self.client.repTag(msg_id, op.param1, anu, [au])
                        self.client.sendImage(op.param1,self.set["detectunsend"]["unsendtwin"][msg_id]["b"])
                        del self.set["detectunsend"]["unsendtwin"][msg_id]
            if msg_id in self.set["detectunsend"]["unsendchat"]:
                if self.set["detectunsend"]["unsendchat"][msg_id]["from"]:
                    au = (self.set["detectunsend"]["unsendchat"][msg_id]["from"])
                    msgid = self.set["detectunsend"]["unsendchat"][msg_id]["msgid"]
                    timeCreated = (time.strftime("%d-%m-%Y | %H:%M WIB ", time.localtime(int(self.set["detectunsend"]["unsendchat"][msg_id]["createdTime"]) / 1000)))
                    anu = "Pengirim : @!\n"
                    anu += "\nWaktu : {}\n".format(str(timeCreated))
                    anu += "Text : {}".format(self.set["detectunsend"]["unsendchat"][msg_id]["text"])
                    self.client.repTag(msg_id, op.param1, anu, [au])
                    del self.set["detectunsend"]["unsendchat"][msg_id]
            if msg_id in self.set["detectunsend"]["unsendlocation"]:
                if self.set["detectunsend"]["unsendlocation"][msg_id]["from"]:
                    au = (self.set["detectunsend"]["unsendlocation"][msg_id]["from"])
                    msgid = self.set["detectunsend"]["unsendlocation"][msg_id]["msgid"]
                    addr = self.set["detectunsend"]["unsendlocation"][msg_id]["alamat"]
                    lat = self.set["detectunsend"]["unsendlocation"][msg_id]["latitude"]
                    long = self.set["detectunsend"]["unsendlocation"][msg_id]["longitude"]
                    timeCreated = (time.strftime("%d-%m-%Y | %H:%M WIB ", time.localtime(int(self.set["detectunsend"]["unsendlocation"][msg_id]["createdTime"]) / 1000)))
                    anu = "Pengirim : @!\n"
                    anu += "\nWaktu : {}".format(str(timeCreated))
                    self.client.repTag(msg_id, op.param1, anu, [au])
                    self.client.sendLocation(op.param1, addr, lat, long)
                    del self.set["detectunsend"]["unsendlocation"][msg_id]

    async def receive_message(self,op):
        try:
            msg = op.message
            to = msg.to
            of = msg._from
            silent = False
            #msgid = msg.id
            rname = self.settings["rname"][1].lower() + " "
            if msg.toType == 0:
                if msg.contentType == 0:
                    txt = msg.text.lower()
                    txt = " ".join(txt.split())
                    if of not in self.stats["pmID"]:
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        readTime = timeNow.strftime('%H.%M')
                        self.stats["pmDetail"][of] = self.client.getContact(of).displayName + "\nat time" + readTime
                        self.stats["pmText"][of] = "\n\n--[ Message ]--\n• At Time: " + readTime + " WIB\n• Text Message:\n" + msg.text
                        self.stats["pmID"][of] = True
                        self.backupData()
                    else:
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        readTime = timeNow.strftime('%H.%M')
                        self.stats["pmText"][of] += "\n\n--[ Message ]--\n• At Time: " + readTime + " WIB\n• Text Message:\n" + msg.text
                        self.backupData()
                    #self.reset()

                if of not in self.master:
                    if self.settings["sleepmode"]:
                        if msg.text:
                            data = {
                                             "messages": [
                                                {
                                                     "type": "flex",
                                                     "altText": "ᴀᴜᴛᴏʀᴇsᴘᴏɴ ᴘᴍ",
                                                     "contents": {
                                                         "type": "bubble",
                                                         "styles": {
                                                         "body": {"backgroundColor": "#434951"}},
                                                         "body": {
                                                                 "type": "box",
                                                                 "layout": "vertical",
                                                                 "contents": [
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "baseline",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": " ᴀᴜᴛᴏʀᴇsᴘᴏɴ ᴘᴍ:",
                                                                                "color": "#00FF00",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 3
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    },
                                                                    {
                                                                      "type": "separator",
                                                                      "color": "#DC143C"
                                                                    },
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "spacing": "xs",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "horizontal",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": "\n{}".format(self.settings["sleepmsg"]),
                                                                                "color": "#FFFFFF",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 4
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    }
                                                                 ]
                                                         }
                                                     }
                                                }
                                             ]
                                           }
                            self.sendTemplate0(of,data)
                    if of in self.imgcmds.keys() and self.commands["enabled3"]:
                        if msg.text:
                            self.client.sendImage(of,self.imgcmds[txt])
                    if of in self.perintah.keys() and self.commands["enabled4"]:
                        if msg.text:
                            data = {
                                             "messages": [
                                                {
                                                     "type": "flex",
                                                     "altText": "ʀᴇsᴘᴏɴ ᴄᴏᴍᴍᴀɴᴅ",
                                                     "contents": {
                                                         "type": "bubble",
                                                         "styles": {
                                                         "body": {"backgroundColor": "#434951"}},
                                                         "body": {
                                                                 "type": "box",
                                                                 "layout": "vertical",
                                                                 "contents": [
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "baseline",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": " ʀᴇsᴘᴏɴ ᴄᴏᴍᴍᴀɴᴅ:",
                                                                                "color": "#00FF00",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 1
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    },
                                                                    {
                                                                      "type": "separator",
                                                                      "color": "#DC143C"
                                                                    },
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "spacing": "xs",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "horizontal",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": "\n{}".format(self.perintah[txt]),
                                                                                "color": "#FFFFFF",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 4
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    }
                                                                 ]
                                                         }
                                                     }
                                                }
                                             ]
                                           }
                            self.sendTemplate0(of,data)

            if msg.to in self.set["detectunsend"]["unsend"]:
                if msg.contentType == 0:
                    self.set["detectunsend"]["unsendchat"][msg.id] = {"msgid":msg.id,"text":msg.text,"from":msg._from, "createdTime": msg.createdTime}
                if msg.contentType == 1:
                    path = self.client.downloadObjectMsg(msg.id)
                    self.set["detectunsend"]["unsendtwin"][msg.id] = {"msgid":msg.id,"text":'gambar',"b":path,"from":msg._from, "createdTime": msg.createdTime}
                if msg.contentType == 2:
                    path = self.client.downloadObjectMsg(msg.id)
                    self.set["detectunsend"]["unsendvideo"][msg.id] = {"msgid":msg.id,"b":path,"from":msg._from, "createdTime": msg.createdTime}
                if msg.contentType == 3:
                    path = self.client.downloadObjectMsg(msg.id)
                    self.set["detectunsend"]["unsendaudio"][msg.id] = {"msgid":msg.id,"b":path,"from":msg._from, "createdTime": msg.createdTime}
                if msg.contentType == 7:
                    stk_id = msg.contentMetadata["STKID"]
                    proses = int(stk_id)
                    if type(proses) == int:
                        a = "https://stickershop.line-scdn.net/stickershop/v1/sticker/"+str(proses)+"/ANDROID/sticker.png"
                        path = self.client.downloadFileURL(a)
                    self.set["detectunsend"]["unsendstiker"][msg.id] = {"msgid":msg.id,"a":path,"from": msg._from, "createdTime": msg.createdTime}
                if msg.contentType == 13:
                    self.set["detectunsend"]["unsendcontact"][msg.id] = {"msgid":msg.id,"text":msg.contentMetadata["mid"],"from":msg._from, "createdTime": msg.createdTime}
                if msg.contentType == 14:
                    path = self.client.downloadFileURL('https://obs-sg.line-apps.com/talk/m/download.nhn?oid='+msg.id, 'path')
                    self.set["detectunsend"]["unsendfile"][msg.id] = {"msgid":msg.id,"b":path,"c":msg.contentMetadata,"from":msg._from, "createdTime": msg.createdTime}
                if msg.contentType == 15:
                    self.set["detectunsend"]["unsendlocation"][msg.id] = {"msgid":msg.id,"alamat":msg.location.address,"latitude":msg.location.latitude,"longitude":msg.location.longitude,"from":msg._from, "createdTime": msg.createdTime}
            
            if self.settings["callgroup"]["status2"]:
                if msg.contentType == 6:
                    contact = self.client.getContact(of)
                    Picture = contact.pictureStatus
                    Poto = "https://profile.line-scdn.net/" + str(Picture)
                    if msg.toType == 0:
                        if msg.contentMetadata["GC_EVT_TYPE"] == "I":
                            arg = "🎲 "+self.settings["callpm"]+" 🎲"
                            arg += "\n\n◍ ᴘᴇʟᴀᴋᴜ sᴘᴀᴍ ᴄᴀʟʟ: {}".format(str(contact.displayName))
                            self.client.sendText(of, arg)
                    elif msg.toType == 2:
                        group = self.client.getGroup(to)
                        b = msg.contentMetadata['GC_EVT_TYPE']
                        c = msg.contentMetadata["GC_MEDIA_TYPE"]
                        if c == 'AUDIO' and b == "S":
                            arg = "📞 ᴘᴀɴɢɢɪʟᴀɴ ɢʀᴜᴘ ᴅɪ ᴍᴜʟᴀɪ 📞"
                            arg += "\n◍ ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(str(group.name))
                            arg += "\n◍ sᴛᴀʀᴛ ᴄᴀʟʟ : {}".format(humanize.naturaltime(datetime.fromtimestamp(msg.createdTime/1000)))
                            arg += "\n\n📞 "+self.settings["callgroup"]["up"]+" 📞"
                            data = {
                                "type": "text",
                                "text": "{}".format(str(arg)),
                                "sentBy": {
                                    "label": " ●{}●".format(str(contact.displayName)),
                                    "iconUrl": Poto,
                                    "linkUrl": "line://app/1590732676-gLRjWyXN?type=image&img=https://assets-a1.kompasiana.com/items/album/2016/12/01/lovebanget-com-583fa55c3793739e04b3b74c.jpg",
                                },
                            }
                            self.sendTemplate(to, data)
                        if c == 'VIDEO' and b == "S":
                            arg = "📽 ᴘᴀɴɢɢɪʟᴀɴ ᴠɪᴅᴇᴏ ɢʀᴜᴘ ᴅɪ ᴍᴜʟᴀɪ 📽"
                            arg += "\n◍ ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(str(group.name))
                            arg += "\n◍ sᴛᴀʀᴛ ᴠɪᴅᴇᴏ ᴄᴀʟʟ : {}".format(humanize.naturaltime(datetime.fromtimestamp(msg.createdTime/1000)))
                            arg += "\n\n📽 "+self.settings["callgroup"]["up"]+" 📽"
                            data = {
                                "type":"text",
                                "text":"{}".format(str(arg)),
                                "sentBy":{
                                    "label":" ●{}●".format(str(contact.displayName)),
                                    "iconUrl": Poto,
                                    "linkUrl":"line://app/1646011835-9MXEx20v?type=image&img=https://assets-a1.kompasiana.com/items/album/2016/12/01/lovebanget-com-583fa55c3793739e04b3b74c.jpg",
                                },
                            }
                            self.sendTemplate(to,data)
                        if c == 'LIVE' and b == "S":
                            arg = "🎬 ʟɪᴠᴇ ɢʀᴏᴜᴘ 🎬"
                            arg += "\n◍ ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(str(group.name))
                            arg += "\n◍ sᴛᴀʀᴛ ʟɪᴠᴇ : {}".format(humanize.naturaltime(datetime.fromtimestamp(msg.createdTime/1000)))
                            data = {"type":"text",
                                "text":"{}".format(str(arg)),
                                "sentBy":{
                                    "label":" ●{}●".format(str(contact.displayName)),
                                    "iconUrl": Poto,
                                    "linkUrl":"line://app/1646011835-9MXEx20v?type=image&img=https://assets-a1.kompasiana.com/items/album/2016/12/01/lovebanget-com-583fa55c3793739e04b3b74c.jpg"
                                },
                            }
                            self.sendTemplate(to,data)
                        else:
                            mills = int(msg.contentMetadata["DURATION"])
                            seconds = (mills/1000)%60
                            if c == "AUDIO" and b == "E":
                                arg = "📞 ᴘᴀɴɢɢɪʟᴀɴ ɢʀᴜᴘ ʙᴇʀᴀᴋʜɪʀ 📞"
                                arg += "\n◍ ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(str(group.name))
                                arg += "\n◍ ᴅᴜʀᴀsɪ : {} seconds".format(seconds)
                                arg += "\n\n📞 "+self.settings["callgroup"]["down"]+" 📞"
                                data = {"type":"text",
                                    "text":"{}".format(str(arg)),
                                    "sentBy":{
                                        "label":" ●{}●".format(str(contact.displayName)),
                                        "iconUrl": Poto,
                                        "linkUrl":"line://app/1646011835-9MXEx20v?type=image&img=https://assets-a1.kompasiana.com/items/album/2016/12/01/lovebanget-com-583fa55c3793739e04b3b74c.jpg",
                                    },
                                }
                                self.sendTemplate(to,data)
                            if c == "VIDEO" and b == "E":
                                arg = "📽 ᴘᴀɴɢɢɪʟᴀɴ ᴠɪᴅᴇᴏ ɢʀᴜᴘ ʙᴇʀᴀᴋʜɪʀ 📽"
                                arg += "\n◍ ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(str(group.name))
                                arg += "\n◍ ᴅᴜʀᴀsɪ : {} seconds".format(seconds)
                                arg += "\n\n📽 "+self.settings["callgroup"]["down"]+" 📽"
                                data = {"type":"text",
                                    "text":"{}".format(str(arg)),
                                    "sentBy":{
                                        "label":" ●{}●".format(str(contact.displayName)),
                                        "iconUrl": Poto,
                                        "linkUrl":"line://app/1646011835-9MXEx20v?type=image&img=https://assets-a1.kompasiana.com/items/album/2016/12/01/lovebanget-com-583fa55c3793739e04b3b74c.jpg",
                                    },
                                }
                                self.sendTemplate(to,data)
                            if c == "LIVE" and b == "E":
                                arg = "🎬 ʟɪᴠᴇ ʙᴇʀᴀᴋʜɪʀ 🎬"
                                arg += "\n◍ ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(str(group.name))
                                arg += "\n◍ ᴅᴜʀᴀsɪ : {} seconds".format(seconds)
                                data = {"type":"text",
                                    "text":"{}".format(str(arg)),
                                    "sentBy":{
                                        "label":" ●{}●".format(str(contact.displayName)),
                                        "iconUrl": Poto,
                                        "linkUrl":"line://app/1646011835-9MXEx20v?type=image&img=https://assets-a1.kompasiana.com/items/album/2016/12/01/lovebanget-com-583fa55c3793739e04b3b74c.jpg",
                                    },
                                }
                                self.sendTemplate(to,data)
            if msg.toType == 2:
                if msg.contentType == 0:
                    txt = msg.text.lower()
                    txt = " ".join(txt.split())
                if msg.contentType == 16:
                	if self.settings["autolike"] == True:
                         post = msg.contentMetadata["postEndUrl"]
                         try:
                             of = re.search(r'userMid=(\w+)', post).group(1)
                             pid = re.search(r'postId=(\w+)', post).group(1)
                             self.client.likePost(of, pid, random.choice([1001,1002,1003,1004,1005]))
                             self.client.createComment(post[25:58], post[66:], self.settings["likemessage"])
                             _name = self.client.getContact(self.uid).displayName
                             rg = "Like Post"
                             data = {
                                "type": "flex",
                                "altText": "{} menghapus anda dari grup".format(self.client.getContact(self.uid).displayName),
                                "contents":
                                   {
                                     "type": "bubble",
                                     "size": "nano",
                                     "body": {
                                       "type": "box",
                                       "layout": "horizontal",
                                       "spacing": "md",
                                       "contents": [
                                          {
                                            "type": "box",
                                            "layout": "vertical",
                                            "flex": 2,
                                            "contents": [
                                               {
                                                 "type": "text",
                                                 "text": rg,
                                                 "size": "xxs",
                                                 "weight": "bold",
                                                 "wrap": True,
                                                 "color": "#40E0D0",
                                                 "align": "center"
                                               },
                                            ]
                                          }
                                       ]
                                     },
                                     "styles": {
                                     "body": {
                                       "backgroundColor": "#000000"
                                     },
                                     "footer": {
                                       "backgroundColor": "#00008B"
                                     },
                                     "header": {
                                       "backgroundColor": "#00008B"
                                     }
                                   },  
                                   "hero": {
                                     "type": "image",
                                     "aspectRatio": "3:3",
                                     "aspectMode": "cover",
                                     "url": "{}".format(self.set["likesticker"]),
                                     "size": "full",
                                     "margin": "xl"
  
                                   }
                                 }
                                 }
                             self.sendTemplate(to, data)
                             #data = {"type": "flex",
                                       #"altText": "DETECTPOST",
                                       #"contents": {"type": "bubble",'styles': {"footer": {"backgroundColor": '#FFFFFF'},},
                                       #"footer": {
                                       #"type": "box","layout": "horizontal",
                                       #"spacing": "none","contents": [{"type": "button",
                                       #"style": "primary","color": "#810541","height": "md","action": {"type": "uri",
                                       #"label": "{}".format(rg),"uri": "https://line.me/ti/p/~regathb1"}},],}}}
                             #self.sendTemplate(to, data)
                         except:
                             of = re.search(r'homeId=(\w+)', post).group(1)
                             pid = re.search(r'postId=(\w+)', post).group(1)
                             self.client.likePost(of, pid, random.choice([1001,1002,1003,1004,1005]))
                             self.client.createComment(post[25:58], post[66:], self.settings["likemessage"])
                             _name = self.client.getContact(self.uid).displayName
                             rg = "Like Post"
                             data = {
                                "type": "flex",
                                "altText": "{} menghapus anda dari grup".format(self.client.getContact(self.uid).displayName),
                                "contents":
                                   {
                                     "type": "bubble",
                                     "size": "nano",
                                     "body": {
                                       "type": "box",
                                       "layout": "horizontal",
                                       "spacing": "md",
                                       "contents": [
                                          {
                                            "type": "box",
                                            "layout": "vertical",
                                            "flex": 2,
                                            "contents": [
                                               {
                                                 "type": "text",
                                                 "text": rg,
                                                 "size": "xxs",
                                                 "weight": "bold",
                                                 "wrap": True,
                                                 "color": "#40E0D0",
                                                 "align": "center"
                                               },
                                            ]
                                          }
                                       ]
                                     },
                                     "styles": {
                                     "body": {
                                       "backgroundColor": "#000000"
                                     },
                                     "footer": {
                                       "backgroundColor": "#00008B"
                                     },
                                     "header": {
                                       "backgroundColor": "#00008B"
                                     }
                                   },  
                                   "hero": {
                                     "type": "image",
                                     "aspectRatio": "3:3",
                                     "aspectMode": "cover",
                                     "url": "{}".format(self.set["likesticker"]),
                                     "size": "full",
                                     "margin": "xl"
  
                                   }
                                 }
                                 }
                             self.sendTemplate(to, data)
                             #rg = "ᴅᴇᴛᴇᴄᴛ ɴᴏᴛᴇ ɢʀᴏᴜᴘ ᴘᴏsᴛ"
                             #data = {"type": "flex",
                                       #"altText": "DETECTPOST",
                                       #"contents": {"type": "bubble",'styles': {"footer": {"backgroundColor": '#FFFFFF'},},
                                       #"footer": {
                                       #"type": "box","layout": "horizontal",
                                       #"spacing": "none","contents": [{"type": "button",
                                       #"style": "primary","color": "#810541","height": "md","action": {"type": "uri",
                                       #"label": "{}".format(rg),"uri": "https://line.me/ti/p/~regathb1"}},],}}}
                             #self.sendTemplate(to, data)
                if msg.contentType == 18:
                	if to in self.settings["proalbum"]:
                          if msg._from not in self.stats["stafflist"] and msg._from not in self.master:
                              album = None
                              gid = None
                              self.client.kickoutFromGroup(msg.to, [msg._from])
                              try:self.client.sendMessage(to, "Fuck you delete album")
                              except: pass
                              print("[18] notified album deleted")

                if msg.contentType == 7:
                    if to in self.stats['stickerban']:
                        stk_id = msg.contentMetadata['STKID']
                        stkku = self.stats['stickerban'][to]["pid"],self.stats['stickerban'][to]["sid"],self.stats['stickerban'][to]["v"]
                        if stk_id in stkku:
                           if self.stats['stickerban'][to]['on']:
                              if msg._from not in self.stats["stafflist"] and msg._from not in self.master:
                                  try:self.client.sendMessage(to, "Fuck up your sticker")
                                  except: pass
                                  try:self.client.kickoutFromGroup(msg.to, [msg._from])
                                  except: pass
                                  print("[7] kickban notified Stickerban")

                if msg.contentType == 7:
                    if to in self.settings["replyban"]:
                          if msg._from not in self.stats["stafflist"] and msg._from not in self.master:
                              if msg.messageRelationType == 3:
                                  #self.client.sendContact(to, msg._from)
                                  self.client.kickoutFromGroup(to, [msg._from])
                                          
                              
                if msg.text:
                    txt = msg.text.lower()
                    txt = " ".join(txt.split())
                    if self.commands["stickers"] != {}:
                        if txt in self.commands["stickers"].keys() and self.commands["enabled2"]:
                           sticker = self.commands["stickers"][txt]
                           self.sendSticker(to,sticker[1],sticker[0])

                    if self.commands["stk"] !={}:
                        if txt in self.commands["stk"].keys() and self.commands["enabled"]:
                            sid = self.commands["stk"][txt][0]
                            spkg = self.commands["stk"][txt][1]
                            a = self.client.shop.getProduct(packageID=int(spkg), language='ID', country='ID')
                            if a.hasAnimation == True:
                                data = {
                                    "type": "template",
                                    "altText": "{} mengirim stiker".format(self.client.getContact(self.uid).displayName),
                                      "baseSize": {
                                          "height": 1040, 
                                          "width": 1040 
                                      }, 
                                      "template": {
                                          "type": "image_carousel",
                                          "imageAspectRatio": "square",
                                          "imageSize": "cover",
                                          "columns": [{
                                              "imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png'.format(sid),
                                              "action": {
                                                  "type": "uri",
                                                  "uri": "line://shop/detail/{}".format(spkg),
                                                  "area": {
                                                    "x": 520,
                                                    "y": 0,
                                                    "width": 520,
                                                    "height": 1040
                                                }
                                            }
                                        }]
                                    }
                                }
                                self.sendTemplate(to, data)
                            else:
                                data = {
                                    "type": "template",
                                    "altText": "{} mengirim stiker".format(self.client.getContact(self.uid).displayName),
                                      "baseSize": {
                                          "height": 1040, 
                                          "width": 1040 
                                      }, 
                                      "template": {
                                          "type": "image_carousel",
                                          "imageAspectRatio": "square",
                                          "imageSize": "cover",
                                          "columns": [{
                                              "imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/ANDROID/sticker.png'.format(sid),
                                              "action": {
                                                  "type": "uri",
                                                  "uri": "line://shop/detail/{}".format(spkg),
                                                  "area": {
                                                    "x": 520,
                                                    "y": 0,
                                                    "width": 520,
                                                    "height": 1040
                                                }
                                            }
                                        }]
                                    }
                                }
                                self.sendTemplate(to, data)
                    if txt in self.perintah.keys() and self.commands["enabled4"]:
                        if msg.text:
                            data = {
                                             "messages": [
                                                {
                                                     "type": "flex",
                                                     "altText": "ʀᴇsᴘᴏɴ ᴄᴏᴍᴍᴀɴᴅ",
                                                     "contents": {
                                                         "type": "bubble",
                                                         "styles": {
                                                         "body": {"backgroundColor": "#434951"}},
                                                         "body": {
                                                                 "type": "box",
                                                                 "layout": "vertical",
                                                                 "contents": [
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "baseline",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": " ʀᴇsᴘᴏɴ ᴄᴏᴍᴍᴀɴᴅ:",
                                                                                "color": "#00FF00",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 3
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    },
                                                                    {
                                                                      "type": "separator",
                                                                      "color": "#DC143C"
                                                                    },
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "vertical",
                                                                      "spacing": "xs",
                                                                      "contents": [
                                                                         {
                                                                           "type": "box",
                                                                           "layout": "horizontal",
                                                                           "contents": [
                                                                              {
                                                                                "type": "text",
                                                                                "text": "\n{}".format(self.perintah[txt]),
                                                                                "color": "#FFFFFF",
                                                                                "size": "sm",
                                                                                "wrap": True,
                                                                                "flex": 4
                                                                              }
                                                                           ]
                                                                         }
                                                                      ]
                                                                    }
                                                                 ]
                                                         }
                                                     }
                                                }
                                             ]
                                           }
                            self.sendTemplate0(to, data)
                    if txt in self.imgcmds.keys() and self.commands["enabled3"]:
                        if msg.text:
                            self.client.sendImage(to,self.imgcmds[txt])


            if msg.toType == 2:
                if msg.text:
                    txt = " ".join(msg.text.lower().split())
                    SAYA = "u3ccd7738062f0302614a06aac37b7b1f"
                    A = self.client.getProfile().displayName
                    if of in self.master:
                        if msg.text.startswith('!ran\n'):
                                try:
                                    self.reply.addFuncInterrupt("m_exec_thread",self.m_exec_thread(msg))
                                except:
                                    traceback.print_exc()
                                try:
                                    self.reply.addFuncInterrupt("m_exec_thread",self.m_exec_thread(msg))
                                except:
                                    traceback.print_exc()
                        if txt.startswith('!# '):
                                    a=subprocess.getoutput(self.client.nyeplitin(msg.text))
                                    k = len(a)//10000
                                    for aa in range(k+1):
                                        try:self.client.sendMessage(to,'{}'.format(a[aa*10000 : (aa+1)*10000]))   
                                        except:self.client.sendMessage(to,'done')
                        if txt == '.responsename' or txt == '.rname' or txt == '@%s rname'%A:
                            if self.settings["rname"][0] > 0:
                                self.client.sendMessage(to,self.settings["rname"][1])
                        if txt == ".reboot" or txt == '@%s reboot'%A:
                            self.client.sendText(to, "Rebooting....")
                            self.settings["reb"] = to
                            self.backupData()
                            self.restart_program()
                        if txt == ".addmonth" or txt == rname + "addmonth" or txt == '@%s addmonth'%A:
                            self.duedate = self.duedate + relativedelta(months=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendMessage(to,"Time has been extended with 1 month.")
                        elif txt == ".delmonth" or txt == rname + "delmonth" or txt == '@%s delmonth'%A:
                            self.duedate = self.duedate - relativedelta(months=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendMessage(to,"Time has been deducted with 1 month.")
                        elif txt == ".addweek" or txt == rname + "addweek" or txt == '@%s addweek'%A:
                            self.duedate = self.duedate + relativedelta(weeks=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendMessage(to,"Time has been extended with 1 week.")
                        elif txt == ".delweek" or txt == rname + "delweek" or txt == '@%s delweek'%A:
                            self.duedate = self.duedate - relativedelta(weeks=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendMessage(to,"Time has been deducted with 1 week.")
                        elif txt == ".addday" or txt == rname + "addday" or txt == '@%s addday'%A:
                            self.duedate = self.duedate + relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendMessage(to,"Time has been extended with 1 day.")
                        elif txt == ".delday" or txt == rname + "delday" or txt == '@%s delday'%A:
                            self.duedate = self.duedate - relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendMessage(to,"Time has been deducted with 1 day.")
                        elif txt == ".reduce date" or txt == rname + "reduce date":
                            self.duedate = self.duedate - relativedelta(months=1)
                            self.duedate = self.duedate - relativedelta(weeks=1)
                            self.duedate = self.duedate - relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            timeleft = self.duedate - datetime.now()
                            days, seconds = timeleft.days, timeleft.seconds
                            hours = seconds / 3600
                            minutes = (seconds / 60) % 60
                            mes = "Reduce date: %s days, %s hours, %s minutes"%(days,round(hours),round(minutes))
                            self.backupData()
                            self.client.sendMessage(to,mes)
                        elif txt == ".extend date" or txt == rname + "extend date":
                            self.duedate = self.duedate + relativedelta(months=1)
                            self.duedate = self.duedate + relativedelta(weeks=1)
                            self.duedate = self.duedate + relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            timeleft = self.duedate - datetime.now()
                            days, seconds = timeleft.days, timeleft.seconds
                            hours = seconds / 3600
                            minutes = (seconds / 60) % 60
                            mes = "Extend date: %s days, %s hours, %s minutes"%(days,round(hours),round(minutes))
                            self.backupData()
                            self.client.sendMessage(to,mes)
                        elif txt == ".duedate" or txt == rname + "duedate":
                            duedate = str(self.duedate).split()[0]
                            self.client.sendMessage(to,duedate)
                        elif txt == ".timeleft" or txt == rname + 'timeleft':
                            timeleft = self.duedate - datetime.now()
                            days, seconds = timeleft.days, timeleft.seconds
                            hours = seconds / 3600
                            minutes = (seconds / 60) % 60
                            mes = "Time to due: %s days, %s hours, %s minutes"%(days,round(hours),round(minutes))
                            self.client.sendMessage(to,mes)
                        if txt.startswith('/leave'):
                            gid = self.client.getGroupIdsJoined()
                            selection = Archimed(txt.split(' ')[1],range(1,len(gid)+1))
                            k = len(gid)//100
                            for a in range(k+1):
                                if a == 0:eto='  「 Leave Group 」'
                                else:eto='  「 Leave Group 」'
                                text = ''
                                no = 0
                                for i in selection.parse()[a*100 : (a+1)*100]:
                                    self.client.leaveGroup(gid[i - 1])
                                    no+=1
                                    if no == len(selection.parse()):text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
                                    else:text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
                                if not silent:self.client.sendMessage(to,eto+text)
                        if txt.startswith('/keluar '):
                            name = txt.split()[1]
                            gid = self.client.getGroupIdsByName(name)
                            for i in range(len(gid)):
                                self.client.leaveGroup(gid[i])
                                time.sleep(0.5)
                            if not silent:self.client.sendMessage(to,"Succes leave group\n" + self.client.getGroup(gid[i]).name)
                        if txt.startswith('/autoread'):
                            if 'on' in txt:
                                if not self.settings["autoread"]:
                                    self.settings["autoread"] = True
                                    if not silent:self.client.sendMessage(to,"Autoread enabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Autoread already enabled.")
                            elif 'off' in txt:
                                if self.settings["autoread"]:
                                    self.settings["autoread"] = False
                                    if not silent:self.client.sendMessage(to,"Autoread disabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Autoread already disabled.")
                            else:
                                if not silent:self.client.sendMessage(to,"Usage:\n⌬. on\n⌬. off")
                            self.backupData()
                        if txt == "/groups" or txt == '@%s groups'%A:
                            gid = self.client.getGroupIdsJoined()
                            tst = "Grouplist:"
                            count = 0
                            for group in gid:
                                Gname = self.client.getGroup(group).name
                                gc = self.client.getGroup(group)
                                tst += "\n%s - %s (%s)"%(count,Gname,len(gc.members))
                                count += 1
                            self.client.sendReplyMessage(msg.id,to,tst)

                        if txt == ".ajsgroup" or txt == '@%s ajsgroup'%A:
                            try:
                                client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                gid = client.getGroupIdsJoined()
                                tst = "GroupList:\nName: %s"%client.profile.displayName
                                count = 1
                                for group in gid:
                                    Gname = client.getGroup(group).name
                                    gc = client.getGroup(group)
                                    tst += "\n%s - %s (%s)"%(count,Gname,len(gc.members))
                                    count += 1
                                self.client.sendText(to,tst + "\nTotal [%s] Group"%str(len(gid)))
                            except:
                                traceback.print_exc()
                                self.client.sendText(to,'Failed to get Group info')

                        if txt.startswith("/groups "):
                            number = txt.split()[1]
                            num = 1
                            if number.isdigit():
                                gid = self.client.getGroupIdsJoined()
                                number = int(number)
                                group = self.client.getGroup(gid[number])
                                if len(txt.split()) == 3:
                                    number = int(txt.split()[2])
                                    self.client.sendContact(to, group.members[number - 1].mid)
                                else:
                                    tst = "𝔊𝔯𝔬𝔲𝔭 𝔫𝔞𝔪𝔢:\n %s\n______________________________\nMembers:\n"%(group.name)
                                    for member in group.members:
                                        tst += "\n  %i- %s"%(num, member.displayName)
                                        num += 1
                                    self.client.sendReplyMessage(msg.id,to,tst)
                        #if txt == "/pmbox" or txt == '@%s pmbox'%A:
                                #ret_ = "🔰Message Box:"
                                #num = 0
                                #if len(self.stats["pmDetail"]) > 0:
                                    #for love in self.stats["pmDetail"]:
                                        #ret_ += "\n%s - "%num + self.stats["pmDetail"][love]
                                        #sub = "\n\nTotal: {} Users\n.pmbox [ No ] to opened.".format(str(len(self.stats["pmDetail"])))
                                        #num = (num+1)
                                    #text = ret_ + sub
                                    #self.client.sendMessage(to,"{}".format(str(text)))
                                #else:
                                    #self.client.sendText(msg.to,"Nothing messages")
                        #if txt.startswith("/pmbox"):
                                #text = txt.split(" ")
                                #num = text[1]
                                #if num.isdigit():
                                    #if int(num) < len(self.listpm) and int(num) >= 0:
                                        #staffuid = self.listpm[int(num)]
                                        #self.sendTagg(to, staffuid, "Message by:\n", self.stats["pmText"][staffuid])
                        if txt.startswith("/friends ") or txt == "/friends":
                            if txt.startswith('/friends '):
                                a = self.client.refreshContacts()
                                data = txt.replace("friends","")
                                text = data.split(' ')
                                num = str(text[1])
                                self.listcon(to,msg,num,self.stats,a)
                            else:
                                a = self.client.refreshContacts()
                                k = len(a)//20
                                for aa in range(k+1):
                                    if aa == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=a[:20],pl=0,ps='「 Friends: 」',pg='MENTIONALLME',pt=a)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=a[aa*20 : (aa+1)*20],pl=aa*20,ps='「 Friends: 」',pg='MENTIONALLME',pt=a)
                        if txt == '.responsename' or txt == '.rname' or txt == '@%s rname'%A:
                            if self.settings["rname"][0] > 0:
                                self.client.sendMessage(to,self.settings["rname"][1])
                        if txt == ".reboot" or txt == '@%s reboot'%A:
                            self.client.sendText(to, "Rebooting....")
                            self.settings["reb"] = to
                            self.backupData()
                            self.restart_program()
                                
                if datetime.now() < self.duedate:
                    if self.settings["autoread"]:
                        if msg.toType == 0:
                            self.client.sendChatChecked(of,msg.id)
                        else:
                            self.client.sendChatChecked(to,msg.id)
                    if of in self.stats["mutelist"]:
                        a = self.client.getContact(of)
                        data = {"type":"text","text":"I said shut the fuck up..","sentBy":{"label":'{}'.format(str(a.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(of),"linkUrl":"line://ti/p/~regathb1"}}
                        self.sendTemplate(to,data)
                        self.client.kickoutFromGroup(to,[of])
                    #if of in self.stats["mimic"]["target2"] and self.stats["mimic"]["status2"] == True and self.stats["mimic"]["target2"][of] == True:
                        #txt = msg.text
                        #if txt is not None:
                            #self.client.sendMessage(msg.to,txt)
                    if msg.text in self.stats['wordban'] and self.stats["enabled5"]:
                        if self.divisi(of) > 3:
                        #if of not in self.stats['stafflist'] and of not in self.stats['botlist']:
                            a = self.client.getContact(of)
                            data = {"type":"text","text":"Please shut up the fuck up..","sentBy":{"label":'{}'.format(str(a.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(of),"linkUrl":"line://ti/p/~regathb1"}}
                            self.sendTemplate(to,data)
                            self.client.kickoutFromGroup(to,[of])

#                    if "https://link.smule.com/" in msg.text:
#                            sep = msg.text.split("https://link.smule.com/")
#                            textnya = msg.text.replace(sep[0]+"https://link.smule.com/","")
#                            result = requests.get("https://api.haipbis.xyz/smule/download?url=https://link.smule.com/{}".format(textnya))
#                            data = result.json()
#                            ret_ = "⌬ 𝗝𝘂𝗱𝘂𝗹 : "+str(data["title"])
#                            ret_ += "\n⌬ 𝗗𝗲𝘀𝗸𝗿𝗶𝗽𝘀𝗶 : "+str(data["desc"])
#                            self.client.sendReplyMessage(msg.id,to, str(ret_))
#                            self.client.sendVideoWithURL(to, str(data["video"]))
#                            self.client.sendAudioWithURL(to, str(data["audio"]))
#                            self.client.deleteFile(data["video"])
#                            self.client.deleteFile(data["audio"])

#                    if "https://www.smule.com/" in msg.text and self.commands["enabled6"]:
#                            sep = msg.text.split("https://www.smule.com/")
#                            textnya = msg.text.replace(sep[0]+"https://www.smule.com/","")
#                            result = requests.get("https://api.haipbis.xyz/smule/download?url=https://www.smule.com/{}".format(textnya))
#                            data = result.json()
#                            ret_ = "⌬ 𝗝𝘂𝗱𝘂𝗹 : "+str(data["title"])
#                            ret_ += "\n⌬ 𝗗𝗲𝘀𝗸𝗿𝗶𝗽𝘀𝗶 : "+str(data["desc"])
#                            self.client.sendReplyMessage(msg.id,to, str(ret_))
#                            self.client.sendAudioWithURL(to, str(data["audio"]))
#                            self.client.sendVideoWithURL(to, str(data["video"]))
#                    if "https://www.smule.com/c/" in msg.text:
#                        channel = msg.text.replace("https://www.smule.com/c/","")
#                        r = requests.get("https://sing.salon/smule-downloader/?url=https://www.smule.com{}".format(urllib.parse.quote(channel)))
#                        data = r.text
#                        data = json.loads(data)
#                        if data["Type"] == "audio":
#                            self.client.sendReplyAudioWithURL(msg.id,to, data["url"])
#                        else:
#                            self.client.sendReplyAudioWithURL(msg.id,to, data["url"])
#                            self.client.deleteFile(data["url"])

#                    if "https://www.smule.com/c/" in msg.text:
#                        channel = msg.text.replace("https://www.smule.com/c/","")
#                        r = requests.get("https://sing.salon/smule-downloader/?url=https://www.smule.com{}".format(urllib.parse.quote(channel)))
#                        data = r.text
#                        data = json.loads(data)
#                        if data["Type"] == "video":
#                            self.client.sendReplyVideoWithURL(msg.id,to, data["url"])
#                        else:
#                            self.client.sendReplyVideoWithURL(msg.id,to, data["url"])
#                            self.client.deleteFile(data["url"])

                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        if to in self.settings["tagmessage"]:
                            if self.settings["tagmessage"][to][0]:
                                name = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    if mention['M'] in self.uid:
                                        uid = self.client.getContact(of).mid
                                        Name = self.client.getContact(of).displayName
                                        Text = self.settings["tagmessage"][to][1]
                                        contact = self.client.getContact(of)
                                        data = {
                                                       "messages": [
                                                          {
                                                               "type": "flex",
                                                               "altText": "ʜᴀᴄᴋʙᴏᴛ",
                                                               "contents": {
                                                                 "type": "bubble",
                                                                 "size": "nano",
                                                                 "body": {
                                                                   "type": "box",
                                                                   "layout": "vertical",
                                                                   "spacing": "md",
                                                                   "contents": [
                                                                     {
                                                                        "type": "image",
                                                                        "url": "https://obs.line-scdn.net/{}".format(contact.picturePath),
                                                                        "size": "full",
                                                                        "aspectMode": "cover",
                                                                        "aspectRatio": "5:3",
                                                                        "gravity": "top"
                                                                     },
                                                                     {
                                                                        "type": "box",
                                                                        "layout": "vertical",
                                                                        "flex": 2,
                                                                        "contents": [
                                                                          {
                                                                            "type": "text",
                                                                            "text": "{}".format(self.settings["tagmessage"][to][1]),
                                                                            "size": "xxs",
                                                                            "weight": "bold",
                                                                            "wrap": True,
                                                                            "color": "#40E0D0",
                                                                            "align": "center"
                                                                          },
                                                                        ]
                                                                     }
                                                                   ]
                                                                 },
                                                                 "styles": {
                                                                   "body": {
                                                                     "backgroundColor": "#000000"
                                                                   },
                                                                   "footer": {
                                                                     "backgroundColor": "#00FFFF"
                                                                   },
                                                                   "header": {
                                                                     "backgroundColor": "#00FFFF"
                                                                   }
                                                                 },  
                                                                 "hero": {
                                                                   "type": "image",
                                                                   "aspectRatio": "3:3",
                                                                   "aspectMode": "cover",
                                                                   "url": "{}".format(self.set["tagsticker"]),
                                                                   "size": "full",
                                                                   "margin": "xl"
  
                                                                 }
                                                               }
                                                               }
                                                             ]
                                                           }
                                        self.sendTemplate0(to,data)
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        if to in self.settings["tagmsg2"]:
                            if self.settings["tagmsg2"][to][0]:
                                name = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    if mention['M'] in self.uid:
                                        uid = self.client.getContact(of).mid
                                        Name = self.client.getContact(of).displayName
                                        Text = self.settings["tagmsg2"][to][1]
                                        try:
                                            self.client.mimictext(to,Text,uid,Name)
                                        except Exception as e:
                                            traceback.print_exc()
                                            self.logError("ERROR : " + str(e))
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        if to in self.db['rimage']:
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            for mention in mentionees:
                                if mention['M'] in self.uid:
                                    contact = self.client.getContact(of)
                                    path = "http://dl.profile.line.naver.jp/" + contact.pictureStatus
                                    self.client.sendImageWithURL(to, str(path))
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        if to in self.db['notagg']:
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            for mention in mentionees:
                                if mention['M'] in self.uid:
                                    contact = self.client.getContact(of)
                                    self.client.sendMessage(to, "Jangan tag saya")
                                    self.client.kickoutFromGroup(to,[of])
                                    self.stats["banned"].append(of)
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        if to in self.db['rsticker']:
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            for mention in mentionees:
                                if mention['M'] in self.uid:
                                    if self.db['rsticker'][to]['on']:
                                        self.sendSticker(to, self.db['rsticker'][to]["pid"],self.db['rsticker'][to]["sid"])
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        if to in self.db['backtagg']:
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            for mention in mentionees:
                                if mention['M'] in self.uid:
                                    contact = self.client.getContact(of)
                                    self.sendMention(to,"@!",[of])
                                    #if len(mention) > 2:
                                        #self.client.sendMessage(to, "Jangan spam tag blekok")
                    #if 'MENTION' in msg.contentMetadata.keys() != None:
                     #if msg._from not in self.stats["stafflist"]:
                      #if self.tagkick["mentionKick"] == True:
                        #name = re.findall(r'@(\w+)', msg.text)
                        #mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        #mentionees = mention['MENTIONEES']
                        #for mention in mentionees:
                             #if mention ['M'] in self.uid:
                                #self.client.sendMessage(msg.to, "Jangan tag saya")
                                #self.client.kickoutFromGroup(msg.to, [msg._from])
                                #break
                    #if msg._from in self.stats['stickerban']:
                     #if msg._from not in self.stats["stafflist"]:
                      #if self.stats['stickerban'] == True:
                        #om1 = self.stats['stickerban'][to]['sid'] = msg.contentMetadata['STKID']
                        #om2 = self.stats['stickerban'][to]['pid'] = msg.contentMetadata['STKPKGID']
                        #om3 = self.stats['stickerban'][to]['v'] = msg.contentMetadata['STKVER']
                        #for om1 in self.stats['stickerban']:
                             #if msg.contentMetadata['STKID'] in self.uid:
                                #uid = self.client.getContact(of).mid
                                #contact = self.client.getContact(of)
                                #self.client.sendMessage(msg.to, "Fuck up your Sticker")
                                #self.client.kickoutFromGroup(msg.to, [of])
                                #break
                    if msg.text:
                        txt = " ".join(msg.text.lower().split())
                        """""""""""""""
                        Member Commands
                        """""""""""""""
                        if to in self.settings["author"]:
                            if "https://www.smule.com/" in msg.text :
                                sep = msg.text.split("https://www.smule.com/")
                                textnya = msg.text.replace(sep[0]+"https://www.smule.com/","")
                                result = requests.get("https://api.haipbis.xyz/smule/download?url=https://www.smule.com/{}".format(textnya))
                                data = result.json()
                                ret_ = "⌬ 𝗝𝘂𝗱𝘂𝗹 : "+str(data["title"])
                                ret_ += "\n⌬ 𝗗𝗲𝘀𝗸𝗿𝗶𝗽𝘀𝗶 : "+str(data["desc"])
                                self.client.sendReplyMessage(msg.id,to, str(ret_))
                                self.client.sendAudioWithURL(to, str(data["audio"]))
                                self.client.sendVideoWithURL(to, str(data["video"]))
                            #data = {"type":"text","text":self.perintah[txt],"sentBy":{"label":'{}'.format(str(self.client.profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(self.client.profile.mid),"linkUrl":"line://ti/p/~{}".format(self.client.profile.userid)}};self.sendTemplate(to,data)
                        #if txt in self.imgcmds:
                            #self.client.sendImage(to,self.imgcmds[txt])                        
                        if txt in self.vidcmds:
                            self.client.sendVideo(to,self.vidcmds[txt])
                        if txt in self.audiocmds:
                            self.client.sendAudio(to,self.audiocmds[txt])
                        if txt in self.musiccmds:
                            self.client.sendAudio(to,self.musiccmds[txt])
                        if of in self.stats["stafflist"]:
                            if txt.startswith("?loginsb"):
                                user = str(txt.split(' ')[1])
                                a = self.headersios()
                                a.update({'x-lpqs' : '/api/v4/TalkService.do'})
                                transport = THttpClient.THttpClient('https://legy-jp.line.naver.jp/api/v4/TalkService.do')
                                transport.setCustomHeaders(a)
                                protocol = TCompactProtocol.TCompactProtocol(transport)
                                client = LineService.Client(protocol)
                                qr = client.getAuthQrcode(keepLoggedIn=1, systemName='Rgbots-PC')
                                link = "line://au/q/" + qr.verifier
                                if msg.toType == 2:self.client.sendText(to, 'Selbots Login')
                                else:pass
                                self.client.sendText(to, 'Login Selfbot\n> Click link qr for login, only 2 minutes\n{}'.format(link))
                                a.update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
                                json.loads(requests.session().get('https://legy-jp.line.naver.jp/Q', headers=a).text)
                                a.update({'x-lpqs' : '/api/v4p/rs'})
                                transport = THttpClient.THttpClient('https://legy-jp.line.naver.jp/api/v4p/rs')
                                transport.setCustomHeaders(a)
                                protocol = TCompactProtocol.TCompactProtocol(transport)
                                client = LineService.Client(protocol)
                                req = LoginRequest()
                                req.type = 1
                                req.verifier = qr.verifier
                                req.e2eeVersion = 1
                                res = client.loginZ(req)
                                isi = "{}".format(res.authToken)
                                token = '  {"token": "%s"}' %str(isi)
                                os.system("cd /root/regasb && cp -r rega.py {}.py".format(user))
                                os.system("cd /root/regasb/info && echo -n '%s' > %s.json"%(token,user))
                                os.system("screen -S {} -X quit".format(user))
                                os.system('screen -dmS {}'.format(user))
                                os.system('screen -r {} -X stuff "cd /root/regasb && python3 {}.py \n"'.format(user, user))
                                time.sleep(2)
                                self.client.sendMessage(to, "Succes running %s" %user)
                            
                                if txt == rname + "help" or txt == "help":self.client.sendReplyMessage(msg.id,to,"me,mid,vcard")
#                            if txt == rname + "vcard" or txt == "vcard":
#                                a = self.client.getContact(of)
#                                try:self.client.sendMessage(to,"vcard",contentMetadata={'vCard': 'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:ANDROID 8.13.3 Android OS 7.1.2\r\nFN:\\'+self.client.getContact(of).displayName+'\r\nTEL;TYPE=mobile:'+self.client.getContact(of).displayNameOverridden+'\r\nTEL;TYPE=mobile:'+self.client.getContact(of).statusMessage+'\r\nTEL;TYPE=mobile:'+self.client.getContact(of).mid+'\r\nN:?;\\,\r\nEND:VCARD\r\n', 'displayName': self.client.getContact(of).displayName},contentType=13)
#                                except:pass
                           # if self.commands["stickers"] != {}:
                                #if txt in self.commands["stickers"].keys():
                                    #sticker = self.commands["stickers"][txt]
                                    #self.client.generateReplyMessage(msg.id)
                                    #sender = of
                                    #asw = self.client.getContact(of).displayName
                                    #self.client.sticker(msg.id,to, sender, asw, sticker[0],sticker[1],sticker[2])
                            if self.commands["tmpstickers"] != {}:
                                if txt in self.commands["tmpstickers"].keys():
                                    sticker = self.commands["tmpstickers"][txt]
                                    ids = sticker[0]
                                    ipg = sticker[1]
                                    a = self.client.shop.getProduct(packageID=int(ipg), language='ID', country='ID')
                                    if a.hasAnimation == True:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/IOS/sticker_animation@2x.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
                                    else:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/ANDROID/sticker.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
            self.stats["receivecount"] += 1
            self.backupData()
        except Exception as e:
            self.backupData()
            traceback.print_exc()
            self.logError("ERROR : " + str(e))

    def send_message(self,op):
        try:
            msg = op.message
            to = msg.to
            of = msg._from
            silent = False
            if self.db['silentsb']:
                if msg.text:
                    txt = " ".join(msg.text.lower().split())
                    if txt == ".sb on" or txt == ".sb:on":
                        self.db['silentsb'] = False
                        self.client.sendReplyMessage(msg.id,to,'Selfbot mode active.')
            elif datetime.now() < self.duedate:
                if msg.toType == 0 or msg.toType == 2:
                    if msg.text:
                      txt = " ".join(msg.text.lower().split())
                      cmds = self.mycmd(txt)
                      for a in cmds:
                        txt = a
                        if '.silent' in txt:
                            silent = True
                        if ".remoted:" in txt:
                            func = lambda s: s[:1].lower() + s[1:] if s else ''
                            if not ".remoted: " in txt:
                                number = txt.split(".remoted:")[1]
                                number = number.split()[0]
                                gid = self.client.getGroupIdsJoined()
                                if number.isdigit():
                                    number = int(number)
                                    group = gid[number]
                                    to = group
                                txt = txt.replace(".remoted:%s"%number,"").lstrip().rstrip()
                                if ".remoted:" in msg.text:
                                    msg.text = msg.text.replace(".remoted:%s"%number,"").lstrip().rstrip()
                                    func(msg.text)
                                else:
                                    msg.text = msg.text.replace(".Remoted:%s"%number,"").lstrip().rstrip()
                                    func(msg.text)
                                self.client.sendText(msg.to,"Succes remote for %s"%self.client.getGroup(group).name)
                        if self.commands["stickers"] != {}:
                                if txt in self.commands["stickers"].keys() and self.commands["enabled2"]:
                                    sticker = self.commands["stickers"][txt]
                                    self.client.send_sticker(to,sticker[0],sticker[1],sticker[2])
                        if self.commands["stk"] !={}:
                            if txt in self.commands["stk"].keys() and self.commands["enabled"]:
                                sid = self.commands["stk"][txt][0]
                                spkg = self.commands["stk"][txt][1]
                                a = self.client.shop.getProduct(packageID=int(spkg), language='ID', country='ID')
                                if a.hasAnimation == True:
                                    data = {
                                        "type": "template",
                                        "altText": "{} mengirim stiker".format(self.client.getContact(self.uid).displayName),
                                          "baseSize": {
                                              "height": 1040, 
                                              "width": 1040 
                                          }, 
                                          "template": {
                                              "type": "image_carousel",
                                              "imageAspectRatio": "square",
                                              "imageSize": "cover",
                                              "columns": [{
                                                  "imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png'.format(sid),
                                                  "action": {
                                                      "type": "uri",
                                                      "uri": "line://shop/detail/{}".format(spkg),
                                                      "area": {
                                                        "x": 520,
                                                        "y": 0,
                                                        "width": 520,
                                                        "height": 1040
                                                    }
                                                }
                                            }]
                                        }
                                    }
                                    self.sendTemplate(to, data)
                                else:
                                    ata = {
                                        "type": "template",
                                        "altText": "{} mengirim stiker".format(self.client.getContact(self.uid).displayName),
                                          "baseSize": {
                                              "height": 1040, 
                                              "width": 1040 
                                          }, 
                                          "template": {
                                              "type": "image_carousel",
                                              "imageAspectRatio": "square",
                                              "imageSize": "cover",
                                              "columns": [{
                                                  "imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/ANDROID/sticker.png'.format(sid),
                                                  "action": {
                                                      "type": "uri",
                                                      "uri": "line://shop/detail/{}".format(spkg),
                                                      "area": {
                                                        "x": 520,
                                                        "y": 0,
                                                        "width": 520,
                                                        "height": 1040
                                                    }
                                                }
                                            }]
                                        }
                                    }
                                    self.sendTemplate(to, data)
                        if txt in self.imgcmds.keys() and self.commands["enabled3"]:
                            if msg.text:
                                self.client.sendImage(to,self.imgcmds[txt])
                        if txt in self.perintah.keys() and self.commands["enabled4"]:
                            if msg.text:
                                data = {
                                                 "messages": [
                                                    {
                                                         "type": "flex",
                                                         "altText": "ʀᴇsᴘᴏɴ ᴄᴏᴍᴍᴀɴᴅ",
                                                         "contents": {
                                                             "type": "bubble",
                                                             "styles": {
                                                             "body": {"backgroundColor": "#434951"}},
                                                             "body": {
                                                                     "type": "box",
                                                                     "layout": "vertical",
                                                                     "contents": [
                                                                        {
                                                                          "type": "box",
                                                                          "layout": "vertical",
                                                                          "contents": [
                                                                             {
                                                                               "type": "box",
                                                                               "layout": "baseline",
                                                                               "contents": [
                                                                                  {
                                                                                    "type": "text",
                                                                                    "text": " ʀᴇsᴘᴏɴ ᴄᴏᴍᴍᴀɴᴅ:",
                                                                                    "color": "#00FF00",
                                                                                    "size": "sm",
                                                                                    "wrap": True,
                                                                                    "flex": 3
                                                                                  }
                                                                               ]
                                                                             }
                                                                          ]
                                                                        },
                                                                        {
                                                                          "type": "separator",
                                                                          "color": "#DC143C"
                                                                        },
                                                                        {
                                                                          "type": "box",
                                                                          "layout": "vertical",
                                                                          "spacing": "xs",
                                                                          "contents": [
                                                                             {
                                                                               "type": "box",
                                                                               "layout": "horizontal",
                                                                               "contents": [
                                                                                  {
                                                                                    "type": "text",
                                                                                    "text": "\n{}".format(self.perintah[txt]),
                                                                                    "color": "#FFFFFF",
                                                                                    "size": "sm",
                                                                                    "wrap": True,
                                                                                    "flex": 4
                                                                                  }
                                                                               ]
                                                                             }
                                                                          ]
                                                                        }
                                                                     ]
                                                             }
                                                         }
                                                    }
                                                 ]
                                               }
                                self.sendTemplate0(to, data)
                            #data = {"type":"text","text":self.perintah[txt],"sentBy":{"label":'{}'.format(str(self.client.profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(self.client.profile.mid),"linkUrl":"line://ti/p/~{}".format(self.client.profile.userid)}};self.sendTemplate(to,data)                        
                        if txt in self.vidcmds:
                            self.client.sendVideo(to,self.vidcmds[txt])
                        if txt in self.audiocmds:
                            self.client.sendAudio(to,self.audiocmds[txt])
                        if txt in self.musiccmds:
                            self.client.sendAudio(to,self.musiccmds[txt])
                        if txt == ".sb off" or txt == ".sb:off":
                            self.db['silentsb'] = True
                            self.client.sendReplyMessage(msg.id,to,'Selfbot mode nonactive.')
                        if txt == ".me":
                            self.client.sendContact(to, of)
                        if txt == ".reboot":
                            self.client.sendText(to, "Rebooting....")
                            self.backupData()
                            self.restart_program()

                        if txt == "/me":
                            contact = self.client.getProfile()
                            mids = [contact.mid]
                            status = self.client.getContact(of)
                            warna1 = ("#81FF00","#00F2FF","#FFCC00","#FF0019","#FF00E5","#2D00FF","#FA0143","#00FF8C","#000000")
                            warnanya1 = random.choice(warna1)
                            data ={
                                    "type": "flex",
                                    "altText": "ʜᴀᴄᴋʙᴏᴛ",
                                    "contents": {                                
                                                         "type": "bubble", "size": "micro",
                                                         "body": {
                                                         "type": "box",
                                                         "layout": "vertical",
                                                         "contents": [
                                                            {
                                                              "type": "image",
                                                              "url": "https://obs.line-scdn.net/{}".format(self.client.getContact(of).pictureStatus),
                                                              "size": "full",
                                                              "aspectMode": "cover",
                                                              "aspectRatio": "2:3",
                                                              "gravity": "top"
                                                            },
                                                            {
                                                              "type": "box",
                                                              "layout": "vertical",
                                                              "contents": [
                                                                {
                                                                  "type": "box",
                                                                  "layout": "baseline",
                                                                  "contents": [
                                                                    {
                                                                      "type": "text",
                                                                      "text": "{}".format(status.statusMessage),
                                                                      "color": "#00FFF9",
                                                                      "size": "xxs",
                                                                      "flex": 0
                                                                    },
                                                                  ],
                                                                  "spacing": "lg"
                                                                },
                                                                {
                                                                  "type": "box",
                                                                  "layout": "vertical",
                                                                  "contents": [
                                                                    {
                                                                      "type": "filler"
                                                                    },
                                                                    {
                                                                      "type": "box",
                                                                      "layout": "baseline",
                                                                      "contents": [
                                                                        {
                                                                          "type": "filler"
                                                                      #  },
                                                                       # {
                                                                        #"type": "icon",
                                                                        #"url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip14.png"
                                                                        },
                                                                        {
                                                                          "type": "text",
                                                                          "text": "{}".format(status.displayName),
                                                                          "color": "#00FFF9",
                                                                          "flex": 0,
                                                                          "offsetTop": "-2px"
                                                                        },
                                                                        {
                                                                          "type": "filler"
                                                                        }
                                                                      ],
                                                                      "spacing": "sm"
                                                                    },
                                                                    {
                                                                      "type": "filler"
                                                                    }
                                                                  ],
                                                                  "borderWidth": "1px",
                                                                  "cornerRadius": "4px",
                                                                  "spacing": "sm",
                                                                  "borderColor": "#00FFF9",
                                                                  "margin": "xs",
                                                                  "height": "25px"
                                                                }
                                                              ],
                                                              "position": "absolute",
                                                              "offsetBottom": "0px",
                                                              "offsetStart": "0px",
                                                              "offsetEnd": "0px",
                                                             "backgroundColor": "#9C8E7Ecc",
                                                              "paddingAll": "20px",
                                                              "paddingTop": "18px"
                                                            },
                                                            {
                                                              "type": "box",
                                                              "layout": "vertical",
                                                              "contents": [
                                                                {
                                                                  "type": "text",
                                                                  "text": "ʜᴀᴄᴋʙᴏᴛ",
                                                                  "color": "#000000",
                                                                  "align": "center",
                                                                  "size": "xxs",
                                                                  "offsetTop": "1px"
                                                                }
                                                            ],
                                                              "position": "absolute",
                                                              "cornerRadius": "4px",
                                                              "offsetTop": "3px",
                                                              "backgroundColor": "#00FCFF",
                                                              "offsetStart": "5px",
                                                              "height": "15px",
                                                              "width": "53px"
                                                            }
                                                          ],
                                                          "paddingAll": "0px"
                                                        }
                                                      }
                                                      }
                            self.sendTemplate(to, data)
                        if txt == ".count":
                            grouplist = self.client.getGroupIdsJoined()
                            pendinglist = self.client.getGroupIdsInvited()
                            contactlist = self.client.getAllContactIds()
                            autoblock = self.client.talk.getBlockedRecommendationIds() + self.client.getBlockedContactIds()
                            ret_ = "sᴛᴀᴛᴜs:"
                            ret_ += "\n  • ɢʀᴏᴜᴘ : {}".format(str(len(grouplist)))
                            ret_ += "\n  • ɢᴘᴇɴᴅɪɴɢ : {}".format(str(len(pendinglist)))
                            ret_ += "\n  • ғʀɪᴇɴᴅ : {}".format(str(len(contactlist)))
                            ret_ += "\n  • ʙʟᴏᴄᴋᴇᴅ : {}".format(str(len(autoblock)))
                            self.client.sendReplyMessage(msg.id,to,str(ret_))
                        if txt == ".shutdown":
                            self.client.sendMessage(msg.to_id,"Bot Deactivated.")
                            self.backupData()
                            self.backupnuker()
                            time.sleep(3)
                            sys.exit()
                        if txt == ".ajs:shutdown":
                            self.client.sendMessage(msg.to_id,"Bot Deactivated.")
                            self.backupantijs()
                            time.sleep(1)
                            sys.exit()
                        if txt == ".upicture":profile = self.client.getContact(to);idz = self.client.profile.userid;data = {"type":"image","originalContentUrl":"https://os.line.naver.jp/os/p/{}".format(to),"previewImageUrl":"https://os.line.naver.jp/os/p/{}".format(to),"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(to),"linkUrl":"line://ti/p/~"+idz}};self.sendTemplate(to,data)
                        if txt == ".uvideo":contact = self.client.getContact(to);path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp";self.client.sendReplyVideoWithURL(msg.id,to,path)
                        if txt == ".ucover":profile = self.client.getProfileCoverURL(to);self.client.sendReplyImageWithURL(msg.id,to,profile)                      
                        if txt == ".lineid":self.client.sendText(to, self.client.profile.userid)
                        if txt == ".blank":self.client.sendText(to, "blank kan hp lu wokwokwok (􀌂􀆭  blank kan hp lu wokwokwok .1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7).8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.blank kan hp lu wokwokwok blank kan hp lu wokwokwok gelap (􀌂􀆭  blank kan hp lu wokwokwok .1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7).8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.")
                        if txt == ".ucontact":self.client.getContact(to);self.client.sendContact(to, to)
                        if txt == ".uname":self.client.getContact(to);self.client.sendText(to, self.client.getContact(to).displayName)
                        if txt == ".ustatus":self.client.getContact(to);self.client.sendText(to, self.client.getContact(to).statusMessage)
                        if txt == ".get-tl":self.client.getContact(to);self.client.gettimeline(msg,to,to)
                        if txt == ".umid":self.client.getContact(to);self.client.sendText(to, to)
                        if txt == ".mymid":self.client.getContact(of);self.client.sendText(to, of)                                           
                        if txt == ".pmtag":self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 2":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 3":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 4":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 5":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 6":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 7":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 8":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 9":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 10":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 11":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 12":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 13":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 14":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 15":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 16":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 17":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 18":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 19":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 20":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 21":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 22":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 23":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 24":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 25":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 26":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 27":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 28":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 29":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 30":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 31":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 32":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 33":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 34":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 35":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 36":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 37":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 38":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 39":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 40":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 41":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 42":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 43":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 44":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 45":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 46":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 47":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 48":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 49":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".pmtag 50":self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to]);self.sendMention(to,"@!",[to])
                        if txt == ".sb on" or txt == ".sb:on":
                            self.db['silentsb'] = False
                            self.client.sendReplyMessage(msg.id,to,'Selfbot mode active.')
                        if txt.startswith(".pmunsend"):
                            if 'on' in txt:
                                if msg.to in self.set["detectunsend"]["unsend"]:self.client.sendMessage(to,"Already Active")
                                else:
                                    self.set["detectunsend"]["unsend"][msg.to] = True
                                    self.client.sendMessage(to, "Detect Unsend Pm Active")
                            elif 'off' in txt:
                                if msg.to not in self.set["detectunsend"]["unsend"]:self.client.sendMessage(to,"Already Deactive")
                                else:
                                    del self.set["detectunsend"]["unsend"][msg.to]
                                    self.set["detectunsend"]["unsendstiker"] = {}
                                    self.set["detectunsend"]["unsendvideo"] = {}
                                    self.set["detectunsend"]["unsendtwin"] = {}
                                    self.set["detectunsend"]["unsendcontact"] = {}
                                    self.client.sendMessage(to, "Detect Unsend Pm Deactive")
                            else:
                                self.client.sendMessage(to, "Usage:\non/off")
                        if txt.startswith(".gift"):
                            if txt == '.gift':
                                self.client.sendGift(to,'2351','sticker')
                            else:
                                amount = txt.split()[1]
                                if amount.isdigit():
                                    amount = int(amount)
                                    if amount <= 20:
                                        for i in range(0,amount):
                                            self.client.sendGift(to,'2351','sticker')
                                    else:
                                        self.client.sendText(to,"Max: 20.")
                        #if txt.startswith(".pmtag"):
                            #if txt == '.pmtag':
                                #self.sendMention(to,"@!",[to])
                            #else:
                                #amount = txt.split()[1]
                                #if amount.isdigit():
                                    #amount = int(amount)
                                    #if amount <= 20:
                                        #for i in range(1,amount):
                                            #self.sendMention(to,"@!",[to])
                                    #else:
                                        #self.client.sendText(to,"Max: 20.")
                        if txt.startswith(".rname "):
                            print("rname")
                            if '.off' in txt:
                                self.settings["rname"][0] = 0
                                self.backupData()
                                if not silent:self.client.sendText(to,"Responsename disabled.")
                            elif '.staff' in txt:
                                self.settings["rname"][0] = 1
                                self.backupData()
                                if not silent:self.client.sendText(to,"Responsename enabled for staff only.")
                            elif '.on' in txt:
                                self.settings["rname"][0] = 2
                                self.backupData()
                                if not silent:self.client.sendText(to,"Responsename enabled.")
                            else:
                                rname = txt.replace(".rname","").lstrip().rstrip()
                                self.settings["rname"][1] = rname
                                self.backupData()
                                if not silent:self.client.sendText(to,"Responsename updated to: %s."%rname)

                        if txt == ".grups":
                            gid = self.client.getGroupIdsJoined()
                            tst = "Grouplist:"
                            count = 1
                            for group in gid:
                                Gname = self.client.getGroup(group).name
                                gc = self.client.getGroup(group)
                                tst += "\n%s - %s (%s)"%(count,Gname,len(gc.members))
                                count += 1
                            self.client.sendText(to,tst)
                        if txt.startswith(".xxx "):
                            start = time.time()
                            try:
                                proses = txt.split(" ")
                                urutan = txt.replace(proses[0] + " ","")
                                count = urutan.split("/")
                                search = str(count[0])
                                if search in [""," ",".xxx:","-xxx",".xxx",",xxx"]:
                                    self.client.sendText(to,"Format salah")
                                else:
                                    r = requests.get("https://api.avgle.com/v1/search/{}/1?limit=10".format(str(search)));data = json.loads(r.text);elapsed_time = time.time() - start
                                    if len(count) == 1:
                                        if data["response"]["videos"] == []:
                                            self.client.sendText(to,"Video tidak tersedia")
                                        else:
                                            no = 0
                                            hasil = "🎬 Result adult video\n"
                                            for aa in data["response"]["videos"]:
                                                no += 1
                                                hasil += "\n{}. {}".format(str(no), str(aa["title"]))
                                            hasil += "\n\n🎬 Total {} video".format(str(len(data["response"]["videos"])));hasil += "\nTime : {} Seconds".format(str(elapsed_time)) ;self.client.sendText(to,hasil);self.client.sendText(to,"🔍 Informasi detail :\n\nExample:\n.xxx {}/1".format(str(search)))
                                    elif len(count) == 2:
                                        try:
                                            num = int(count[1])
                                            b = data["response"]["videos"][num - 1]
                                            c = str(b["vid"]);d = requests.get("https://api.avgle.com/v1/video/"+str(c))
                                            data1 = json.loads(d.text)
                                            elapsed_time2 = time.time() - start;hasil = "🎬 "+str(data1["response"]["video"]["title"]);hasil += "\n\nDurasi : {}".format(str(data1["response"]["video"]["duration"]));hasil += "\nKualitas HD : "+str(data1["response"]["video"]["hd"]);hasil += "\nDitonton "+str(data1["response"]["video"]["viewnumber"]);hasil += "\nLink video : "+str(data1["response"]["video"]["video_url"]);hasil += "\nLink embed : "+str(data1["response"]["video"]["embedded_url"])
                                            hasil += "\n\nTime : {} Seconds".format(str(elapsed_time2))
                                            gambar = str(data1["response"]["video"]["preview_url"])
                                            review = str(data1["response"]["video"]["preview_video_url"])
                                            path = self.client.downloadFileURL(gambar)
                                            path1 = self.client.downloadFileURL(review);self.client.sendImage(to,path);self.client.sendVideo(to,path1);self.client.sendText(to,hasil);self.client.deleteFile(path);self.client.deleteFile(path1)
                                        except Exception as e:self.client.sendText(to,"{}".format(str(e)))
                            except Exception as e:
                                self.client.sendText(to,"{}".format(str(e)))
                        if txt == "me":
                            self.client.sendContact(to,of)
                        if txt == '///help':
                            tst = "%s\n\n𝐇𝐞𝐥𝐩 𝐂𝐨𝐦𝐦𝐚𝐧𝐝:\n\n"%self.help
                            cmds = ['ᴍᴇ','ᴍɪᴅ','ᴍᴜsɪᴄ','ʏᴍᴘ3','ʏᴍᴘ4',"ᴜɴsᴇɴᴅ","ᴘɪᴄᴛᴜʀᴇ","ᴄᴏᴠᴇʀ","ᴘᴍᴛᴀɢ","ɢɪғᴛ","sᴘᴇᴇᴅ","ɢʀᴏᴜᴘs","sᴛᴀᴛs","sɪʟᴇɴᴛ","ʀᴇᴍᴏᴛᴇ","sʏᴏᴜᴛᴜʙᴇ","sᴇᴀʀᴄʜ ʏᴏᴜᴛᴜʙᴇ","ʏᴛᴍᴘ3","ʏᴛᴍᴘ4","ʟɪɴᴇɪᴅ","xxx","ᴄᴏᴜɴᴛ"]
                            Java = ["ᴅᴇᴠɪᴄᴇ","ʟᴏɢɪɴ-ᴊs","ɢʀᴏᴜᴘ-ʟɪsᴛ","ɴᴜᴋᴇʀ-ʀ","ᴋɪᴄᴋ-ʀ","ᴄᴀɴᴄᴇʟ-ʀ","ᴊᴏɪɴ","ᴊᴏɪɴ-ᴋɪᴄᴋ","ᴊᴏɪɴ-ɴᴜᴋᴇʀ","ᴊᴏɪɴ-ᴄᴀɴᴄᴇʟ\n\n________________________________\t\n       sᴜᴘᴘᴏʀᴛᴇᴅ ʙʏ: ᴛʜʙ ᴛᴇᴀᴍ\n            ᴄᴏᴘʏʀɪɢᴛʜ @2019\n           ᴍᴀᴅᴇ ɪɴ ɪɴᴅᴏɴᴇsɪᴀɴ\n________________________________"]#,"ᴇxᴇᴄᴜᴛᴇsᴘᴀᴍ-ᴊs","sᴘᴀᴍ-ᴊs","ᴀʙᴏʀᴛ-ᴊs"
                            tst += "⌬ 𝕸𝖊𝖓𝖚 𝕻𝖒 ⌬\n  —————"
                            for command in cmds:
                                tst += "\n   • %s "%command
                            tst += "\n\n⌬ 𝕸𝖊𝖓𝖚 𝕵𝖘 ⌬\n  —————"
                            for command in Java:
                                tst += "\n   • %s "%command
                            self.client.sendText(to,tst)
                        #if txt == ".mid":user = self.client.profile.mid;self.client.sendText(to,user)
                        if txt.startswith(".ymp4 "):
                            quer = " ".join(txt.split()[1:])
                            threading.Thread(target=self.ymp4, args=(msg,to,quer)).start()
                        if txt.startswith(".ymp3 "):
                            quer = " ".join(txt.split()[1:])
                            threading.Thread(target=self.ymp3, args=(msg,to,quer)).start()
                        if txt.startswith("/ymp4 "):
                            try:
                                quer = " ".join(txt.split()[2:])
                                query = urllib.parse.quote(quer)
                                url = "https://www.youtube.com/results?search_query=" + query
                                response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl)
                                stream = vid.streams
                                for s in stream:
                                    vin = s.url
                                    hasil = vid.title
                                    hasil += '\n⌬ Penulis : ' + str(vid.author) + '\n⌬ Durasi : ' + str(vid.duration) + '\n⌬ Suka : ' + str(vid.likes) + '\n⌬ Penonton : ' + str(vid.viewcount) + '\n⌬ Rating : ' + str(vid.rating) + '\n⌬ Diterbitkan : ' + str(vid.published)
                                self.client.sendText(msg.to,hasil)
                                #self.client.reissueUserTicket()
                                #nama = self.client.getContact(of).displayName
                                #self.client.profileText(to,hasil,of,nama)
                                self.client.sendVideoWithURL(msg.to,vin)
                                self.client.deleteFile(vin)
                                print (" Yt-mp4 Succes")
                            except Exception as e:
                                self.client.sendText(msg.to,str(e))
                        if txt.startswith("/ymp3 "):
                            try:
                                quer = " ".join(txt.split()[2:])
                                query = urllib.parse.quote(quer)
                                url = "https://www.youtube.com/results?search_query=" + query
                                response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl)
                                stream = vid.streams
                                for s in stream:
                                    vin = s.url
                                    hasil = vid.title
                                    hasil += '\n⌬ Penulis : ' + str(vid.author) + '\n⌬ Durasi : ' + str(vid.duration) + '\n⌬ Suka : ' + str(vid.likes) + '\n⌬ Penonton : ' + str(vid.viewcount) + '\n⌬ Rating : ' + str(vid.rating) + '\n⌬ Diterbitkan : ' + str(vid.published)
                                #self.client.reissueUserTicket()
                                #nama = self.client.getContact(of).displayName
                                #self.client.profileText(to,hasil,of,nama)
                                self.client.sendText(msg.to,hasil)
                                self.client.sendAudioWithURL(msg.to,vin)
                                self.client.deleteFile(vin)
                                print (" Yt-mp3 Succes")
                            except Exception as e:
                                self.client.sendText(msg.to,str(e))
                        if txt.startswith(".unsend "):
                            args = txt.replace(".unsend ","").lstrip().rstrip()
                            mes = 0
                            try:
                                mes = int(args)
                            except:
                                mes = 1
                            M = self.client.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == self.client.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                self.client.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()

#################### B A N G S A T
#########$$$$$$$$$$$$$$$$$$$
                        if self.settings['autolike']:
                            if txt.startswith('.assjoin '):
                                text = msg.text[len(".assjoin "):]
                                ticket = text.split("/ti/g/")
                                try:
                                    client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    group = client.findGroupByTicket(ticket[1])
                                    client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                    client.sendText(of,"Successfully joined %s (%s)."%(group.name,len(group.members)))
                                except Exception as error:self.client.sendText(to,"Failed\n %s"%(error))
                            if txt.startswith('.device'):
                                if '.mac' in txt:
                                    self.temp_db['device'] = self.headersmac()
                                    self.temp_db['appName'] = 'DESKTOPMAC\t5.1.2\tMAC\t10.9.4-MAVERICKS-x64'
                                    self.client.sendText(to,'Device updated to mac.')
                                elif '.windows' in txt:
                                    self.temp_db['device'] = self.headerswin()
                                    self.temp_db['appName'] = 'DESKTOPWIN\t5.9.0\t10.9.4-MAVERICKS-x64'#'DESKTOPWIN\t5.1.2\t10.9.4-MAVERICKS-x64'
                                    self.client.sendText(to,'Device updated to windows.')
                                elif '.ipad' in txt:
                                    self.temp_db['device'] = self.headersios()
                                    self.temp_db['appName'] = 'IOSIPAD\t10.2.1\tiPhone 8\t12.1.1'
                                    self.client.sendText(to,'Device updated to ipad.')
                                elif '.win10' in txt:
                                    self.temp_db['device'] = self.headerswin10()
                                    self.temp_db['appName'] = 'WIN10\t5.5.5\tTRIAL\tBot\t12.1.1'
                                    self.client.sendText(to,'Device updated to win10.')
                                elif '.chrome' in txt:
                                    self.temp_db['device'] = self.headerschrome()
                                    self.temp_db['appName'] = 'CHROMEOS\t2.3.0\tChrome_OS\t1'
                                    self.client.sendText(to,'Device updated to chrome.')
                                elif '.tizen' in txt:
                                    self.temp_db['device'] = self.headerstizen()
                                    self.temp_db['appName'] = 'TIZEN\t2.3.2\tpsd\tBot\t12.1.1'
                                    self.client.sendText(to,'Device updated to tizen.')
                                elif '.fire' in txt:
                                    self.temp_db['device'] = self.headersfir()
                                    self.temp_db['appName'] = 'FIREFOXOS 1.4.11 Firefox_OS 1'
                                    self.client.sendText(to,'Device updated to FIREFOXOS.')
                                else:
                                    self.client.sendText(to,"List Device:\n\n  • .mac\n  • .windows\n  • .ipad\n  • .win10\n  • .chrome\n\nexample:\n.device .mac")
                            if txt == "!login-asis":
                                threading.Thread(target=self.loginjs, args=(to,msg)).start()
#--------------------------------BYPASS

#===========BYPASS REMOTE BY THB===================
                            if txt.startswith(".bypassremote "):
                                     text = txt.split(" ")
                                     num = text[1]
                                     if num.isdigit():
                                       groups = self.client.getGroupIdsJoined()
                                       if int(num) < len(groups) and int(num) >= 0:
                                             groupid = groups[int(num)]
                                             group = self.client.getGroup(groupid)
                                             inviter = []
                                             groupnum = []
                                             cmd = 'kickall.js gid={} token={}'.format(groupid, self.client.authToken)
                                             members = [o.mid for o in group.members if o.mid not in self.stats["bots"] and o.mid not in self.staff + self.master]
                                             for invitees in group.invitee:
                                                for o in group.members:
                                                   if invitees.mid not in self.stats["botlist"] and invitees.mid not in self.stats["stafflist"]:
                                                      if o.mid not in self.stats["botlist"] and o.mid not in self.stats["stafflist"]:
                                                         cmd += ' uid={}'.format(invitees.mid)
                                                         cmd += ' uid={}'.format(o.mid)
                                             print(cmd)
                                             success = execute_js(cmd)
                            if txt.startswith('.join-cancel '):
                                text = msg.text[len(".join-cancel "):]
                                ticket = text.split("/ti/g/")
                                try:
                                    client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    group = client.findGroupByTicket(ticket[1])
                                    client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                    x = client.getGroup(group.id)
                                    nama = [contact.mid for contact in x.invitee]
                                    targets = []
                                    for a in nama:
                                        if self.pangkat(a) > 4:
                                            targets.append(a)
                                    if targets == []:
                                        self.client.sendMessage(to,"Target not found.")
                                    else:
                                        cms = 'clear.js gid={} token={} app={}'.format(group.id,self.temp_db['token'],self.temp_db['appName'])
                                        for y in targets:
                                            cms += ' uid={}'.format(y)
                                        success = execute_js(cms)
                                        if success:
                                            try:
                                                client.leaveGroup(group.id)
                                            except:
                                                self.client.sendMessage(to,'LOG_OUT')
                                        else:
                                            self.client.sendMessage(to,'Execute Fail')
                                except Exception as error:self.client.sendText(to,"Failed\n %s"%(error))
                            if txt.startswith('.join-kick '):
                                text = msg.text[len(".join-kick "):]
                                ticket = text.split("/ti/g/")
                                try:
                                    client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    group = client.findGroupByTicket(ticket[1])
                                    client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                    x = client.getGroup(group.id)
                                    abort = False
                                    nami = [contact.mid for contact in x.members]
                                    targetk = []
                                    cms = 'kick.js gid={} token={} app={}'.format(group.id,self.temp_db['token'],self.temp_db['appName'])
                                    for a in nami:
                                        #if a != msg._from and a not in self.master:
                                        if self.pangkat(a) > 4 and a != client.profile.mid:
                                            targetk.append(a)
                                    if msg._from not in self.master:
                                        for m in nami:
                                            if m in self.master:
                                                abort = True
                                    for y in targetk:
                                        cms += ' uid={}'.format(y)
                                    if abort:
                                        for m in self.master:
                                            pass
                                        self.client.sendMessage(to,'Cannot destroy {} ,there are my master'.format(x.name))
                                    else:
                                        self.client.sendMessage(to,'Please wait to destroy {}'.format(x.name))
                                        success = execute_js(cms)
                                        if success:
                                            self.client.sendMessage(to,'Execute success')
                                        else:
                                            self.client.sendMessage(to,'Execute Fail')
                                except Exception as error:self.client.sendText(to,"Failed\n %s"%(error))
                            if txt.startswith('.join-nuker '):
                                text = msg.text[len(".join-nuker "):]
                                ticket = text.split("/ti/g/")
                                try:
                                    client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    group = client.findGroupByTicket(ticket[1])
                                    client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                    x = client.getGroup(group.id)
                                    abort = False
                                    if x.invitee == None:nama = []
                                    else:nama = [contact.mid for contact in x.invitee]
                                    targets = []
                                    for a in nama:
                                        targets.append(a)
                                    nami = [contact.mid for contact in x.members]
                                    targetk = []
                                    cms = 'nook.js gid={} token={} app={}'.format(group.id,self.temp_db['token'],self.temp_db['appName'])
                                    for a in nami:
                                        #if a != msg._from and a not in self.master:
                                        if self.pangkat(a) > 4 and a != client.profile.mid:
                                            targetk.append(a)
                                    if msg._from not in self.master:
                                        for m in nami:
                                            if m in self.master:
                                                abort = True
                                    for y in targets:
                                        cms += ' uid={}'.format(y)
                                    for y in targetk:
                                        cms += ' uik={}'.format(y)
                                    if abort:
                                        for m in self.master:
                                            pass
                                        self.client.sendMessage(to,'Cannot destroy {} ,there are my master'.format(x.name))
                                    else:
                                        self.client.sendMessage(to,'Please wait to destroy {}'.format(x.name))
                                        success = execute_js(cms)
                                        if success:
                                            self.client.sendMessage(to,'Execute Success')
                                        else:
                                            self.client.sendMessage(to,'Execute Fail')
                                except Exception as error:self.client.sendText(to,"Failed\n %s"%(error))
                            if txt.startswith(".kick-r "):
                                number = txt.split(' ')[1]
                                if number.isdigit():
                                    client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    gid = client.getGroupIdsJoined()
                                    gids = gid[int(number)-1]
                                    x = client.getGroup(gids)
                                    abort = False
                                    nami = [contact.mid for contact in x.members]
                                    targetk = []
                                    cms = 'nook.js gid={} token={} app={}'.format(gids,self.temp_db['token'],self.temp_db['appName'])
                                    for a in nami:
                                        if self.pangkat(a) > 4 and a != client.profile.mid:
                                            targetk.append(a)
                                    if msg._from not in self.master:
                                        for m in nami:
                                            if m in self.master:
                                                abort = True
                                    for y in targetk:
                                        cms += ' uid={}'.format(y)
                                    if abort:
                                        for m in self.master:
                                            pass
                                        self.client.sendMessage(to,'Cannot destroy {} ,there are my master'.format(x.name))
                                    else:
                                        self.client.sendMessage(to,'Please wait to destroy {}'.format(x.name))
                                        success = execute_js(cms)
                                        if success:
                                            self.client.sendMessage(to,'Execute success')
                                        else:
                                            self.client.sendMessage(to,'Execute Fail')
                            if txt.startswith(".cancel-r "):
                                number = txt.split(' ')[1]
                                if number.isdigit():
                                    client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    gid = client.getGroupIdsJoined()
                                    gids = gid[int(number)-1]
                                    x = client.getGroup(gids)
                                    nama = [contact.mid for contact in x.invitee]
                                    targets = []
                                    for a in nama:
                                        if self.pangkat(a) > 4:
                                            targets.append(a)
                                    if targets == []:
                                        self.client.sendMessage(to,"Target not found.")
                                    else:
                                        cms = 'cancel.js gid={} token={} app={}'.format(gids,self.temp_db['token'],self.temp_db['appName'])
                                        for y in targets:
                                            cms += ' uid={}'.format(y)
                                        success = execute_js(cms)
                                        if success:
                                            self.client.sendMessage(to,'Execute success')
                                        else:
                                            self.client.sendMessage(to,'Execute Fail')
                            if txt.startswith(".nuker-r "):
                                number = txt.split(' ')[1]
                                if number.isdigit():
                                    client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    gid = client.getGroupIdsJoined()
                                    gids = gid[int(number)-1]
                                    x = client.getGroup(gids)
                                    abort = False
                                    if x.invitee == None:nama = []
                                    else:nama = [contact.mid for contact in x.invitee]
                                    targets = []
                                    for a in nama:
                                        targets.append(a)
                                    nami = [contact.mid for contact in x.members]
                                    targetk = []
                                    cms = 'dual.js gid={} token={} app={}'.format(gids,self.temp_db['token'],self.temp_db['appName'])
                                    for a in nami:
                                        #if a != msg._from and a not in self.master:
                                        if self.pangkat(a) > 4 and a != client.profile.mid:
                                            targetk.append(a)
                                    if msg._from not in self.master:
                                        for m in nami:
                                            if m in self.master:
                                                abort = True
                                    for y in targets:
                                        cms += ' uid={}'.format(y)
                                    for y in targetk:
                                        cms += ' uik={}'.format(y)
                                    if abort:
                                        for m in self.master:
                                            pass
                                        self.client.sendMessage(to,'Cannot destroy {} ,there are my master'.format(x.name))
                                    else:
                                        self.client.sendMessage(to,'Please wait to destroy {}'.format(x.name))
                                        success = execute_js(cms)
                                        if success:
                                            self.client.sendMessage(to,'Execute Success')
                                        else:
                                            self.client.sendMessage(to,'Execute Fail')
######## EXC
#########################
                        if of in self.master:
                            if msg.text.startswith('.run\n'):
                                try:
                                    self.reply.addFuncInterrupt("m_exec_thread",self.m_exec_thread(msg))
                                except:
                                    traceback.print_exc()
                            if txt.startswith('# '):
                                    a=subprocess.getoutput(self.client.nyeplitin(msg.text))
                                    k = len(a)//10000
                                    for aa in range(k+1):
                                        try:self.client.sendMessage(to,'{}'.format(a[aa*10000 : (aa+1)*10000]))   
                                        except:self.client.sendMessage(to,'done')
                            if txt.startswith(".savefile "):
                                    txt = msg.text.split(".savefile ")
                                    jmlh = str(txt[1])
                                    add["img"] = jmlh
                                    add["save"] = True
                                    self.client.sendMessage(to,"Kirim Berkasnya")
                            if txt.startswith('.delfile '):
                                    try:
                                        separate = msg.text.split(".delfile ")
                                        tos = msg.text.replace(separate[0] + ".delfile ","")
                                        self.client.sendFile(to,tos)
                                    except Exception as e:self.client.sendMessage(to, "「 File  "+ tos +" tidak ditemukan 」")
                            if txt.startswith('.saveaudio '):
                                    try:
                                        separate = msg.text.split(".saveaudio ")
                                        tis = msg.text.replace(separate[0] + ".saveaudio ","")
                                        self.client.sendAudio(to,tis)
                                    except:self.client.sendMessage(to, " File  "+ tis +" tidak ditemukan 」")
                            if txt.startswith('.saveimage '):
                                    try:
                                        separate = msg.text.split(".saveimage ")
                                        tex = msg.text.replace(separate[0] + ".saveimage ","")
                                        self.client.sendImage(to,tex)
                                    except:self.client.sendMessage(to, "「 File  "+ tex +" tidak ditemukan 」")
                            if txt.startswith('.savevideo '):
                                    try:
                                        separate = msg.text.split(".savevideo ")
                                        tus = msg.text.replace(separate[0] + ".savevideo ","")
                                        self.client.sendVideo(to,tus)
                                    except:self.client.sendMessage(to, "「 File  "+ tus +" tidak ditemukan 」")

######## EXC
#########################
                    elif msg.contentType == 7:
                        if self.settings['staggpm'] == True:
                                stk_id = msg.contentMetadata['STKID']
                                stkku = self.stats["staggpm"]['pid'],self.stats['staggpm']['sid'],self.stats['staggpm']['v']
                                if stk_id in stkku:
                                    if msg._from in of:
                                        profile = self.client.getContact(to)
                                        try:
                                            self.sendMention(to,"@!",[to])
                                        except:
                                            print("[7] notified Stickertaggpm")
                    elif msg.contentType == 13:
                        if self.spam:
                            uid = msg.contentMetadata["mid"]
                            if uid not in self.sasaran:
                                self.sasaran.append(uid)
                                if not silent:self.client.sendMessage(to,"User %s added to spam list"%(self.client.getContact(uid).displayName))
                            else:
                                if not silent:self.client.sendMessage(to,"%s already on spam list"%(self.client.getContact(uid).displayName))
######## C O N T E N T Y P E
#########################
                if msg.toType == 1:
                    if msg.text:
                      txt = " ".join(msg.text.lower().split())
                      cmds = self.mycmd(txt)
                      for a in cmds:
                        txt = a
                        if txt == ".id":
                            self.client.sendMessage(to,msg.to)

                if msg.toType == 2:
                    if msg.text:
                      txt = " ".join(msg.text.lower().split())
                      A = self.client.getProfile().displayName
                      cmds = self.mycmd(txt)
                      for a in cmds:
                        txt = a      
                        if '.silent' in txt:
                            silent = True
                        if ".r:" in txt:
                            func = lambda s: s[:1].lower() + s[1:] if s else ''
                            if not ".r: " in txt:
                                number = txt.split(".r:")[1]
                                number = number.split()[0]
                                gid = self.client.getGroupIdsJoined()
                                if number.isdigit():
                                    number = int(number)
                                    group = gid[number]
                                    to = group
                                txt = txt.replace(".r:%s"%number,"").lstrip().rstrip()
                                if ".r:" in msg.text:
                                    msg.text = msg.text.replace(".r:%s"%number,"").lstrip().rstrip()
                                    func(msg.text)
                                else:
                                    msg.text = msg.text.replace(".R:%s"%number,"").lstrip().rstrip()
                                    func(msg.text)
                                self.client.sendText(msg.to,"Succes remote for %s"%self.client.getGroup(group).name)

                        if self.commands["tmpstickers"] != {}:
                            if txt in self.commands["tmpstickers"].keys():
                                sticker = self.commands["tmpstickers"][txt]
                                ids = sticker[0]
                                ipg = sticker[1]
                                a = self.client.shop.getProduct(packageID=int(ipg), language='ID', country='ID')
                                if a.hasAnimation == True:
                                    data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/IOS/sticker_animation@2x.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                    print(data)
                                    self.sendTemplate(to,data)
                                else:
                                    data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/ANDROID/sticker.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                    print(data)
                                    self.sendTemplate(to,data)
                
                        if msg.text.lower().startswith(".remote:"):
                            if not ".remote: " in msg.text.lower():
                                number = msg.text.lower().split(".remote:")[1]
                                number = number.split()[0]
                                num = int(number)
                                gid = self.client.getGroupIdsJoined()
                                sumi = gid[num-1]
                                group = sumi
                                to = group
                                if not " & " in msg.text.lower():
                                   z = msg.text.lower().replace(".remote:%s "%number,"").lstrip().rstrip()
                                   cmds = [z]
                                   if not silent:self.client.sendMessage(msg.to,"Command '%s' sent to group %s."%(z.replace(".remote:",""),self.client.getGroup(group).name))
                                else:
                                   z = msg.text.lower().replace(".remote:%s "%number,"").lstrip().rstrip()
                                   cmds = z.split(" & ")
                                   if not silent:self.client.sendMessage(msg.to,"Multi Command '%s' sent to group %s."%(z.replace(".remote:",""),self.client.getGroup(group).name))
#################### B A N G S A T
#########$$$$$$$$$$$$$$$$$$$
                        if self.settings['autolike']:
                            if txt.startswith('.assjoin '):
                                text = msg.text[len(".assjoin "):]
                                ticket = text.split("/ti/g/")
                                try:
                                    client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    group = client.findGroupByTicket(ticket[1])
                                    client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                    client.sendText(of,"Successfully joined %s (%s)."%(group.name,len(group.members)))
                                except Exception as error:self.client.sendText(to,"Failed\n %s"%(error))
                            if txt.startswith('.device'):
                                if '.mac' in txt:
                                    self.temp_db['device'] = self.headersmac()
                                    self.temp_db['appName'] = 'DESKTOPMAC\t5.8.0\t10.9.4-TRIAL-BOT-x64'
                                    self.client.sendText(to,'Device updated to mac.')
                                elif '.windows' in txt:
                                    self.temp_db['device'] = self.headerswin()
                                    self.temp_db['appName'] = 'DESKTOPWIN\t5.9.0\t10.9.4-MAVERICKS-x64'#'DESKTOPWIN\t5.1.2\t10.9.4-MAVERICKS-x64'
                                    self.client.sendText(to,'Device updated to windows.')
                                elif '.ipad' in txt:
                                    self.temp_db['device'] = self.headersios()
                                    self.temp_db['appName'] = 'IOSIPAD\t10.2.1\tiPhone 8\t12.1.1'
                                    self.client.sendText(to,'Device updated to ipad.')
                                elif '.win10' in txt:
                                    self.temp_db['device'] = self.headerswin10()
                                    self.temp_db['appName'] = 'WIN10\t5.5.5\tTRIAL\tBot\t12.1.1'
                                    self.client.sendText(to,'Device updated to win10.')
                                elif '.chrome' in txt:
                                    self.temp_db['device'] = self.headerschrome()
                                    self.temp_db['appName'] = 'CHROMEOS 2.1.5 RgBot12.1.1'
                                    self.client.sendText(to,'Device updated to chrome.')
                                elif '.tizen' in txt:
                                    self.temp_db['device'] = self.headerstizen()
                                    self.temp_db['appName'] = 'TIZEN\t2.3.2\tpsd\tBot\t12.1.1'
                                    self.client.sendText(to,'Device updated to tizen.')
                                elif '.fire' in txt:
                                    self.temp_db['device'] = self.headersfir()
                                    self.temp_db['appName'] = 'FIREFOXOS 1.4.11 Firefox_OS 1'
                                    self.client.sendText(to,'Device updated to FIREFOXOS.')
                                else:
                                    self.client.sendText(to,"List Device:\n\n  • .mac\n  • .windows\n  • .ipad\n  • .win10\n  • .chrome\n\nexample:\n.device .mac")
                            if txt == "!login-asis":
                                try:
                                    nama = "RgBots"
                                    self.temp_db['device'].update({'x-lpqs' : '/api/v4/TalkService.do'})
                                    transport = THttpClient.THttpClient('https://legy-jp.line.naver.jp/api/v4/TalkService.do')
                                    transport.setCustomHeaders(self.temp_db['device'])
                                    protocol = TCompactProtocol.TCompactProtocol(transport)
                                    cl = TalkService.Client(protocol)
                                    qr = cl.getAuthQrcode(keepLoggedIn=1, systemName=nama)
                                    link = "line://au/q/" + qr.verifier
                                    self.client.sendText(to,"Click link below in 2 minutes before expired \n"+str(link))
                                    self.temp_db['device'].update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
                                    json.loads(requests.session().get('https://legy-jp.line.naver.jp/Q', headers=self.temp_db['device']).text)
                                    self.temp_db['device'].update({'x-lpqs' : '/api/v4p/rs'})
                                    transport = THttpClient.THttpClient('https://legy-jp.line.naver.jp/api/v4p/rs')
                                    transport.setCustomHeaders(self.temp_db['device'])
                                    protocol = TCompactProtocol.TCompactProtocol(transport)
                                    cl = AuthService.Client(protocol)
                                    req = LoginRequest()
                                    req.type = 1
                                    req.verifier = qr.verifier
                                    req.e2eeVersion = 1
                                    temp_client = cl.loginZ(req)
                                    self.temp_db['token'] = temp_client.authToken
                                    self.client.sendText(to,"Success login Antijs")
                                except Exception as e:self.client.sendText(to,"Maaf anda di banned login\ntunggu 24 jam br anda bisa login lagi.");traceback.print_exc()
                        if txt == '.glink':
                            try:
                                g = self.client.getCompactGroup(to)
                                gurl = self.client.reissueGroupTicket(to)
                                self.client.sendMessage(msg.to,"https://line.me/R/ti/g/" + gurl)
                                if g.preventedJoinByTicket == True:
                                    g.preventedJoinByTicket = False
                                    self.client.updateGroup(g)
                            except:self.client.sendMessage(msg.to,"「 failed 」")

                        if txt == ".protection:max":
                            self.settings["protect"][to] = 2
                            self.settings["denyinvite"][to] = 2
                            self.settings["linkprotect"][to] = 1
                            self.settings["allowban"][to] = 0
                            group = self.client.getGroup(to)
                            self.settings["namelock"][to] = {"on":1,"name":group.name}
                            links = group.preventedJoinByTicket
                            if links == False:
                                group.preventedJoinByTicket = True
                                self.client.updateGroup(group)
                            if not silent:self.client.sendText(to,"Max protection enabled.")
                        if txt == ".protection:none":
                            self.settings["protect"][to] = 0
                            self.settings["denyinvite"][to] = 0
                            self.settings["linkprotect"][to] = 0
                            self.settings["allowban"][to] = 0
                            self.settings["namelock"][to] = {"on":0,"name":""}
                            if not silent:self.client.sendText(to,"All protection disabled.")
######## EXC
#########################
                        if of in self.master:
                            if msg.text.startswith('.run\n'):
                                try:
                                    self.reply.addFuncInterrupt("m_exec_thread",self.m_exec_thread(msg))
                                except:
                                    traceback.print_exc()
                            if txt.startswith('# '):
                                    a=subprocess.getoutput(self.client.nyeplitin(msg.text))
                                    k = len(a)//10000
                                    for aa in range(k+1):
                                        try:self.client.sendMessage(to,'{}'.format(a[aa*10000 : (aa+1)*10000]))   
                                        except:self.client.sendMessage(to,'done')
                            if txt.startswith(".savefile "):
                                    txt = msg.text.split(".savefile ")
                                    jmlh = str(txt[1])
                                    add["img"] = jmlh
                                    add["save"] = True
                                    self.client.sendMessage(to,"Kirim Berkasnya")
                            if txt.startswith('.sendfile '):
                                    try:
                                        separate = msg.text.split(".sendfile ")
                                        tos = msg.text.replace(separate[0] + ".sendfile ","")
                                        self.client.sendFile(to,tos)
                                    except Exception as e:self.client.sendMessage(to, "「 File  "+ tos +" tidak ditemukan 」")
                            if txt.startswith('.sendaudio '):
                                    try:
                                        separate = msg.text.split(".sendaudio ")
                                        tis = msg.text.replace(separate[0] + ".sendaudio ","")
                                        self.client.sendAudio(to,tis)
                                    except:self.client.sendMessage(to, "「 File  "+ tis +" tidak ditemukan 」")
                            if txt.startswith('.sendimage '):
                                    try:
                                        separate = msg.text.split(".sendimage ")
                                        tex = msg.text.replace(separate[0] + ".sendimage ","")
                                        self.client.sendImage(to,tex)
                                    except:self.client.sendMessage(to, "「 File  "+ tex +" tidak ditemukan 」")
                            if txt.startswith('.sendvideo '):
                                    try:
                                        separate = msg.text.split(".sendvideo ")
                                        tus = msg.text.replace(separate[0] + ".sendvideo ","")
                                        self.client.sendVideo(to,tus)
                                    except:self.client.sendMessage(to, "「 File  "+ tus +" tidak ditemukan 」")
                            if txt == ".here":
                                x = self.client.getGroup(to)
                                nama = [contact.mid for contact in x.members]
                                targets = []
                                with open('/root/register.json', 'r') as fp:
                                  uka = json.load(fp)
                                for a in nama:
                                    if a in uka:
                                        targets.append(a)
                                if not silent:self.client.sendMessage(to,"Bots in group: {}/{}.".format(len(targets),len(uka)))
                            if txt.lower() == ".regis bot":
                                with open('/root/token.json', 'r') as fp:
                                    uki = json.load(fp)
                                with open('/root/register.json', 'r') as fp:
                                    uka = json.load(fp)
                                for a in uki:
                                    for z in uki[a]:
                                        print(z)
                                        if ':' in z:
                                            k = z.split(':')[0]
                                            if k not in uka:
                                                uka.append(k)
                                with open('/root/register.json', 'w') as fp:
                                    json.dump(uka, fp, sort_keys=True, indent=4)
                                self.client.sendMessage(to, "All bot has been registered.")
                            if txt.lower() == ".botlist contact":
                                with open('/root/register.json', 'r') as fp:
                                    uka = json.load(fp)
                                dl = []
                                no = 1
                                mc = 'List Bot:\n\n'
                                for a in uka:
                                    try:
                                        self.client.sendContact(to, a)
                                    except:
                                        dl.append(a)
                                for j in dl:
                                    uka.remove(j)
                                with open('/root/register.json', 'w') as fp:
                                    json.dump(uka, fp, sort_keys=True, indent=4)
                                mc+='Total {} bots'.format(len(uka))
                                self.client.sendMessage(to, mc)
                            if txt.lower() == ".bot list":
                                with open('/root/register.json', 'r') as fp:
                                    uka = json.load(fp)
                                dl = []
                                no = 1
                                mc = 'List Bot:\n\n'
                                for a in uka:
                                    try:
                                        mc+= '{}. {}\n'.format(no,self.client.getContact(a).displayName)
                                        no = no+1
                                    except:
                                        dl.append(a)
                                for j in dl:
                                    uka.remove(j)
                                with open('/root/register.json', 'w') as fp:
                                    json.dump(uka, fp, sort_keys=True, indent=4)
                                mc+='\nTotal {} bots'.format(len(uka))
                                self.client.sendMessage(to, mc)
######## EXC
#########################
                        
                        if txt == ".help js":
                                data = {
                                    "type": "flex",
                                    "altText": "ᴊᴀᴠᴀsᴄʀɪᴘᴛ",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "1:1",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ʙʏᴘᴀss\n• .ᴊsᴄᴀɴᴄᴇʟ\n",
                                                                    "size": "xs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "140px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴊs",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == ".help antijs":
                                data = {
                                    "type": "flex",
                                    "altText": "ᴀɴᴛɪᴊs",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ᴍʏᴀᴊs\n• .ᴀᴊs:ᴏɴ\n• .ᴀᴊs:ᴏғғ\n• .ᴀᴊs:ᴛᴇsᴛ\n• .ᴀᴊs:ᴊᴏɪɴ\n• .ᴀᴊs:ʙʏᴇ\n• .ᴀᴊsᴋɪᴄᴋ\n• .ᴀᴊsɴᴜᴋᴇ\n• .ᴄʜᴀɴɢᴇᴘɪᴄᴛ:ᴀᴊs\n• .ᴄʜᴀɴɢᴇɴᴀᴍᴇᴀᴊs\n• .ᴄʜᴀɴɢᴇʙɪᴏᴀᴊs\n",
                                                                    "size": "xs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "240px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴀɴᴛɪᴊs",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == ".help respon":
                                data = {
                                    "type": "flex",
                                    "altText": "respon command",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ʙɪɢsᴛɪᴄᴋᴇʀ ᴏɴ/ᴏғғ\n• .ᴛᴀɢᴍsɢ:ᴏғғ\n• .ᴛᴀɢᴍsɢ2:ᴏɴ (ᴋᴀᴛᴀ𝟸ɴʏᴀ)\n• .sᴛɪᴄᴋᴇʀᴛᴇxᴛ ᴏɴ/ᴏғғ\n• .ʀᴇsᴘᴏɴɪᴍɢ ᴏɴ/ᴏғғ\n• .ʀᴇsᴘᴏɴᴛᴇxᴛ ᴏɴ/ᴏғғ\n• .ᴀʟʟʀᴇsᴘᴏɴ ᴏɴ/ᴏғғ\n• .sᴛɪᴄᴋᴇʀʙᴀɴ\n• .sɪᴅᴇʀᴛᴇxᴛ: (ᴋᴀᴛᴀ𝟸ɴʏᴀ)\n• .sᴛɪᴄᴋᴇʀʙᴀɴ ᴏɴ/ᴏғғ\n• .ʀsᴛɪᴄᴋᴇʀ\n• .ʀsᴛɪᴄᴋᴇʀ ᴏɴ/ᴏғғ\n",
                                                                    "size": "xs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ʀᴇsᴘᴏɴ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ᴛᴀɢᴍsɢ2:ᴏғғ\n• .ᴛᴀɢᴍsɢ:ᴏɴ (ᴋᴀᴛᴀ𝟸ɴʏᴀ)\n• .sɪᴅᴇʀ .ᴏɴ/.ᴏғғ\n• .ʀsɪᴅᴇʀ (ᴋᴀᴛᴀ𝟸ɴʏᴀ)\n• .ᴄᴇᴋsɪᴅᴇʀ ᴏɴ/ᴏғғ\n• .sᴛɪᴄᴋᴇʀ .ᴀᴅᴅ (ᴋᴀᴛᴀ𝟸ɴʏᴀ)\n• .sᴛɪᴄᴋᴇʀ .ᴏғғ (ᴋᴀᴛᴀ𝟸ɴʏᴀ)\n• .ᴀᴅᴅᴄᴏᴍᴍᴀɴᴅ .ᴀᴅᴅ (ᴋᴀᴛᴀ𝟸ɴʏᴀ)\n• .ᴀᴅᴅᴄᴏᴍᴍᴀɴᴅ .ᴅᴇʟ (ᴋᴀᴛᴀ𝟸ɴʏᴀ)\n",
                                                                    "size": "xs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ʀᴇsᴘᴏɴ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == ".help pm":
                                data = {
                                    "type": "flex",
                                    "altText": "ᴘᴍ",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ᴜᴄᴏɴᴛᴀᴄᴛ\n• .ᴜsᴛᴀᴛᴜs\n• .ᴜᴘɪᴄᴛᴜʀᴇ\n• .ᴜᴠɪᴅᴇᴏ\n• .ɢᴇᴛ-ᴛʟ\n• .ᴜᴍɪᴅ\n• .ᴜɴᴀᴍᴇ\n• .ᴜᴄᴏᴠᴇʀ\n• .ʟɪɴᴇɪᴅ\n• .ʙʟᴀɴᴋ",
                                                                    "size": "xs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴘᴍ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == ".help spam":
                                data = {
                                    "type": "flex",
                                    "altText": "ʜᴇʟᴘ sᴘᴀᴍ",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:3",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .sᴘᴀᴍᴄʟᴇᴀʀ\n• .ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴏɴ/ᴏғғ\n• .ʀᴏᴏᴍ ᴏɴ/ᴏғғ\n• .ʟᴇᴀᴠᴇ:ᴀʟʟ\n• .ʀᴇᴊᴇᴄᴛᴀʟʟ\n• .ᴀᴜᴛᴏʙʟᴏᴄᴋ ᴏɴ/ᴏғғ\n• .ᴋᴇʟᴜᴀʀ (ɴᴀᴍᴀ ɢʀᴏᴜᴘ)",
                                                                    "size": "xs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "180px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ sᴘᴀᴍ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == 'help':
                            datafox = [{
                                "type": "bubble",
                                "styles": {
                                "header": {"backgroundColor": "#000000"},
                                "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                "header": {
                                "type": "box",
                                "layout": "vertical",
                                "spacing": "sm",
                                "contents": [{
                                "type": "text",
                                "text": "☯☯ 𝕳𝖊𝖑𝖕 𝕮𝖔𝖒𝖒𝖆𝖓𝖉 ☯☯",
                                "size": "lg",
                                "weight": "bold",
                                "align": "center",
                                "color": "#FFFFFF"},{
                                "type": "text",
                                "text": "• .ʜᴇʟᴘ ᴍᴀɴᴀɢɪɴɢ",
                                "color": "#FFFFFF",
                                'flex': 1,},{
                                "type": "text",
                                "text": "• .ʜᴇʟᴘ ɢʀᴏᴜᴘs",
                                "color": "#FFFFFF",
                                'flex': 2,},{
                                "type": "text",
                                "text": "• .ʜᴇʟᴘ ᴜsᴇʀ",
                                "color": "#FFFFFF",
                                'flex': 3,},{
                                "type": "text",
                                "text": "• .ʜᴇʟᴘ ᴍᴇᴅɪᴀ",
                                "color": "#FFFFFF",
                                'flex': 4,},{
                                "type": "text",
                                "text": "• .ʜᴇʟᴘ ᴘʀᴏ",
                                "color": "#FFFFFF",
                                'flex': 5,},{
                                "type": "text",
                                "text": "• .ʜᴇʟᴘ ᴊs",
                                "color": "#FFFFFF",
                                'flex': 6,},{
                                "type": "text",
                                "text": "• .ʜᴇʟᴘ ᴘᴍ",
                                "color": "#FFFFFF",
                                'flex': 7,},{
                                "type": "text",
                                "text": "• .ʜᴇʟᴘ ᴀɴᴛɪsᴘᴀᴍ",
                                "color": "#FFFFFF",
                                'flex': 8,},{
                                "type": ".ʙᴇʟᴀᴊᴀʀ",
                                "text": "• .sᴇᴛᴛɪɴɢs",
                                "color": "#FFFFFF",
                                'flex': 9,},{
                                "type": "text",
                                "text": "• .sᴇᴛᴛɪɴɢs",
                                "color": "#FFFFFF",
                                'flex': 10,},{
                                "type": "text",
                                "text": "• .ᴋᴇʏ",
                                "color": "#FFFFFF",
                                'flex': 11,}]},
                                "footer": {
                                "type": "box",
                                "layout": "vertical",
                                "spacing": "sm",
                                "contents": [{
                                "type": "box",
                                "layout": "baseline",
                                "contents": [{
                                "type": "icon",
                                "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                "size": "xl"},{
                                "type": "text",
                                "text": "˜”*°• 𝕽𝖌 𝖘𝖊𝖑𝖋𝖇𝖔𝖙 𝓥.1.4 •°*”˜",
                                "align": "center",
                                "color": "#FFFFFF",
                                "size": "md",
                                "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~regathb1"}},{
                                "type": "icon",
                                "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                "size": "xl"},{
                                "type": "spacer",
                                "size": "sm"}]}]}}]
                            data = {"type": "flex","altText": "ʜᴇʟᴘ ᴄᴏᴍᴍᴀɴᴅ","contents": {"type": "carousel","contents": datafox}}#carousel
                            self.sendTemplate(to, data)
                        if txt == ".help protect":
                                data = {
                                    "type": "flex",
                                    "altText": "ᴘʀᴏᴛᴇᴄᴛ",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ᴅᴇɴʏɪɴᴠɪᴛᴇ\n• .ʟɪɴᴋᴘʀᴏᴛᴇᴄᴛ\n• .ᴘʀᴏᴛᴇᴄᴛ\n• .ɴᴀᴍᴇʟᴏᴄᴋ\n• .ɪᴄᴏɴʟᴏᴄᴋ\n• .ᴘʀᴏᴀʟʙᴜᴍ\n• .ᴀᴜᴛᴏᴘᴜʀɢᴇ\n• .ᴘʀᴏᴛᴇᴄᴛɪᴏɴ:ᴍᴀx\n• .ᴘʀᴏᴛᴇᴄᴛɪᴏɴ:ɴᴏɴᴇ",
                                                                    "size": "xs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴘʀᴏᴛᴇᴄᴛ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == ".help media":
                                data = {
                                    "type": "flex",
                                    "altText": "ᴍᴇᴅɪᴀ",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .sʏᴏᴜᴛᴜʙᴇ\n• .ɢʀᴏᴜᴘᴄᴀsᴛ\n• .ɪɴsᴛᴀɢʀᴀᴍ\n• .ʏᴏᴜᴛᴜʙᴇ\n• .ʏᴍᴘ3\n• .ʏᴍᴘ4\n• .ᴛᴡɪᴛᴛᴇʀ\n• .ɢɪᴛʜᴜʙ\n• .ɪᴍɢ\n• .ᴀʀᴛ",
                                                                    "size": "xs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴍᴇᴅɪᴀ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ǫᴜᴏᴛᴇs\n• .ᴀɴɪᴍᴇǫᴜᴏᴛᴇs\n• .ᴀɴɪᴍᴇ\n• .ᴀɴɪᴅᴏᴡɴ\n• .ʀᴇᴛʀᴏ\n• .ᴘᴍᴄᴀsᴛ\n• .sᴘʀᴏғɪʟᴇ\n• .ᴍᴘ3\n• .ᴍᴘ4\n• .sᴄʟᴏᴜᴅ",
                                                                    "size": "xs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴍᴇᴅɪᴀ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == ".help user":
                                data = {
                                    "type": "flex",
                                    "altText": "ᴍᴀɴᴀɢɪɴɢ",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ᴍᴇ\n• .ғʀɪᴇɴᴅs\n• .ᴀᴅᴅᴄᴏɴ\n• .ᴅᴇʟᴄᴏɴ\n• .sᴛᴀᴛs\n• .ᴀᴅᴅᴍᴇssᴀɢᴇ\n• .ᴀᴜᴛᴏʙʟᴏᴄᴋ\n• .ᴘɪᴄᴛᴜʀᴇ\n• .ᴄᴏᴠᴇʀ\n• .ᴜʀʟᴄᴏᴠeʀ",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴜsᴇʀ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ᴜʀʟᴘɪᴄᴛ\n• .ᴀᴜᴛᴏʟᴇᴀᴠᴇ ᴏɴ/ᴏғғ\n• .ᴄᴏᴘʏᴄᴏᴠᴇʀ\n• .ᴄᴏᴘʏᴘɪᴄᴛ\n• .ᴄʟᴏɴᴇ\n• .ᴜᴘsᴛᴀᴛᴜs\n• .ᴜᴘɴᴀᴍᴇ\n• .ᴜᴘᴅᴜᴀʟ\n• .ᴜᴘɪᴍᴀɢᴇ\n• .ᴜᴘᴅᴀᴛᴇᴄᴏᴠᴇʀ",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴜsᴇʀ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .sᴛᴀᴛᴜs\n• .ᴜsᴇʀɪᴅ\n• .ᴄᴏᴜɴᴛᴅᴏᴡɴ (ɴᴜᴍʙᴇʀ)\n• .ɢᴇᴛ-ɴᴏᴛᴇ (ɴᴜᴍʙᴇʀ ᴘᴏsᴛ)\n• .ɢᴇᴛ-ɴᴀᴍᴇ @\n• .ɢᴇᴛ-ɢɴᴏᴛᴇ (ɴᴏ.ᴘᴏsᴛ ɴᴏᴛᴇ)(ɴᴏ.ɢʀᴏᴜᴘ)\n• .ɢᴇᴛ-ɪɴғᴏ (ɴᴏ.ɢʀᴏᴜᴘ)\n• .ɢᴇᴛ-ᴘʀᴏғɪʟᴇ (ɴᴏ.ɢʀᴏᴜᴘ)(ɴᴏ.ᴍᴇᴍʙᴇʀ)\n• .ɢᴇᴛ-sᴛᴀᴛᴜs (ɴᴏ.ɢʀᴏᴜᴘ)(ɴᴏ.ᴍᴇᴍʙᴇʀ)\n• .ɪɴғᴏ:ᴏɴ/ʀᴇᴘᴇᴀᴛ\n",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴜsᴇʀ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ɢᴇᴛᴠɪᴅᴇᴏ\n• .ᴍɪᴅ\n• .ᴘᴍʙᴏx\n• .sᴛɪᴄᴋᴇʀᴛᴇxᴛ ᴏɴ/ᴏғғ\n• .ʀᴇɴᴀᴍᴇ\n• .ᴄʀᴇᴀᴛᴇ\n• .ʀᴇᴍᴏᴠᴇ\n• .ᴄᴏᴍᴍᴀɴᴅ\n• .ɢᴘᴇɴᴅɪɴɢ\n• .ᴍʏᴠɪᴅᴇᴏ\n• .ᴍʏ sᴛɪᴄᴋᴇʀ",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap":True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴜsᴇʀ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == ".managing":
                                data = {
                                    "type": "flex",
                                    "altText": "ᴍᴀɴᴀɢɪɴɢ",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .sɪʟᴇɴᴛ\n• .ʀᴇᴍᴏᴛᴇ\n• .ɢʀᴏᴜᴘs\n• .ᴀᴅᴅsᴛᴀғғ\n• .ᴀᴅᴅʙᴏᴛ\n• .ᴀᴅᴅʙᴀɴ\n• .ᴜɴʙᴀɴ\n• .sᴛᴀғғʟɪsᴛ\n• .ʙᴏᴛʟɪsᴛ\n• .ʙᴀɴʟɪsᴛ",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴍᴀɴᴀɢɪɴɢ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .sᴛᴀғғᴄᴏɴ\n• .ʙᴏᴛᴄᴏɴ\n• .ʙᴀɴᴄᴏɴ\n• .ʙɪɢsᴛᴋ\n• .ᴜɴsᴇɴᴅ\n• .ᴋᴇʏ\n• .sᴛɪᴄᴋᴇʀ\n• .sᴇɴᴅᴠɪᴅᴇᴏ\n• .sᴇɴᴅғɪʟᴇ\n• .sᴇɴᴅɪᴍᴀɢᴇ",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴍᴀɴᴀɢɪɴɢ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .sᴇɴᴅᴀᴜᴅɪᴏ\n• .ʀᴇʙᴏᴏᴛ\n• .sᴇɴᴅᴀᴜᴅɪᴏ\n• !ᴜᴘᴅᴀᴛᴇ\n• .ʟᴀsᴛsᴇᴇɴ\n• .ɢɪғᴛ\n• .ᴀʙᴏʀᴛ\n• .ᴀᴜᴛᴏᴊᴏɪɴ\n• .sʟᴇᴇᴘᴍsɢ\n• .sʟᴇᴇᴘᴍᴏᴅᴇ\n",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴍᴀɴᴀɢɪɴɢ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ᴀʙᴏʀᴛ\n• .ᴀʙᴏʀᴛ-ᴊs\n• .ʙɪɢsᴛɪᴄᴋᴇʀ ᴏɴ/ᴏғғ\n• .sᴛɪᴄᴋᴇʀᴛᴇxᴛ ᴏɴ/ᴏғғ\n• .ɴᴇxᴛ ᴜᴘᴅᴀᴛᴇ\n• .ɴᴇxᴛ ᴜᴘᴅᴀᴛᴇ\n• .ɴᴇxᴛ ᴜᴘᴅᴀᴛᴇ\n• .ɴᴇxᴛ ᴜᴘᴅᴀᴛᴇ\n• .ɴᴇxᴛ ᴜᴘᴅᴀᴛᴇ\n• .ɴᴇxᴛ ᴜᴘᴅᴀᴛᴇ\n",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap":True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ᴍᴀɴᴀɢɪɴɢ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == ".help group":
                                data = {
                                    "type": "flex",
                                    "altText": "ʜᴇʟᴘ ɢʀᴏᴜᴘ",
                                    "contents": {
                                        "type": "carousel",
                                        "contents": [
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ɢᴄᴏɴ\n• .ᴋɪᴄᴋ\n• .ᴄᴀɴᴄᴇʟ\n• .ᴜᴘᴅᴀᴛᴇ ɢᴘɪᴄ\n• .ʀᴏᴏᴍ ᴏɴ/ᴏғғ\n• .ɢʟɪɴᴋ\n• .ʀsᴛɪᴄᴋᴇʀ ᴏɴ/ᴏғғ\n• .ᴛᴀɢᴍsɢ:ᴏɴ (ᴛᴇxᴛ)\n• .ɢᴇᴛᴘɪᴄᴀʟʟ\n• .ᴛᴀɢᴍsɢ:ᴏғғ",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ɢʀᴏᴜᴘ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .ʀsᴛɪᴄᴋᴇʀ\n• .sᴇɴᴅᴍsɢ @\n• .ᴅᴇᴛᴇᴄᴛᴜɴsᴇɴᴅ ᴏɴ/ᴏғғ\n• .ᴛʀᴀɴsʟᴀᴛᴇ\n• .ʀᴇᴍᴏᴛᴇᴅ\n• .ᴏᴜᴛsᴛɪᴄᴋᴇʀ:ᴏɴ/ᴏғғ\n• .ᴊᴏɪɴʙᴏᴛs\n• .ɪɴᴠɪᴛᴇʙᴏᴛs\n• .ɪᴄᴏɴʟᴏᴄᴋ:ᴏɴ/ᴏғғ\n• .ɢᴄᴀʟʟ (ɴᴜᴍʙᴇʀ)",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ɢʀᴏᴜᴘ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .sᴘᴀᴍᴄᴀʟʟ (ɴᴜᴍʙᴇʀ) @\n• .sᴘᴀᴍᴛᴀɢ (ɴᴜᴍʙᴇʀ) @\n• .sᴀᴠᴇғɪʟᴇ\n• .sᴀᴠᴇᴀᴜᴅɪᴏ\n• .sᴀᴠᴇᴠɪᴅᴇᴏ\n• .sᴀᴠᴇɪᴍᴀɢᴇ\n• .ʟᴇᴀᴠᴇ\n• .ɪᴍɢsɪᴅᴇʀ\n• .ᴠᴋɪᴄᴋ\n• .sɪᴅᴇʀ .ᴏɴ/.ᴏғғ\n",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap": True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ɢʀᴏᴜᴘ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                            {
                                                "type": "bubble",
                                                "size": "micro",
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "image",
                                                            "url": "{}".format(self.settings["tema"]),
                                                            "size": "full",
                                                            "aspectMode": "cover",
                                                            "aspectRatio": "3:5",
                                                            "gravity": "center",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "horizontal",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "• .sɪᴅᴇʀ .ᴏɴ/.ᴏғғ\n• .ɢᴇᴛ-ᴛʟ @\n• .sᴇᴛᴛɪɴɢs\n• .ᴄʜᴇᴄᴋ\n• .ᴛᴀɢᴍsɢ𝟸:ᴏɴ (ᴛᴇxᴛ)\n• .ᴛᴀɢᴍsɢ𝟸:ᴏғғ\n• .ᴀᴜᴛᴏʀᴇᴀᴅ\n• .ᴡᴇʟᴄᴏᴍᴇᴍsɢ:ᴏɴ\n• .ᴡᴇʟᴄᴏᴍᴇᴍsɢ:ᴏғғ\n• .ᴏᴜᴛᴍsɢ:ᴏɴ/ᴏғғ\n",
                                                                    "size": "xxs",
                                                                    "color": "#00FFF9",
                                                                    "align": "start",
                                                                    "gravity": "center",
                                                                    "wrap":True,
                                                                }
                                                            ],
                                                            "paddingAll": "2px",
                                                            "paddingStart": "4px",
                                                            "paddingEnd": "4px",
                                                            "flex": 0,
                                                            "position": "absolute",
                                                            "offsetStart": "8px",
                                                            "offsetTop": "8px",
                                                            "cornerRadius": "10px",
                                                            "width": "140px",
                                                            "height": "250px",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "ʜᴇʟᴘ ɢʀᴏᴜᴘ",
                                                                    "color": "#ffffff",
                                                                    "align": "center",
                                                                    "size": "sm",
                                                                    "offsetTop": "1px"
                                                                }
                                                            ],
                                                            "position": "absolute",
                                                            "cornerRadius": "4px",
                                                            "offsetTop": "3px",
                                                            "backgroundColor": "#ff334b",
                                                            "offsetStart": "20px",
                                                            "height": "20px",
                                                            "width": "120px"
                                                        }
                                                    ],
                                                    "paddingAll": "0px",
                                                },
                                            },
                                        ],
                                    },
                                }
                                self.sendTemplate(to, data)
                        if txt == self.stats["helpcom"]:
                                datafox = [{
                                        "type": "bubble", "size": "micro",
                                        "styles": {
                                        "header": {"backgroundColor": "#000000"},
                                        "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                        "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                        "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "text",
                                        "text": "Ħ₳ʗҜ฿❂Ŧ",
                                        "size": "lg",
                                        #"weight": "bold",
                                        "align": "center",
                                        "color": "#FFFFFF"}]},
                                        "hero": {
                                        "type": "image",
                                        "url": "{}".format(self.settings["wallA"]),
                                        "size": "full",
                                        "aspectRatio": "1:1",
                                        "aspectMode": "cover",},
                                        "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "box",
                                        "layout": "baseline",
                                        "contents": [{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "text",
                                        "text": " ᴍᴀɴᴀɢɪɴɢ ",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "size": "md",
                                        "action": {
                                        "type": "uri",
                                        "uri": "line://app/1646011835-9MXEx20v?type=text&text=.managing"}},{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "spacer",
                                        "size": "sm"}]}]}},{
                                        "type": "bubble", "size": "micro",
                                        "styles": {
                                        "header": {"backgroundColor": "#000000"},
                                        "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                        "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                        "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "text",
                                        "text": "Ħ₳ʗҜ฿❂Ŧ",
                                        "size": "lg",
                                        #"weight": "bold",
                                        "align": "center",
                                        "color": "#FFFFFF"}]},
                                        "hero": {
                                        "type": "image",
                                        "url": "{}".format(self.settings["wallB"]),
                                        "size": "full",
                                        "aspectRatio": "1:1",
                                        "aspectMode": "cover",},
                                        "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "box",
                                        "layout": "baseline",
                                        "contents": [{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "text",
                                        "text": " ᴜsᴇʀ ",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "size": "md",
                                        "action": {
                                        "type": "uri",
                                        "uri": "line://app/1646011835-9MXEx20v?type=text&text=.help%20user"}},{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "spacer",
                                        "size": "sm"}]}]}},{
                                        "type": "bubble", "size": "micro",
                                        "styles": {
                                        "header": {"backgroundColor": "#000000"},
                                        "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                        "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                        "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "text",
                                        "text": "Ħ₳ʗҜ฿❂Ŧ",
                                        "size": "lg",
                                        #"weight": "bold",
                                        "align": "center",
                                        "color": "#FFFFFF"}]},
                                        "hero": {
                                        "type": "image",
                                        "url": "{}".format(self.settings["wallC"]),
                                        "size": "full",
                                        "aspectRatio": "1:1",
                                        "aspectMode": "cover",},
                                        "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "box",
                                        "layout": "baseline",
                                        "contents": [{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "text",
                                        "text": " ɢʀᴏᴜᴘs ",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "size": "md",
                                        "action": {
                                        "type": "uri",
                                        "uri": "line://app/1646011835-9MXEx20v?type=text&text=.help%20group"}},{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "spacer",
                                        "size": "sm"}]}]}},{
                                        "type": "bubble", "size": "micro",
                                        "styles": {
                                        "header": {"backgroundColor": "#000000"},
                                        "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                        "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                        "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "text",
                                        "text": "Ħ₳ʗҜ฿❂Ŧ",
                                        "size": "lg",
                                        #"weight": "bold",
                                        "align": "center",
                                        "color": "#FFFFFF"}]},
                                        "hero": {
                                        "type": "image",
                                        "url": "{}".format(self.settings["wallD"]),
                                        "size": "full",
                                        "aspectRatio": "1:1",
                                        "aspectMode": "cover",},
                                        "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "box",
                                        "layout": "baseline",
                                        "contents": [{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "text",
                                        "text": " ᴍᴇᴅɪᴀ ",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "size": "md",
                                        "action": {
                                        "type": "uri",
                                        "uri": "line://app/1646011835-9MXEx20v?type=text&text=.help%20media"}},{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "spacer",
                                        "size": "sm"}]}]}},{
                                        "type": "bubble", "size": "micro",
                                        "styles": {
                                        "header": {"backgroundColor": "#000000"},
                                        "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                        "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                        "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "text",
                                        "text": "Ħ₳ʗҜ฿❂Ŧ",
                                        "size": "lg",
                                        #"weight": "bold",
                                        "align": "center",
                                        "color": "#FFFFFF"}]},
                                        "hero": {
                                        "type": "image",
                                        "url": "{}".format(self.settings["wallE"]),
                                        "size": "full",
                                        "aspectRatio": "1:1",
                                        "aspectMode": "cover",},
                                        "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "box",
                                        "layout": "baseline",
                                        "contents": [{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "text",
                                        "text": " ᴊs ",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "size": "md",
                                        "action": {
                                        "type": "uri",
                                        "uri": "line://app/1646011835-9MXEx20v?type=text&text=.help%20js"}},{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "spacer",
                                        "size": "sm"}]}]}},{
                                        "type": "bubble", "size": "micro",
                                        "styles": {
                                        "header": {"backgroundColor": "#000000"},
                                        "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                        "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                        "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "text",
                                        "text": "Ħ₳ʗҜ฿❂Ŧ",
                                        "size": "lg",
                                        #"weight": "bold",
                                        "align": "center",
                                        "color": "#FFFFFF"}]},
                                        "hero": {
                                        "type": "image",
                                        "url": "{}".format(self.settings["wallF"]),
                                        "size": "full",
                                        "aspectRatio": "1:1",
                                        "aspectMode": "cover",},
                                        "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [{
                                        "type": "box",
                                        "layout": "baseline",
                                        "contents": [{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "text",
                                        "text": " ᴘʀᴏ ",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "size": "md",
                                        "action": {
                                        "type": "uri",
                                        "uri": "line://app/1646011835-9MXEx20v?type=text&text=.help%20pro"}},{
                                        "type": "icon",
                                        "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                        "size": "xl"},{
                                        "type": "spacer",
                                        "size": "sm"}]}]}}]
                                data = {"type": "flex","altText": "⌬ MESSAGE ⌬","contents": {"type": "carousel","contents": datafox}}
                                self.sendTemplate(to, data)
                        if txt == ".smule":self.client.sendMessage(to,"Usage:\n.user\n.recor\n.download")
                        if txt.startswith('.smule .user'):self.client.searchusersmule(msg,msg.text,"FUCKER",to)
                        if txt.startswith('.smule .recor'):self.client.searchusersmulerecord(msg,self.settings,msg.text)
                        if txt.startswith('.smule .download'):self.client.smuledownloader(msg,self.settings,msg.text)
#########################
                        if self.commands["tmpstickers"] != {}:
                                if txt in self.commands["tmpstickers"].keys():
                                    sticker = self.commands["tmpstickers"][txt]
                                    ids = sticker[0]
                                    ipg = sticker[1]
                                    a = self.client.shop.getProduct(packageID=int(ipg), language='ID', country='ID')
                                    if a.hasAnimation == True:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/IOS/sticker_animation@2x.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
                                    else:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/ANDROID/sticker.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
                        if txt == "?me":
                            a = self.client.getContact(of)
                            b = self.client.getContact(self.uid)
                            sender_profile = self.client.getContact(of)
                            dataProfile = [{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#191970"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#191970", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "PROFILE PICTURE",
                                    "size": "md",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#00FF00"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://os.line.naver.jp/os/p/{}".format(of),
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1646011835-9MXEx20v?type=image&img=https://assets-a1.kompasiana.com/items/album/2016/12/01/lovebanget-com-583fa55c3793739e04b3b74c.jpg"}},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [{
                                    "type": "text",
                                    "text": '{}'.format(str(a.displayName)),
                                    "color": "#00FF00",
                                    "weight": "bold",
                                    "size": "xl"},{
                                    "type": "box",
                                    "layout": "vertical",
                                    "margin": "lg",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "{}".format(str(a.statusMessage if a.statusMessage != '' else 'line://ti/p/~regathb1')),
                                    "size": "sm",
                                    "color": "#00FF00",
                                    "wrap": True,
                                    "flex": 2}]}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": "https://i.postimg.cc/bJX97vqP/178551.jpg",
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "˜”*°• 𝕽𝖌 𝖘𝖊𝖑𝖋𝖇𝖔𝖙 𝓥.1.4 •°*”˜",
                                    "align": "center",
                                    "color": "#00FF00",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://ti/p/~regathb1"}},{
                                    "type": "icon",
                                    "url": "https://i.postimg.cc/bJX97vqP/178551.jpg",
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#191970"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#191970", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "PROFILE COVER",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#00FF00"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": str(self.client.getProfileCoverURL(of)),
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "cover",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1646011835-9MXEx20v?type=image&img=https://www.ypi-trainingcenter.com/wp-content/uploads/2016/10/3542206813974136macam-macam-kepo-600x400-hh88.jpg"}},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [{
                                    "type": "text",
                                    "text": '{}'.format(str(a.displayName)),
                                    "weight": "bold",
                                    "color": "#00FF00",
                                    "size": "xl"},{
                                    "type": "box",
                                    "layout": "vertical",
                                    "margin": "lg",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "Name:",
                                    "color": "#00FF00",
                                    "size": "sm",
                                    "flex": 1},{
                                    "type": "text",
                                    "text": '{}'.format(str(b.displayName)),
                                    "color": "#00FF00",
                                    "size": "sm",
                                    "flex": 2}]},{
                                    "type": "box",
                                    "layout": "baseline",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "sᴜᴘᴘᴏʀᴛᴇᴅ:",
                                    "color": "#00FF00",
                                    "size": "sm",
                                    "flex": 1},{
                                    "type": "text",
                                    "text": 'ᴛʜʙ ᴛᴇᴀᴍ\nᴄᴏᴘʏʀɪɢᴛʜ @2018\nᴍᴀᴅᴇ ɪɴ ɪɴᴅᴏɴᴇsɪᴀɴ',
                                    "color": "#00FF00",
                                    "wrap": True,
                                    "size": "sm",
                                    "flex": 2}]}]}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": "https://i.postimg.cc/bJX97vqP/178551.jpg",
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "˜”*°• 𝕽𝖌 𝖘𝖊𝖑𝖋𝖇𝖔𝖙 𝓥.1.4 •°*”˜",
                                    "align": "center",
                                    "color": "#00FF00",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://ti/p/~regathb1"}},{
                                    "type": "icon",
                                    "url": "https://i.postimg.cc/bJX97vqP/178551.jpg",
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm",}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#191970"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#191970", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "PROFILE STATUS",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#00FF00"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://media.giphy.com/media/VGnWxiNDMF0UBh5YGz/giphy.gif",#"https://media.giphy.com/media/xTka034bGJ8H7wH1io/giphy.gif",#"https://obs-sg.line-apps.com/myhome/c/download.nhn?userid=uf8371eac88419ee87775697e5840d1ca&oid=f89be623bb17918acff2586228c6e997",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "cover",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1646011835-9MXEx20v?type=image&img=https://i.postimg.cc/nc8NCqJj/kepo-jpg.jpg"}},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [{
                                    "type": "text",
                                    "text": "PROFILE STATUS",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#00FF00"}]},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "text",
                                    "text": "Name:",
                                    "size": "sm",
                                    "color": "#00FF00",
                                    "wrap": True},{
                                    "type": "text",
                                    "text": str(sender_profile.displayName),
                                    "size": "sm",
                                    "color": "#00FF00",
                                    "wrap": True,
                                    "flex": 2}]},{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "text",
                                    "text": "sᴜᴘᴘᴏʀᴛᴇᴅ ʙʏ: ᴛʜʙ ᴛᴇᴀᴍ\nᴄᴏᴘʏʀɪɢᴛʜ @2018\nᴍᴀᴅᴇ ɪɴ ɪɴᴅᴏɴᴇsɪᴀɴ",
                                    "align": "center",
                                    "size": "sm",
                                    "color": "#00FF00",
                                    "wrap": True,
                                    "flex": 2}]}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": "https://i.postimg.cc/bJX97vqP/178551.jpg",
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "˜”*°• 𝕽𝖌 𝖘𝖊𝖑𝖋𝖇𝖔𝖙 𝓥.1.4 •°*”˜",
                                    "align": "center",
                                    "color": "#00FF00",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://ti/p/~regathb1"}},{
                                    "type": "icon",
                                    "url": "https://i.postimg.cc/bJX97vqP/178551.jpg",
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}}]
                            data = {
                                    "type": "flex",
                                    "altText": "Profile",
                                    "contents": {
                                    "type": "carousel",
                                    "contents": dataProfile}}
                            self.sendTemplate(to,data)
                        if txt == ".sosmed":
                                dataProfile = [{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000","separator": True,"separatorColor": "#ffffff"},#999966
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ ғᴀᴄᴇʙᴏᴏᴋ ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/facebook_epic_internet-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#ffffff"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ ʟᴏɢɪɴ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-V72WRQYZ"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ ɪɴsᴛᴀɢʀᴀᴍ ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/web_internet_instagram-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ ʟᴏɢɪɴ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-rA095Ydx"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ ᴛᴡɪᴛᴛᴇʀ ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/web_internet_twitter-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ ʟᴏɢɪɴ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-vM7yl5Lo"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ ʏᴏᴜᴛᴜʙᴇ ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/youtube_epic_internet-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ sᴇᴇ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-Nn7AwG5W"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ sɴᴀᴘᴄʜᴀᴛ ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/snapchat_epic_internet-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ ʟᴏɢɪɴ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-w0R704eb"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ ᴘɪɴᴛᴇʀᴇsᴛ ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/pinterest_epic_internet-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ ʟᴏɢɪɴ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-jmXgaoNy"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ sᴋʏᴘᴇ ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/skype_web_internet-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ ʟᴏɢɪɴ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-QBgy3maD"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ ᴅʀᴏᴘʙᴏx ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/dropbox_epic_social-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ ʟᴏɢɪɴ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-bwLNBj4O"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ ɢɪᴛʜᴜʙ ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/github_epic_social-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ ʟᴏɢɪɴ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-OkgAl24N"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}},{
                                    "type": "bubble",
                                    "styles": {
                                    "header": {"backgroundColor": "#000000"},
                                    "body": {"backgroundColor": "#000000"},
                                    "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                    "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                    "header": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": "☯☯ ᴛᴜᴍʙʟʀ ☯☯",
                                    "size": "lg",
                                    "weight": "bold",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "hero": {
                                    "type": "image",
                                    "url": "https://cdn1.iconfinder.com/data/icons/epic-social-media-1/32/tumblr_epic_internet-512.png",
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",},
                                    "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "text",
                                    "text": 'ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4',
                                    "weight": "bold",
                                    "size": "xl",
                                    "align": "center",
                                    "color": "#FFFFFF"}]},
                                    "footer": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "spacing": "sm",
                                    "contents": [{
                                    "type": "box",
                                    "layout": "baseline",
                                    "contents": [{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "text",
                                    "text": "☯☯ ᴄʟɪᴄᴋ ᴛᴏ ʟᴏɢɪɴ ☯☯",
                                    "align": "center",
                                    "color": "#FFFFFF",
                                    "size": "md",
                                    "action": {
                                    "type": "uri",
                                    "uri": "line://app/1636367965-Xvr2pVmq"}},{
                                    "type": "icon",
                                    "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                    "size": "xl"},{
                                    "type": "spacer",
                                    "size": "sm"}]}]}}]
                                data = {"type": "flex","altText": "Social Media","contents": {"type": "carousel","contents": dataProfile}}
                                self.sendTemplate(to, data)
                        if txt.startswith(".msg "):
                                contact = self.client.getContact(of)
                                text = msg.text[len(".msg "):]
                                dataProfile = [
                                        {
                                            "type": "bubble",
                                            "styles": {
                                                "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                                "header": {"backgroundColor": "#000000"},
                                                "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}
                                            },
                                            "hero": {
                                                "type": "image",
                                                "url": "https://ladangit.files.wordpress.com/2011/04/matrixt.gif",
                                                "size": "full",
                                                "aspectRatio": "1:1",
                                                "aspectMode": "fit",
                                            },
                                            "header": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "☯☯ Message ☯☯",
                                                        "size": "lg",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "#FFFFFF"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(str(text)),
                                                        "color": "#FFFFFF",
                                                        'flex': 1,
                                                     }
                                                ]
                                            },
                                            "footer": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "baseline",
                                                        "contents": [
                                                            {
                                                                "type": "icon",
                                                                "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                                                "size": "xl"
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈",
                                                                "align": "center",
                                                                "color": "#FFFFFF",
                                                                "size": "md"
                                                            },
                                                            {
                                                                "type": "icon",
                                                                "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                                                "size": "xl"
                                                            },
                                                            {
                                                                "type": "spacer",
                                                                "size": "sm"
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                data = {
                                            "type": "flex",
                                            "altText": "⌬ MESSAGE ⌬",
                                            "contents": {
                                                "type": "carousel",
                                                "contents": dataProfile
                                                }
                                            }
                                self.sendTemplate(to, data)
                        if txt.startswith('.bc '):
                            text = txt.replace(".bc ","")
                            gid = self.client.getGroupIdsJoined()
                            if text == "":
                                if not silent:self.client.sendMessage(to,"Message is Empty")
                            else:
                                for i in gid:
                                    data = {
                                        "type": "flex",
                                        "altText": "ʙʀᴏᴀᴅᴄᴀsᴛ",
                                        "contents": {
                                          "type": "bubble",
                                          "size": "micro",
                                          "body": {
                                            "type": "box",
                                            "layout": "vertical",
                                            "contents": [
                                              {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                  {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                      {
                                                        "type": "text",
                                                        "contents": [],
                                                        "size": "xs",
                                                        "wrap": True,
                                                        "text": "ʙʀᴏᴀᴅᴄᴀsᴛ",
                                                        "color": "#ffffff",
                                                        "weight": "bold",
                                                        "gravity": "center",
                                                        "position": "relative",
                                                        "align": "center"
                                                      }
                                                    ],
                                                    "spacing": "sm",
                                                    "borderWidth": "1px",
                                                    "borderColor": "#011212",
                                                    "backgroundColor": "#590310",
                                                    "cornerRadius": "10px"
                                                  },
                                                  {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                      {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                          {
                                                            "type": "text",
                                                            "contents": [],
                                                            "size": "xxs",
                                                            "wrap": True,
                                                            "margin": "lg",
                                                            "color": "#000000",
                                                            "text": "{}".format(text),
                                                            "align": "start"
                                                          }
                                                        ]
                                                      }
                                                    ],
                                                    "backgroundColor": "#FFFFFF",
                                                    "cornerRadius": "2px",
                                                    "margin": "sm",
                                                    "borderColor": "#08011c",
                                                    "borderWidth": "1px"
                                                  }
                                                ],
                                                "borderWidth": "2px"
                                              }
                                            ],
                                            "borderWidth": "3px",
                                            "cornerRadius": "10px",
                                            "borderColor": "#00FFFF",
                                            "paddingAll": "0px",
                                            "paddingTop": "1px",
                                            "paddingBottom": "1px",
                                            "backgroundColor": "#051566"
                                          }
                                        }}
                                    self.sendTemplate(i, data)
                                    time.sleep(1)
                                self.client.sendMessage(to, "Succes broadcast to all groups")
#                        if txt.startswith('.bc '):
#                            lol = txt.replace(".bc ","")
#                            text = "{}".format(lol)
#                            groups = self.client.getGroupIdsJoined()
#                            for x in range(len(groups)):
#                                data = {
#                                       "messages": [
#                                          {
#                                               "type": "flex",
#                                               "altText": "Group Broadcast",
#                                               "contents": {
#                                                   "type": "bubble",
#                                                   "styles": {
#                                                           "header": {
#                                                               "backgroundColor": "#584880",
#                                                           },
#                                                           "footer": {
#                                                               "backgroundColor": "#203060",
#                                                               "separator": True
#                                                           }
#                                                       },
#                                                   "header": {
#                                                     "type": "box",
#                                                     "layout": "vertical",
#                                                     "contents": [
#                                                       {
#                                                         "type": "text",
#                                                         "text": "Group Broadcast",
#                                                         "weight": "bold",
#                                                         "color": "#ffffff",
#                                                         "size": "xl",
#                                                       },
#                                                       {
#						                              	        "type": "separator",
#						                                        "color": "#203060"
#					                                         }
#			                                             ]
#                                                   },
#                                                   "hero": {
#                                                           "type": "image",
#                                                           "url": "https://media1.tenor.com/images/c235f651486e71c5b49702f36783aa26/tenor.gif?itemid=12191275",
#                                                           "size": "full",
#                                                           "aspectRatio": "20:13",
#                                                           "aspectMode": "cover",
#                                                           "backgroundColor": "#203060",
#                                                       },
#                                                       "body": {
#                                                               "type": "box",
#                                                               "layout": "vertical",
#                                                               "contents": [
#                                                                  {
#                                                                    "type": "box",
#                                                                    "layout": "vertical",
#                                                                    "contents": [
#                                                                       {
#                                                                         "type": "box",
#                                                                         "layout": "baseline",
#                                                                         "contents": [
#                                                                            {
#                                                                              "type": "text",
#                                                                              "text": "©Broadcast",
#                                                                              "color": "#191919",
#                                                                              "weight": "bold"
#                                                                             }
#                                                                         ]
#                                                                       }
#                                                                    ]
#                                                                  },
#                                                                  {
#                                                                    "type": "box",
#                                                                    "layout": "vertical",
#                                                                    "spacing": "xs",
#                                                                    "contents": [
#                                                                       {
#                                                                         "type": "box",
#                                                                         "layout": "horizontal",
#                                                                         "contents": [
#                                                                            {
#                                                                              "type": "text",
#                                                                              "text": "©Text:",
#                                                                              "color": "#191919",
#                                                                              "size": "xs",
#                                                                              "weight": "bold",
#                                                                              "flex": 1
#                                                                            },
#                                                                            {
#                                                                              "type": "text",
#                                                                              "text": "{}".format(text),
#                                                                              "color": "#191919",
#                                                                              "size": "xl",
#                                                                              "wrap": True,
#                                                                              "flex": 4
#                                                                            }
#                                                                         ]
#                                                                       }
#                                                                    ]
#                                                                  },
#                                                                  {
#                                                                    "type": "box",
#                                                                    "layout": "vertical",
#                                                                    "spacing": "xs",
#                                                                    "contents": [
#                                                                       {
#                                                                         "type": "box",
#                                                                         "layout": "horizontal",
#                                                                         "contents": [
#                                                                            {
#                                                                              "type": "text",
#                                                                              "text": "™pengirim:",
#                                                                              "color": "#ff0000",
#                                                                              "size": "xs",
#                                                                              "weight": "bold",
#                                                                              "flex": 1
#                                                                            },
#                                                                            {
#                                                                              "type": "text",
#                                                                              "text": "{}".format(self.client.profile.displayName),
#                                                                              "color": "#4B0082",
#                                                                              "size": "xl",
#                                                                              "wrap": True,
#                                                                              "flex": 1
#                                                                            }
#                                                                         ]
#                                                                       }
#                                                                    ]
#                                                                  }
#                                                               ]
#                                                       },
#                                                       "footer": {
#                                                               "type": "box",
#                                                               "layout": "vertical",
#                                                               "spacing": "lg",
#                                                               "contents": [
#                                                                  {
#                                                                    "type": "button",
#                                                                    "style": "primary",
#                                                                    "action": {
#                                                                        "type": "uri",
#                                                                        "label": "®for help",
#                                                                        "uri": "http://line.me/ti/p/~regathb1"
#                                                                     }
#                                                                  }
#                                                               ]
#                                                       }
#                                                   }
#                                              }
#                                           ]
#                                       }
#                            groups = self.client.getGroupIdsJoined()
#                            #cgroup = self.client.getGroups(groups)
#                            #for x in range(len(cgroup)):
#                            for x in groups:
#                                self.bc(x,data)
#                                #time.sleep(0.1)
                        
                        if txt == "..me":a = self.client.profile;b = self.client.profile.displayName;c = self.client.profile.userid;data = {"type": "flex","altText": b,"contents": {"type": "bubble","styles": {"body": {"backgroundColor": "#191970"},"footer": {"backgroundColor": "#ffffff"}},"hero": {"type": "image","url": "https://os.line.naver.jp/os/p/{}".format(of),"size": "full","aspectRatio": "20:13","aspectMode": "cover","action": {"type": "uri","uri": "line://ti/p/~"+c}},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": '{}'.format(str(a.displayName)),"weight": "bold","size": "xl"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Name","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(a.displayName)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Status","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": "{}".format(str(a.statusMessage if a.statusMessage != '' else 'line://ti/p/8iwH4pMmGx')),"color": "#ffffff","wrap": True,"size": "sm","flex": 2}]}]}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "C̳R̳E̳A̳T̳O̳R̳","uri": "line://ti/p/~"+c}},{"type": "spacer","size": "sm",}],"flex": 0}}};self.sendTemplate(to,data)#"color": "#aaaaaa","wrap": True,"size": "sm","flex"
                        if txt.startswith(".lastseen"):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    if mention in self.db['lastseen']:
                                        t = time.time() - self.db['lastseen'][mention][0]
                                        m, s = divmod(t, 60)
                                        h, m = divmod(m, 60)
                                        if self.db['lastseen'][mention][1].startswith('u'):
                                            name = 'pm'
                                        else:
                                            name = self.client.getGroup(self.db['lastseen'][mention][1]).name
                                        n = self.client.getContact(mention).displayName
                                        a = self.client.getContact(mention)
                                        c = self.client.profile.userid
                                        b = self.client.profile.displayName
                                        Time = "%s hours, %s min, %s sec"%(round(h),round(m),round(s))
                                        data = {"type": "flex","altText": "Lastseen","contents": {"type": "bubble","styles": {"body": {"backgroundColor": "#ff0000"},"footer": {"backgroundColor": "#ffffff"}},"hero": {"type": "image","url": "https://os.line.naver.jp/os/p/{}".format(mention),"size": "full","aspectRatio": "20:13","aspectMode": "cover","action": {"type": "uri","uri": "line://ti/p/~"+c}},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": 'Lastseen',"weight": "bold","size": "xl"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬Name:","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(n)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬Active:","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(name)),"color": "#ffffff","size": "sm","flex": 2}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "⌬Time:","color": "#ffffff","size": "sm","flex": 1},{"type": "text","text": "{}".format(str(Time if Time != '' else "line://ti/p/~"+c)),"color": "#ffffff","wrap": True,"size": "sm","flex": 2}]}]}]}]}}}
                                        self.sendTemplate(to,data)
                                    else:
                                        self.client.sendText(to,'Unknown.')
                        if txt.startswith("!syoutube"):
                            try:
                                sep = msg.text.split(" ")
                                search = msg.text.replace(sep[0] + " ", "")
                           #     r = requests.get("https://api.boteater.us/ytdl?search={}&auth=u6Ha289rP0el".format(str(search)))
                                r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=20&q={}&type=video&key=AIzaSyBgLiO8GoVAXggNkuT9Ps0wjjgsBCuRTrw".format(str(search)))
                                self.yt.clear()
                                data = r.text
                                a = json.loads(data)
                                if a["items"] != []:
                                    ret_ = []
                                    for music in a["items"]:
                                        ret_.append({ "type": "bubble", "styles": { "header": {"backgroundColor": "#FFFFFF","separator": True,"separatorColor": "#FF0400"}, "body": {"backgroundColor": "#FFFFFF","separator": True,"separatorColor": "#FF0400"}, "footer": {"backgroundColor": "#7CFC00","separator": True,"separatorColor": "#FF0400"}}, "body": { "type": "box", "layout": "horizontal", "contents": [{ "type": "box", "flex": 1, "layout": "vertical", "contents": [{ "type": "image", "url": "https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music["id"]["videoId"]), "aspectMode": "cover", "aspectRatio": "1:1", "gravity": "bottom", "size": "sm", "action": { "type": "uri", "uri": "line://app/1646011835-9MXEx20v?type=image&img=https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music["id"]["videoId"]), }}] }, { "type": "separator", "color": "#FF0400" }, { "type": "box", "contents": [{ "type": "separator", "color": "#FF0000" },{ "type": "text", "text": "ᴅᴇᴛᴀɪʟ", "color": "#0A00FF", "size": "sm", "align": "center", "wrap": True, "flex": 2, "gravity": "top" }, { "type": "separator", "color": "#FF0400" }, { "type": "text", "text": "%s"% music["snippet"]["title"], "color": "#0A00FF", "size": "xxs", "wrap": True, "flex": 3, "gravity": "top" }, { "type": "separator", "color": "#FF0400" }], "flex": 2, "layout": "vertical" }] }, "footer": { "type": "box", "layout": "vertical", "contents": [{ "type": "box", "layout": "horizontal", "contents": [{ "type": "button", "flex": 2, "style": "primary", "color": "#0200FF", "height": "sm", "action": { "type": "uri", "label": "Page", "uri": "https://www.youtube.com/watch?v=" + music["id"]["videoId"], } }, { "flex": 3, "type": "button", "margin": "sm", "style": "primary", "color": "#0200FF", "height": "sm", "action": { "type": "uri", "label": "mp3", "uri": "line://app/1646011835-9MXEx20v?type=audio&link=https://www.youtube.com/watch?v={}".format(music["id"]["videoId"]) } }] }, { "type": "button", "margin": "sm", "style": "primary", "color": "#0200FF", "height": "sm", "action": { "type": "uri", "label": "ᴅᴏᴡɴʟᴏᴀᴅ", "uri": "line://app/1646011835-9MXEx20v?type=video&ocu=https://www.youtube.com/watch?v={}&piu=https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music["id"]["videoId"],music["id"]["videoId"]), } }] } } )
                                        self.yt.append("https://www.youtube.com/watch?v={}".format(str(music['id']["videoId"])))
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "type": "flex",
                                            "altText": "Youtube",
                                            "contents": {
                                                "type": "carousel",
                                                "contents": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        self.sendTemplate(to, data)     
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt.startswith(".syoutube"):
                            try:
                                sep = msg.text.split(" ")
                                search = msg.text.replace(sep[0] + " ","")
                                r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=20&q={}&type=video&key=AIzaSyBgLiO8GoVAXggNkuT9Ps0wjjgsBCuRTrw".format(str(search)))
                                self.yt.clear()
                                data = r.text
                                a = json.loads(data)
                                if a["items"] != []:
                                    ret_ = []
                                    for music in a["items"]:
                                        ret_.append({"type": "bubble","styles": {"header": {"backgroundColor": "#0a0a0f"},"body": {"backgroundColor": "#0a0a0f","separator": True,"separatorColor": "#ffffff"},"footer": {"backgroundColor": "#0a0a0f","separator": True,"separatorColor": "#ff0000"}},"header": {"type": "box","layout": "horizontal","contents": [{"type": "text","text": "Youtube","weight": "bold","color": "#ffffff","size": "lg"}]},"hero": {"type": "image","url": "https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music['id']['videoId']),"size": "full","aspectRatio": "20:13","aspectMode": "cover","action": {"type": "uri","uri": "line://app/1646011835-9MXEx20v?type=image&img=https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music['id']['videoId'])}},"body": {"type": "box","spacing": "md","layout": "horizontal","contents": [{"type": "box","spacing": "none","flex": 1,"layout": "vertical","contents": [{"type": "image","url": "https://cdn2.iconfinder.com/data/icons/social-icons-circular-color/512/youtube-512.png","aspectMode": "cover","gravity": "bottom","size": "sm","aspectRatio": "1:1","action": {"type": "uri","uri": "line://ti/p/~"+ self.client.profile.userid}}]},{"type": "separator","color": "#ffffff"},{"type": "box","contents": [{"type": "text","text": "Title","color": "#ffffff","size": "md","weight": "bold","flex": 1,"gravity": "top"},{"type": "text","text": "%s" % music['snippet']['title'],"color": "#ffffff","size": "sm","weight": "bold","flex": 3,"wrap": True,"gravity": "top"}],"flex": 2,"layout": "vertical"}]},"footer": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "button","flex": 2,"style": "primary","color": "#ff1a1a","height": "sm","action": {"type": "uri","label": "Page","uri": 'https://www.youtube.com/watch?v=' +music['id']['videoId']}},{"flex": 3,"type": "button","margin": "sm","style": "primary","color": "#ff1a1a","height": "sm","action": {"type": "uri","label": "Mp3","uri": "line://app/1646011835-9MXEx20v?type=audio&link=https://www.youtube.com/watch?v={}".format(music['id']['videoId'])}}]},{"type": "button","margin": "sm","style": "primary","color": "#ff1a1a","height": "sm","action": {"type": "uri","label": "Mp4","uri": "line://app/1646011835-9MXEx20v?type=video&ocu=https://www.youtube.com/watch?v={}&piu=https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music['id']['videoId'],music['id']['videoId'])}}]}})
                                        self.yt.append("https://www.youtube.com/watch?v={}".format(str(music['id']["videoId"])))
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {"type": "flex","altText": "Youtube","contents": {"type": "carousel","contents": ret_[aa*10 : (aa-1)*10]}}
                                        self.sendTemplate(to,data)
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt.startswith(".listyoutube"):
                            try:
                                sep = msg.text.split(" ")
                                search = msg.text.replace(sep[0] + " ","")
                                r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=20&q={}&type=video&key=AIzaSyBgLiO8GoVAXggNkuT9Ps0wjjgsBCuRTrw".format(str(search)))
                                self.yt.clear()
                                data = r.text
                                a = json.loads(data)
                                if a["items"] != []:
                                    ret_ = []
                                    for music in a["items"]:
                                        ret_.append({"thumbnailImageUrl": 'https://i.ytimg.com/vi/{}/maxresdefault.jpg'.format(music['id']['videoId']),"imageSize": "contain","imageAspectRatio": "square","title": '{}'.format(str(music['snippet']['title'][:40])),"text": '{}'.format(str(music['snippet']['channelTitle'][:15])),"actions": [{"type": "uri","label": "Go Page","uri": 'https://www.youtube.com/watch?v=' +music['id']['videoId']}]})
                                        self.yt.append("https://www.youtube.com/watch?v={}".format(str(music['id']["videoId"])))
                                    k = len(ret_)//10 
                                    for aa in range(k+1):
                                        data = {"type": "template","altText": " ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈","template": {"type": "carousel","columns": ret_[aa*10 : (aa+1)*10]}}
                                        self.sendTemplate(to,data)
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt == ".mycover":
                                cover = self.client.getProfileCoverURL(of)
                                a = self.client.getContact(of)
                                data = {"type":"image","originalContentUrl":cover,"previewImageUrl":cover,"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(a.displayName)),"iconUrl":"https://obs.line-scdn.net/" + self.client.getContact(of).pictureStatus,"linkUrl":"line://ti/p/~"+ self.client.profile.userid}}
                                self.sendTemplate(to, data)
                        if txt == ".penpicall":
                                kontak = self.client.getGroup(to)
                                if kontak.invitee:
                                    group = kontak.invitee
                                    picall = []
                                    for ids in group:
                                        if len(picall) >= 40:
                                            pass
                                        else:
                                            picall.append({
                                                "imageUrl": "https://os.line.naver.jp/os/p/{}".format(ids.mid),
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "http://line.me/ti/p/~{}".format(self.client.profile.userid)
                                                    }
                                                }
                                            )
                                    k = len(picall)//10
                                    for aa in range(k+1):
                                        data = {"type": "template","altText": "Picture All","template": {"type": "image_carousel","columns": picall[aa*10 : (aa+1)*10]}}
                                        self.sendTemplate(to,data)
                        if txt == ".getpicall":
                                kontak = self.client.getGroup(to)
                                group = kontak.members
                                picall = []
                                for ids in group:
                                    if len(picall) >= 40:
                                        pass
                                    else:
                                        picall.append({
                                            "imageUrl": "https://os.line.naver.jp/os/p/{}".format(ids.mid),
                                            "action": {
                                                "type": "uri",
                                                "uri": "http://line.me/ti/p/~{}".format(self.client.profile.userid)
                                                }
                                            }
                                        )
                                k = len(picall)//10
                                for aa in range(k+1):
                                    data = {"type": "template","altText": "Picture All","template": {"type": "image_carousel","columns": picall[aa*10 : (aa+1)*10]}}
                                    self.sendTemplate(to,data)
#==========================NEW COMMAND========================================#33
                        if txt == "!login-asis":
                            try:
                                nama = "RgBots"
                                self.temp_db['device'].update({'x-lpqs' : '/api/v4/TalkService.do'})
                                transport = THttpClient.THttpClient('https://legy-jp.line.naver.jp/api/v4/TalkService.do')
                                transport.setCustomHeaders(self.temp_db['device'])
                                protocol = TCompactProtocol.TCompactProtocol(transport)
                                cl = TalkService.Client(protocol)
                                qr = cl.getAuthQrcode(keepLoggedIn=1, systemName=nama)
                                link = "line://au/q/" + qr.verifier
                                self.client.sendText(to,"Click link below in 2 minutes before expired \n"+str(link))
                                self.temp_db['device'].update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
                                json.loads(requests.session().get('https://legy-jp.line.naver.jp/Q', headers=self.temp_db['device']).text)
                                self.temp_db['device'].update({'x-lpqs' : '/api/v4p/rs'})
                                transport = THttpClient.THttpClient('https://legy-jp.line.naver.jp/api/v4p/rs')
                                transport.setCustomHeaders(self.temp_db['device'])
                                protocol = TCompactProtocol.TCompactProtocol(transport)
                                cl = AuthService.Client(protocol)
                                req = LoginRequest()
                                req.type = 1
                                req.verifier = qr.verifier
                                req.e2eeVersion = 1
                                temp_client = cl.loginZ(req)
                                self.temp_db['token'] = temp_client.authToken
                                self.client.sendText(to,"Success login Antijs")
                            except Exception as e:self.client.sendText(to,"Maaf anda di banned login\ntunggu 24 jam br anda bisa login lagi.");traceback.print_exc()
                        if txt == ".invite:on":
                            self.stats["invite"] = True
                            self.backupData()
                            if not silent:self.client.sendReplyMessage(msg.id, to,"Send contact to invite")
                        if txt == ".clone:on":
                            self.clear()
                            self.stats["clone"] = True
                            if not silent:self.client.sendReplyMessage(msg.id, to,"Send a contact to Clone.")
                        if txt == '.rimage on' or txt == '.rimage:on':
                            if to in self.db['rimage']:
                                self.client.sendText(to, 'Respon image already enabled.')
                            else:
                                self.db['rimage'].append(to)
                                self.client.sendText(to, 'Respon image enabled.')
                        if txt == '.rimage off' or txt == '.rimage:off':
                            if to not in self.db['rimage']:
                                self.client.sendText(to, 'Respon image already disabled.')
                            else:
                                self.db['rimage'].remove(to)
                                self.ceks = []
                                self.client.sendText(to, 'Respon image disabled.')
                        if txt == '.notag on' or txt == '.notag:on':
                            if to in self.db['notagg']:
                                self.client.sendText(to, 'Notag already enabled.')
                            else:
                                self.db['notagg'].append(to)
                                self.client.sendText(to, 'Notag enabled.')
                        if txt == '.notag off' or txt == '.notag:off':
                            if to not in self.db['notagg']:
                                self.client.sendText(to, 'Notag already disabled.')
                            else:
                                self.db['notagg'].remove(to)
                                self.ceks = []
                                self.client.sendText(to, 'Notag disabled.')
                        if txt == '.backtag on' or txt == '.backtag:on':
                            if to in self.db['backtagg']:
                                self.client.sendText(to, 'Backtag already enabled.')
                            else:
                                self.db['backtagg'].append(to)
                                self.client.sendText(to, 'Backtag enabled.')
                        if txt == '.backtag off' or txt == '.backtag:off':
                            if to not in self.db['backtagg']:
                                self.client.sendText(to, 'Backtag already disabled.')
                            else:
                                self.db['backtagg'].remove(to)
                                self.ceks = []
                                self.client.sendText(to, 'Backtag disabled.')
                        if txt == '//status':
                              try:self.client.inviteIntoGroup(to, ["u3ccd7738062f0302614a06aac37b7b1f"]);has = "Ciee gak Limit..."
                              except:has = "Sue limit dah..."
                              if not silent:self.client.sendReplyMessage(msg.id,to, "{}".format(has)) 
                        #if txt == '.notag on':
                            #self.tagkick["mentionKick"] = True
                            #self.client.sendReplyMessage(msg.id,to,'Notag enabled.')
                        #if txt == '.notag off':
                            #self.tagkick["mentionKick"] = False
                            #self.client.sendReplyMessage(msg.id,to,'Notag disabled.')
                        if txt == ".imagecast":
                            self.stats["bcimage"] = True
                            if not silent:self.client.sendText(to,"Kirim Gambarnya")
                        if txt == ".audiocast":
                            self.stats["bcaudio"] = True
                            if not silent:self.client.sendText(to,"Send Audio.")
                        if txt == ".videocast":
                            self.stats["bcvideo"] = True
                            if not silent:self.client.sendText(to,"Send Video.")
                        if txt == ".info:on":
                            self.clear()
                            self.stats["info"] = True
                            if not silent:self.client.sendText(to,"Send a contact to info.")
                        if txt == ".info:repeat":
                            self.clear()
                            self.stats["info"] = True
                            self.stats["repeat"] = True
                            if not silent:self.client.sendText(to,"Send contacts to info.")
                        if txt == ".mids:on":
                            self.clear()
                            self.set["mids"] = True
                            if not silent:self.client.sendText(to,"Send a contact to get mid.")
                        if txt == ".mids:repeat":
                            self.clear()
                            self.set["mids"] = True
                            self.stats["repeat"] = True
                            if not silent:self.client.sendText(to,"Send contacts to get mid.")
                        if txt == self.stats["joinbots"]:
                            bots = [o for o in self.stats['botlist'] if o != self.uid]
                            g = self.client.getGroup(to)
                            links = g.preventedJoinByTicket
                            bots = [o for o in self.stats['botlist'] if o != self.uid]
                            if links == True:
                                g.preventedJoinByTicket = False
                                self.client.updateGroup(g)
                            link = self.client.reissueGroupTicket(to)
                            for bot in bots:
                                self.client.sendMessage(bot,"%s %s"%(to,link))
                            time.sleep(0.1)
                            g.preventedJoinByTicket = True
                            self.client.updateGroup(g)
                        if txt == ".grouplist":
                            try:
                                client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                gid = client.getGroupIdsJoined()
                                tst = "Group List:\nName: %s"%client.profile.displayName
                                count = 1
                                for group in gid:
                                    Gname = client.getGroup(group).name
                                    gc = client.getGroup(group)
                                    tst += "\n%s - %s (%s)"%(count,Gname,len(gc.members))
                                    count += 1
                                self.client.sendText(to,tst + "\nTotal [%s] Group"%str(len(gid)))
                            except:
                                traceback.print_exc()
                                self.client.sendText(to,'Failed to get Group info')
                        if txt == ".ajsstatus":
                            try:
                                client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                client.inviteIntoGroup(to, ["u3ccd7738062f0302614a06aac37b7b1f"]);has = "%s Ready"%client.profile.displayName
                            except:has = "%s Limit"%client.profile.displayName
                            self.client.sendMessage(to, "{}".format(has))
                        if txt == ".asstagall":
                            G = self.client.getGroup(to)
                            G.preventedJoinByTicket = False
                            client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                            self.client.updateGroup(G)
                            Ti = self.client.reissueGroupTicket(to)
                            client.acceptGroupInvitationByTicket(to,Ti)                     
                            X = client.getGroup(to)
                            X.preventedJoinByTicket = True
                            group = client.getGroup(to)
                            self.client.updateGroup(X)
                            members = [o.mid for o in group.members]
                            k = len(members)//20
                            for j in range(k+1):
                                msg = Message(to=to)
                                tst = u'ᴛᴀɢᴀʟʟ ᴍᴇᴍʙᴇʀs:\t\n\n'
                                s=len(tst)
                                d=[]
                                for i in members[j*20 : (j+1)*20]:
                                    d.append({"S":str(s+3), "E" :str(s+7), "M":i})
                                    s += 8
                                    tst += u'⌬. @asu\n'
                                msg.text = tst.rstrip()
                                msg.contentMetadata = {u'MENTION':json.dumps({"MENTIONEES":d})}
                                try:
                                    client.sendMessage(to,msg.text,msg.contentMetadata)
                                    client.leaveGroup(to)
                                except:
                                    print("error")
                        if txt == '.invitebots':
                            self.client.inviteIntoGroup(to,self.stats["botlist"])

                        if txt == ".outsticker:on":
                            self.client.sendText(to,"Please send Sticker.")
                            self.leavesticker = True
                        if txt == ".outsticker:off":
                            if to in self.stats["leaveStickers"]:
                                del self.stats["leaveStickers"]
                                self.client.sendText(to,"Leave Sticker disabled.")
                            else:
                                self.client.sendText(to,"Leave Sticker wasn't on.")

                        if txt == ".iconlock:off":
                            if to in self.settings["picon"]:
                                if self.settings["picon"][to]["on"] == 0:
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Iconlock already disabled.")
                                else:
                                    self.settings["picon"][to]["on"] = 0
                                    self.settings["picon"][to]["pictureStatus"] = ""
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Iconlock disabled.")
                            else:
                                self.settings["picon"][to]["on"] = 0
                                self.settings["picon"][to]["pictureStatus"] = ""
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Iconlock disabled.")
                        if txt == ".iconlock:on":
                            if to in self.settings["picon"]:
                                if self.settings["picon"][to]["on"] == 1:
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Iconlock already enabled.")
                                else:
                                    group = self.client.getGroup(to)
                                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                    self.settings["picon"][to] = {"on":1,"pictureStatus":self.client.downloadFileURL(path)}
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Iconlock enabled.")
                            else:
                                group = self.client.getGroup(to)
                                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                self.settings["picon"][to] = {"on":1,"pictureStatus":self.client.downloadFileURL(path)}
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Iconlock enabled.")
                        if txt == ".cancel":
                            group = self.client.getGroup(to)
                            if group.invitee:
                                invitees = [o.mid for o in group.invitee]
                                #amount = len(invitees)
                                for i in invitees:
                                    self.client.cancelGroupInvitation(to,[i])
                                    time.sleep(1)
                        if txt == ".update gpic":
                            self.stats['gpic'][to] = True
                            self.client.sendText(to,"Send Image")
                        if txt == ".proalbum on":
                            self.settings["proalbum"][to] = True
                            self.client.sendText(to,"Protect album enabled")
                        if txt == ".proalbum off":
                            try:del self.settings["proalbum"][to]
                            except: pass
                            self.client.sendText(to,"Protect album disabled")
                        if txt == ".stag on":
                            self.settings["stickertagg"] = True
                            self.client.sendText(to,"Stickertagg enabled")
                        if txt == ".stag off":
                            self.stats['stickertagg']['sid'] = {}
                            self.stats['stickertagg']['pid'] = {}
                            self.stats['stickertagg']['v'] = {}
                            self.settings["stickertagg"] = False
                            self.client.sendText(to,"Stickertagg disabled")
                        if txt == ".pmtag on":
                            self.settings["staggpm"] = True
                            self.client.sendText(to,"Stickertaggpm enabled")
                        if txt == ".pmtag off":
                            self.stats['staggpm']['sid'] = {}
                            self.stats['staggpm']['pid'] = {}
                            self.stats['staggpm']['v'] = {}
                            self.settings["staggpm"] = False
                            self.client.sendText(to,"Stickertaggpm disabled")
                        if txt == ".sbye on":
                            self.settings["stickerbye"] = True
                            self.client.sendText(to,"Stickerbye enabled")
                        if txt == ".sbye off":
                            self.stats['stickerbye']['sid'] = {}
                            self.stats['stickerbye']['pid'] = {}
                            self.stats['stickerbye']['v'] = {}
                            self.settings["stickerbye"] = False
                            self.client.sendText(to,"Stickerbye disabled")
                        if txt == ".snook on":
                            self.settings["stickernook"] = True
                            self.client.sendText(to,"Stickernook enabled")
                        if txt == ".snook off":
                            self.stats['stickernook']['sid'] = {}
                            self.stats['stickernook']['pid'] = {}
                            self.stats['stickernook']['v'] = {}
                            self.settings["stickernook"] = False
                            self.client.sendText(to,"Stickernook disabled")
                        if txt == ".updatecover":
                            self.adc = True
                            self.client.sendReplyMessage(msg.id,to,"Send Image for Cover")
                        if txt == '.rsticker on' or txt == '.rsticker:on':
                            if to in self.db['rsticker']:
                                self.db['rsticker'][to]['on'] = True
                                self.client.sendText(to,"Response sticker enabled.")
                            else:
                                self.client.sendText(to,"Must set rsticker first.\nUse .sticker")
                        if txt == '.rsticker off' or txt == '.rsticker:off':
                            if to not in  self.db['rsticker']:
                                self.client.sendText(to,"response sticker already disabled.")
                            else:
                                self.db['rsticker'][to]['on'] = False
                                self.client.sendText(to,"response sticker disabled.")
                        if txt == '.rsticker':
                            self.rsticker = True
                            self.client.sendText(to, 'Send sticker.')
                        if txt == '.stickerban on' or txt == '.stickerban:on':
                            if to in self.stats['stickerban']:
                                self.stats['stickerban'][to]['on'] = True
                                self.client.sendText(to,"Stickerban enabled.")
                            else:
                                self.client.sendText(to,"Must set stickerban first.\nUse .stickerban")
                        if txt == '.stickerban off' or txt == '.stickerban:off':
                            if to not in self.stats['stickerban']:
                                self.client.sendText(to,"Stickerban already disabled.")
                            else:
                                self.stats['stickerban'][to]['on'] = False
                                self.client.sendText(to,"Stickerban disabled.")
                        if txt == '.stickerban':
                            self.stickerban = True
                            self.client.sendText(to, 'Send sticker.')
                        if txt == '.bigsticker on' or txt == '.bigsticker:on':
                            self.commands["enabled"] = True
                            self.client.sendReplyMessage(msg.id,to,'Bigsticker enabled.')
                        if txt == '.bigsticker off' or txt == '.bigsticker:off':
                            self.commands["enabled"] = False
                            self.client.sendReplyMessage(msg.id,to,'Bigsticker disabled.')
                        if txt == '.stickertext on' or txt == '.stickertext:on':
                            self.commands["enabled2"] = True
                            self.client.sendReplyMessage(msg.id,to,'Text sticker enabled.')
                        if txt == '.stickertext off' or txt == '.stickertext:off':
                            self.commands["enabled2"] = False
                            self.client.sendReplyMessage(msg.id,to,'Text sticker disabled.')
                        if txt == '.responimg on' or txt == '.responimg:on':
                            self.commands["enabled3"] = True
                            self.client.sendReplyMessage(msg.id,to,'Respon image enabled.')
                        if txt == '.responimg off' or txt == '.responimg:off':
                            self.commands["enabled3"] = False
                            self.client.sendReplyMessage(msg.id,to,'Respon image disabled.')
                        if txt == '.respontext on' or txt == '.respontext:on':
                            self.commands["enabled4"] = True
                            self.client.sendReplyMessage(msg.id,to,'Respon text enabled.')
                        if txt == '.respontext off' or txt == '.respontext:off':
                            self.commands["enabled4"] = False
                            self.client.sendReplyMessage(msg.id,to,'Respon text disabled.')
                        if txt == '.setwordban on' or txt == '.setwordban:on':
                            self.stats["enabled5"] = True
                            self.client.sendReplyMessage(msg.id,to,'Wordban enabled.')
                        if txt == '.setwordban off' or txt == '.setwordban:off':
                            self.stats["enabled5"] = False
                            self.client.sendReplyMessage(msg.id,to,'Wordban disabled.')
                        if txt == ".replyban on":
                            self.settings["replyban"][to] = True
                            self.client.sendText(to,"Replyban enabled")
                        if txt == ".replyban off":
                            try:del self.settings["replyban"][to]
                            except: pass
                            self.client.sendText(to,"Replyban disabled")
#                        if txt == '.rsmule on' or txt == '.rsmule:on':
#                            self.commands["enabled6"] = True
#                            self.client.sendReplyMessage(msg.id,to,'Respon Smule enabled.')
#                        if txt == '.rsmule off' or txt == '.rsmule:off':
#                            self.commands["enabled6"] = False
#                            self.client.sendReplyMessage(msg.id,to,'Respon Smule disabled.')
                        if txt == '.allrespon on' or txt == '.allrespon:on':
                            self.commands["enabled"] = True
                            self.commands["enabled2"] = True
                            self.commands["enabled3"] = True
                            self.commands["enabled4"] = True
                            self.client.sendReplyMessage(msg.id,to,'All Respon enabled.') 
                        if txt == '.allrespon off' or txt == '.allrespon:off':
                            self.commands["enabled"] = False
                            self.commands["enabled2"] = False
                            self.commands["enabled3"] = False
                            self.commands["enabled4"] = False
                            self.client.sendReplyMessage(msg.id,to,'All Respon disabled.')
                        if txt.startswith('.gcall '):
                            numb = int(txt.split()[1])
                            group = self.client.getGroup(to)
                            members = [o.mid for o in group.members]
                            status = self.client.call.getGroupCall(to)
                            for i in range(numb):
                                self.client.call.inviteIntoGroupCall(to, members, 1)
                            if not silent:self.client.sendMessage(to, "Send Callgroup to all member")
                        if txt.startswith('.blank'):
                            self.client.sendText(to, "blank kan hp lu wokwokwok (􀌂􀆭  blank kan hp lu wokwokwok .1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7).8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.blank kan hp lu wokwokwok blank kan hp lu wokwokwok gelap (􀌂􀆭  blank kan hp lu wokwokwok .1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7).8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.")
                        if txt.startswith('.join '):
                                text = msg.text[len(".join "):]
                                ticket = text.split("/ti/g/")
                                try:
                                    #client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    group = self.client.findGroupByTicket(ticket[1])
                                    self.client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                    self.client.sendReplyMessage(msg.id,to,"Successfully joined %s (%s)."%(group.name,len(group.members)))
                                except Exception as error:sendReplyMessage(msg.id,to,"Failed\n %s"%(error))
                        if txt.startswith('.spamcall '):
                            numb = int(txt.split()[1])
                            if msg.contentMetadata:
                                mids = [x['M'] for x in eval(msg.contentMetadata["MENTION"])['MENTIONEES']]
                                cons = self.client.getContacts(mids)
                                for i in range(numb):
                                    self.client.call.inviteIntoGroupCall(to, mids, 1)
                                if not silent:self.client.sendMessage(to, "Have send spamcall to:\n"+'\n'.join([m.displayName for m in cons]))
                        if txt.startswith(".spamtag "):
                            numb = int(txt.split()[1])
                            if msg.contentMetadata:
                                mids = [x['M'] for x in eval(msg.contentMetadata["MENTION"])['MENTIONEES']]
                                cons = self.client.getContacts(mids)
                                for i in range(numb):
                                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                                        names = re.findall(r'@(\w+)', txt)
                                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                        mentionees = mention['MENTIONEES']
                                        lists = []
                                        for mention in mentionees:
                                            if mention["M"] not in lists:
                                                lists.append(mention["M"])
                                        for mids in lists:
                                            contact = self.client.getContact(mids)
                                            self.sendtag(to, '@!', ' Tagging', [mids])
                        if txt.startswith('.assjoin '):
                                text = msg.text[len(".assjoin "):]
                                ticket = text.split("/ti/g/")
                                try:
                                    client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                    group = client.findGroupByTicket(ticket[1])
                                    client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                    client.sendText(of,"Successfully joined %s (%s)."%(group.name,len(group.members)))
                                except Exception as error:self.client.sendText(to,"Failed\n %s"%(error))

                        if txt.startswith('.asstag '):
                            text = msg.text[len(".asstag "):]
                            ticket = text.split("/ti/g/")
                            try:
                                client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                group = client.findGroupByTicket(ticket[1])
                                client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                group = client.getGroup(to)
                                members = [o.mid for o in group.members]
                                k = len(members)//20
                                for j in range(k+1):
                                    msg = Message(to=to)
                                    tst = u'ᴛᴀɢᴀʟʟ ᴍᴇᴍʙᴇʀs:\t\n\n'
                                    s=len(tst)
                                    d=[]
                                    for i in members[j*20 : (j+1)*20]:
                                        d.append({"S":str(s+3), "E" :str(s+7), "M":i})
                                        s += 8
                                        tst += u'⌬. @asu\n'
                                    msg.text = tst.rstrip()
                                    msg.contentMetadata = {u'MENTION':json.dumps({"MENTIONEES":d})}
                                    try:
                                        client.sendMessage(to,msg.text,msg.contentMetadata)
                                        client.leaveGroup(to)
                                    except:
                                        self.client.sendMessage(to,'LOG_OUT')
                                else:
                                    self.client.sendMessage(to,'Remote Assist Succes')
                            except Exception as error:self.client.sendText(to,"Failed\n %s"%(error))
                        if txt.startswith('.asscancel '):
                            text = msg.text[len(".asscancel "):]
                            ticket = text.split("/ti/g/")
                            try:
                                client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                group = client.findGroupByTicket(ticket[1])
                                client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                x = client.getGroup(group.id)
                                nama = [contact.mid for contact in x.invitee]
                                targets = []
                                for a in nama:
                                    if self.pangkat(a) > 4:
                                        targets.append(a)
                                if targets == []:
                                    self.client.sendMessage(to,"Target not found.")
                                else:
                                    cms = 'clear.js gid={} token={} app={}'.format(group.id,self.temp_db['token'],self.temp_db['appName'])
                                    for y in targets:
                                        cms += ' uid={}'.format(y)
                                    success = execute_js(cms)
                                    if success:
                                        try:
                                            client.leaveGroup(group.id)
                                        except:
                                            self.client.sendMessage(to,'LOG_OUT')
                                    else:
                                        self.client.sendMessage(to,'Execute Fail')
                            except Exception as error:self.client.sendText(to,"Failed\n %s"%(error))
                        if txt.startswith('.assbypass '):
                            text = msg.text[len(".assbypass "):]
                            ticket = text.split("/ti/g/")
                            try:
                                client = LINE(idOrAuthToken=self.temp_db['token'],appName=self.temp_db['appName'])
                                group = client.findGroupByTicket(ticket[1])
                                client.acceptGroupInvitationByTicket(group.id,ticket[1])
                                cmd = 'nook.js gid={} token={}'.format(to, self.temp_db['token'],self.temp_db['appName'])
                                g = client.getGroup(to)
                                for m in g.members:
                                    if m.mid not in self.stats["botlist"] and m.mid not in self.stats["stafflist"] and m.mid not in self.master:
                                        cmd += ' uid={}'.format(m.mid)
                                print(cmd)
                                success = execute_js(cmd)
                            except Exception as error:self.client.sendText(to,"Failed\n %s"%(error))
                        #if txt.startswith(".addmimic "):
                            #targets = []
                            #key = eval(msg.contentMetadata["MENTION"])
                            #key["MENTIONEES"][0]["M"]
                            #for x in key["MENTIONEES"]:
                                 #targets.append(x["M"])
                            #for target in targets:
                                #try:
                                    #self.stats["mimic"]["target2"][target] = True
                                    #self.client.sendMessage(msg.to,"Target ditambahkan!")
                                    #break
                                #except:
                                    #self.client.sendMessage(msg.to,"Added Target Fail !")
                                    #break
                        #if txt.startswith(".delmimic "):
                            #targets = []
                            #key = eval(msg.contentMetadata["MENTION"])
                            #key["MENTIONEES"][0]["M"]
                            #for x in key["MENTIONEES"]:
                                #targets.append(x["M"])
                            #for target in targets:
                                #try:
                                    #del self.stats["mimic"]["target2"][target]
                                    #self.client.sendMessage(msg.to,"Target dihapuskan!")
                                    #break
                                #except:
                                    #self.client.sendMessage(msg.to,"Deleted Target Fail !")
                                    #break
                            
                        #if txt == '.mimiclist':
                            #if self.stats["mimic"]["target2"] == {}:
                                #self.stats.sendMessage(msg.to,"Tidak Ada Target")
                            #else:
                                #mc = "╔══[ Mimic List ]"
                                #for mi_d in self.stats["mimic"]["target2"]:
                                    #mc += "\n╠ "+self.client.getContact(mi_d).displayName
                                #self.client.sendMessage(msg.to,mc + "\n╚══[◑ The End  ◑]")
                        if txt.startswith('.get-name '):
                            if msg.contentMetadata:
                                mids = [x['M'] for x in eval(msg.contentMetadata["MENTION"])['MENTIONEES']]
                                cons = self.client.getContacts(mids)
                                self.client.sendMessage(to, '\n'.join([m.displayName for m in cons]))
                            elif 'group' in txt:
                                g = self.client.getGroup(to)
                                self.client.sendMessage(to, g.name)
                        if txt.startswith(".sendmsg "):
                            text = txt.split(" ")
                            teks = txt.replace(".sendmsg "+text[1]+" ","")
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            dt = self.client.getContact(key1)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xtxt = 'Hey '
                            shizuka = str(dt.displayName)
                            txt = ''
                            txt2 = txt+"@a"" "
                            xlen = str(len(zxc)+len(xtxt))
                            xlen2 = str(len(zxc)+len(txt2)+len(xtxt)-1)
                            zx = {'S':xlen, 'E':xlen2, 'M':dt.mid}
                            zx2.append(zx)
                            zxc += txt2
                            msg.contentType = 0
                            msg.text = xtxt+ zxc + "\nBaca Pm ku."
                            msg.contentMetadata ={'MENTION':'{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}'}
                            self.client.sendMessage(to,msg.text,msg.contentMetadata)               
                            self.client.sendText(dt.mid,teks)

                        if txt == ".myvideo":
                            h = self.client.getContact(of)
                            if h.videoProfile == None:
                              return self.client.sendMessage(to, "You have no video profile")
                            self.client.sendVideoWithURL(to,"http://dl.profile.line-cdn.net/" + h.pictureStatus + "/vp")
                        if txt.startswith(".playstore "):
                            a = " ".join(txt.split()[2:])
                            c = urllib.parse.quote(a)
                            self.client.sendText(to,"Title : "+a+"\nSource : Google Play\nLinknya : https://play.google.com/store/search?q=" + c)
                        if txt.startswith(".get-note"):
                            data = self.client.getGroupPost(to)
                            try:
                                music = data['result']['feeds'][int(msg.text.split(' ')[1]) - 1]
                                print(music)
                                b = [music['post']['userInfo']['writerMid']]
                                try:
                                    for a in music['post']['contents']['textMeta']:b.append(a['mid'])
                                except:pass
                                try:
                                    g= "\n\nᴅᴇsᴄʀɪᴘᴛɪᴏɴ:\n"+str(music['post']['contents']['text'].replace('@','@!'))
                                except:
                                    g=""
                                a="\n   ᴛᴏᴛᴀʟ ʟɪᴋᴇ: "+str(music['post']['postInfo']['likeCount'])
                                a +="\n   ᴛᴏᴛᴀʟ ᴄᴏᴍᴍᴇɴᴛ: "+str(music['post']['postInfo']['commentCount'])
                                gtime = music['post']['postInfo']['createdTime']
                                a +="\n   ᴄʀᴇᴀᴛᴇᴅ ᴀᴛ: "+str(humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                a += g
                                zx = ""
                                zxc = " ɴᴏᴛᴇ ɢʀᴏᴜᴘ:\nᴛʏᴘᴇ: ɢᴇᴛ ɴᴏᴛᴇ\n   ᴘᴇɴᴜʟɪs : @!" + a
                                try:
                                    #self.sendtag(msg_id, to, zxc, b)
                                    self.sendMention(to,zxc, b)
                                except Exception as e:
                                    self.client.sendMessage(to, str(e))
                                try:
                                    for c in music['post']['contents']['media']:
                                        params = {'userMid': self.client.getProfile().mid, 'oid': c['objectId']}
                                        path = self.client.server.urlEncode(self.client.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                                        if 'PHOTO' in c['type']:
                                            try:
                                                self.client.sendReplyImageWithURL(msg.id,to,path)
                                            except:pass
                                        else:
                                            pass
                                        if 'VIDEO' in c['type']:
                                            try:
                                                self.client.sendVideoWithURL(to,path)
                                            except:pass
                                        else:
                                            pass
                                except:
                                    pass
                            except Exception as e:
                                return self.client.sendMessage(to,"「 Auto Respond 」\n"+str(e))
# NEW COOMAND STARTWIST ===========================##
                        if txt.startswith(".stag"):
                            if 'add' in txt:
                                self.stickertagg = True
                                if not silent:self.client.sendText(to,"Send Sticker for Tagall sticker.")
                            elif '...off' in txt:
                                if not silent:self.client.sendText(to,"Tagall Sticker Disable.")
                        if txt.startswith(".pmtag"):
                            if 'add' in txt:
                                self.staggpm = True
                                if not silent:self.client.sendText(to,"Send Sticker for Tagpm sticker.")
                            elif '...off' in txt:
                                if not silent:self.client.sendText(to,"Tagall Sticker Disable.")  
                        if txt.startswith(".sbye"):
                            if 'add' in txt:
                                self.stickerbye = True
                                if not silent:self.client.sendText(to,"Send Sticker for bye sticker.")
                            elif '...off' in txt:
                                if not silent:self.client.sendText(to,"Tagall Sticker Disable.")
                        #if txt.startswith(".replykick"):
                            #if 'on' in txt:
                                #self.replykick = True
                                #if not silent:self.client.sendText(to,"Send Sticker for Replykick.")
                            #elif 'off' in txt:
                                #self.stats['replykick']['sid'] = {}
                                #self.stats['replykick']['pid'] = {}
                                #self.stats['replykick']['v'] = {}
                                #if not silent:self.client.sendText(to,"Replykick Sticker Disable.")
                        if txt.startswith(".snook"):
                            if 'add' in txt:
                                self.stickernook = True
                                if not silent:self.client.sendText(to,"Send Sticker for bypass sticker.")
                            elif '...off' in txt:
                                if not silent:self.client.sendText(to,"Tagall Sticker Disable.")

                        if txt == ".get-token ios":
                            try:
                                nama = "Rgjs"
                                self.temp_db['device'].update({'x-lpqs' : '/api/v4/TalkService.do'})
                                transport = THttpClient.THttpClient('https://legy-jp.line.naver.jp/api/v4/TalkService.do')
                                transport.setCustomHeaders(self.temp_db['device'])
                                protocol = TCompactProtocol.TCompactProtocol(transport)
                                cl = TalkService.Client(protocol)
                                qr = cl.getAuthQrcode(keepLoggedIn=1, systemName=nama)
                                link = "line://au/q/" + qr.verifier
                                self.client.sendText(to,"Klik link dibawah ini untuk login Antijs \n\n"+str(link))
                                self.temp_db['device'].update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
                                json.loads(requests.session().get('https://legy-jp.line.naver.jp/Q', headers=self.temp_db['device']).text)
                                self.temp_db['device'].update({'x-lpqs' : '/api/v4p/rs'})
                                transport = THttpClient.THttpClient('https://legy-jp.line.naver.jp/api/v4p/rs')
                                transport.setCustomHeaders(self.temp_db['device'])
                                protocol = TCompactProtocol.TCompactProtocol(transport)
                                cl = AuthService.Client(protocol)
                                req = LoginRequest()
                                req.type = 1
                                req.verifier = qr.verifier
                                req.e2eeVersion = 1
                                temp_client = cl.loginZ(req)
                                self.temp_db['token'] = temp_client.authToken
                                self.client.sendText(to,"Success login Antijs")
                                self.client.sendText(to,self.temp_db['token'])
                            except Exception as e:self.client.sendText(to,"Maaf anda di banned login\ntunggu 24 jam br anda bisa login lagi.");traceback.print_exc()
 
                        if txt.startswith(".quit "):
                            screen = txt.replace('.quit ','').split(' ')
                            for x in screen:
                                os.system("screen -S {} -X quit".format(x))
                                time.sleep(2)
                                self.client.sendMessage(to, "Screen name %s has been quit" %x)

                        if txt.startswith("?run "):
                            screen = txt.replace('?run ','').split(' ')
                            for x in screen:
                                os.system("screen -S {} -X quit".format(x))
                                os.system('screen -dmS {}'.format(x))
                                os.system('screen -r {} -X stuff "python3 login.py {}\n"'.format(x, x,x))
                                time.sleep(2)
                                self.client.sendMessage(to, "%s has been runned" %x)

                        if txt.startswith(".runjs "):
                            screen = txt.replace('.runjs ','').split(' ')
                            for cust in screen:
                                isi = self.client.authToken
                                umid = self.client.profile.mid
                                token = '{"token": "%s"}' %str(isi)
                                comm = '  {"user": "%s"}' %str(umid)
                                os.system("cd /root/djs/src && echo -n '%s' > token.json"%token)
                                os.system("cd /root/djs/src && echo -n '%s' > user.json"%(comm))
                                os.system("screen -S {} -X quit".format(cust))
                                os.system('screen -dmS {}'.format(cust))
                                os.system('screen -r {} -X stuff "cd /root/djs && npm start \n"'.format(cust))
                                time.sleep(1)
                                self.client.sendMessage(to, "Succes run Js")

                        if txt.startswith(".setjs "):                                  
                            setcom = str(txt.split(' ')[1])
                            comm = '  {"com": "%s"}' %str(setcom)
                            try:     
                                os.system("cd /root/djs/src && echo -n '%s' > com.json"%(comm))
                                self.client.sendMessage(to, "Command js diubah ke %s" %setcom)
                            except:
                                self.client.sendMessage(to,"Error")

                        if txt.startswith(".rfile "):
                            screen = txt.replace('.rfile ','').split(' ')
                            for x in screen:
                                os.system("cd /root && rm -rf {}\n".format(x))
                                time.sleep(2)
                                self.client.sendMessage(to, "Folder name %s has been remove" %x)
                        if txt == ".screen":
                            proses = os.popen("screen -ls")
                            x = proses.read()
                            self.client.sendText(to, "{}".format(x))
                            proses.close()

                        if txt == ".delcache":                          
                            #cd = str(txt.split(' ')[1])
                            try:
                               prosses = os.popen("sync; echo 3 > /proc/sys/vm/drop_caches")
                               a = prosses.read()
                               self.client.sendText(to, "Done")
                               prosses.close()
                            except:
                               self.client.sendText(to, "Error")
                        if txt == ".free":                          
                            #cd = str(txt.split(' ')[1])
                            try:
                               prosses = os.popen("free -m")
                               a = prosses.read()
                               self.client.sendText(to, "{}".format(a))
                               prosses.close()
                            except:
                               self.client.sendText(to, "Error")
                        if txt.startswith(self.stats["uplike"]):
                            if 'on' in txt or '1' in txt:
                                if not self.settings["autolike"]:
                                    self.settings["autolike"] = True
                                    if not silent:self.client.sendMessage(to,"Autolike enabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Autolike already enabled.")
                            elif 'off' in txt or '0' in txt:
                                if self.settings["autolike"]:
                                    self.settings["autolike"] = False
                                    if not silent:self.client.sendMessage(to,"Autolike disabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Autolike already disabled.")
                            else:
                                self.client.sendMessage(to,"Usage:\n⌬ .on\n⌬ .off")
                            self.backupData()
#execusi ny
                        #if txt.startswith(".smulelink "): #gunakan dengan link smule
                            #textt = txt.split(" ")
                            #self.client.sendVideoWithURL(to, self.talk.smule(textt))
                        if txt.startswith("//smule "):
                            sep = txt.split(" ")
                            search = txt.replace(sep[0] + " ", "")
                            r = requests.get("https://www.smule.com/" + search + "/performances/json")
                            data = r.text
                            a = json.loads(data)
                            num = 0
                            if a["list"] != []:
                                ret_ = []
                                yt = []
                                for music in a["list"]:
                                    if len(ret_) >= 20:
                                        pass
                                    num = num + 1
                                    smule = str(music["web_url"])
                                    dl = str(music["cover_url"])
                                    ret_.append(
                                        {
                                            "type": "bubble",
                                            "styles": {
                                                "header": {
                                                    "backgroundColor": "#800000",
                                                    "separator": True,
                                                    "separatorColor": "#00FF00",
                                                },
                                                "body": {
                                                    "backgroundColor": "#800000",
                                                    "separator": True,
                                                    "separatorColor": "#00FF00",
                                                },
                                                "footer": {
                                                    "backgroundColor": "#DCDCDC",
                                                    "separator": True,
                                                    "separatorColor": "#00FF00",
                                                },
                                            },
                                            "body": {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "flex": 1,
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "image",
                                                                "url": dl,
                                                                "aspectMode": "cover",
                                                                "aspectRatio": "1:1",
                                                                "gravity": "bottom",
                                                                "size": "sm",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "uri": (
                                                                        "https://smule.com/"
                                                                        + smule
                                                                    ),
                                                                },
                                                            }
                                                        ],
                                                    },
                                                    {
                                                        "type": "separator",
                                                        "color": "#22301f",
                                                    },
                                                    {
                                                        "type": "box",
                                                        "contents": [
                                                            {
                                                                "type": "separator",
                                                                "color": "#22301f",
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "ᴅᴇᴛᴀɪʟ ʀᴇᴄᴏʀᴅ",
                                                                "color": "#0a0675",
                                                                "size": "sm",
                                                                "align": "center",
                                                                "wrap": True,
                                                                "flex": 2,
                                                                "gravity": "top",
                                                            },
                                                            {
                                                                "type": "separator",
                                                                "color": "#22301f",
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "ᴏᴄ: "
                                                                + str(
                                                                    music["title"]
                                                                ),
                                                                "color": "#0a0675",
                                                                "size": "xxs",
                                                                "wrap": True,
                                                                "flex": 3,
                                                                "gravity": "top",
                                                            },
                                                            {
                                                                "type": "separator",
                                                                "color": "#22301f",
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "ᴄʀᴇᴀᴛᴇ: {}".format(
                                                                    music[
                                                                        "created_at"
                                                                    ][:10]
                                                                ),
                                                                "color": "#0a0675",
                                                                "size": "xxs",
                                                                "wrap": True,
                                                                "flex": 4,
                                                                "gravity": "top",
                                                            },
                                                            {
                                                                "type": "separator",
                                                                "color": "#22301f",
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "ɪᴅ: "
                                                                + str(
                                                                    music["owner"][
                                                                        "handle"
                                                                    ]
                                                                ),
                                                                "color": "#0a0675",
                                                                "size": "xxs",
                                                                "wrap": True,
                                                                "flex": 5,
                                                                "gravity": "top",
                                                            },
                                                            {
                                                                "type": "separator",
                                                                "color": "#22301f",
                                                            },
                                                        ],
                                                        "flex": 2,
                                                        "layout": "vertical",
                                                    },
                                                ],
                                            },
                                            "footer": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "button",
                                                                "flex": 2,
                                                                "style": "primary",
                                                                "color": "#0a0675",
                                                                "height": "sm",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "ᴡᴀᴛᴄʜɪɴɢ",
                                                                    "uri": (
                                                                        "https://smule.com/"
                                                                        + smule
                                                                    ),
                                                                },
                                                            },
                                                            {
                                                                "flex": 3,
                                                                "type": "button",
                                                                "margin": "sm",
                                                                "style": "primary",
                                                                "color": "#0a0675",
                                                                "height": "sm",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "mp3",
                                                                    "uri": "line://app/1646011835-9MXEx20v?type=text&text=smule%20{}/{}".format(
                                                                        str(search),
                                                                        str(num),
                                                                    ),
                                                                },
                                                            },
                                                        ],
                                                    },
                                                    {
                                                        "type": "button",
                                                        "margin": "sm",
                                                        "style": "primary",
                                                        "color": "#0a0675",
                                                        "height": "sm",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "ᴅᴏᴡɴʟᴏᴀᴅ",
                                                            "uri": "line://app/1646011835-9MXEx20v?type=text&text=smule%20{}/{}".format(
                                                                str(search),
                                                                str(num),
                                                            ),
                                                        },
                                                    },
                                                ],
                                            },
                                        }
                                    )
                                    yt.append("https://smule.com/" + smule)
                                k = len(ret_) // 20
                                for aa in range(k + 1):
                                    data = {
                                        "type": "flex",
                                        "altText": "sᴍᴜʟᴇ",
                                        "contents": {
                                            "type": "carousel",
                                            "contents": ret_[
                                                aa * 10 : (aa + 1) * 10
                                            ],
                                        },
                                    }
                                    self.sendTemplate(to, data)
                        if txt.startswith("smule "):
                            proses = txt.split(" ")
                            urutan = txt.replace(proses[0] + " ", "")
                            count = urutan.split("/")
                            search = str(count[0])
                            r = requests.get(
                                "https://www.smule.com/"
                                + search
                                + "/performances/json"
                            )
                            data = json.loads(r.text)
                            if len(count) == 1:
                                no = 0
                                ret_ = "「 Record Smule 」\n"
                                for aa in data["list"]:
                                    no += 1
                                    ret_ += "\n" + str(no) + ". " + str(aa["title"])
                                ret_ += "\n\nSelanjutnya Smule {}/(urutan)\nuntuk melihat detailnya.".format(
                                    str(search)
                                )
                                hasil = ret_
                                data = {
                                    "type": "flex",
                                    "altText": "ѕмυℓє",
                                    "contents": {
                                        "type": "bubble",
                                        "header": {
                                            "type": "box",
                                            "layout": "vertical",
                                            "spacing": "xs",
                                            "contents": [
                                                {
                                                    "type": "text",
                                                    "text": "Smule List",
                                                    "size": "xl",
                                                    "wrap": True,
                                                    "align": "center",
                                                    "color": "#a05b00",
                                                }
                                            ],
                                        },
                                        "footer": {
                                            "type": "box",
                                            "layout": "horizontal",
                                            "contents": [
                                                {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                        "type": "text",
                                                            "text": "{}".format(
                                                                str(hasil)
                                                            ),
                                                            "color": "#0010FF",
                                                            "wrap": True,
                                                            "size": "xxs",
                                                        }
                                                    ],
                                                }
                                            ],
                                        },
                                    },
                                }
                                self.sendTemplate(to, data)
                            elif len(count) == 2:
                                try:
                                    num = int(count[1])
                                    fn = data["list"][num - 1]
                                    smule = str(fn["web_url"])
                                    c = "🎶 ᴊᴜᴅᴜʟ ᴏᴄ: " + str(fn["title"])
                                    c += "\n👥 ɪᴅ sᴍᴜʟᴇ: " + str(
                                        fn["owner"]["handle"]
                                    )
                                    c += (
                                        "\n👍 ᴛᴏᴛᴀʟ ʟɪᴋᴇ: "
                                        + str(fn["stats"]["total_loves"])
                                        + " ʟɪᴋᴇ"
                                    )
                                    c += (
                                        "\n🗯 ᴛᴏᴛᴀʟ ᴄᴏᴍᴍᴇɴᴛs: "
                                        + str(fn["stats"]["total_comments"])
                                        + " ᴄᴏᴍᴍᴇɴᴛs"
                                    )
                                    c += "\n🎼 sᴛᴀᴛᴜs ᴠɪᴘ: " + str(
                                        fn["owner"]["is_vip"]
                                    )
                                    c += "\n🎹 sᴛᴀᴛᴜs ᴏᴄ: " + str(fn["message"])
                                    c += "\n📆 ᴄʀᴇᴀᴛᴇ ᴏᴄ: {}".format(
                                        fn["created_at"][:10]
                                    )
                                    c += (
                                        "\n🎧 ᴅɪ ᴅᴇɴɢᴀʀᴋᴀɴ: {}".format(
                                            fn["stats"]["total_listens"]
                                        )
                                        + " ᴏʀᴀɴɢ"
                                    )
                                    hasil = "📄 ᴅᴇᴛᴀɪʟ ʀᴇᴄᴏʀᴅ\n" + str(c)
                                    dl = str(fn["cover_url"])
                                    data = {
                                        "type": "flex",
                                        "altText": "ѕмυℓє",
                                        "contents": {
                                            "type": "bubble",
                                            "header": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "xs",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "𝙎𝙢𝙪𝙡𝙚 𝙄𝙣𝙛𝙤",
                                                        "size": "xl",
                                                        "wrap": True,
                                                        "align": "center",
                                                        "color": "#a05b00",
                                                    }
                                                ],
                                            },
                                            "footer": {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "{}".format(
                                                                    str(hasil)
                                                                ),
                                                                "color": "#0010FF",
                                                                "wrap": True,
                                                                "size": "xxs",
                                                            }
                                                        ],
                                                    }
                                                ],
                                            },
                                        },
                                    }
                                    self.sendTemplate(to, data)
                                    with requests.session() as s:
                                        s.headers["user-agent"] = "Mozilla/5.0"
                                        r = s.get(
                                            "https://sing.salon/smule-downloader/?url=https://www.smule.com{}".format(
                                                urllib.parse.quote(smule)
                                            )
                                        )
                                        data = BeautifulSoup(r.content, "html5lib")
                                        get = data.select(
                                            "a[href*=https://www.smule.com/redir?]"
                                        )[0]
                                        title = data.findAll("h2")[0].text
                                        imag = data.select(
                                            "img[src*=https://www.smule.com/redir?]"
                                        )[0]
                                        if "Smule.m4a" in get["download"]:
                                            self.Footerlimbz(
                                                to, "ᴡᴀɪᴛ ғᴏʀ ᴜᴘʟᴏᴀᴅɪɴɢ.....!!!"
                                            )
                                            self.client.sendAudioWithURL(
                                                msg.to, get["href"]
                                            )
                                                # self.client.sendMessage(to, hasil, {'AGENT_NAME': ' URL Smule','AGENT_LINK': 'https://www.smule.com/{}'.format(str(fn['owner']['handle'])),'AGENT_ICON': 'https://png.icons8.com/color/50/000000/speaker.png' })
                                        else:
                                            self.Footerlimbz(
                                                to, "ᴡᴀɪᴛ ғᴏʀ ᴜᴘʟᴏᴀᴅɪɴɢ.....!!!"
                                            )
                                            self.client.sendVideoWithURL(
                                                    msg.to, get["href"]
                                            )
                                                # self.client.sendMessage(to, hasil, {'AGENT_NAME': ' URL Smule','AGENT_LINK': 'https://www.smule.com/{}'.format(str(fn['owner']['handle'])),'AGENT_ICON': 'https://png.icons8.com/color/50/000000/speaker.png' })
                                        #self.client.unsendMessage(msg_id)
                                except Exception as e:
                                    self.client.sendText(
                                        msg.to, "「 Result Error 」\n" + str(e)
                                    )
                        if txt.startswith(".imgtext "):
                          #if msg._from in admin:
                            textnya = msg.text.replace(".imgtext ","")
                            with requests.session() as s:
                                    s.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0"
                                    font = random.choice(["tahoma","verdana"])
                                    r = s.get("http://api.img4me.com/?text=%s&font=%s&fcolor=FFFFFF&size=35&bcolor=000000&type=jpg" %(urllib.parse.quote(textnya),font))
                                    data = str(r.text)
                                    if "Error" not in data:
                                        path = data
                                        self.client.sendReplyImageWithURL(msg.id, to,path)
                                    else:
                                        self.client.sendReplyMessage(msg.id, to, "「Result Error」 %s" %(data.replace("Error: ")))
                        if txt.startswith(".nk: "):
                            if msg.toType == 2:
                                _name = msg.text.replace(".nk: ","")
                                gs = self.client.getGroup(msg.to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName:
                                        targets.append(g.mid)
                                if targets == []:
                                    self.client.sendMessage(msg.to,"Not found same name")
                                else:
                                    for target in targets:
                                        try:
                                            self.client.kickoutFromGroup(msg.to,[target])
                                            print (msg.to,[g.mid])
                                        except:
                                            pass
                        #if txt.startswith(".schat"):
                            #text = msg.text.replace(".schat ","").lstrip().rstrip()
                            #jmlh = int(text[2])
                            #balon = jmlh * (text[3]+"\n")
                            #if text[1] == "on":
                                #if jmlh <= 999:
                                    #for x in range(jmlh):
                                        #self.client.sendMessage(to, text[3])
                                #else:
                                    #self.client.sendMention(to, "Sorry the amount is too much :) @!", [sender])
                            #elif text[1] == "off":
                              #if jmlh <= 999:
                                #self.client.sendMessage(to, balon)
                              #else:
                                #self.client.sendMention(to, "Sorry the amount is too much :) @!", [sender])
                        if txt.startswith(".schat "):
                            xpesan = txt.lower()
                            txt = xpesan.split(" ")
                            jmlh = int(txt[2])
                            teks = xpesan.replace(".schat "+str(txt[1])+" "+str(jmlh)+ " ","")
                            tulisan = jmlh * (teks+"\n")
                            if txt[1] == "on":
                                 if jmlh <= 1000000:
                                      for x in range(jmlh):
                                            self.client.sendMessage(msg.to, teks)
                                 else:
                                        self.client.sendMention(to, "Sorry the amount is too much :) @!", [sender])
                            elif txt[1] == "off":
                                  if jmlh <= 1000000:
                                       self.client.sendMessage(msg.to, tulisan)
                                  else:
                                       self.client.sendMention(to, "Sorry the amount is too much :) @!", [sender])       
                        if txt.startswith('.countdown'):
                            number = txt.replace(".countdown","").lstrip().rstrip()
                            if len(number) > 0:
                                if number.isdigit():
                                    number = int(number)
                                    if number > 10000:
                                        self.client.sendReplyMessage(msg.id,to,"Max: 10000.")
                                    else:
                                        for i in range(0,number):
                                            self.client.sendReplyMessage(msg.id,to,str(number))
                                            number -= 1
                                            time.sleep(1)
                                else:
                                    self.client.send_reply(msg,"Please specify a valid number.")
                            else:
                                self.client.sendReplyMessage(msg.id,to,"Usage:\n⌬.「number」")
                        if txt.startswith(".wordban "):
                            wban = msg.text.replace(".wordban ","").lstrip().rstrip()
                            #wban = " ".join(txt.split()[2:])
                            self.stats['wordban'].append(wban)
                            self.client.sendReplyMessage(msg.id,to,"%s add in Wordban."%wban)
                        if txt.startswith(".delwordban "):
                            wuban = msg.text.replace(".delwordban ","").lstrip().rstrip()
                            #wuban = " ".join(txt.split()[2:])
                            if wuban in self.stats['wordban']:
                                self.stats['wordban'].remove(wuban)
                                self.client.sendReplyMessage(msg.id,to,"%s Remove in Wordban."%wuban)
                            else:
                                self.client.sendReplyMessage(msg.id,to,"%s is not Wordban."%wuban)
                        if txt == ".wordbanlist":
                            tst = "Wordbanlist:\n"
                            if len(self.stats['wordban']) > 0:
                                for word in self.stats['wordban']:
                                    tst += "⌬ %s"%word
                                self.client.sendReplyMessage(msg.id,to,tst)
                            else:
                                self.client.sendReplyMessage(msg.id,to,"Wordban is empty!")
                        if txt == ".stkbanlist":
                            tst = "Sticker banlist:\n"
                            if len(self.stats['stickerban']) > 0:
                                for word in self.stats['stickerban']:
                                    tst += "⌬ %s"%word
                                self.client.sendReplyMessage(msg.id,to,tst)
                            else:
                                self.client.sendReplyMessage(msg.id,to,"Stickerban is empty!")
                        if txt == ".curl":
                            g = self.client.getGroup(to)
                            links = g.preventedJoinByTicket
                            if links == False:
                                g.preventedJoinByTicket = True
                                self.client.updateGroup(g)
                                self.client.sendReplyMessage(msg.id,to,"Invites by link are now disabled.")
                            else:
                                self.client.sendReplyMessage(msg.id,to,"Invites by link are already disabled.")
                        if txt == ".stkbypasslist":
                            tst = "Sticker bypasslist:\n"
                            if len(self.stats['stickerbypass']) > 0:
                                for word in self.stats['stickerbypass']:
                                    tst += "⌬ %s"%word
                                self.client.sendReplyMessage(msg.id,to,tst)
                            else:
                                self.client.sendReplyMessage(msg.id,to,"Stickerbypass is empty!")
                        if txt == ".curl":
                            g = self.client.getGroup(to)
                            links = g.preventedJoinByTicket
                            if links == False:
                                g.preventedJoinByTicket = True
                                self.client.updateGroup(g)
                                self.client.sendReplyMessage(msg.id,to,"Invites by link are now disabled.")
                            else:
                                self.client.sendReplyMessage(msg.id,to,"Invites by link are already disabled.")
                        if txt == ".ourl":
                            g = self.client.getGroup(to)
                            links = g.preventedJoinByTicket
                            gTicket = "https://line.me/R/ti/g/{}".format(str(self.client.reissueGroupTicket(g.id)))
                            if links == True:
                                g.preventedJoinByTicket = False
                                self.client.updateGroup(g)
                                self.client.sendReplyMessage(msg.id,to,"Invites by link are now enabled.\nLink group:\n"+gTicket)
                            else:
                                self.client.sendReplyMessage(msg.id,to,"Invites by link are already enabled.\nLink group:\n"+gTicket)

                        if txt == ".infocctv":
                          try:
                              f = open("cctv.text","r")
                              lines = f.readlines()
                              hasil = "Kode & wilayah cctv\n\n"
                              for a in lines:
                                  hasil += str(a)
                              #self.client.sendText(to,str(hasil))
                              self.client.reissueUserTicket()
                              self.client.sendMessage(to,"{}".format(str(hasil)),contentMetadata = {'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+self.client.getContact(self.uid).pictureStatus, 'AGENT_NAME': self.client.profile.displayName, 'AGENT_LINK': "http://line.me/ti/p/" + self.client.getUserTicket().id})
                              self.client.sendText(to,"🔍 Informasi detail :\n\nExample:\n.cctv 333")
                          except Exception as e:
                              self.client.sendText(to,"{}".format(str(e)))

                        if txt.startswith(".cctv "):
                            try:
                                proses = txt.split(" ")
                                kode = txt.replace(proses[0] + " ","")
                                with requests.session() as a:
                                    a.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0"
                                    r = a.get("http://lewatmana.com/cam/{}/bundaran-hi/".format(urllib.parse.quote(kode)))
                                    soup = BeautifulSoup(r.content, "html5lib")
                                    hasil = "🎬 Informasi CCTV\n\n"
                                    hasil += soup.select("[class~=cam-viewer-title]")[0].text
                                    hasil += " "
                                    video = soup.find("source")["src"]
                                    #self.client.sendText(to,hasil)
                                    self.client.reissueUserTicket()
                                    self.client.sendMessage(to,"{}".format(str(hasil)),contentMetadata = {'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+self.client.getContact(self.uid).pictureStatus, 'AGENT_NAME': self.client.profile.displayName, 'AGENT_LINK': "http://line.me/ti/p/" + self.client.getUserTicket().id})
                                    self.client.sendVideoWithURL(to,video)
                            except Exception as e:
                                self.client.sendText(to,"{}".format(str(e)))
                        if txt.startswith(".location"):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:  
                                    groups = self.client.getGroupIdsJoined()
                                    #groups = self.client.groups
                                    ingroups = []
                                    for group in groups:
                                        members = [o.mid for o in self.client.getGroup(group).members]
                                        if mention in members:
                                            ingroups.append(self.client.getGroup(group).name)
                                    if len(ingroups) > 0:
                                        tst = "User found in %s groups:\n"%len(ingroups)
                                        for g in ingroups:
                                            tst += "\n⌬. %s"%g
                                        self.client.sendText(to,tst)
                                    else:
                                        self.client.sendText(to,"User not found in any group.")
                            else:
                                self.clear()
                                self.stats["locate"] = True
                                if not silent:self.client.sendText(to,"Send contact to locate.")
                        #if txt.startswith(".lirik "):
                            #try:
                                #songname = txt.replace('.lirik ','')
                                #params = {'songname': songname}
                                #r = requests.get("http://ide.fdlrcn.com/workspace/yumi-apis/joox?{}".format(params))
                                #data = r.text
                                #data = json.loads(data)
                                #for song in data:
                                    #hasil = 'Lyric Lagu ('
                                    #hasil += song[0]
                                    #hasil += ')\n\n'
                                    #hasil += song[5]
                                    #self.client.sendMessage(msg.to, hasil)
                            #except Exception as wak:
                                    #self.client.sendMessage(msg.to, str(wak))
                        if txt.startswith('.upbypass '):
                            if '.upbypass' in msg.text:
                                upbypass = msg.text.replace(".upbypass","").lstrip().rstrip()
                            else:
                                upbypass = msg.text.replace(".Upbypass","").lstrip().rstrip()
                            self.stats["kickal"] = upbypass
                            if not silent:self.client.sendMessage(to,"Bypass command set to:\n%s"%upbypass)
                            self.backupData()
                        if txt.startswith('.upsider '):
                            if '.upsider' in msg.text:
                                upsider = msg.text.replace(".upsider","").lstrip().rstrip()
                            else:
                                upsider = msg.text.replace(".Upsider","").lstrip().rstrip()
                            self.stats["sidercom"] = upsider
                            if not silent:self.client.sendMessage(to,"Sider command set to:\n%s"%upsider)
                            self.backupData()
                        if txt.startswith('.uphelp '):
                            if '.uphelp' in msg.text:
                                uphelp = msg.text.replace(".uphelp","").lstrip().rstrip()
                            else:
                                uphelp = msg.text.replace(".Uphelp","").lstrip().rstrip()
                            self.stats["helpcom"] = uphelp
                            if not silent:self.client.sendMessage(to,"Help command set to:\n%s"%uphelp)
                            self.backupData()
                        if txt.startswith('.upkick '):
                            if '.upkick' in msg.text:
                                upkick = msg.text.replace(".upkick","").lstrip().rstrip()
                            else:
                                upkick = msg.text.replace(".Upkick","").lstrip().rstrip()
                            self.stats["tendang"] = upkick
                            if not silent:self.client.sendMessage(to,"Kick command set to:\n%s"%upkick)
                            self.backupData()
                        if txt.startswith('.upjoinbots '):
                            if '.upjoinbots' in msg.text:
                                upjoin = msg.text.replace(".upjoinbots","").lstrip().rstrip()
                            else:
                                upjoin = msg.text.replace(".Upjoinbots","").lstrip().rstrip()
                            self.stats["joinbots"] = upjoin
                            if not silent:self.client.sendMessage(to,"Joinbots command set to:\n%s"%upjoin)
                            self.backupData()
                        if txt.startswith('.uptag '):
                            if '.uptag' in msg.text:
                                uptag = msg.text.replace(".uptag","").lstrip().rstrip()
                            else:
                                uptag = msg.text.replace(".Uptag","").lstrip().rstrip()
                            self.stats["tagal"] = uptag
                            if not silent:self.client.sendMessage(to,"Tagall command set to:\n%s"%uptag)
                            self.backupData()
                        if txt.startswith('.uplike '):
                            if '.uplike' in msg.text:
                                uplike = msg.text.replace(".uplike","").lstrip().rstrip()
                            else:
                                uplike = msg.text.replace(".Uplike","").lstrip().rstrip()
                            self.stats["uplike"] = uplike
                            if not silent:self.client.sendMessage(to,"Autolike command set to:\n%s"%uplike)
                            self.backupData()
                        if txt.startswith('.uptagon '):
                            if '.uptagon' in msg.text:
                                uptagon = msg.text.replace(".uptagon","").lstrip().rstrip()
                            else:
                                uptagon = msg.text.replace(".Uptagon","").lstrip().rstrip()
                            self.stats["uptagon"] = uptagon
                            if not silent:self.client.sendMessage(to,"TagRespon On command set to:\n%s"%uptagon)
                            self.backupData()
                        if txt.startswith('.uptagoff '):
                            if '.uptagoff' in msg.text:
                                uptagoff = msg.text.replace(".uptagoff","").lstrip().rstrip()
                            else:
                                uptagoff = msg.text.replace(".Uptagoff","").lstrip().rstrip()
                            self.stats["uptagoff"] = uptagoff
                            if not silent:self.client.sendMessage(to,"TagRespon Off command set to:\n%s"%uptagoff)
                            self.backupData()
                        if txt.startswith('.upaddcom '):
                            if '.upaddcom' in msg.text:
                                upaddcom = msg.text.replace(".upaddcom","").lstrip().rstrip()
                            else:
                                upaddcom = msg.text.replace(".Upaddcom","").lstrip().rstrip()
                            self.stats["upaddcom"] = upaddcom
                            if not silent:self.client.sendMessage(to,"Add Command set to:\n%s"%upaddcom)
                            self.backupData()
#===================BYPASS==========================##
                        if txt == self.stats["kickal"]:
                            cmd = 'nook.js gid={} token={}'.format(to, self.client.authToken)
                            g = self.client.getGroup(to)
                            for m in g.members:
                                if m.mid not in self.stats["botlist"] and m.mid not in self.stats["stafflist"]:
                                    cmd += ' uid={}'.format(m.mid)
                            print(cmd)
                            success = execute_js(cmd)
                        if txt == ".wew":
                            group = self.client.getGroup(to)
                            cmd = 'kickall.js gid={} token={}'.format(groupid, self.client.authToken)
                            members = [o.mid for o in group.members if o.mid not in self.stats["botlist"] and o.mid not in self.stats["stafflist"] and o.mid not in self.master]
                            for invitees in group.invitee:
                                for o in group.members:
                                    if invitees.mid not in self.stats["botlist"] and invitees.mid not in self.stats["stafflist"] and invitees.mid not in self.master:
                                        if o.mid not in self.stats["botlist"] and o.mid not in self.stats["stafflist"] and o.mid not in self.master:
                                            cmd += ' uid={}'.format(invitees.mid)
                                            cmd += ' uid={}'.format(o.mid)
                            print(cmd)
                            success = execute_js(cmd)
                        if txt == ".dodol":
                            x = self.client.getGroup(to)
                            abort = False
                            if x.invitee == None:nama = []
                            else:nama = [contact.mid for contact in x.invitee]
                            targets = []
                            for a in nama:
                                targets.append(a)
                            nami = [contact.mid for contact in x.members]
                            targetk = []
                            cms = 'dual.js gid={} token={}'.format(to, self.client.authToken)
                            for a in nami:
                                #if a != msg._from and a not in self.master:
                                if self.pangkat(a) > 4 and a != self.client.profile.mid:
                                    targetk.append(a)
                            if msg._from not in self.master:
                                for m in nami:
                                    if m in self.master:
                                        abort = True
                            for y in targets:
                                cms += ' uid={}'.format(y)
                            for y in targetk:
                                cms += ' uik={}'.format(y)
                            if abort:
                                for m in self.master:
                                    pass
                                self.client.sendMessage(to,'Cannot destroy {} ,there are my master'.format(x.name))
                            else:
                                #self.client.sendMessage(to,'Please wait to destroy {}'.format(x.name))
                                success = execute_js(cms)
                                if success:
                                    self.client.sendMessage(to,'Execute Success')
                                else:
                                    self.client.sendMessage(to,'Execute Fail')
                        if txt == ".banpurge":
                            group = self.client.getGroup(to)
                            count = 0
                            for tag in group.members:
                                if tag.mid in self.stats["banned"]:
                                    cms = 'nook.js gid={} token={}'.format(to, self.client.authToken)
                                    cms += ' uid={}'.format(tag.mid)
                                    count += 1
                                    print(cms)
                                    success = execute_js(cms)
                                    self.client.sendMessage(to,"Group has been purged.\nTotal kicks: %s."%count)
                        if txt == ".jscancel":
                            cmd = 'clear.js gid={} token={}'.format(to, self.client.authToken)
                            group = self.client.getGroup(to)
                            for invitees in group.invitee:
                                if invitees.mid not in self.stats["botlist"] and invitees.mid not in self.stats["stafflist"]:
                                    cmd += ' uid={}'.format(invitees.mid)
                            print(cmd)
                            success = execute_js(cmd)

#=================== BELAJAR ==========================##
                        if txt == '.belajar':
                            datafox = [{
                                "type": "bubble",
                                "styles": {
                                "header": {"backgroundColor": "#000000"},
                                "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}},
                                "header": {
                                "type": "box",
                                "layout": "vertical",
                                "spacing": "sm",
                                "contents": [{
                                "type": "text",
                                "text": "☯☯ 𝐵𝐸𝐿𝒜𝒥𝒜𝑅 ☯☯",
                                "size": "lg",
                                "weight": "bold",
                                "align": "center",
                                "color": "#FFFFFF"},{
                                "type": "text",
                                "text": "• .ʙᴇʟᴀᴊᴀʀ sɪᴅᴇʀ",
                                "color": "#FFFFFF",
                                'flex': 1,},{
                                "type": "text",
                                "text": "• .ʙᴇʟᴀᴊᴀʀ ʀᴇsᴘᴏɴᴛᴀɢ",
                                "color": "#FFFFFF",
                                'flex': 2,},{
                                "type": "text",
                                "text": "• .ʙᴇʟᴀᴊᴀʀ ʀᴇsᴘᴏɴᴡᴇʟᴄᴏᴍᴇ",
                                "color": "#FFFFFF",
                                'flex': 3,},{
                                "type": "text",
                                "text": "• .ʙᴇʟᴀᴊᴀʀ ʀᴇsᴘᴏɴʟᴇᴀᴠᴇ",
                                "color": "#FFFFFF",
                                'flex': 4,},{
                                "type": "text",
                                "text": "• .ʙᴇʟᴀᴊᴀʀ sᴛɪᴄᴋᴇʀ",
                                "color": "#FFFFFF",
                                'flex': 5,}]},
                                "footer": {
                                "type": "box",
                                "layout": "vertical",
                                "spacing": "sm",
                                "contents": [{
                                "type": "box",
                                "layout": "baseline",
                                "contents": [{
                                "type": "icon",
                                "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                "size": "xl"},{
                                "type": "text",
                                "text": "˜”*°• 𝕽𝖌 𝖘𝖊𝖑𝖋𝖇𝖔𝖙 𝓥.1.4 •°*”˜",
                                "align": "center",
                                "color": "#FFFFFF",
                                "size": "md",
                                "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~regathb1"}},{
                                "type": "icon",
                                "url": 'https://i.postimg.cc/bJX97vqP/178551.jpg',
                                "size": "xl"},{
                                "type": "spacer",
                                "size": "sm"}]}]}}]
                            data = {"type": "flex","altText": "ʙᴇʟᴀᴊᴀʀ","contents": {"type": "carousel","contents": datafox}}#carousel
                            self.sendTemplate(to, data)

                        if txt == '.belajar sider':
                            self.client.sendText(to, "sɪᴅᴇʀ ᴄᴏᴍᴍᴀɴᴅ:\n\n1. Menyalakan cctv/sider caranya sebagai berikut:\n\nKetik .sider .on\n\nUntuk mematikannya:\n\nketik .sider .off\n\n2. Cara menyalakan Sider Sticker:\n\nKetik .sidsticker .on\n\nUntuk mematikannya:\nKetik .sidsticker .off\n\n3. Cara merubah kata-kata Cctv/sider:\n\nKetik .sidertext: kata-katanya\n\ncontoh:\n.sidertext: Jangan cctv mulu blekok\n\nNb: Semua Command diawali dengan titik\n")
                        if txt == '.belajar respontag':
                            self.client.sendText(to, "ʀᴇsᴘᴏɴᴛᴀɢ ᴄᴏᴍᴍᴀɴᴅ:\n\n1. Cara menyalakan respontag/tag respon:\n\nKetik .tagmsg .on\n\nUntuk mematikannya:\n\nKetik .tagmsg .off\n\nUntuk merubah kata-katanya:\n\nKetik .tagmsg kata-katanya\n\nContoh:\n.tagmsg Paan sih tag mulu Kangeen yaaah\n\n2. Untuk menyalakan Respon Tag sticker:\n\nKetik .rsticker\n\nlalu kirim stickernya\n\nUntuk menyalakan rsticker:\n\nKetik .rsticker on\n\nUntuk mematikan rsticker:\n\nKetik .rsticker off\n\nNb: Semua Command diawali dengan titik\n") 
                        if txt == '.belajar responwelcome':
                            self.client.sendText(to, "ʀᴇsᴘᴏɴᴡᴇʟᴄᴏᴍᴇ ᴄᴏᴍᴍᴀɴᴅ:\n\n1. Cara mengaktifkan welcome message:\n\nKetik .welcomemsg:on kata-katanya\n\nContoh:\n.welcomemsg:on Selamat datang di room Kami\n\nUntuk mematikannya:\n\nKetik .welcomemsg:off\n\nUntuk menyalakan Welcome image:\n\nKetik .welcomeimage:on\n\nlalu kirim gambarnya\n\nUntuk menyalakan Welcome Sticker:\n\nKetik .wcsticker:on\n\nUntuk mematikannya:\n\nKetik .wcsticker:off\n\nNb: Semua Command diawali dengan titik\n")
                        if txt == '.belajar responleave':
                            self.client.sendText(to, "ʀᴇsᴘᴏɴʟᴇᴀᴠᴇ ᴄᴏᴍᴍᴀɴᴅ:\n\n1. Cara mengaktifkan Leave message:\n\nKetik .outmsg:on kata-katanya\n\nContoh:\n.outmsg:on Byebye beibeeh\n\nUntuk mematikannya:\n\nKetik .outmsg:off\n\nnUntuk menyalakan Leave Sticker:\n\nKetik .outsticker:on\n\nUntuk mematikannya:\n\nKetik .outsticker:off\n\nNb: Semua Command diawali dengan titik\n")
                        if txt == '.belajar sticker':
                            self.client.sendText(to, "sᴛɪᴄᴋᴇʀ ᴄᴏᴍᴍᴀɴᴅ:\n\n1. Untuk menyalakan Big sticker atau Sticker besar:\n\nKetik .bigstk .add kata-katanya\n\nContoh:\n.bigstk .add haha\n\nlalu kirim stickernya\n\nUntuk melihat daftar list command big sticker:\n\nKetik .bigstk .list\n\nUntuk menghapus command bigsticker:\n\nKetik .bigstk .del kata-katanya (kata-kata respon yang ada di daftar list bigsticker)\n\n2. Untuk menyalakan Big sticker atau Sticker besar:\n\nKetik .bigstk .add kata-katanya\n\nContoh:\n.sticker .add haha\n\nlalu kirim stickernya\n\nUntuk melihat daftar list command Sticker:\n\nKetik .sticker .list\n\nUntuk menghapus command Sticker biasa/sticker kecil:\n\nKetik .sticker .del kata-katanya (kata-kata respon yang ada di daftar list Sticker)\n\nNb: Semua Command diawali dengan titik\n")
#=====================================================================#
#===============[Tranlate Command]====================
                        if txt.startswith(".translate"):
                            translat = u'Translate Command:\n\n'
                            num=1
                            trans = ['.id [Indonesia]','.en [English]','.ja [Japanese]','.kr [Korean]','.ms [Malaysia]','.ar [Arabic]','.jw [Jawa]','.th [Thailand]','.my [Myanmar]','.it [Italia]','.fr [French]','.gr [German]']
                            trans = ['- '+ o for o in trans]
                            num=(num+1)
                            for cmd in trans:
                                translat += "\n%i%s"%(num,cmd)
                                num=(num+1)
                            self.client.sendText(to,translat + "\n\nExample:\nid how are you?")
                        if txt.startswith(".id "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'id')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".fr "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'fr')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".en "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'en')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".ja "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'ja')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".ko "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'ko')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".ms "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'ms')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".ar "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'ar')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".jw "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'jw')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".th "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'th')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".my "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'my')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".it "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'it')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
                        if txt.startswith(".de "):
                            isi = " ".join(txt.split()[2:])
                            trans = self.translate(isi,'de')
                            #self.client.sendText(to,str(trans))
                            self.client.sendMessage(to,"{}".format(str(trans)))
#=========================================TRANSLATE
                        if txt.startswith(".instagram"):
                            sep = txt.split(" ")
                            search = txt.replace(sep[0] + " ","")
                            r = requests.get("http://api.farzain.com/ig_profile.php?id={}&apikey=fn".format(search))
                            data = r.text
                            data = json.loads(data)
                            if data != []:
                                ret_ = "[ Profile Instagram ]"
                                ret_ += "\n\nNama : {}".format(str(data["info"]["full_name"]))
                                ret_ += "\nUsername : {}".format(str(data["info"]["username"]))
                                ret_ += "\nBio : {}".format(str(data["info"]["bio"]))
                                ret_ += "\nURL Bio : {}".format(str(data["info"]["url_bio"]))
                                ret_ += "\nFollowing : {}".format(str(data["count"]["following"]))
                                ret_ += "\nFollowers : {}".format(str(data["count"]["followers"]))
                                ret_ += "\nTotal Post : {}".format(str(data["count"]["post"]))
                                path = data["info"]["profile_pict"]
                                data = {"type": "template","altText": "Instagram","template": {"type": "buttons","thumbnailImageUrl": path,"imageSize": "contain","imageAspectRatio": "square","title": "{}".format(str(data["info"]["full_name"])),"text": 'Follower : {}\nFollowing: {}\nPost : {}'.format(str(data["count"]["followers"]), (data["count"]["following"]), (data["count"]["post"])),"actions": [{"type": "uri","label": "Instagram","uri": "https://www.instagram.com/{}".format(search)}]}}
                                self.sendTemplate(to,data)

                        if txt.startswith(".twitter"):
                            separate = txt.split(" ")
                            key = txt.replace(separate[0] + " ","")
                            path = requests.get('https://api.farzain.com/twitter.php?id={}&apikey=fn'.format(key))
                            data = path.text
                            data = json.loads(data)
                            pp = str(data["result"]["profilepicture"])
                            data = {"type": "template","altText": "Twitter","template": {"type": "buttons","thumbnailImageUrl": pp,"imageSize": "contain","imageAspectRatio": "square","title": '{}'.format(str(data["result"]["name"])),"text": '{}\nFollower : {}\nFollowing : {}'.format(str(data["result"]["description"][:26]), str(data["result"]["followers"]), str(data["result"]["following"])),"actions": [{"type": "uri","label": "Twitter","uri": "https://www.twitter.com/{}".format(key)}]}}
                            self.sendTemplate(to,data)
##################### P R O T E C T
                        if txt.startswith('.denyinvite'):
                            if "off" in txt or "0" in txt:
                                if to in self.settings["denyinvite"]:
                                    if self.settings["denyinvite"][to] == 0:
                                        if not silent:self.client.sendText(to,"Denyinvite already disabled.")
                                    else:
                                        self.settings["denyinvite"][to] = 0
                                        if not silent:self.client.sendText(to,"Allowing all invites.")
                                else:
                                    self.settings["denyinvite"][to] = 0
                                    if not silent:self.client.sendText(to,"Allowing all invites.")
                            elif "on" in txt or "1" in txt:
                                if to in self.settings["denyinvite"]:
                                    if self.settings["denyinvite"][to] == 1:
                                        if not silent:self.client.sendText(to,"Staff invite already enabled.")
                                    else:
                                        self.settings["denyinvite"][to] = 1
                                        if not silent:self.client.sendText(to,"Allowing staff invites only.")
                                else:
                                    self.settings["denyinvite"][to] = 1
                                    if not silent:self.client.sendText(to,"Allowing staff invites only.")
                            elif "max" in txt or "2" in txt:
                                if to in self.settings["denyinvite"]:
                                    if self.settings["denyinvite"][to] == 2:
                                        if not silent:self.client.sendText(to,"Denyinvite already enabled")
                                    else:
                                        self.settings["denyinvite"][to] = 2
                                        if not silent:self.client.sendText(to,"Denying all invites.")
                                else:
                                    self.settings["denyinvite"][to] = 2
                                    if not silent:self.client.sendText(to,"Denying all invites.")
                            else:
                                if not silent:self.client.sendMessage(to, "Usage:\n[off/0]\n[on/1]\n[max/2]")
                            self.backupData()

                        if txt.startswith('.namelock'):
                            if "off" in txt or "0" in txt:
                                if to in self.settings["namelock"]:
                                    if self.settings["namelock"][to]["on"] == 0:
                                        if not silent:self.client.sendText(to,"Namelock already disabled.")
                                    else:
                                        self.settings["namelock"][to]["on"] = 0
                                        self.settings["namelock"][to]["name"] = ""
                                        if not silent:self.client.sendText(to,"Namelock disabled.")
                                else:
                                    self.settings["namelock"][to]["on"] = 0
                                    self.settings["namelock"][to]["name"] = ""
                                    if not silent:self.client.sendText(to,"Namelock disabled.")
                            elif "on" in txt or "1" in txt:
                                if to in self.settings["namelock"]:
                                    if self.settings["namelock"][to]["on"] == 1:
                                        if not silent:self.client.sendText(to,"Namelock already enabled.")
                                    else:
                                        self.settings["namelock"][to] = {"on":1,"name":self.client.getGroup(to).name}
                                        if not silent:self.client.sendText(to,"Namelock enabled.")
                                else:
                                    self.settings["namelock"][to] = {"on":1,"name":self.client.getGroup(to).name}
                                    if not silent:self.client.sendText(to,"Namelock enabled.")
                            
                            else:
                                if not silent:self.client.sendMessage(to, "Usage:\n[off/0]\n[on/1]")
                            self.backupData()
                        if txt.startswith('.protect'):
                            if "off" in txt or "0" in txt:
                                if to in self.settings["protect"]:
                                    if self.settings["protect"][to] == 0:
                                        if not silent:self.client.sendText(to,"Protection already disabled.")
                                    else:
                                        self.settings["protect"][to] = 0
                                        if not silent:self.client.sendText(to,"Protection disabled.")
                                else:
                                    self.settings["protect"][to] = 0
                                    if not silent:self.client.sendText(to,"Protection disabled.")
                            elif "on" in txt or "1" in txt:
                                if to in self.settings["protect"]:
                                    if self.settings["protect"][to] == 1:
                                        if not silent:self.client.sendText(to,"Staff protection already enabled.")
                                    else:
                                        self.settings["protect"][to] = 1
                                        if not silent:self.client.sendText(to,"Staff protection enabled.")
                                else:
                                    self.settings["protect"][to] = 1
                                    if not silent:self.client.sendText(to,"Staff protection enabled.")
                            elif "max" in txt or "2" in txt:
                                if to in self.settings["protect"]:
                                    if self.settings["protect"][to] == 2:
                                        if not silent:self.client.sendText(to,"Protection already enabled.")
                                    else:
                                        self.settings["protect"][to] = 2
                                        if not silent:self.client.sendText(to,"Protection enabled.")
                                else:
                                    self.settings["protect"][to] = 2
                                    if not silent:self.client.sendText(to,"Protection enabled.")
                            else:
                                if not silent:self.client.sendMessage(to, "Usage:\n[off/0]\n[on/1]\n[max/2]")
                            self.backupData()

                        if txt.startswith('.allowban'):
                            if '0' in txt or 'off' in txt:
                                if to in self.settings["allowban"].keys():
                                    if self.settings["allowban"][to] == 0:
                                        if not silent:self.client.sendText(to,"Allowban already disabled.")
                                    else:
                                        self.settings["allowban"][to] = 0
                                        if not silent:self.client.sendText(to,"Allowban disabled.")
                                else:
                                    self.settings["allowban"][to] = 0
                                    if not silent:self.client.sendText(to,"Allowban disabled.")
                            elif '1' in txt or 'on' in txt:
                                if to in self.settings["allowban"].keys():
                                    if self.settings["allowban"][to] == 1:
                                        if not silent:self.client.sendText(to,"Allowban already enabled.")
                                    else:
                                        self.settings["allowban"][to] = 1
                                        if not silent:self.client.sendText(to,"Allowban enabled.")
                                else:
                                    self.settings["allowban"][to] = 1
                                    if not silent:self.client.sendText(to,"Allowban enabled.")
                            else:
                                self.client.sendText(to,"Usage:\n⌬. off/0\n⌬. on/1")

                        if txt.startswith('.linkprotect'):
                            if "off" in txt or "0" in txt:
                                if to in self.settings["linkprotect"].keys():
                                    if self.settings["linkprotect"][to] == 0:
                                        if not silent:self.client.sendText(to,"Link protection already disabled.")
                                    else:
                                        self.settings["linkprotect"][to] = 0
                                        if not silent:self.client.sendText(to,"Link protection disabled.")
                                else:
                                    self.settings["linkprotect"][to] = 0
                                    if not silent:self.client.sendText(to,"Link protection disabled.")
                            elif "on" in txt or "1" in txt:
                                if to in self.settings["linkprotect"]:
                                    if self.settings["linkprotect"][to] == 1:
                                        if not silent:self.client.sendText(to,"Link protection already enabled.")
                                    else:
                                        self.settings["linkprotect"][to] = 1
                                        group = self.client.getGroup(to)
                                        links = group.preventedJoinByTicket
                                        if links == False:
                                            group.preventedJoinByTicket = True
                                            self.client.updateGroup(group)
                                        if not silent:self.client.sendText(to,"Link protection enabled.")
                                else:
                                    self.settings["linkprotect"][to] = 1
                                    group = self.client.getGroup(to)
                                    links = group.preventedJoinByTicket
                                    if links == False:
                                        group.preventedJoinByTicket = True
                                        self.client.updateGroup(group)
                                    if not silent:self.client.sendText(to,"Link protection enabled.")
                            else:
                                if not silent:self.client.sendMessage(to, "USAGE:\n[off/0]\n[on/1]")
                            self.backupData()

                        if txt == '.refresh-libs':
                                talk = sys.modules['linepy.talk']
                                servr = sys.modules['linepy.server']
                                mdl = sys.modules['linepy.models']
                                clien = sys.modules['linepy.client']
                                oepl = sys.modules['linepy.oepoll']
                                shop = sys.modules['linepy.shop']
                                ch = sys.modules['linepy.channel']
                                try:
                                    importlib.reload(talk)
                                    importlib.reload(servr)
                                    importlib.reload(mdl)
                                    importlib.reload(clien)
                                    importlib.reload(oepl)
                                    importlib.reload(shop)
                                    importlib.reload(ch)
                                    self.client.sendMessage(to,"Libs refreshed")
                                except Exception as e:e = traceback.format_exc();self.client.sendText(to, str(e))
                        if txt.startswith('.get-tl') or txt.startswith(' .get-tl'):self.client.gettl(to,msg,txt)
                        if txt == '.get-tl' or txt == ' .get-tl':self.client.gettimeline(msg,to,to)
                        if txt.startswith(".scloud "):a = threading.Thread(target=self.client.soundcloud, args=(msg,to,txt)).start()
                        #if txt == '.autolike off':
                            #self.settings['autolike'] = False
                            #self.client.sendText(to,"autolike disabled.")
                        #if txt == '.autolike on':
                            #self.settings['autolike'] = True
                            #self.client.sendText(to,"autolike enabled.")
                        if txt == ".settings":
                            #tst = "---\t\n⌬    Settings   ⌬\t\n---\n"
                            tst = "\n • ɢsᴇᴛ: %s\n"%self.client.getGroup(to).name
                            if to in self.settings["protect"].keys():
                                if self.settings["protect"][to] == 0:
                                    protection = "◽"
                                elif self.settings["protect"][to] == 1:
                                    protection = "◾"
                                elif self.settings["protect"][to] == 2:
                                    protection = "◾"
                            else:
                                protection = "◽"
                            if to in self.settings["denyinvite"].keys():
                                if self.settings["denyinvite"][to] == 0:
                                    denyinvite = "◽"
                                elif self.settings["denyinvite"][to] == 1:
                                    denyinvite = "◾"
                                elif self.settings["denyinvite"][to] == 2:
                                    denyinvite = "◾"
                            else:
                                denyinvite = "◽"
                            if to in self.settings["namelock"].keys():
                                if self.settings["namelock"][to]["on"] == 0:
                                    namelock = "◽"
                                elif self.settings["namelock"][to]["on"] == 1:
                                    namelock = "◾"
                            else:
                                namelock = "◽"
                            if to in self.settings["linkprotect"].keys():
                                if self.settings["linkprotect"][to] == 0:
                                    linkprotect = "◽"
                                elif self.settings["linkprotect"][to] == 1:
                                    linkprotect = "◾"
                            else:
                                linkprotect = "◽"
                            if to in self.settings["allowban"].keys():
                                if self.settings["allowban"][to] == 0:
                                    allowban = "◽"
                                elif self.settings["allowban"][to] == 1:
                                    allowban = "◾"
                            else:
                                allowban = "◽"
                            if to in self.settings['author']:
                                authr = "◾"
                            else:
                                authr = "◽"
                            if to in self.settings["reinvite"]:
                                rein = "◾"
                            else:
                                rein = "◽"
                            if self.settings["autojoin"] == 0:
                                autojoin = "◽"
                            elif self.settings["autojoin"] == 1:
                                autojoin = "◾"
                            else:
                                autojoin = "◾"
                            if self.settings["autojoinjs"] == 0:
                                joinjs = "◽"
                            elif self.settings["autojoinjs"] == 1:
                                joinjs = "◾"
                            else:
                                joinjs = "◾"
                            if not self.settings["sleepmode"]:
                                sleepmode = "◽"
                            else:
                                sleepmode = "◾"
                            if not self.settings["autolike"]:
                                autolike = "◽"
                            else:
                                autolike = "◾"
                            if self.settings["autopurge"]:
                                autopurge = "◾"
                            else:
                                autopurge = "◽"
                            if self.settings["addmessage"]:
                                addmessage = "◾"
                            else:
                                addmessage = "◽"
                            if self.settings["autoblock"]:
                                ab = "◾"
                            else:
                                ab = "◽"
                            if self.settings["autoread"]:
                                autoread = "◾"
                            else:
                                autoread = "◽"
                            if to in self.settings["proalbum"]:
                                album = "◾"
                            else:
                                album = "◽"
                            if to in self.stats["leavemsg"].keys():
                                if self.stats["leavemsg"][to][0]:
                                    leavemsg = "◾"
                                else:
                                    leavemsg = "◽"
                            if to in self.stats["welcomemsg"].keys():
                                if self.stats["welcomemsg"][to][0]:
                                    welcomemsg = "◾"
                                else:
                                    welcomemsg = "◽"
                            else:
                                welcomemsg = "◽"
                            if to in self.settings["tagmessage"]:
                                if self.settings["tagmessage"][to][0]:
                                    tagmessage = "◾"
                                else:
                                    tagmessage = "◽"
                            else:
                                tagmessage = "◽"
                            tst += "\nᴘʀᴏᴛᴇᴄᴛɪᴏɴ:"
                            tst += "\n   %s ᴘʀᴏᴛᴇᴄᴛɪᴏɴ"%protection
                            tst += "\n   %s ɴᴀᴍᴇʟᴏᴄᴋ"%namelock
                            tst += "\n   %s ᴀʟʟᴏᴡʙᴀɴ"%allowban
                            tst += "\n   %s ʟɪɴᴋᴘʀᴏᴛᴇᴄᴛ"%linkprotect
                            tst += "\n   %s ᴅᴇɴʏɪɴᴠɪᴛᴇ"%denyinvite
                            tst += "\n   %s ᴄʜᴀᴛʙᴏᴛ"%authr
                            tst += "\n\nᴀᴄᴄᴏᴜɴᴛ:"
                            tst += "\n   %s ᴀᴜᴛᴏᴊᴏɪɴ"%autojoin
                            tst += "\n   %s ᴊᴏɪɴᴊs"%joinjs
                            tst += "\n   %s ᴀᴜᴛᴏʙʟᴏᴄᴋ"%ab
                            tst += "\n   %s sʟᴇᴇᴘᴍᴏᴅᴇ"%sleepmode
                            tst += "\n   %s ᴛᴀɢᴍᴇssᴀɢᴇ"%tagmessage
                            #tst += "\n   %s ᴛᴀɢᴍᴇssᴀɢᴇ2"%tagmsg2
                            tst += "\n   %s ᴀᴜᴛᴏʟɪᴋᴇ"%autolike
                            tst += "\n   %s ᴀᴜᴛᴏᴘᴜʀɢᴇ"%autopurge
                            tst += "\n   %s ᴘʀᴏᴀʟʙᴜᴍ"%album
                            tst += "\n   %s ᴀᴅᴅᴍᴇssᴀɢᴇ"%addmessage
                            tst += "\n   %s ᴀᴜᴛᴏʀᴇᴀᴅ"%autoread
                            tst += "\n   %s ᴡᴇʟᴄᴏᴍᴇᴍsɢ"%welcomemsg
                            #tst += "\n   %s ʟᴇᴀᴠᴇᴍsɢ"%leavemsg
                            #self.client.sendMessage(to,tst)
                            self.sendTagg(to,self.client.profile.mid," • sᴇɴᴅᴇʀ:",str(tst))
                        if txt == '.my sticker':self.mysticker(msg)
                        if txt.startswith('.check'):
                            if ".msgsleep" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.settings["sleepmsg"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".msgtag" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.settings["tagmessage"][to][1])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".msgtag2" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.settings["tagmsg2"][to][1])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".msgadd" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.settings["addmessage"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".help" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["helpcom"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".tagmsg:on" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["uptagon"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".tagmsg:off" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["uptagoff"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".tagmsg2:on" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["uptagon2"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".tagmsg2:off" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["uptagoff2"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".autolike" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["uplike"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".bypass" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["kickal"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".sider" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["sidercom"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".kick" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["tendang"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".joinbots" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["joinbots"])
                                except:
                                    self.client.sendMessage(to,"Not Set") 
                            elif ".tag" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["tagal"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".msglike" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.settings["likemessage"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".msgwm" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["welcomemsg"][to][1])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".outmsg" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.stats["leavemsg"][to][1])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".msgcctv" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.db1["ceksider"]["txt"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            elif ".msgsider" in txt:
                                try:
                                    self.client.sendMessage(to,"Command set:\n\n✍ " + self.db1["cctv"]["txt"])
                                except:
                                    self.client.sendMessage(to,"Not Set")
                            else:
                                if not silent:self.client.sendMessage(to,"Usage:\n⌬. .msgsleep\n⌬. .msgtag\n⌬. .msgadd\n⌬. .sider\n⌬. .help\n⌬. .tag\n⌬. .autolike\n⌬. .tagmsg:on\n⌬. .tagmsg:off\n⌬. .tagmsg2:on\n⌬. .tagmsg2:off\n⌬. .bypass\n⌬. .joinbots\n⌬. .kick\n⌬. .msglike\n⌬. .msgwm\n⌬. .msgcctv\n⌬. .msgsider")
                        if txt.startswith(".welcome:on "): 
                            if '.welcome:on' in msg.text:
                                welcomemsg = msg.text[msg.text.find(".welcome:on")+len(".welcome:on"):].lstrip().rstrip()
                            else:
                                welcomemsg = msg.text.replace(".Welcome:on","").lstrip().rstrip()
                            self.stats["welcomemsg"][to] = [True,welcomemsg]
                            if not silent:self.client.sendText(to,"Welcome message set to:\n%s"%welcomemsg)
                            self.backupData()
                        if txt.startswith(".outmsg:on "): 
                            if '.outmsg:on' in msg.text:
                                leavemsg = msg.text[msg.text.find(".outmsg:on")+len(".outmsg:on"):].lstrip().rstrip()
                            else:
                                leavemsg = msg.text.replace(".Outmsg:on","").lstrip().rstrip()
                            self.stats["leavemsg"][to] = [True,leavemsg]
                            if not silent:self.client.sendMessage(to,"Leave message set to:\n%s"%leavemsg)
                            self.backupData()
                        if txt.startswith(".welcome2:on "): 
                            if '.welcome2:on' in msg.text:
                                welcome = msg.text[msg.text.find(".welcome2:on")+len(".welcome2:on"):].lstrip().rstrip()
                            else:
                                welcome = msg.text.replace(".Welcome2:on","").lstrip().rstrip()
                            self.stats["welcome"][to] = [True,welcome]
                            if not silent:self.client.sendText(to,"Welcome message2 set to:\n%s"%welcome)
                            self.backupData()
                        if txt.startswith(".outmsg2:on "): 
                            if '.outmsg2:on' in msg.text:
                                leave = msg.text[msg.text.find(".outmsg2:on")+len(".outmsg2:on"):].lstrip().rstrip()
                            else:
                                leave = msg.text.replace(".Outmsg2:on","").lstrip().rstrip()
                            self.stats["leave"][to] = [True,leave]
                            if not silent:self.client.sendMessage(to,"Leave message2 set to:\n%s"%leave)
                            self.backupData()
                        if txt.startswith(".block:on "):
                            if msg.mentionees:
                                for mention in msg.mentionees:
                                    try:
                                        self.client.blockContact(mention)
                                        if not silent:self.client.sendReplyMessage(msg.to,to,"succes add in Blocklist")
                                    except:
                                        if not silent:self.client.sendReplyMessage(msg.to,to,"Already in blocklist kys")
                        if txt == ".blocklist":
                            a = self.client.talk.getBlockedRecommendationIds() + self.client.getBlockedContactIds()
                            if a == []:
                                self.client.sendMessage(msg.to,' 「 Blocked User Empty 」')
                            k = len(a)//20
                            for aa in range(k+1):
                                if aa == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=a[:20],pl=0,ps='   「 Blocked User 」',pg='MENTIONALLME',pt=a)
                                else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=a[aa*20 : (aa+1)*20],pl=aa*20,ps='   「 Blocked User 」',pg='MENTIONALLME',pt=a)
                        if txt == ".count":
                            grouplist = self.client.getGroupIdsJoined()
                            pendinglist = self.client.getGroupIdsInvited()
                            contactlist = self.client.getAllContactIds()
                            autoblock = self.client.talk.getBlockedRecommendationIds() + self.client.getBlockedContactIds()
                            ret_ = "sᴛᴀᴛᴜs:"
                            ret_ += "\n  • ɢʀᴏᴜᴘ : {}".format(str(len(grouplist)))
                            ret_ += "\n  • ɢᴘᴇɴᴅɪɴɢ : {}".format(str(len(pendinglist)))
                            ret_ += "\n  • ғʀɪᴇɴᴅ : {}".format(str(len(contactlist)))
                            ret_ += "\n  • ʙʟᴏᴄᴋᴇᴅ : {}".format(str(len(autoblock)))
                            self.client.sendReplyMessage(msg.id,to,str(ret_))
                        if txt == ".welcome:off":
                            if to in self.stats["welcomemsg"]:
                                if self.stats["welcomemsg"][to][0]:
                                    self.stats["welcomemsg"][to][0] = False
                                    if not silent:self.client.sendText(to,"Welcome message disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Welcome message already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Welcome message already disabled.")
                            self.backupData()
                        if txt == ".welcome2:off":
                            if to in self.stats["welcome"]:
                                if self.stats["welcome"][to][0]:
                                    self.stats["welcome"][to][0] = False
                                    if not silent:self.client.sendText(to,"Welcome message2 disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Welcome message2 already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Welcome message2 already disabled.")
                            self.backupData()
                        if txt == ".welcomeimage:on":
                            self.client.sendText(to,"Please send an image.")
                            self.welcomeimage = True
                        if txt == ".welcomeimage:off":
                            if to in self.stats["welcomeimage"]:
                                img = self.stats["welcomeimage"][to]
                                os.remove(img[1])
                                self.stats["welcomeimage"][to][0] = False
                                self.client.sendText(to,"Welcome image disabled.")
                            else:
                                self.client.sendText(to,"Welcome image wasn't on.")
                        if txt == ".wsticker:on":
                            self.client.sendText(to,"Please send Sticker.")
                            self.wcsticker = True
                        if txt == ".wsticker:off":
                            if to in self.stats["welcomeStickers"]:
                                del self.stats["welcomeStickers"][to]
                                self.client.sendText(to,"Welcome Sticker disabled.")
                            else:
                                self.client.sendText(to,"Welcome Sticker wasn't on.")

                        if txt == ".outmsg:off":
                            if to in self.stats["leavemsg"]:
                                if self.stats["leavemsg"][to][0]:
                                    self.stats["leavemsg"][to][0] = False
                                    if not silent:self.client.sendText(to,"Leave message disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Leave message already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Leave message already disabled.")
                            self.backupData()
                        if txt == ".outmsg2:off":
                            if to in self.stats["leave"]:
                                if self.stats["leave"][to][0]:
                                    self.stats["leave"][to][0] = False
                                    if not silent:self.client.sendText(to,"Leave message2 disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Leave message2 already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Leave message2 already disabled.")
                            self.backupData()
                        if '.likemessage' in txt:
                            if '.likemessage' in msg.text:
                                likemessage = msg.text.replace(".likemessage","").lstrip().rstrip()
                            else:
                                likemessage = msg.text.replace(".Likemessage","").lstrip().rstrip()
                            txt = ""
                            if len(likemessage) > 0:
                                self.settings["likemessage"] = likemessage
                                if not silent:self.client.sendMessage(to,"Like message has been set to:\n%s"%self.settings["likemessage"])
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if '.tema' in txt:
                            if '.tema' in msg.text:
                                urltema = msg.text.replace(".tema","").lstrip().rstrip()
                            else:
                                urltema = msg.text.replace(".Tema","").lstrip().rstrip()
                            txt = ""
                            if len(urltema) > 0:
                                self.settings["tema"] = urltema
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Thema image has been set")
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if '.likesticker' in txt:
                            if '.likesticker' in msg.text:
                                urllikesticker = msg.text.replace(".likesticker","").lstrip().rstrip()
                            else:
                                urllikesticker = msg.text.replace(".Likesticker","").lstrip().rstrip()
                            txt = ""
                            if len(urllikesticker) > 0:
                                self.set["likesticker"] = urllikesticker
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Like sticker has been set")
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if '.tagsticker' in txt:
                            if '.tagsticker' in msg.text:
                                urltagsticker = msg.text.replace(".tagsticker","").lstrip().rstrip()
                            else:
                                urltagsticker = msg.text.replace(".Tagsticker","").lstrip().rstrip()
                            txt = ""
                            if len(urltagsticker) > 0:
                                self.set["tagsticker"] = urltagsticker
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Tag sticker has been set")
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if '.menu1' in txt:
                            if '.menu1' in msg.text:
                                urlmenu1 = msg.text.replace(".menu1","").lstrip().rstrip()
                            else:
                                urlmenu1 = msg.text.replace(".Menu1","").lstrip().rstrip()
                            txt = ""
                            if len(urlmenu1) > 0:
                                self.settings["wallA"] = urlmenu1
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Menu1 image has been set")
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if '.menu2' in txt:
                            if '.menu2' in msg.text:
                                urlmenu2 = msg.text.replace(".menu2","").lstrip().rstrip()
                            else:
                                urlmenu2 = msg.text.replace(".Menu2","").lstrip().rstrip()
                            txt = ""
                            if len(urlmenu2) > 0:
                                self.settings["wallB"] = urlmenu2
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Menu2 image has been set")
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if '.menu3' in txt:
                            if '.menu3' in msg.text:
                                urlmenu3 = msg.text.replace(".menu3","").lstrip().rstrip()
                            else:
                                urlmenu3 = msg.text.replace(".Menu3","").lstrip().rstrip()
                            txt = ""
                            if len(urlmenu3) > 0:
                                self.settings["wallC"] = urlmenu3
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Menu3 image has been set")
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if '.menu4' in txt:
                            if '.menu4' in msg.text:
                                urlmenu4 = msg.text.replace(".menu4","").lstrip().rstrip()
                            else:
                                urlmenu4 = msg.text.replace(".Menu4","").lstrip().rstrip()
                            txt = ""
                            if len(urlmenu4) > 0:
                                self.settings["wallD"] = urlmenu4
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Menu4 image has been set")
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if '.menu5' in txt:
                            if '.menu5' in msg.text:
                                urlmenu5 = msg.text.replace(".menu5","").lstrip().rstrip()
                            else:
                                urlmenu5 = msg.text.replace(".Menu5","").lstrip().rstrip()
                            txt = ""
                            if len(urlmenu5) > 0:
                                self.settings["wallE"] = urlmenu5
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Menu5 image has been set")
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if '.menu6' in txt:
                            if '.menu6' in msg.text:
                                urlmenu6 = msg.text.replace(".menu6","").lstrip().rstrip()
                            else:
                                urlmenu6 = msg.text.replace(".Menu6","").lstrip().rstrip()
                            txt = ""
                            if len(urlmenu6) > 0:
                                self.settings["wallF"] = urlmenu6
                                if not silent:self.client.sendReplyMessage(msg.id,to,"Menu6 image has been set")
                            else:
                                self.client.sendMessage(to,"The given message is too short.")
                            self.backupData()
                        if txt.startswith('.sleepmsg '):
                            if '.sleepmsg' in msg.text:
                                sleepmsg = msg.text.replace(".sleepmsg","").lstrip().rstrip()
                            else:
                                sleepmsg = msg.text.replace(".Sleepmsg","").lstrip().rstrip()
                            self.settings["sleepmsg"] = sleepmsg
                            if not silent:self.client.sendMessage(to,"Sleepmessage set to:\n%s"%sleepmsg)
                            self.backupData()
                        if txt.startswith('.sleepmode'):
                            if 'on' in txt or '1' in txt:
                                if not self.settings["sleepmode"]:
                                    self.settings["sleepmode"] = True
                                    if not silent:self.client.sendMessage(to,"Sleepmode enabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Sleepmode already enabled.")
                            elif 'off' in txt or '0' in txt:
                                if self.settings["sleepmode"]:
                                    self.settings["sleepmode"] = False
                                    if not silent:self.client.sendMessage(to,"Sleepmode disabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Sleepmode already disabled.")
                            else:
                                if not silent:self.client.sendMessage(to,"Usage:\n⌬. on\n⌬. off")
                            self.backupData()
                        if txt.startswith('.purge'):
                            if "all" in txt:
                                count = 0
                                a = self.client.getGroupIdsJoined()
                                for group in self.client.getGroups(a):
                                    for member in group.members:
                                        if member.mid in self.stats["banned"]:
                                            count += 1
                                            self.client.kickoutFromGroup(group.id,[member.mid])
                                if not silent:self.client.sendMessage(to,"Purged all groups.\nTotal kicks: %s."%count)
                            else:
                                group = self.client.getGroup(to)
                                count = 0
                                for member in group.members:
                                    if member.mid in self.stats["banned"]:
                                        self.client.kickoutFromGroup(to,[member.mid])
                                        count += 1
                                if not silent:self.client.sendMessage(to,"Group has been purged.\nTotal kicks: %s."%count)
                        if txt.startswith('.autopurge'):
                            if 'on' in txt or '1' in txt:
                                if self.settings["autopurge"]:
                                    if not silent:self.client.sendMessage(to,"Autopurge already enabled.")
                                else:
                                    self.settings["autopurge"] = True
                                    if not silent:self.client.sendMessage(to,"Autopurge enabled.")
                            elif 'off' in txt or '0' in txt:
                                if not self.settings["autopurge"]:
                                    if not silent:self.client.sendMessage(to,"Autopurge already disabled.")
                                else:
                                    self.settings["autopurge"] = False
                                    if not silent:self.client.sendMessage(to,"Autopurge disabled.")
                            else:
                                if not silent:self.client.sendMessage(to,"Usage:\n⌬. on/1\n⌬. off/0")
                            self.backupData()
                        if txt.startswith('.room'):
                            if 'on' in txt or '1' in txt:
                                if self.settings["leaverom"] != 1:
                                    self.settings["leaverom"] = 1
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Autoleave Mc enabled.")
                                else:
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Autoleave Mc already enabled.")
                            elif 'off' in txt or '0' in txt:
                                if self.settings["leaverom"] != 0:
                                    self.settings["leaverom"] = 0
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Autoleave disable.")
                        if txt.startswith('.autoleave'):
                            if 'on' in txt or '1' in txt:
                                if self.settings["autoleave"] != 1:
                                    self.settings["autoleave"] = 1
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Autoleave Group enabled.")
                                else:
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Autoleave Group already enabled.")
                            elif 'off' in txt or '0' in txt:
                                if self.settings["autoleave"] != 0:
                                    self.settings["autoleave"] = 0
                                    if not silent:self.client.sendReplyMessage(msg.id,to,"Autoleave Group disable.")
                        if txt.startswith('.autojoin'):
                            if 'on' in txt or '2' in txt:
                                if self.settings["autojoin"] != 2:
                                    self.settings["autojoin"] = 2
                                    if not silent:self.client.sendMessage(to,"Autojoin Group enabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Autojoin already enabled.")
                            elif 'staff' in txt or '1' in txt:
                                if self.settings["autojoin"] != 1:
                                    self.settings["autojoin"] = 1
                                    if not silent:self.client.sendMessage(to,"Autojoin Group enabled for staff.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Autojoin Group already enabled for staff.")
                            elif 'off' in txt or '0' in txt:
                                if self.settings["autojoin"] != 0:
                                    self.settings["autojoin"] = 0
                                    if not silent:self.client.sendMessage(to,"Autojoin Group disabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Autojoin already disabled.")
                            else:
                                if not silent:self.client.sendMessage(to,"Usage:\n⌬. on/2\n⌬. off/0\n⌬. staff/1")
                            self.backupData()
                        if txt.startswith('.joinjs'):
                            if 'on' in txt or '2' in txt:
                                if self.settings["autojoinjs"] != 2:
                                    self.settings["autojoinjs"] = 2
                                    if not silent:self.client.sendMessage(to,"Join Nuke enabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Join Nuke already enabled.")
                            elif 'staff' in txt or '1' in txt:
                                if self.settings["autojoinjs"] != 1:
                                    self.settings["autojoinjs"] = 1
                                    if not silent:self.client.sendMessage(to,"Join Nuke enabled for staff.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Join Nuke already enabled for staff.")
                            elif 'off' in txt or '0' in txt:
                                if self.settings["autojoinjs"] != 0:
                                    self.settings["autojoinjs"] = 0
                                    if not silent:self.client.sendMessage(to,"Join Nuke disabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Join Nuke already disabled.")
                            else:
                                if not silent:self.client.sendMessage(to,"Usage:\n⌬. on/2\n⌬. off/0\n⌬. staff/1")
                            self.backupData()
                        if txt.startswith('.autoread'):
                            if 'on' in txt:
                                if not self.settings["autoread"]:
                                    self.settings["autoread"] = True
                                    if not silent:self.client.sendMessage(to,"Autoread enabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Autoread already enabled.")
                            elif 'off' in txt:
                                if self.settings["autoread"]:
                                    self.settings["autoread"] = False
                                    if not silent:self.client.sendMessage(to,"Autoread disabled.")
                                else:
                                    if not silent:self.client.sendMessage(to,"Autoread already disabled.")
                            else:
                                if not silent:self.client.sendMessage(to,"Usage:\n⌬. on\n⌬. off")
                            self.backupData()
                        #if txt.startswith('.mimic'):
                            #if 'on' in txt:
                                #if not self.stats["mimic"]:
                                    #self.stats["mimic"]["target2"] = True
                                    #if not silent:self.client.sendMessage(to,"Mimic enabled.")
                                #else:
                                    #if not silent:self.client.sendMessage(to,"Mimic already enabled.")
                            #elif 'off' in txt:
                                #if self.stats["mimic"]:
                                    #self.stats["mimic"]["target2"] = False
                                    #if not silent:self.client.sendMessage(to,"Mimic disabled.")
                                #else:
                                    #if not silent:self.client.sendMessage(to,"Mimic already disabled.")
                            #else:
                                #if not silent:self.client.sendMessage(to,"Usage:\n⌬. on\n⌬. off")
                            #self.backupData()
                        if txt.startswith('.clear'):
                            if ".botlist" in txt:
                                length = len(self.stats["botlist"])
                                self.stats["botlist"] = []
                                self.backupData()
                                if not silent:self.client.sendText(to,"Expelled %s bots."%length)
                            elif ".stafflist" in txt:
                                length = len(self.stats["stafflist"])
                                self.stats["stafflist"] = []
                                self.backupData()
                                if not silent:self.client.sendText(to,"Expelled %s staff."%length)
                            elif ".ban" in txt:
                                length = len(self.stats["banned"])
                                self.stats["banned"] = []
                                self.backupData()
                                if not silent:self.client.sendText(to,"Unbanned %s"%length)
                            #elif ".pmbox" in txt:
                                #length = len(self.stats["pmDetail"])
                                #self.stats["pmDetail"] = []
                                #self.stats["pmID"] = []
                                #self.stats["pmText"] = []
                                #self.backupData()
                                #if not silent:self.client.sendText(to,"Pmbox %s"%length)
                            elif ".stickerban" in txt:
                                length = len(self.stats["stickerban"])
                                self.stats["stickerban"] = []
                                self.backupData()
                                if not silent:self.client.sendText(to,"Unbanned sticker %s"%length)
                            #elif ".stickertagg" in txt:
                                #length = len(self.db["stickertagg"])
                                #self.db["stickertagg"] = []
                                #self.backupData()
                                #if not silent:self.client.sendText(to,"Succes remove sticker %s"%length)
                            elif ".mute" in txt:
                                length = len(self.stats["mutelist"])
                                self.stats["mutelist"] = []
                                self.backupData()
                                if not silent:self.client.sendText(to,"Unmute %s"%length)
                            #elif ".pmbox" in txt:
                                #self.stats["pmID"] = {}
                                #self.stats["pmDetail"] = {}
                                #self.stats["pmText"] = {}
                                #self.backupData()
                                #self.client.sendText(to,"Box message cleared.")
                            elif ".protectall" in txt:
                                self.settings['protect'] = {}
                                self.settings['denyinvite'] = {}
                                self.settings['namelock'] = {}
                                self.settings['linkprotect'] = {}
                                self.settings['allowban'] = {}
                                self.settings['picon'] = {}
                                self.client.sendText(to,"Protect all group cleared.")
                            elif ".unsend" in txt:
                                self.set["detectunsend"]["unsendstiker"] = {}
                                self.set["detectunsend"]["unsendvideo"] = {}
                                self.set["detectunsend"]["unsendtwin"] = {}
                                self.set["detectunsend"]["unsendcontact"] = {}
                                self.set["detectunsend"]["unsendchat"] = {}
                                self.set["detectunsend"]["unsendfile"] = {}
                                self.set["detectunsend"]["unsendaudio"] = {}
                                self.set["detectunsend"]["unsendlocation"] = {}
                                self.client.sendText(to,"Unsend message cleared.")
                            else:
                                self.client.sendText(to,"Usage:\n.botlist\n.stafflist\n.ban\n.pmbox\n.unsend")
                        if txt.startswith(".command"):
                                cmd = txt.replace(".command","").lstrip().rstrip()
                                if cmd in self.commands["invite"].keys():
                                    names = self.commands["invitenames"][cmd]
                                    tst = "♬♬♬♬♬♬♬♬\t\n♬ Commands ♬\t\n♬♬♬♬♬♬♬♬\n♬ Cmd Name: %s\n♬ Count: %i\n"%(cmd,len(self.commands["invite"][str(cmd)]))
                                    for name in names:
                                        tst += "\n•. %s"%name
                                    self.client.sendText(to,tst)
                                else:
                                    self.client.sendText(to,"Command %s does not exist."%cmd)

                        if txt.startswith(".create "):
                            if not self.addcommand:
                                command = txt.replace(".create ","")
                                self.addcmd = command.lstrip().rstrip()
                                self.addcommand = True
                                self.backupData()
                                if not silent:self.client.sendText(to,"Command %s created, now send contacts to be added."%command)
                                if not silent:self.client.sendText(to,"Type /!finish when you're done.\nType /!stop to cancel.")
                            else:
                                if not silent:self.client.sendText(to,"Command creation %s already in progress.\nType .abort to cancel."%self.addcmd)
                        if txt.startswith('.remove'):
                            cmd = txt.replace(".remove","").lstrip().rstrip()
                            if cmd in self.commands["invite"].keys():
                                del self.commands["invite"][cmd]
                                del self.commands["invitenames"][cmd]
                                self.backupData()
                                self.client.sendText(to,"Command %s has been removed."%cmd)
                            else:
                                self.client.sendText(to,"Command %s does not exist."%cmd)
                        if txt == '.finish':
                            if self.addcommand:
                                self.commands["invite"][self.addcmd] = self.tempbots
                                self.commands["invitenames"][self.addcmd] = self.tempnames
                                self.backupData()
                                if not silent:self.client.sendText(to,"Command creation of %s has been finished."%self.addcmd)
                                self.addcmd = ""
                                self.tempbots = []
                                self.tempnames = []
                                self.addcommand = False
                            else:
                                if not silent:self.client.sendText(to,"Nothing to finish.")
                        if txt == '.stop':
                            if self.addcommand:
                                self.addcmd = ""
                                self.addcommand = False
                                self.tempbots = []
                                self.tempnames = []
                                if not silent:self.client.sendText(to,"Command creation aborted.")
                            else:
                                if not silent:self.client.sendText(to,"Nothing to abort.")
                        if txt == ".speed":
                            b = time.time()
                            self.client.getProfile()
                            end = time.time() - b
                            self.client.sendReplyMessage(msg.id,to,"Timespeed:\n%s"%round(end,5))
                        if txt == ".time":
                            b = time.time()
                            self.client.getProfile()
                            end = time.time() - b
                            self.client.sendText(to,"%s"%round(end,5)) 
                            
                        if txt == ".timeleft":
                            timeleft = self.duedate - datetime.now()
                            days, seconds = timeleft.days, timeleft.seconds
                            hours = seconds / 3600
                            minutes = (seconds / 60) % 60
                            mes = "Time to due:\nD:%s H:%s M:%s"%(days,round(hours),round(minutes))
                            self.client.sendReplyMessage(msg.id,to, mes)
                        if txt == ".addmonth":
                            self.duedate = self.duedate + relativedelta(months=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendReplyMessage(msg.id,to, "Time has been extended with 1 month.")
                        if txt == ".delmonth":
                            self.duedate = self.duedate - relativedelta(months=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendReplyMessage(msg.id,to, "Time has been deducted with 1 month.")
                        if txt == ".addweek":
                            self.duedate = self.duedate + relativedelta(weeks=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendReplyMessage(msg.id,to, "Time has been extended with 1 week.")
                        if txt == ".delweek":
                            self.duedate = self.duedate - relativedelta(weeks=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendReplyMessage(msg.id,to, "Time has been deducted with 1 week.")
                        if txt == ".addday":
                            self.duedate = self.duedate + relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendReplyMessage(msg.id,to, "Time has been extended with 1 day.")
                        if txt == ".delday":
                            self.duedate = self.duedate - relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.backupData()
                            self.client.sendReplyMessage(msg.id,to, "Time has been deducted with 1 day.")
                        if txt == ".reduce date":
                            self.duedate = self.duedate - relativedelta(months=1)
                            self.duedate = self.duedate - relativedelta(weeks=1)
                            self.duedate = self.duedate - relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            timeleft = self.duedate - datetime.now()
                            days, seconds = timeleft.days, timeleft.seconds
                            hours = seconds / 3600
                            minutes = (seconds / 60) % 60
                            mes = "Reduce date: %s days, %s hours, %s minutes"%(days,round(hours),round(minutes))
                            self.backupData()
                            self.client.sendReplyMessage(msg.id,to, mes)
                        if txt == ".extend date":
                            self.duedate = self.duedate + relativedelta(months=1)
                            self.duedate = self.duedate + relativedelta(weeks=1)
                            self.duedate = self.duedate + relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            timeleft = self.duedate - datetime.now()
                            days, seconds = timeleft.days, timeleft.seconds
                            hours = seconds / 3600
                            minutes = (seconds / 60) % 60
                            mes = "Extend date: %s days, %s hours, %s minutes"%(days,round(hours),round(minutes))
                            self.backupData()
                            self.client.sendReplyMessage(msg.id,to, mes)
                        if txt == ".duedate":
                            duedate = str(self.duedate).split()[0]
                            self.client.sendReplyMessage(msg.id,to, duedate)
                        if txt == ".debug":self.client.sendMessage(to,self.client.debug())
                        #if self.commands["stickers"] != {}:
                                #if txt in self.commands["stickers"].keys():
                                    #sticker = self.commands["stickers"][txt]
                                    #self.client.send_sticker(to,sticker[0],sticker[1],sticker[2])
                        if self.commands["tmpstickers"] != {}:
                            if txt in self.commands["tmpstickers"].keys():
                                sticker = self.commands["tmpstickers"][txt]
                                ids = sticker[0]
                                ipg = sticker[1]
                                a = self.client.shop.getProduct(packageID=int(ipg), language='ID', country='ID')
                                if a.hasAnimation == True:
                                    data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/IOS/sticker_animation@2x.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                    print(data)
                                    self.sendTemplate(to,data)
                                else:
                                    data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/ANDROID/sticker.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                    print(data)
                                    self.sendTemplate(to,data)        
                        if self.commands["invite"] != {}:
                            if txt in self.commands["invite"].keys():
                                inv = self.commands["invite"][txt]
                                try:
                                    self.client.inviteIntoGroup(to,inv)
                                except:
                                    x = self.client.getCompactGroup(to)
                                    if x.preventedJoinByTicket == True:
                                        x.preventedJoinByTicket = False
                                        self.client.updateGroup(x)
                                    gurl = self.client.reissueGroupTicket(to)
                                    for m in inv:
                                        if m not in self.client.getProfile().mid:
                                            self.client.sendMessage(m,"{} {}".format(to,gurl))
                        if txt == ".abort":
                            self.abort(to)
                        if txt == ".cancelcommand":
                            self.abortz(to)
                        if txt.startswith(".addstaff") or txt.startswith(".addstaff"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                for target in targets:
                                    if target in self.stats["botlist"]:
                                        self.stats["botlist"].remove(target)
                                    if target in self.stats["banned"]:
                                        self.stats["banned"].remove(target)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 New Stafflist 」\n',pg='ADDST',pt=targets)
                            else:
                                self.clear()
                                self.stats["staff"] = True
                                self.backupData()
                                if not silent:self.client.sendText(to,"Send a contact to make staff.")
                        if txt == ".lurkers":
                            print ("Lurking Starting........")
                            if to in self.sider2['readPoint']:
                                if not silent:self.client.sendMessage(to, "╔════════════════\n║READCHAT IN GRpsd\n╠════════════════%s\n║\n╚════════════════" % (self.sider2['readMember'][to]))
                                try:
                                    del self.sider2['readPoint'][to]
                                    del self.sider2['readPoint'][to]
                                except:
                                    pass
                                self.sider2['readPoint'][to] = msg.id
                                self.sider2['readMember'][to] = ""
                                self.sider2['ROM'][to] = {}
                                if not silent:self.client.sendMessage(to, "lurking started")
                            else:
                                try:
                                    del self.sider2['readPoint'][to]
                                    del self.sider2['readMember'][to]
                                except:
                                    pass
                                self.sider2['readPoint'][to] = msg.id
                                self.sider2['readMember'][to] = ""
                                self.sider2['ROM'][to] = {}
                                if not silent:self.client.sendMessage(to, "lurking started")

                        if txt == ".lurkers2":
                            print ("Lurking2 Starting........")
                            if to in self.sider['readPoint']:
                                if self.sider["ROM"][to].items() == []:
                                    if not silent:self.client.sendMessage(to, "╔════════════════\n║READCHAT IN GRpsd\n╠════════════════%s\n║\n╚════════════════" % (self.sider['readMember'][to]))
                                else:
                                    chiya = []
                                    for rom in self.sider["ROM"][to].items():
                                        chiya.append(rom[1])
                                    cmem = self.client.getContacts(chiya)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xtxt = '***Lurkers V0.7***\n\n'
                                    for x in range(len(cmem)):
                                        xname = str(cmem[x].displayName)
                                        txt = ''
                                        txt2 = txt+"@a\n"
                                        xlen = str(len(zxc)+len(xtxt))
                                        xlen2 = str(len(zxc)+len(txt2)+len(xtxt)-1)
                                        zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                                        zx2.append(zx)
                                        zxc += txt2
                                    msg.contentType = 0
                                    print (zxc)
                                    msg.text = xtxt+ zxc + "\nLurking Set: %s\nLurking View: %s"%(self.sider['setTime'][to],datetime.now().strftime('%H:%M:%S'))
                                    lol ={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    print (lol)
                                    msg.contentMetadata = lol
                                    try:
                                        self.client.sendMessage(to,msg.text,lol)
                                    except Exception as error:
                                        print (error)
                            else:
                                try:
                                    del self.sider['readPoint'][to]
                                    del self.sider['readMember'][to]
                                except:
                                    pass
                                self.sider['readPoint'][to] = msg.id
                                self.sider['readMember'][to] = ""
                                self.sider['setTime'][to] = datetime.now().strftime('%H:%M:%S')
                                self.sider['ROM'][to] = {}
                                if not silent:self.client.sendMessage(to, "lurking started")
                        if txt.startswith(".urlcover"):
                            if txt == ".urlcover":
                                cu = self.client.getProfileCoverURL(of)
                                self.client.sendMessage(to,cu)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    cu = self.client.getProfileCoverURL(target)
                                    self.client.sendMessage(to,cu)
                        if txt.startswith(".urlpict"):
                            if txt == ".urlpict":
                                profile = self.client.getContact(of)
                                self.client.sendMessage(to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    profile = self.client.getContact(target)
                                    self.client.sendMessage(to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                        if txt.startswith(".cover"):
                            if txt == ".cover":
                                profile = self.client.getContact(of)
                                cu = self.client.getProfileCoverURL(of)
                                self.client.sendReplyImageWithURL(msg.id,to,cu)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    cu = self.client.getProfileCoverURL(target)
                                    self.client.sendReplyImageWithURL(msg.id,to,cu)
                            else:
                                try:
                                    tx = txt.split(":")
                                    num = int(tx[1])
                                    foo = int(tx[2])
                                    me = self.client.getContact(of)
                                    gid = self.client.getGroupIdsJoined()
                                    gs = self.client.getGroup(gid[num-0])
                                    nama = [o.mid for o in gs.members]
                                    if nama == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        cu = self.client.getProfileCoverURL(nama[foo-2])
                                        self.client.sendReplyImageWithURL(msg.id,to,cu)
                                except:
                                    _name = "/.".join(txt.split()[1:])
                                    gs = self.client.getGroup(to)
                                    targets = []
                                    for g in gs.members:
                                        if _name in g.displayName.lower():
                                            targets.append(g.mid)
                                    if targets == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        for target in targets:
                                            cu = self.client.getProfileCoverURL(target)
                                            self.client.sendReplyImageWithURL(msg.id,to,cu)
##################################### ALQURAN ###################################################
                        if txt.startswith(".alquran "):self.client.surahlist(msg)
                        if txt == ".quranlist":
                            rg = self.client.rgrequestweb("http://api.alquran.cloud/surah")
                            if rg["data"] != []:
                                no = 0
                                ret_ = "╭──「 Al-Qur'an 」"
                                for music in rg["data"]:
                                    no += 1
                                    if no == len(rg['data']):ret_ += "\n╰{}. {}".format(no,music['englishName'])
                                    else:ret_ += "\n│{}. {}".format(no,music['englishName'])
                                self.client.generateReplyMessage(msg.id)
                                self.client.sendReplyMessage(msg.id, to,ret_)
                        if txt == "//keterangan 1":
                            f = open("surah/1.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 2":
                            f = open("surah/2.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 3":
                            f = open("surah/3.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 4":
                            f = open("surah/4.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 5":
                            f = open("surah/5.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 6":
                            f = open("surah/6.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 7":
                            f = open("surah/7.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 8":
                            f = open("surah/8.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 9":
                            f = open("surah/9.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 10":
                            f = open("surah/10.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 11":
                            f = open("surah/11.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 12":
                            f = open("surah/12.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 13":
                            f = open("surah/13.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 14":
                            f = open("surah/14.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 15":
                            f = open("surah/15.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 16":
                            f = open("surah/16.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 17":
                            f = open("surah/17.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 18":
                            f = open("surah/18.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 19":
                            f = open("surah/19.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 20":
                            f = open("surah/20.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 21":
                            f = open("surah/21.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 22":
                            f = open("surah/22.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 23":
                            f = open("surah/23.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 24":
                            f = open("surah/24.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 25":
                            f = open("surah/25.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 26":
                            f = open("surah/26.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 27":
                            f = open("surah/27.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 28":
                            f = open("surah/28.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 29":
                            f = open("surah/29.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 30":
                            f = open("surah/30.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 31":
                            f = open("surah/31.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 32":
                            f = open("surah/32.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 33":
                            f = open("surah/33.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 34":
                            f = open("surah/34.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 35":
                            f = open("surah/35.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 36":
                            f = open("surah/36.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 37":
                            f = open("surah/37.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 38":
                            f = open("surah/38.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 39":
                            f = open("surah/39.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 40":
                            f = open("surah/40.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 41":
                            f = open("surah/41.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 42":
                            f = open("surah/42.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 43":
                            f = open("surah/43.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 44":
                            f = open("surah/44.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 45":
                            f = open("surah/45.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 46":
                            f = open("surah/46.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 47":
                            f = open("surah/47.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 48":
                            f = open("surah/48.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 49":
                            f = open("surah/49.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 50":
                            f = open("surah/50.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 51":
                            f = open("surah/51.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 52":
                            f = open("surah/52.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 53":
                            f = open("surah/53.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 54":
                            f = open("surah/54.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 55":
                            f = open("surah/55.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 56":
                            f = open("surah/56.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 57":
                            f = open("surah/57.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 58":
                            f = open("surah/58.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 59":
                            f = open("surah/59.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 60":
                            f = open("surah/60.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 61":
                            f = open("surah/61.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 62":
                            f = open("surah/62.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 63":
                            f = open("surah/63.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 64":
                            f = open("surah/64.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 65":
                            f = open("surah/65.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 66":
                            f = open("surah/66.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 67":
                            f = open("surah/67.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 68":
                            f = open("surah/68.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 69":
                            f = open("surah/69.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 70":
                            f = open("surah/70.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 71":
                            f = open("surah/71.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 72":
                            f = open("surah/72.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 73":
                            f = open("surah/73.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 74":
                            f = open("surah/74.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 75":
                            f = open("surah/75.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 76":
                            f = open("surah/76.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 77":
                            f = open("surah/77.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 78":
                            f = open("surah/78.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 79":
                            f = open("surah/79.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 80":
                            f = open("surah/80.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 81":
                            f = open("surah/81.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 82":
                            f = open("surah/82.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 83":
                            f = open("surah/83.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 84":
                            f = open("surah/84.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 85":
                            f = open("surah/85.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 86":
                            f = open("surah/86.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 87":
                            f = open("surah/87.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 88":
                            f = open("surah/88.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 89":
                            f = open("surah/89.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 90":
                            f = open("surah/90.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 91":
                            f = open("surah/91.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 92":
                            f = open("surah/92.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 93":
                            f = open("surah/93.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 94":
                            f = open("surah/94.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 95":
                            f = open("surah/95.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 96":
                            f = open("surah/96.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 97":
                            f = open("surah/97.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 98":
                            f = open("surah/98.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 99":
                            f = open("surah/99.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 100":
                            f = open("surah/100.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 101":
                            f = open("surah/101.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 102":
                            f = open("surah/102.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 103":
                            f = open("surah/103.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 104":
                            f = open("surah/104.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 105":
                            f = open("surah/105.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 106":
                            f = open("surah/106.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 107":
                            f = open("surah/107.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 108":
                            f = open("surah/108.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 109":
                            f = open("surah/109.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 110":
                            f = open("surah/110.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 111":
                            f = open("surah/111.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 112":
                            f = open("surah/112.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 113":
                            f = open("surah/113.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt == "//keterangan 114":
                            f = open("surah/114.txt","r")
                            lines = f.readlines()
                            hasil = ""
                            for a in lines:
                                hasil += str(a)
                            #self.client.sendText(to,str(hasil))
                            self.client.sendMessage(to,"{}".format(str(hasil)))
                        if txt.startswith(".murottal"):
                                    sep = msg.text.split(" ")
                                    surah = int(msg.text.replace(sep[0] + " ",""))
                                    if 0 < surah < 115:
                                        if len(str(surah)) == 1:
                                            audionya = "https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/00" + str(surah) + ".mp3"
                                            self.client.sendAudioWithURL(to, audionya)
                                        if len(str(surah)) == 2:
                                            audionya = "https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/0" + str(surah) + ".mp3"
                                            self.client.sendAudioWithURL(to, audionya)
                                        else:
                                            audionya = "https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/" + str(surah) + ".mp3"
                                            self.client.sendAudioWithURL(to, audionya)
                                    else:self.client.sendMessage(to, "Quran hanya 114 surah")
##################################### ALQURAN ###################################################
                        #if txt.startswith(".retro"):
                            #text = msg.text.split(" ")
                            #text1 = text[1]
                            #text2 = text[2]
                            #text3 = text[3]
                            #key = msg.text.replace(text[0] + " " + text1[0] + " " + text2[0] + text3[0] + " " ,"")
                            #data = {
                                #"altText": "Retro",
                                #"template": {
                                #"columns": [{
                                #"action": { 
                                #"type": "uri",
                                #"uri": "line://nv/profilePopup/mid=u3df07ab6c96c93e81adaba0a727999ea"},
                                #"imageUrl": "https://rest.farzain.com/api/photofunia/retro.php?text1={}&text2={}&text3={}&apikey=3w92e8nR5eWuDWQShRlh6C1ye".format(text1, text2, text3)}],
                                #"type": "image_carousel"},
                                #"type": "template"}
                            #self.sendTemplate(to, data)
                        if txt.startswith('.groupcast '):
                            text = txt.replace(".groupcast ","")
                            gid = self.client.getGroupIdsJoined()
                            if text == "":
                                if not silent:self.client.sendMessage(to,"Message is Empty")
                            else:
                                for i in gid:
                                    self.client.sendMessage(i, text+"\n\n___________________________\nBroadcast by:"+self.client.profile.displayName)
                        if txt.startswith(".gcastvoice "):
                            bc = txt.replace(".gcastvoice ","")
                            lang = 'id'
                            tts = gTTS(text=bc, lang=lang)
                            tts.save("gcastvoice.mp3")
                            gid = self.client.getGroupIdsJoined()
                            for i in gid:
                                self.client.sendAudio(i,"gcastvoice.mp3")
                        if txt.startswith(".voice "):
                            xres = txt.replace(".voice ","")
                            tts = gTTS(text=xres, lang='id')
                            path = '%s/pythonLine-vn.data' % (tempfile.gettempdir())
                            ac = tts.save(path)
                            self.client.sendAudio(to,path)
                            self.client.deleteFile(path)
                        if txt.startswith('.pmcast '):
                            xres = txt.replace(".pmcast ","")
                            C = self.client.getAllContactIds()
                            cmem = self.client.getContacts(C)
                            nc = ""
                            for x in range(len(cmem)):
                                self.client.sendMessage(cmem[x].mid,xres + "\n\nCasted by:\n" + self.client.getContact(of).displayName)
                                nc += "\n" + cmem[x].displayName
                            pass
                            self.client.sendMessage(to,"Success broadcast to :\n%s\n\nAll Contact: %s"%(nc,str(len(cmem))))
                        if txt.startswith(".membercast "):
                            text = txt.replace(".membercast ","")
                            group = self.client.getGroup(to)
                            mem = [o.mid for o in group.members]
                            cmem = self.client.getContacts(mem)
                            nc = ""
                            for x in range(len(cmem)):
                                  self.client.sendText(cmem[x].mid,text + "\n\nBroadcast by:\n" + self.client.getContact(of).displayName)
                                  nc += "\n" + cmem[x].displayName
                            pass
                            self.client.sendText(to, "Success BC to :\n%s\n\nTotal Members: %s"%(nc,str(len(cmem))))
                        if txt.startswith(".sprofile"):
                                if txt == ".sprofile":
                                    contact = self.client.getContact(of)
                                    LINKFOTO = "https://os.line.naver.jp/os/p/" + of
                                    LINKVIDEO = "https://os.line.naver.jp/os/p/" + of + "/vp"
                                    data = {"type": "flex",
                                            "altText": "{} Send Flex".format(contact.displayName),
                                            "contents": {"type": "bubble",'styles': {"footer": {"backgroundColor": '#000000'},},
                                                        "footer": {
                                                        "type": "box","layout": "horizontal",
                                                        "spacing": "sm","contents": [{"type": "button",
                                                        "style": "link","height": "sm","action": {"type": "uri",
                                                        "label": "PROFILE ","uri": "line://app/1646011835-9MXEx20v?type=video&ocu={}&piu={}".format(LINKVIDEO,LINKFOTO)}},
                                                        {"type": "spacer","size": "sm"},],"flex": 0}}}
                                    self.sendTemplate(to, data)
                                elif 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', txt)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                            contact = self.client.getContact(ls)
                                            LINKFOTO = "https://os.line.naver.jp/os/p/" + ls
                                            LINKVIDEO = "https://os.line.naver.jp/os/p/" + ls + "/vp"
                                            data = {"type": "flex",
                                                    "altText": "{} Send Flex".format(contact.displayName),
                                                    "contents": {"type": "bubble",'styles': {"footer": {"backgroundColor": '#000000'},},
                                                                 "footer": {
                                                                 "type": "box","layout": "horizontal",
                                                                 "spacing": "sm","contents": [{"type": "button",
                                                                "style": "link","height": "sm","action": {"type": "uri",
                                                                "label": "PROFILE ","uri": "line://app/1646011835-9MXEx20v?type=video&ocu={}&piu={}".format(LINKVIDEO,LINKFOTO)}},
                                                                {"type": "spacer","size": "sm"},],"flex": 0}}}
                                            self.sendTemplate(to, data)
                        if txt.startswith(".zx"):
                            text = msg.text.split(" ")
                            Text = text[1]
                            ipg = text[2]
                            ids = text[3]
                            ser = "1"
                            key = msg.text.replace(text[0] + " " + ids[0] + " " + ipg[0] + " " ,"")
                            a = self.client.shop.getProduct(packageID=int(ipg), language='ID', country='ID')
                            self.commands["tmpstickers"][Text] = [ids,ipg,ser]
                            self.client.sendText(to,"Sticker successfully added to command %s."%Text)
                            if a.hasAnimation == True:
                                data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/IOS/sticker_animation@2x.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                print(data)
                                self.sendTemplate(to,data)
                            else:
                                data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/ANDROID/sticker.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                print(data)
                                self.sendTemplate(to,data)
                        if txt.startswith(".igf "):
                                anu = msg.text.split(" ")
                                query = msg.text.replace(anu[0] + " ","")
                                cond = query.split("|")
                                search = str(cond[0])
                                r = requests.get("https://citldesign.herokuapp.com/igstory={}".format(str(search)))
                                data = r.text
                                data = json.loads(data)
                                if data != []:
                                    ret_ = []
                                    for fn in data:
                                        if 'http://' in fn["image"]:pass
                                        else:
                                            if len(ret_) >= 10:pass
                                            else:ret_.append({"imageUrl": "{}".format(str(fn["image"])),"action": {"type": "uri","uri": "line://app/1646011835-9MXEx20v?type=image&img={}".format(fn["image"])}})#line://app/1646011835-9MXEx20v?type=image&img={}
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {"type": "template","altText": " Instagram Image","template": {"type": "image_carousel","columns": ret_[aa*10 : (aa+1)*10]}}
                                        self.sendTemplate(to, data)
                        if txt.startswith(".picture"):
                            if txt == ".picture":
                                profile = self.client.getContact(of)
                                #idz = self.client.profile.userid
                                #data = {"type":"image","originalContentUrl":"https://os.line.naver.jp/os/p/{}".format(of),"previewImageUrl":"https://os.line.naver.jp/os/p/{}".format(of),"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(of),"linkUrl":"line://ti/p/~"+ self.client.profile.userid}}
                                self.client.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + profile.pictureStatus)
                            elif 'group' in txt:
                                try:
                                    tx = txt.split(":")
                                    num = int(tx[1])
                                    gid = self.client.getGroupIdsJoined()
                                    gs = self.client.getGroup(gid[num-0])
                                    path = "http://dl.profile.line-cdn.net/" + gs.pictureStatus
                                    self.client.sendReplyImageWithURL(msg.id,to,path)
                                except:
                                    group = self.client.getGroup(to)
                                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                    self.client.sendReplyImageWithURL(msg.id,to,path)
                            elif 'MENTION' in msg.contentMetadata.keys()!=None:
                                targets = []
                                self.mention(msg,targets)
                                for target in targets:
                                    profile = self.client.getContact(target)
                                    idz = self.client.profile.userid
                                    data = {"type":"image","originalContentUrl":"https://os.line.naver.jp/os/p/{}".format(target),"previewImageUrl":"https://os.line.naver.jp/os/p/{}".format(target),"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(target),"linkUrl":"line://ti/p/~"+idz}}
                                    self.client.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + profile.pictureStatus)
                            else:
                                try:
                                    tx = txt.split(":")
                                    num = int(tx[1])
                                    foo = int(tx[2])
                                    me = self.client.getContact(of)
                                    gid = self.client.getGroupIdsJoined()
                                    gs = self.client.getGroup(gid[num-0])
                                    nama = [o.mid for o in gs.members]
                                    if nama == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        profile = self.client.getContact(nama[foo-2])
                                        idz = self.client.profile.userid
                                        data = {"type":"image","originalContentUrl":"https://os.line.naver.jp/os/p/{}".format(nama[foo-2]),"previewImageUrl":"https://os.line.naver.jp/os/p/{}".format(nama[foo-2]),"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(nama[foo-2]),"linkUrl":"line://ti/p/~"+idz}}
                                        self.sendTemplate(to,data)
                                except:
                                    _name = "/.".join(txt.split()[1:])
                                    gs = self.client.getGroup(to)
                                    targets = []
                                    for g in gs.members:
                                        if _name in g.displayName.lower():
                                            targets.append(g.mid)
                                    if targets == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        for target in targets:
                                            profile = self.client.getContact(target)
                                            idz = self.client.profile.userid
                                            data = {"type":"image","originalContentUrl":"https://os.line.naver.jp/os/p/{}".format(target),"previewImageUrl":"https://os.line.naver.jp/os/p/{}".format(target),"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(target),"linkUrl":"line://ti/p/~"+idz}}
                                            self.sendTemplate(to,data)
                        if txt.startswith(".delstaff") or txt.startswith(".delstaff"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 Remove staff 」\n',pg='DELST',pt=targets)
                            else:
                                data = txt.replace(".delstaff","")
                                text = data.split(' ')
                                com = str(text[1])
                                selection = Archimed(com,range(1,len(self.stats['stafflist'])+1))
                                k = len(self.stats['stafflist'])//100
                                d = []
                                for c in selection.parse():
                                    d.append(self.stats['stafflist'][int(c)-1])
                                for a in range(k+1):
                                    if a == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[:100],pl=-0,ps='「 Remove staff 」\n',pg='DELST',pt=d)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='「 Remove staff 」\n',pg='DELST',pt=d)
                        if txt.startswith(".getvideo "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', txt)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = self.client.getContact(ls)
                                    if contact.videoProfile == None:
                                        continue
                                    path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp"
                                    self.client.sendVideoWithURL(to, str(path))                
                        if txt.startswith(".say "):
                            text = " ".join(txt.split()[1:])
                            if not silent:self.client.sendText(to,text)
                        if txt.startswith(".rname "):
                            if '.off' in txt:
                                self.settings["rname"][0] = 0
                                self.backupData()
                                if not silent:self.client.sendText(to,"Responsename disabled.")
                            elif '.staff' in txt:
                                self.settings["rname"][0] = 1
                                self.backupData()
                                if not silent:self.client.sendText(to,"Responsename enabled for staff only.")
                            elif '.on' in txt:
                                self.settings["rname"][0] = 2
                                self.backupData()
                                if not silent:self.client.sendText(to,"Responsename enabled.")
                            else:
                                rname = txt.replace("!.rnameee","").lstrip().rstrip()
                                self.settings["rname"][1] = rname
                                self.backupData()
                                if not silent:self.client.sendText(to,"Responsename updated to: %s."%rname)
                        if txt.startswith(".chatbot"):
                            if "on" in txt:
                                if to in self.settings['author']:
                                    if not silent:self.client.sendText(to,"Respon smule already enabled.")
                                else:
                                    self.settings['author'][to] = True
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Respon smule Enabled")
                            elif "off" in txt:
                                if to in self.settings['author']:
                                    if not silent:self.client.sendText(to,"Respon smule Disabled")
                                    del self.settings['author'][to]
                                    self.backupData()
                                else:
                                    if not silent:self.client.sendText(to,"Chatbot already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Usage:\non\noff")
                        if txt == '.ceksider on' or txt == '.ceksider:on':
                            if to in self.db['intip']['on']:
                                self.client.sendText(to, 'Ceksider already enabled.')
                            else:
                                self.db['intip']['on'].append(to)
                                self.client.sendText(to, 'Ceksider enabled.')
                        if txt == '.ceksider off' or txt == '.ceksider:off':
                            if to not in self.db['intip']['on']:
                                self.client.sendText(to, 'Ceksider already disabled.')
                            else:
                                self.db['intip']['on'].remove(to)
                                self.ceks = []
                                self.client.sendText(to, 'Ceksider disabled.')
                        if txt.startswith('.rsider '):
                            rtext = msg.text.replace('.rsider','').strip()
                            self.db['intip']['txt'] = rtext
                            self.client.sendText(to, 'Text sider updated to:\n{}'.format(rtext))
                        if txt.startswith(self.stats["sidercom"]):
                            if 'on' in txt:
                                if to in self.db1['ceksider']['on']:
                                    self.client.sendText(to, 'cctv already enabled.')
                                else:
                                    self.db1['ceksider']['on'].append(to)
                                    if not silent:self.client.sendMessage(to,"cctv enabled.")
                            elif 'off' in txt:
                                if to not in self.db1['ceksider']['on']:
                                    self.client.sendText(to, 'cctv already disabled.')
                                else:
                                    self.db1['ceksider']['on'].remove(to)
                                    self.ceks = []
                                    self.cctvData()
                                    self.client.sendText(to, 'cctv disabled.')
                                    
                        if txt.startswith('.sidertext: '):
                            rtext = msg.text.replace('.sidertext:','').strip()
                            self.db1['ceksider']['txt'] = rtext
                            self.client.sendText(to, 'Text sider updated to:\n{}'.format(rtext))

                        if txt.startswith(".sidsticker"):
                            if '.on' in txt:
                                    self.cctvSTICKER = True
                                    if not silent:self.client.sendMessage(to,"Please send Sticker for cctv")
                            elif '.off' in txt:
                                    self.cctvSTICKER = False
                                    self.cctvData()
                                    if not silent:self.client.sendMessage(to,"Sider sticker disable")

                        if txt.startswith(".clone "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', txt)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    profile = self.client.getContact(contact)
                                    url = "http://dl.profile.line.naver.jp"+profile.picturePath
                                    path = self.client.downloadFileURL(url)
                                    self.client.updateProfilePicture(path)
                                    #self.cloneProfile(contact)
                                    self.client.copyCover(contact)
                                    self.client.copyName(contact)
                                    self.client.copyStatus(contact)
                                    if not silent:self.client.sendText(to, "Done")
                                    self.client.deleteFile(path)
                                except Exception as e:
                                    print(e)
#________________                       

                        if txt == ".reject:all":
                            group = self.client.getGroup(to)
                            if group.invitee:
                                invitees = [o.mid for o in group.invitee]
                                for i in invitees:
                                      self.client.rejectGroupInvitation(to,[i])
                                      time.sleep(1.5)
                                      self.client.sendText(to, "Rejected groups done")
                        if txt == "..bye":
                            self.client.leaveGroup(to)
                        if txt.startswith(".imgsider"):
                            if ".on" in txt:
                                if to in self.stats['cctvPic']:
                                    if not silent:self.client.sendText(to,"Picture sider already enabled.")
                                else:
                                    self.stats['cctvPic'][to] = True
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Picture sider enabled.")
                            elif ".off" in txt:
                                if to in self.stats['cctvPic']:
                                    if not silent:self.client.sendText(to,"Picture sider disabled")
                                    del self.stats['cctvPic'][to]
                                    self.backupData()
                                else:
                                    if not silent:self.client.sendText(to,"Picture sider already disabled.")
                            else:
                                self.client.sendText(to,"Usage:\n.on\n.off")
                        if txt.startswith('.vkick '):
                                if 'MENTION' in msg.contentMetadata !=None:
                                    targets = []
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key["MENTIONEES"][0]["M"]
                                    for x in key["MENTIONEES"]:targets.append(x["M"])
                                    for target in targets:
                                        try:
                                            self.client.kickoutFromGroup(to,[target])
                                            self.client.findAndAddContactsByMid(target)
                                            self.client.inviteIntoGroup(to,[target])
                                            self.client.cancelGroupInvitation(to,[target])
                                            self.client.inviteIntoGroup(to,[target])
                                            self.client.cancelGroupInvitation(to,[target])
                                        except Exception as e:self.client.sendMessage(to,"Limit cok")
                        if txt.startswith(".upname "):
                            name = msg.text[msg.text.find(" .upname ")+len(" .upname "):].lstrip().rstrip()
                            self.client.updateName(name)
                            if not silent:self.client.sendText(to,"Name updated to: %s."%name) 
                        if txt.startswith(".updatename "):
                            string = " ".join(txt.split()[1:])
                            if len(string) <= 5000:
                                profile = self.client.getProfile()
                                profile.displayName = string
                                self.client.updateProfile(profile)
                                self.client.sendText(to, "Name change to " + string)
                        if txt.startswith(".upgname "):
                               if msg.toType == 2:
                                   X = self.client.getGroup(to)
                                   X.name = msg.text.replace(".upgname ","")
                                   self.client.updateGroup(X)
                                   self.client.sendText(to,"Succes update name group to:\n→ " + X.name)
                               else:
                                   self.client.sendText(to,"It can't be used besides the group.")
                        if txt.startswith(".upstatus "):
                            status = msg.text[msg.text.find(" .upstatus ")+len(" .upstatus "):].lstrip().rstrip()
                            self.client.updateStatus(status)
                            if not silent:self.client.sendText(to,"Status updated to: %s."%status)
                        if txt == '.updual':
                            self.imgsender = of
                            self.stats['changeProfileVideo']['status'] = True
                            self.stats['changeProfileVideo']['stage'] = 1
                            self.backupData()
                            if not silent:self.client.sendText(to, "Please send video for update profile")
                        if txt == ".upimage":
                            self.imgsender = of
                            self.stats['picture'][to] = True
                            self.backupData()
                            if not silent:self.client.sendText(to,"Send Pict")
                        if txt.startswith(self.stats["tendang"]):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    if mention not in self.master:
                                        self.client.kickoutFromGroup(to,[mention])
                                    else:
                                        self.client.sendText(to,"Permission denied.")
                        if txt.startswith(".invite"):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    if mention not in self.master:
                                        self.client.findAndAddContactsByMid(mention)
                                        self.client.inviteIntoGroup(to,[mention])
                                    else:
                                        self.client.sendText(to,"Permission denied.")
                        if txt.startswith(".fast"):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    if mention not in self.master:
                                        cms = 'nook.js gid={} token={}'.format(to, self.client.authToken)
                                        cms += ' uid={}'.format(mention)
                                        print(cms)
                                        success = execute_js(cms)
                                    else:
                                        self.client.sendText(to,"Permission denied.")        
                        #if txt == ".pmbox":
                                #ret_ = "🔰Message Box:"
                                #num = 0
                                #if len(self.stats["pmDetail"]) > 0:
                                    #for love in self.stats["pmDetail"]:
                                        #ret_ += "\n%s - "%num + self.stats["pmDetail"][love]
                                        #sub = "\n\nTotal: {} Users\n.pmbox [ No ] to opened.".format(str(len(self.stats["pmDetail"])))
                                        #num = (num+1)
                                    #text = ret_ + sub
                                    #self.client.sendMessage(to,"{}".format(str(text)))
                                #else:
                                    #self.client.sendText(msg.to,"Nothing messages")
                        #if txt.startswith(".pmbox"):
                                #text = txt.split(" ")
                                #num = text[1]
                                #if num.isdigit():
                                    #if int(num) < len(self.listpm) and int(num) >= 0:
                                        #staffuid = self.listpm[int(num)]
                                        #self.sendTagg(to, staffuid, "Message by:\n", self.stats["pmText"][staffuid])

                        if txt.startswith(".lastseen"):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    if mention in self.db['lastseen']:
                                        t = time.time() - self.db['lastseen'][mention][0]
                                        m, s = divmod(t, 60)
                                        h, m = divmod(m, 60)
                                        if self.db['lastseen'][mention][1].startswith('u'):
                                            name = 'pm'
                                        else:
                                            name = self.client.getGroup(self.db['lastseen'][mention][1]).name
                                        n = self.client.getContact(mention).displayName
                                        text = "  Lastseen info\n⌬Name: %s\n⌬Time: %s hours, %s min, %s sec,\n⌬Active in: %s"%(n,round(h),round(m),round(s),name)
                                        self.client.sendMessage(to, text)
                                    else:
                                        self.client.sendText(to,'Unknown.')
                        if txt.startswith(".gift"):
                            if txt == '.gift':
                                self.client.sendGift(to,'2351','sticker')
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    self.client.sendGift(target,'2351','sticker')
                            else:
                                amount = txt.split()[1]
                                if amount.isdigit():
                                    amount = int(amount)
                                    if amount <= 20:
                                        for i in range(0,amount):
                                            self.client.sendGift(to,'2351','sticker')
                                    else:
                                        self.client.sendText(to,"Max: 20.")
                        if txt == '.abort':
                            self.abort(to)
                        if txt.startswith(".copypict "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', txt)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    profile = self.client.getContact(contact)
                                    url = "http://dl.profile.line.naver.jp"+profile.picturePath
                                    path = self.client.downloadFileURL(url)
                                    self.client.updateProfilePicture(path)
                                    if not silent:self.client.sendText(to, "Done")
                                    self.client.deleteFile(path)
                                except Exception as e:
                                    print(e)
                        if txt.startswith(".copycover "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', txt)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    self.client.copyCover(contact)
                                    if not silent:self.client.sendText(to, "Succes copy Cover")
                                except:
                                    if not silent:self.client.sendText(to, "Target Noting")
                        if txt == ".staff:repeat" or txt == ".staffrepeat":
                            self.clear()
                            self.stats["staff"] = True
                            self.stats["repeat"] = True
                            self.backupData()
                            if not silent:self.client.sendText(to,"Send a contact to make staff.")
                        if txt.startswith(".addbot") or txt.startswith(".add:bot"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                for target in targets:
                                    if target in self.stats["stafflist"]:
                                        self.stats["stafflist"].remove(target)
                                    if target in self.stats["banned"]:
                                        self.stats["banned"].remove(target)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 New Botlist 」\n',pg='ADDBOT',pt=targets)
                            else:
                                self.clear()
                                self.stats["bot"] = True
                                self.backupData()
                                if not silent:self.client.sendText(to,"Send a contact to make bot.")
                        if txt == ".bot:repeat" or txt == ".botrepeat":
                            self.clear()
                            self.stats["bot"] = True
                            self.stats["repeat"] = True
                            self.backupData()
                            if not silent:self.client.sendText(to,"Send a contact to make bot.")
                        if txt.startswith(".delbot") or txt.startswith(".botdel"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 Remove bot 」\n',pg='DELBOT',pt=targets)
                            else:
                                data = txt.replace(".delbot","")
                                text = data.split(' ')
                                com = str(text[1])
                                selection = Archimed(com,range(1,len(self.stats['botlist'])+1))
                                k = len(self.stats['botlist'])//100
                                d = []
                                for c in selection.parse():
                                    d.append(self.stats['botlist'][int(c)-1])
                                for a in range(k+1):
                                    if a == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[:100],pl=-0,ps='「 Remove bot 」\n',pg='DELBOT',pt=d)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='「 Remove bot 」\n',pg='DELBOT',pt=d)
                        if txt.startswith(".addban"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                for target in targets:
                                    if target in self.stats["stafflist"]:
                                        self.stats["stafflist"].remove(target)
                                    if target in self.stats["botlist"]:
                                        self.stats["botlist"].remove(target)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 New Banned 」\n',pg='ADDBAN',pt=targets)
                        if txt == ".addban":
                                self.clear()
                                self.stats["ban"] = True
                                self.backupData()
                                if not silent:self.client.sendText(to,"Send a contact to make banned.")
                        if txt.startswith(".addmute"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                for target in targets:
                                    if target in self.stats["stafflist"]:
                                        self.stats["stafflist"].remove(target)
                                    if target in self.stats["botlist"]:
                                        self.stats["botlist"].remove(target)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 New Mutted 」\n',pg='ADDMUTE',pt=targets)
                        if txt == ".addmute":
                                self.clear()
                                self.stats["mute"] = True
                                self.backupData()
                                if not silent:self.client.sendText(to,"Send a contact to make Mutted.")
                        if txt == ".ban:repeat" or txt == ".banrepeat":
                            self.clear()
                            self.stats["ban"] = True
                            self.stats["repeat"] = True
                            self.backupData()
                            if not silent:self.client.sendText(to,"Send a contact to make banned.")
                        if txt == ".addmute:repeat" or txt == ".muterepeat":
                            self.clear()
                            self.stats["mute"] = True
                            self.stats["repeat"] = True
                            self.backupData()
                            if not silent:self.client.sendText(to,"Send a contact to make mutelist.")
                        if txt.startswith(".unban"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 Remove ban 」\n',pg='DELBAN',pt=targets)
                            else:
                                data = txt.replace(".unban","")
                                text = data.split(' ')
                                com = str(text[1])
                                selection = Archimed(com,range(1,len(self.stats['banned'])+1))
                                k = len(self.stats['banned'])//100
                                d = []
                                for c in selection.parse():
                                    d.append(self.stats['banned'][int(c)-1])
                                for a in range(k+1):
                                    if a == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[:100],pl=-0,ps='「 Remove ban 」\n',pg='DELBAN',pt=d)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='「 Remove bot 」\n',pg='DELBAN',pt=d)
                        if txt.startswith(".unmute"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 Remove mute 」\n',pg='DELMUTE',pt=targets)
                            else:
                                data = txt.replace(".unmute","")
                                text = data.split(' ')
                                com = str(text[1])
                                selection = Archimed(com,range(1,len(self.stats['mutelist'])+1))
                                k = len(self.stats['mutelist'])//100
                                d = []
                                for c in selection.parse():
                                    d.append(self.stats['mutelist'][int(c)-1])
                                for a in range(k+1):
                                    if a == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[:100],pl=-0,ps='「 Remove mute 」\n',pg='DELMUTE',pt=d)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='「 Remove bot 」\n',pg='DELMUTE',pt=d)
                        if txt == ".stafflist":
                            if self.stats['stafflist']:
                                self.listdata(to,self.stats,'Stafflist','staff',self.stats['stafflist'])
                            else:
                                if not silent:self.client.sendMessage(to,"List is empty.")
                        if txt == ".botlist":
                            if self.stats['botlist']:
                                self.listdata(to,self.stats,'botlist:','bot',self.stats['botlist'])
                            else:
                                if not silent:self.client.sendMessage(to,"List is empty.")
                        if txt == ".mutelist":
                            if self.stats['mutelist']:
                                self.listdata(to,self.stats,'mutelist:','mute',self.stats['mutelist'])
                            else:
                                if not silent:self.client.sendMessage(to,"List is empty.")
                        if txt == ".banlist":
                            if self.stats['banned']:
                                self.listdata(to,self.stats,'Banlist:','bot',self.stats['banned'])
                            else:
                                if not silent:self.client.sendMessage(to,"List is empty.")
                        if txt.startswith(".addcon"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 New Friend 」\n',pg='ADDFL',pt=targets)
                        if txt.startswith(".delcon"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 Remove Friend 」\n',pg='DELFL',pt=targets)
                            else:
                                split = txt.replace(".delcon ","")   
                                nama = self.client.refreshContacts()
                                selection = Archimed(split,range(1,len(nama)+1))
                                k = len(nama)//100
                                d = []
                                for c in selection.parse():
                                    d.append(nama[int(c)-1])
                                for a in range(k+1):
                                    if a == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[:100],pl=-0,ps='   「 Remove friends 」\n',pg='DELFL',pt=d)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='   「 Remove friends 」\n',pg='DELFL',pt=d)
                        #if txt.startswith("!inv "):
                        #    a = self.client.refreshContacts()
                        #    data = txt.replace("!inv","")
                        #    text = data.split(' ')
                        #    num = str(text[1])
                        #    self.listinv(to,msg,num,self.stats,a)
                        if txt.startswith('!invite '):
                            name = " ".join(txt.split()[1:])
                            count = 0
                            contact_ids = self.client.getAllContactIds()
                            try:
                                for contact in self.client.getContacts(contact_ids):
                                    cname = contact.displayName.lower()
                                    normalized=''.join(x for x in cname if x in string.printable)
                                    normalized = udd.normalize('NFKD',normalized)
                                    if (SequenceMatcher(a=normalized,b=name).ratio()) > 0.70:
                                        print('4')
                                        count += 1
                                        try:
                                            self.client.inviteIntoGroup(to,[contact.mid])
                                            break
                                        except:
                                            pass
                                    elif name == contact.mid:
                                        count += 1
                                        try:
                                            self.client.inviteIntoGroup(to,[contact.mid])
                                            break
                                        except:
                                            pass
                                if count == 0:
                                    self.client.sendMessage(to,"No users found that match: %s"%name)
                            except Exception as e:
                                self.logError("ERROR : " + str(e))
                                traceback.print_exc()
                        if txt.startswith(".friends ") or txt == ".friends":
                            if txt.startswith('.friends '):
                                a = self.client.refreshContacts()
                                data = txt.replace("friends","")
                                text = data.split(' ')
                                num = str(text[1])
                                self.listcon(to,msg,num,self.stats,a)
                            else:
                                a = self.client.refreshContacts()
                                k = len(a)//20
                                for aa in range(k+1):
                                    if aa == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=a[:20],pl=0,ps='「 Friends: 」',pg='MENTIONALLME',pt=a)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=a[aa*20 : (aa+1)*20],pl=aa*20,ps='「 Friends: 」',pg='MENTIONALLME',pt=a)
                        if txt.startswith(".staffcon"):
                            data = txt.replace(".staffcon","")
                            text = data.split(' ')
                            num = str(text[1])
                            self.listcon(to,msg,num,self.stats,self.stats["stafflist"])
                        if txt.startswith(".botcon"):
                            data = txt.replace(".botcon","")
                            text = data.split(' ')
                            num = str(text[1])
                            self.listcon(to,msg,num,self.stats,self.stats["botlist"])
                        if txt.startswith(".bancon"):
                            data = txt.replace(".bancon","")
                            text = data.split(' ')
                            num = str(text[1])
                            self.listcon(to,msg,num,self.stats,self.stats["banned"])
                        if txt.startswith(".membercon"):
                            data = txt.replace(".membercon","")
                            text = data.split(' ')
                            num = str(text[1])
                            gs = self.client.getGroup(to) 
                            nama = [contact.mid for contact in gs.members]
                            num = str(text[1])
                            self.listcon(to,msg,num,self.stats,nama)
                        if txt == ".groups":
                            gid = self.client.getGroupIdsJoined()
                            tst = "Grouplist:"
                            count = 0
                            for group in gid:
                                Gname = self.client.getGroup(group).name
                                gc = self.client.getGroup(group)
                                tst += "\n%s - %s (%s)"%(count,Gname,len(gc.members))
                                count += 1
                            self.client.sendReplyMessage(msg.id,to,tst)
                        if txt.startswith(".groups "):
                            number = txt.split()[1]
                            num = 1
                            if number.isdigit():
                                gid = self.client.getGroupIdsJoined()
                                number = int(number)
                                group = self.client.getGroup(gid[number])
                                if len(txt.split()) == 3:
                                    number = int(txt.split()[2])
                                    self.client.sendContact(to, group.members[number - 1].mid)
                                else:
                                    tst = "𝔊𝔯𝔬𝔲𝔭 𝔫𝔞𝔪𝔢:\n %s\n______________________________\nMembers:\n"%(group.name)
                                    for member in group.members:
                                        tst += "\n  %i- %s"%(num, member.displayName)
                                        num += 1
                                    self.client.sendReplyMessage(msg.id,to,tst)
                        if txt.startswith(".get-status "):
                            number = txt.split()[1]
                            num = 1
                            if number.isdigit():
                                gid = self.client.getGroupIdsJoined()
                                number = int(number)
                                group = self.client.getGroup(gid[number])
                                if len(txt.split()) == 3:
                                    number = int(txt.split()[2])
                                    self.client.sendText(to, "⌬Status dari:\n" + group.members[number - 1].displayName + "\n⌬Statusnya:\n\n" + group.members[number - 1].statusMessage)
                                else:
                                    tst = "𝔊𝔯𝔬𝔲𝔭 𝔫𝔞𝔪𝔢:\n %s\n______________________________\nMembers:\n"%(group.name)
                                    for member in group.members:
                                        tst += "\n  %i- %s"%(num, member.displayName)
                                        num += 1
                                    self.client.sendReplyMessage(msg.id,to,tst)
                        if txt.startswith(".get-profile "):
                            number = txt.split()[1]
                            num = 1
                            if number.isdigit():
                                gid = self.client.getGroupIdsJoined()
                                number = int(number)
                                group = self.client.getGroup(gid[number])
                                if len(txt.split()) == 3:
                                    number = int(txt.split()[2])
                                    self.client.sendText(to, "⌬Nama:\n" + group.members[number - 1].displayName + "\n⌬Mid:\n" + group.members[number - 1].mid + "\n⌬Status:\n" + group.members[number - 1].statusMessage)
                                    path = "http://dl.profile.line-cdn.net/" + group.members[number - 1].pictureStatus
                                    self.client.sendReplyImageWithURL(msg.id,to, path)
                        if txt.startswith(".get-url "):
                            number = txt.split()[1]
                            num = 1
                            if number.isdigit():
                                gid = self.client.getGroupIdsJoined()
                                number = int(number)
                                g = self.client.getGroup(gid[number])
                                links = g.preventedJoinByTicket
                                gTicket = "https://line.me/R/ti/g/{}".format(str(self.client.reissueGroupTicket(g.id)))
                            if links == True:
                                g.preventedJoinByTicket = False
                                self.client.updateGroup(g)
                                self.client.sendReplyMessage(msg.id,to,"Invites by link are now enabled.\nName Group: {}".format(g.name)+"\nLink group:\n"+gTicket)
                            else:
                                self.client.sendReplyMessage(msg.id,to,"Invites by link are already enabled.\nName Group: {}".format(g.name)+"\nLink group:\n"+gTicket)
                        if txt.startswith(".get-info "):
                            number = txt.split()[1]
                            num = 1
                            if number.isdigit():
                                gid = self.client.getGroupIdsJoined()
                                number = int(number)
                                group = self.client.getGroup(gid[number])
                                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                try:
                                    gCreator = group.creator.displayName
                                except:
                                    gCreator = "Not Found"
                                if group.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(group.invitee))
                                if group.preventedJoinByTicket == True:
                                    gQr = "Close"
                                    gTicket = "Not Have"
                                else:
                                    gQr = "Open"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(self.client.reissueGroupTicket(group.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(group.createdTime) / 1000)))
                                ret_ = "Group Info:\n"
                                ret_ += "\n⌬. Name Group: {}".format(group.name)
                                ret_ += "\n⌬. ID Group: {}".format(group.id)
                                ret_ += "\n⌬. Creator Group: {}".format(gCreator)
                                ret_ += "\n⌬. Time Created: {}".format(str(timeCreated))
                                ret_ += "\n⌬. Members: {}".format(str(len(group.members)))
                                ret_ += "\n⌬. Pendings: {}".format(gPending)
                                ret_ += "\n⌬. Group QR: {}".format(gQr)
                                ret_ += "\n⌬. Group URL: {}".format(gTicket)
                                self.client.sendReplyImageWithURL(msg.id,to, path)
                                self.client.sendText(to,ret_)
                                self.client.sendContact(to, group.creator.mid)
                        if txt.startswith(".get-gnote "):
                            number = txt.split()[1]
                            num = 1
                            if number.isdigit():
                                gid = self.client.getGroupIdsJoined()
                                number = int(number)
                                groupd = self.client.getGroup(gid[number])
                                if len(txt.split()) == 3:
                                    number = int(txt.split()[2])
                                    data = self.client.getGroupPost(gid[number])
                                    try:
                                        music = data['result']['feeds'][int(msg.text.split(' ')[1]) - 1]
                                        print(music)
                                        b = [music['post']['userInfo']['writerMid']]
                                        try:
                                            for a in music['post']['contents']['textMeta']:b.append(a['mid'])
                                        except:pass
                                        try:
                                            g= "\n\nᴅᴇsᴄʀɪᴘᴛɪᴏɴ:\n"+str(music['post']['contents']['text'].replace('@','@!'))
                                        except:
                                            g=""
                                        a="\n   ᴛᴏᴛᴀʟ ʟɪᴋᴇ: "+str(music['post']['postInfo']['likeCount'])
                                        a +="\n   ᴛᴏᴛᴀʟ ᴄᴏᴍᴍᴇɴᴛ: "+str(music['post']['postInfo']['commentCount'])
                                        gtime = music['post']['postInfo']['createdTime']
                                        a +="\n   ᴄʀᴇᴀᴛᴇᴅ ᴀᴛ: "+str(humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                        a += g
                                        zx = ""
                                        zxc = " ɢᴇᴛ ɴᴏᴛᴇ\n   ᴘᴇɴᴜʟɪs : @!" + a
                                        try:
                                            #self.sendtag(msg_id, to, zxc, b)
                                            self.sendMention(to,zxc, b)
                                        except Exception as e:
                                            self.client.sendMessage(to, str(e))
                                        try:
                                            for c in music['post']['contents']['media']:
                                                params = {'userMid': self.client.getProfile().mid, 'oid': c['objectId']}
                                                path = self.client.server.urlEncode(self.client.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                                                if 'PHOTO' in c['type']:
                                                    try:
                                                        self.client.sendReplyImageWithURL(msg.id,to,path)
                                                    except:pass
                                                else:
                                                    pass
                                                if 'VIDEO' in c['type']:
                                                    try:
                                                        self.client.sendVideoWithURL(to,path)
                                                    except:pass
                                                else:
                                                    pass
                                        except:
                                            pass
                                    except Exception as e:
                                        return self.client.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                        if txt.startswith(".gmem"):
                            tx = txt.split(" ")
                            num = int(tx[1])
                            com = str(tx[2])
                            gid = self.client.getGroupIdsJoined()
                            gs = self.client.getGroup(gid[num-0])
                            nama = [contact.mid for contact in gs.members]
                            no = 0
                            mids = []
                            selection = Archimed(com,range(1,len(nama)+1))
                            k = len(nama)//20
                            for a in range(k+1):
                                if a == 0:eto='「 Mentiones 」\n'
                                else:eto='「 Mentiones 」\n'
                                b=[]
                                text = ''
                                mids = []
                                no = 0
                                for i in selection.parse()[a*500 : (a+1)*500]:
                                    mids.append(nama[i-1])
                                self.listdata(to,self.stats,'Mentiones','tag',mids)
                        
                        if txt.startswith('.ats'):
                            tt = txt.split(' ')
                            com = str(tt[1])
                            gs = self.client.getGroup(to)
                            nama = [contact.mid for contact in gs.members]
                            no = 0
                            mids = []
                            selection = Archimed(com,range(1,len(nama)+1))
                            k = len(nama)//20
                            for a in range(k+1):
                                if a == 0:eto='「 Mentiones 」\n'
                                else:eto='「 Mentiones 」\n'
                                b=[]
                                text = ''
                                mids = []
                                no = 0
                                for i in selection.parse()[a*500 : (a+1)*500]:
                                    mids.append(nama[i-1])
                                self.listdata(to,self.stats,'Mentiones','tag',mids)
                        if txt == ".key":
                            tst = "%s\nᴄʀᴇᴀᴛᴇ ᴍᴇɴᴜ:\n\n☯ sᴛɪᴄᴋᴇʀs ☯\n  ——————"%self.help
                            if self.commands["stickers"] != {}:
                                for command in self.commands["stickers"].keys():
                                    tst += "\n   •「%s」"%command
                            if self.commands["invite"] != {}:
                                tst += "\n\n☯ Invite ☯\n  ——————"
                                for command in self.commands["invite"].keys():
                                    tst += "\n   •「%s」"%command
                            if len(self.perintah) > 0 :
                                tst += "\n\n☯ ᴛᴇxᴛ ᴄᴏᴍᴍᴀɴᴅ ☯\n  ——————"
                            if len(self.perintah) > 0:
                                for cmd in self.perintah:
                                    tst += "\n   •「%s」"%cmd
                            if len(self.imgcmds) > 0:
                                tst += "\n\n☯ ɪᴍᴀɢᴇ ᴄᴏᴍᴍᴀɴᴅ ☯\n  ——————"
                            if len(self.imgcmds) > 0:
                                for cmd in self.imgcmds:
                                    tst += "\n   •「%s」"%cmd
                            if len(self.vidcmds) > 0:
                                tst += "\n\n☯ ᴠɪᴅᴇᴏ ᴄᴏᴍᴍᴀɴᴅ ☯\n  ——————"
                            if len(self.vidcmds) > 0:
                                for cmd in self.vidcmds:
                                    tst += "\n   •「%s」"%cmd
                            if len(self.audiocmds) > 0:
                                tst += "\n\n☯ ᴀᴜᴅɪᴏ ᴄᴏᴍᴍᴀɴᴅ ☯\n  ——————"
                            if len(self.audiocmds) > 0:
                                for cmd in self.audiocmds:
                                    tst += "\n   •「%s」"%cmd
                            self.client.sendMessage(to,"{}".format(str(tst)))

                        if txt.startswith(".sticker "):
                            if '.add' in txt:
                                cmd = txt.split('.add',1)[1].lstrip().rstrip()
                                if cmd not in self.commands["stickers"].keys():
                                    self.addsticker = True
                                    self.stickercommand = cmd
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Send a sticker to add to command %s."%cmd)
                                else:
                                    self.client.sendText(to,"Sticker for command %s has already been set."%cmd)
                            elif '.del' in txt:
                                cmd = txt.split('.del',1)[1].lstrip().rstrip()
                                if cmd in self.commands["stickers"].keys():
                                    del self.commands["stickers"][cmd]
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Sticker command %s has been removed."%cmd)
                                else:
                                    if not silent:self.client.sendText(to,"Sticker command %s does not exist"%cmd)
                            elif '.list' in txt:
                                tst = "♬♬♬♬♬♬♬♬♬\t\n♬ Sticker List ♬\t\n♬♬♬♬♬♬♬♬♬\n"
                                if len(self.commands["stickers"].keys()) > 0:
                                    for cmd in self.commands["stickers"].keys():
                                        tst += "\n⌬. %s"%cmd
                                    self.client.sendText(to,tst)
                                else:
                                    self.client.sendText(to,"Stickerlist is empty!")
                            else:
                                self.client.sendText(to,"Usage:\n⌬ !add\n⌬ !del\n⌬ !list")
                        if txt.startswith(".bigstk "):
                            if '.add' in txt:
                                cmd = txt.split('.add',1)[1].lstrip().rstrip()
                                if cmd not in self.commands["stk"].keys():
                                    self.addstk = True
                                    self.stkcomand = cmd
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Send a sticker for add to command %s."%cmd)
                                else:
                                    self.client.sendText(to,"Sticker for command %s has already been set."%cmd)
                            elif '.del' in txt:
                                cmd = txt.split('.del',1)[1].lstrip().rstrip()
                                if cmd in self.commands["stk"].keys():
                                    del self.commands["stk"][cmd]
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Sticker command %s has been removed."%cmd)
                                else:
                                    if not silent:self.client.sendText(to,"Sticker command %s does not exist"%cmd)
                            elif '.list' in txt:
                                tst = "♬♬♬♬♬♬♬♬♬\t\n♬ Sticker List ♬\t\n♬♬♬♬♬♬♬♬♬\n"
                                if len(self.commands["stk"].keys()) > 0:
                                    for cmd in self.commands["stk"].keys():
                                        tst += "\n⌬. %s"%cmd
                                    self.client.sendText(to,tst)
                                else:
                                    self.client.sendText(to,"Stickerlist is empty!")
                            else:
                                self.client.sendText(to,"Usage:\n⌬ .add\n⌬ .del\n⌬ .list")
                        if txt.startswith(".addcommand "):
                            cmdname = txt.split()[1]
                            if cmdname not in self.perintah:
                                perintah = msg.text[len(".addcommand ") + len(cmdname):]
                                if len(perintah.lstrip().rstrip()) > 0:
                                    self.perintah[cmdname] = perintah.lstrip().rstrip()
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Command %s created."%cmdname)
                                else:
                                    self.imgcmd = cmdname
                                    if not silent:self.client.sendText(to,"Send an image to add to command %s."%cmdname)
                            else:
                                self.client.sendText(to,"Image for command %s has already been set."%cmdname)
                        if txt.startswith(".delcommand "):
                            cmdname = txt.split()[1]
                            if cmdname in self.perintah:
                                del self.perintah[cmdname]
                                self.backupData()
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            elif cmdname in self.imgcmds:
                                self.client.deleteFile(self.imgcmds[cmdname])
                                del self.imgcmds[cmdname]
                                self.backupData()
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            else:
                                if not silent:self.client.sendText(to,"Command %s does not exist."%cmdname)
                        if txt.startswith(".addvideo "):
                            cmdname = txt.split()[1]
                            if cmdname not in self.perintah:
                                perintah = msg.text[len(".addvideo ") + len(cmdname):]
                                self.vidcmd = cmdname
                                self.backupData()
                                if not silent:self.client.sendText(to,"Send an video to add to command %s."%cmdname)
                            else:
                                self.client.sendText(to,"Video for command %s has already been set."%cmdname)
                        if txt.startswith(".delvideo "):
                            cmdname = txt.split()[1]
                            if cmdname in self.vidcmds:
                                self.client.deleteFile(self.vidcmds[cmdname])
                                del self.vidcmds[cmdname]
                                self.backupData()
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            else:
                                if not silent:self.client.sendText(to,"Command %s does not exist."%cmdname)
                        if txt.startswith(".addmusic "):
                            cmdname = txt.split()[1]
                            if cmdname not in self.perintah:
                                perintah = msg.text[len(".addmusic ") + len(cmdname):]
                                self.musiccmd = cmdname
                                self.backupData()
                                if not silent:self.client.sendText(to,"Send an Music to add to command %s."%cmdname)
                            else:
                                self.client.sendText(to,"Music for command %s has already been set."%cmdname)
                        if txt.startswith(".delmusic "):
                            cmdname = txt.split()[1]
                            if cmdname in self.musiccmds:
                                self.client.deleteFile(self.musiccmds[cmdname])
                                del self.musiccmds[cmdname]
                                self.backupData()
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            else:
                                if not silent:self.client.sendText(to,"Command %s does not exist."%cmdname)
                        if txt.startswith(".addaudio "):
                            cmdname = txt.split()[1]
                            if cmdname not in self.perintah:
                                perintah = msg.text[len(".addaudio ") + len(cmdname):]
                                self.audiocmd = cmdname
                                self.backupData()
                                if not silent:self.client.sendText(to,"Send an audio to add to command %s."%cmdname)
                            else:
                                self.client.sendText(to,"Audio for command %s has already been set."%cmdname)
                        if txt.startswith(".delaudio "):
                            cmdname = txt.split()[1]
                            if cmdname in self.audiocmds:
                                self.client.deleteFile(self.audiocmds[cmdname])
                                del self.audiocmds[cmdname]
                                self.backupData()
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            else:
                                if not silent:self.client.sendText(to,"Command %s does not exist."%cmdname)

                        if txt.startswith(".detectunsend"):
                            if 'on' in txt:
                                if msg.to in self.set["detectunsend"]["unsend"]:self.client.sendMessage(to,"Already Active")
                                else:
                                    self.set["detectunsend"]["unsend"][msg.to] = True
                                    self.client.sendMessage(to, "Detect Unsend Active")
                            elif 'off' in txt:
                                if msg.to not in self.set["detectunsend"]["unsend"]:self.client.sendMessage(to,"Already Deactive")
                                else:
                                    del self.set["detectunsend"]["unsend"][msg.to]
                                    self.set["detectunsend"]["unsendstiker"] = {}
                                    self.set["detectunsend"]["unsendvideo"] = {}
                                    self.set["detectunsend"]["unsendtwin"] = {}
                                    self.set["detectunsend"]["unsendcontact"] = {}
                                    self.client.sendMessage(to, "Detect Unsend Deactive")
                            else:
                                self.client.sendMessage(to, "Usage:\non/off")
                        
                        if msg.text == self.stats["tagal"]:
                            group = self.client.getGroup(to)
                            members = [o.mid for o in group.members]
                            k = len(members)//20
                            for j in range(k+1):
                                msg = Message(to=to)
                                tst = u'ᴛᴀɢᴀʟʟ ᴍᴇᴍʙᴇʀs:\t\n\n'
                                s=len(tst)
                                d=[]
                                for i in members[j*20 : (j+1)*20]:
                                    d.append({"S":str(s+3), "E" :str(s+7), "M":i})
                                    s += 8
                                    tst += u'⌬. @asu\n'
                                msg.text = tst.rstrip()
                                msg.contentMetadata = {u'MENTION':json.dumps({"MENTIONEES":d})}
                                try:
                                    self.client.sendMessage(to,msg.text,msg.contentMetadata)
                                except:
                                    print("error")

                        if msg.text == ".tagmc":
                            mc = self.client.getRoom(op.param1)
                            contacts = [contact.mid for contact in mc.contacts]
                            k = len(contacts)//20
                            for j in range(k+1):
                                message(to=op.param1)
                                tst = u'ᴛᴀɢᴀʟʟ ᴍᴇᴍʙᴇʀs:\t\n\n'
                                s=len(tst)
                                d=[]
                                for i in contacts[j*20 : (j+1)*20]:
                                    d.append({"S":str(s+3), "E" :str(s+7), "M":i})
                                    s += 8
                                    tst += u'⌬. @asu\n'
                                msg.text = tst.rstrip()
                                msg.contentMetadata = {u'MENTION':json.dumps({"MENTIONEES":d})}
                                try:
                                    self.client.sendMessage(op.param1,msg.text,msg.contentMetadata)
                                except:
                                    print("error")

                        if txt == ".tags":
                            group = self.client.getGroup(msg.to)
                            members = [contact.mid for contact in group.members]
                            tags = []
                            for i in range(0, len(members), 20):
                                tags.append(list(members[i:i+20]))
                            for t in tags:
                                msg = ttypes.Message(to=msg.to)
                                tst ="%s\n\n"%group.name
                                tst += u''
                                s=len(tst)
                                d=[]
                                for i in range(len(t)):
                                    d.append({"S":str(s), "E" :str(s+4), "M":t[i]})
                                    s += 5
                                    tst +=u'@psd\n'
                                msg.text = tst.rstrip() 
                                msg.contentMetadata = {u'MENTION':json.dumps({"MENTIONEES":d})}
                                self.client.talk.sendMessage(0,msg)

                        if txt.startswith(".faketag "):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    nama = self.client.getContact(mention).displayName
                                    group = self.client.getGroup(to)
                                    members = [o.mid for o in group.members]
                                    k = len(members)//20
                                    for j in range(k+1):
                                        msg = Message(to=to)
                                        tst = u'Tagall Members\t\n\n'
                                        s=len(tst)
                                        d=[]
                                        for i in members[j*20 : (j+1)*20]:
                                            d.append({"S":str(s+3), "E" :str(s+7), "M":i})
                                            s += 8
                                            tst += u'⌬. @oup\n'
                                        msg.text = tst.rstrip()
                                        msg.contentMetadata = {'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+mention, 'MSG_SENDER_NAME': nama,u'MENTION':json.dumps({"MENTIONEES":d})}
                                        try:
                                          self.client.sendMessage(msg)
                                        except:
                                            print("error")

                        if txt.startswith(".youtube"):
                            try:
                                sep = msg.text.split(" ")
                                search = msg.text.replace(sep[0] + " ","")
                                params = {"search_query": search}
                                r = requests.get("https://www.youtube.com/results",params=params)
                                spsd = BeautifulSoup(r.content, "html5lib")
                                self.yt.clear()
                                ret_ = "[ Youtube Result ]\n"
                                datas = [] 
                                no = 0
                                for data in spsd.select(".yt-lockup-title > a[title]"):
                                    if "&lists" not in data["href"]:
                                        datas.append(data)
                                        self.yt.append("https://www.youtube.com{}".format(str(data["href"])))
                                for data in datas:
                                    no += 1
                                    ret_ += "\n{}. {}".format(str(no), str(data["title"]))
                                    ret_ += "\nhttps://www.youtube.com{}\n".format(str(data["href"]))
                                self.client.sendMessage(to, str(ret_))
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))

                        if txt.startswith(".ytmp4 "):
                            separate = msg.text.split(" ")
                            threading.Thread(target=self.ytmp4, args=(msg,to,separate)).start()
                        if txt.startswith(".ytmp3 "):
                            separate = msg.text.split(" ")
                            threading.Thread(target=self.ytmp3, args=(msg,to,separate)).start()
                        if txt.startswith(".mp3 "):
                            try:
                                quer = " ".join(txt.split()[2:])
                                query = urllib.parse.quote(quer)
                                url = "https://www.youtube.com/results?search_query=" + query
                                response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl)
                                stream = vid.streams
                                for s in stream:
                                    vin = s.url
                                    hasil = vid.title
                                    hasil += '\n⌬ Penulis : ' + str(vid.author) + '\n⌬ Durasi : ' + str(vid.duration) + '\n⌬ Suka : ' + str(vid.likes) + '\n⌬ Penonton : ' + str(vid.viewcount) + '\n⌬ Rating : ' + str(vid.rating) + '\n⌬ Diterbitkan : ' + str(vid.published)
                                self.client.sendText(to,hasil)
                                self.client.sendAudioWithURL(to,vin)
                                self.client.deleteFile(vin)
                                print (" Yt-mp3 Succes")
                            except Exception as e:
                                self.client.sendText(msg.to,str(e))
                        if txt.startswith(".mp4 "):
                            try:
                                quer = " ".join(txt.split()[2:])
                                query = urllib.parse.quote(quer)
                                url = "https://www.youtube.com/results?search_query=" + query
                                response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl)
                                stream = vid.streams
                                for s in stream:
                                    vin = s.url
                                    hasil = vid.title
                                    hasil += '\n⌬ Penulis : ' + str(vid.author) + '\n⌬ Durasi : ' + str(vid.duration) + '\n⌬ Suka : ' + str(vid.likes) + '\n⌬ Penonton : ' + str(vid.viewcount) + '\n⌬ Rating : ' + str(vid.rating) + '\n⌬ Diterbitkan : ' + str(vid.published)
                                self.client.sendText(to,hasil)
                                self.client.sendVideoWithURL(to,vin)
                                self.client.deleteFile(vin)
                                print (" Yt-mp4 Succes")
                            except Exception as e:
                                self.client.sendText(msg.to,str(e))
                        if txt.startswith(".updual "):
                            separate = msg.text.split(" ")
                            threading.Thread(target=self.updateDual, args=(msg,to,separate)).start()
                        if txt.startswith(".linkupdual "):
                            separate = msg.text.split(" ")
                            threading.Thread(target=self.updateDual2, args=(msg,to,separate)).start()

                        if txt.startswith(".ymp4 "):
                            quer = " ".join(txt.split()[1:])
                            threading.Thread(target=self.ymp4, args=(to,quer)).start()
                        if txt.startswith(".ymp3 "):
                            quer = " ".join(txt.split()[1:])
                            threading.Thread(target=self.ymp3, args=(to,quer)).start()

                        if txt.startswith(".addmessage "):
                            if '.off' in txt:
                                self.settings["addmessage"] = None
                                self.backupData()
                                if not silent:self.client.sendText(to,"Addmessage disabled.")
                            else:
                                if '.addmessage' in msg.text:
                                    addmessage = msg.text.replace(".addmessage","").lstrip().rstrip()
                                else:
                                    addmessage = msg.text.replace(".Addmessage","").lstrip().rstrip()
                                if len(addmessage) > 0:
                                    self.settings["addmessage"] = addmessage
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Addmessage has been set to:\n%s"%self.settings["addmessage"])
                                else:
                                    self.client.sendText(to,"Kalimat terlalu pendek")
                        if txt.startswith(".target "):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    buyer = mention
                                    group = self.client.getGroup(to)
                                    for member in group.members:
                                        if buyer == member.mid:
                                            name = member.displayName
                                    self.settings["buyer"] = buyer
                                    self.backupData()
                                    self.client.sendText(to,"Done.")
                        #if txt.startswith(".tagmsg "):
                            #if '.off' in txt:
                                #if to in self.settings["tagmessage"]:
                                    #if self.settings["tagmessage"][to][0]:
                                        #self.settings["tagmessage"][to][0] = False
                                        #self.backupData()
                                        #if not silent:self.client.sendText(to,"Tagmessage disabled.")
                                    #else:
                                        #if not silent:self.client.sendText(to,"Tagmessage already disabled.")
                            #elif '.on' in txt:
                                #if to not in self.settings["tagmessage"]:
                                    #if not self.settings["tagmessage"][to][0]:
                                        #self.settings["tagmessage"][to][0] = True
                                        #self.backupData()
                                        #if not silent:self.client.sendText(to,"Tagmessage enabled.")
                                    #else:
                                        #if not silent:self.client.sendText(to,"Tagmessage already enabled.")
                            #else:
                                #if '.tagmsg' in msg.text:
                                   #tagmessage = msg.text.replace(".tagmsg","").lstrip().rstrip()
                                #else:
                                    #tagmessage = msg.text.replace(".tagmsg","").lstrip().rstrip()
                                #if to not in self.settings["tagmessage"]:
                                    #self.settings["tagmessage"][to][0] = True 
                                #self.settings["tagmessage"][to][1] = tagmessage
                                #self.backupData()
                                #if not silent:self.client.sendText(to,"Tagmessage set to:\n%s"%tagmessage)
                        if txt.startswith('.responcall'):
                            if 'off' in txt:
                                if self.settings["callgroup"]["status2"]:
                                    self.settings["callgroup"]["status2"] = False
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Autoresponcall off.")
                                else:
                                    if not silent:self.client.sendText(to,"Autoresponcall sudah off.")
                            elif 'on' in txt:
                                if not self.settings["callgroup"]["status2"]:
                                    self.settings["callgroup"]["status2"] = True
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Autoresponcall on")
                                else:
                                    if not silent:self.client.sendText(to,"Autoresponcall sudah on")
                            else:
                                if not silent:self.client.sendText(to,"╭───「 ʀᴇsᴘᴏɴᴄᴀʟʟ ᴜsᴀɢᴇ 」─\n│\n│  ᴋᴇʏ: .ʀᴇsᴘᴏɴᴄᴀʟʟ ᴏɴ\n│  ᴋᴇʏ: .ʀᴇsᴘᴏɴᴄᴀʟʟ ᴏғғ\n│ ᴋᴇʏ: .ᴄᴀʟʟ ᴜᴘ:\n│ ᴋᴇʏ: .ᴄᴀʟʟ ᴅᴏᴡɴ:\n│ ᴋᴇʏ: .ᴄᴀʟʟ ᴘᴍ:\n│\n╰───「 ᴛʜʙ ᴛᴇᴀᴍ  」─")

                        if txt.startswith('.call up: '):
                            if '.call up' in msg.text:
                                callup = msg.text.replace(".call up:","").lstrip().rstrip()
                            else:
                                callup = msg.text.replace(".call up:","").lstrip().rstrip()
                            self.settings["callgroup"]["up"] = callup
                            if not silent:self.client.sendText(to,"Responsecall set to:\n%s"%callup)
                            self.backupData()

                        if txt.startswith('.call down: '):
                            if '.call down' in msg.text:
                                calldown = msg.text.replace(".call down:","").lstrip().rstrip()
                            else:
                                calldown = msg.text.replace(".call down:","").lstrip().rstrip()
                            self.settings["callgroup"]["down"] = calldown
                            if not silent:self.client.sendText(to,"Responsecall set to:\n%s"%calldown)
                            self.backupData()

                        if txt.startswith('.call pm: '):
                            if '.call pm:' in msg.text:
                                msgcallpm = msg.text.replace(".call pm:","").lstrip().rstrip()
                            self.settings["callpm"] = msgcallpm
                            if not silent:self.client.sendText(to,"Responsecall Pm set to:\n%s"%msgcallpm)
                            self.backupData()
                        if txt == self.stats["uptagoff"]:
                            if to in self.settings["tagmessage"]:
                                if self.settings["tagmessage"][to][0]:
                                    self.settings["tagmessage"][to][0] = False
                                    if not silent:self.client.sendText(to,"Tag message disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Tag message already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Tag message already disabled.")
                            self.backupData()
                        if txt.startswith(self.stats["uptagon"]+" "): 
                            if self.stats["uptagon"] in msg.text:
                                tagmessage = msg.text[msg.text.find(self.stats["uptagon"])+len(self.stats["uptagon"]):].lstrip().rstrip()
                            else:
                                tagmessage = msg.text.replace(self.stats["Uptagon"],"").lstrip().rstrip()
                            self.settings["tagmessage"][to] = [True,tagmessage]
                            if not silent:self.client.sendText(to,"Tag message set to:\n%s"%tagmessage)
                            self.backupData()
                        if txt == self.stats["uptagoff"]:
                            if to in self.settings["tagmessage"]:
                                if self.settings["tagmessage"][to][0]:
                                    self.settings["tagmessage"][to][0] = False
                                    if not silent:self.client.sendText(to,"Tag message disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Tag message already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Tag message already disabled.")
                            self.backupData()
                        if txt.startswith(self.stats["uptagon2"]+" "): 
                            if self.stats["uptagon2"] in msg.text:
                                tagmsg2 = msg.text[msg.text.find(self.stats["uptagon2"])+len(self.stats["uptagon2"]):].lstrip().rstrip()
                            else:
                                tagmsg2 = msg.text.replace(self.stats["uptagon2"],"").lstrip().rstrip()
                            self.settings["tagmsg2"][to] = [True,tagmsg2]
                            if not silent:self.client.sendText(to,"Tag message2 set to:\n%s"%tagmsg2)
                            self.backupData()
                        if txt == self.stats["uptagoff2"]:
                            if to in self.settings["tagmsg2"]:
                                if self.settings["tagmsg2"][to][0]:
                                    self.settings["tagmsg2"][to][0] = False
                                    if not silent:self.client.sendText(to,"Tag message2 disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Tag message2 already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Tag message2 already disabled.")
                            self.backupData()
                        if txt.startswith('.gcon'):self.gcon(to,msg)
                        if txt.startswith(".autoblock "):
                            if 'on' in txt:
                                if not self.settings["autoblock"]:
                                    self.settings["autoblock"] = True
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Autoblock enabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Autoblock already enabled.")
                            elif 'off' in txt:
                                if self.settings["autoblock"]:
                                    self.settings["autoblock"] = False
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"Autoblock disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Autoblock already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Usage:\n⌬. .on\n⌬. .off")
                        if txt.startswith(".autoreject "):
                            if 'on' in txt:
                                if not self.db['autoreject']:
                                    self.db['autoreject'] = True
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"AutoReject enabled.")
                                else:
                                    if not silent:self.client.sendText(to,"AutoReject already enabled.")
                            elif 'off' in txt:
                                if self.db['autoreject']:
                                    self.db['autoreject'] = False
                                    self.backupData()
                                    if not silent:self.client.sendText(to,"AutoReject disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"AutoReject already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Usage:\n⌬. on\n⌬. off")
                        #if txt == ".autoreject on" or txt == ".autoreject:on":
                            #self.db['autoreject'] = True
                            #self.client.sendText(to, 'Autoreject enabled')
                        #if txt == ".autoreject off" or txt == ".autoreject:off":
                            #self.db['autoreject'] = False
                            #self.client.sendText(to, 'Autoreject disabled')
                        if txt == ".reboot":
                            self.client.sendText(to, "Rebooting....")
                            self.settings["reb"] = to
                            self.backupData()
                            self.restart_program()
                        if txt == ".lineid":self.client.sendText(to, self.client.profile.userid)
                        if txt.startswith(".mid"):
                            if txt == '.mid':
                                user = self.client.profile.mid
                                self.client.sendText(to, user)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    self.client.sendText(to, target)
                                else:
                                    pass
                        if txt.startswith(".status"):
                            if txt == '.status':
                                user = self.client.profile.statusMessage
                                self.client.sendText(to,"⌬Status:\n\n" + user)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    user = self.client.getContact(target).statusMessage
                                    self.client.sendText(to,"⌬Status:\n\n" + user)
                                else:
                                    pass
                        if txt.startswith(".userid "):
                            id = " ".join(txt.split()[1:])
                            conn = self.client.findContactsByUserid(id)
                            if True:                                      
                                self.client.sendContact(to,conn.mid)
                        if txt.startswith('.getcon'):
                            uid = txt.replace('.getcon', "").strip()
                            self.client.sendContact(to, uid)
                        if txt == ".refresh":
                            con = self.client.getAllContactIds()
                            gc = self.client.getGroupIdsJoined()
                            pen = self.client.getGroupIdsInvited()
                            self.client.refreshContacts()
                            self.client.refreshGroups()
                            self.client.refreshGpendings()
                            c = str(len(con))
                            g = str(len(gc))
                            p = str(len(pen))
                            text = "Refresh %s Contact\nRefresh %s Group\nRefresh %s Gpending"%(c,g,p)
                            self.client.sendReplyMessage(msg.id,to,text)
                        if txt.startswith(".grouppen"):
                            try:
                                if ".name" in txt:
                                    gid = self.client.getGroupIdsInvited()
                                    tst = "Invited:\n"
                                    count = 0
                                    for group in gid:
                                        Gname = self.client.getGroup(group).name
                                        gc = self.client.getGroup(group)
                                        tst += "\n%s - %s (%s)"%(count,Gname,len(gc.members))
                                        count += 1
                                    self.client.sendText(to,tst)
                                else:
                                    gid = self.client.getGroupIdsInvited()
                                    tst = "Invited:\n"
                                    self.client.sendMessage(to,"Total: %s Invited"%str(len(gid)))
                            except:
                                traceback.print_exc()
                        if txt == ".pending":
                            x = self.client.getGroup(to)
                            nama = [contact.mid for contact in x.invitee]
                            h = 'Pendinglist:\n'
                            count = 1
                            for a in nama:
                                pname = self.client.getContact(a).displayName
                                h += "\n%s. %s"%(count,pname)
                                count += 1
                            self.client.sendText(to,h)
                        if txt == ".gpending" or txt.startswith('.gpending '):
                            gid = self.client.getGroupIdsJoined()
                            if txt == '.gpending':
                             print(len(gid))
                             b = 0
                             h = ""
                             for a in gid:
                                 b = b + 1
                                 end = '\n'
                                 h += str(b) + " - " + self.client.getGroup(a).name + "\n"
                             if not silent:self.client.sendMessage(to,"List invitatation:" + "\n" + h + "Total [%s] groups" %str(len(gid)))
                            else:
                             txtk = int(txt.replace(".gpending ",""))
                             p = self.client.getGroup(gid[txtk-1])
                             print(gid[txtk-1])
                             b = 1
                             h = ""
                             gh = [i.mid for i in p.invitee]
                             for a in gh:
                                 b = b + 1
                                 end = '\n'
                                 h += str(b) + " - " + self.client.getContact(a).displayName + "\n"
                             if not silent:self.client.sendMessage(to,"List Pending:" + "\n" + h + "Total [%s] pending" %str(len(gh)))

                        if txt == ".spamclear" or txt == ".clearspam":
                            self.client.sendMessage(to,"Please wait...")
                            def spamClear():
                                gid = self.client.getGroupIdsInvited()
                                gc = []
                                for group in gid:
                                    gc.append(group)
                                    self.client.acceptGroupInvitation(group)
                                    time.sleep(1)
                                for z in gc:
                                    self.client.leaveGroup(z)
                                    time.sleep(1)
                                self.client.sendMessage(to,"Succes clear %s Spam"%str(len(gc)))
                            th = threading.Thread(target=spamClear)
                            th.start()
                            th.join()
                        if txt == ".accept:all":
                            self.client.sendMessage(to,"Please wait...")
                            def spamClear():
                                gid = self.client.getGroupIdsInvited()
                                gc = []
                                for group in gid:
                                    gc.append(group)
                                    self.client.acceptGroupInvitation(group)
                                    time.sleep(1)
                                self.client.sendMessage(to,"Succes accept %s Groups"%str(len(gc)))
                            th = threading.Thread(target=spamClear)
                            th.start()
                            th.join()
                        if txt == ".leave:all":
                            self.client.sendMessage(to,"Please wait...")
                            def spamClear():
                                gid = self.client.getGroupIdsJoined()
                                gc = []
                                for group in gid:
                                    gc.append(group)
                                    self.client.leaveGroup(group)
                                    time.sleep(1)
                                self.client.sendMessage(to,"Succes leave %s Groups"%str(len(gc)))
                            th = threading.Thread(target=spamClear)
                            th.start()
                            th.join()
                        if txt == ".rejectall":
                            self.client.sendMessage(to,"Please wait...")
                            def spamClear():
                                gid = self.client.getGroupIdsInvited()
                                gc = []
                                for group in gid:
                                    gc.append(group)
                                    self.client.rejectGroupInvitation(group)
                                    time.sleep(3)
                                self.client.sendMessage(to,"Succes reject %s Groups"%str(len(gc)))
                            th = threading.Thread(target=spamClear)
                            th.start()
                            th.join()
#                        if txt.startswith(".accept"):
#                            if ".all" in txt:
#                                gid = self.client.getGroupIdsInvited()
#                                for group in gid:
#                                    self.acceptGroupInvitation(group)
#                                self.client.sendText(to,"Succes accept %s group invited"%str(len(gid)))
#                            else:
#                                gid = self.client.getGroupIdsInvited()
#                                selection = Archimed(txt.split(' ')[1],range(1,len(gid)+1))
#                                k = len(gid)//100
#                                for a in range(k+1):
#                                    if a == 0:eto='  「 Accept Group 」'
#                                    else:eto='  「 Accept Group 」'
#                                    text = ''
#                                    no = 0
#                                    for i in selection.parse()[a*100 : (a+1)*100]:
#                                        self.client.acceptGroupInvitation(gid[i - 1])
#                                        no+=1
#                                        if no == len(selection.parse()):text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
#                                        else:text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
#                                    self.client.sendMessage(to,eto+text)
                        if txt == ".gid":
                            self.client.sendMessage(to,msg.to)
                        if txt == ".ginfo":
                            group = self.client.getGroup(to)
                            path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                            try:
                                gCreator = group.creator.displayName
                            except:
                                gCreator = "Not Found"
                            if group.invitee is None:
                                gPending = "0"
                            else:
                                gPending = str(len(group.invitee))
                            if group.preventedJoinByTicket == True:
                                gQr = "Close"
                                gTicket = "Not Have"
                            else:
                                gQr = "Open"
                                gTicket = "https://line.me/R/ti/g/{}".format(str(self.client.reissueGroupTicket(group.id)))
                            timeCreated = []
                            timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(group.createdTime) / 1000)))
                            ret_ = "Group Info:\n"
                            ret_ += "\n⌬. Name Group: {}".format(group.name)
                            ret_ += "\n⌬. ID Group: {}".format(group.id)
                            ret_ += "\n⌬. Creator Group: {}".format(gCreator)
                            ret_ += "\n⌬. Time Created: {}".format(str(timeCreated))
                            ret_ += "\n⌬. Members: {}".format(str(len(group.members)))
                            ret_ += "\n⌬. Pendings: {}".format(gPending)
                            ret_ += "\n⌬. Group QR: {}".format(gQr)
                            ret_ += "\n⌬. Group URL: {}".format(gTicket)
                            self.client.sendReplyImageWithURL(msg.id,to, path)
                            self.client.sendText(to,ret_)
                            self.client.sendContact(to, group.creator.mid)                            
                        if txt == ".unsendall":
                            M = self.client.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == self.client.profile.mid:
                                        MId.append(i.id)
                            def unsMes(id):
                                self.client.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                        if txt.startswith(".unsend "):
                            args = txt.replace(".unsend ","").lstrip().rstrip()
                            mes = 0
                            try:
                                mes = int(args)
                            except:
                                mes = 1
                            M = self.client.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == self.client.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                self.client.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                        if txt.startswith(".unsend"):
                            args = txt.replace(".unsend","").lstrip().rstrip()
                            ginfo = self.client.getGroup(to)
                            start = time.time()
                            mes = 0
                            try:
                                mes = int(args[1])
                            except:
                                mes = 1
                            M = self.client.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == self.client.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                self.client.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                            begin = time.time() - start
                            hasil = "Type: unsend\n⌬.Group: " + ginfo.name + "\n⌬.Time: "+ str(begin) + "\n⌬.Total: " + str(len(MId))
                            if not silent:self.client.sendMessage(to,"{}".format(str(hasil)))

                        if txt == ".logs":
                            a=subprocess.getoutput('cat log/{}'.format(self.dxName))
                            k = len(a)//10000
                            for aa in range(k+1):
                                self.client.sendMessage(to,'{}'.format(a[aa*10000 : (aa+1)*10000]))
                            try:
                                os.remove('log/{}'.format(self.dxName))
                            except:pass

                        if txt == ".stats":
                            umid = self.client.profile.mid
                            uid = self.client.profile.userid
                            try:
                                arr = []
                                timeNow = time.time()
                                runtime = timeNow - self.stats['start']
                                runtime = format_timespan(runtime)
                                contact = self.client.getContact(self.uid)
                                grouplist = self.client.getGroupIdsJoined()
                                pendinglist = self.client.getGroupIdsInvited()
                                contactlist = self.client.getAllContactIds()
                                blockedlist = self.client.getBlockedContactIds()
                                autoblock = self.client.talk.getBlockedRecommendationIds() + self.client.getBlockedContactIds()
                                seal = self.client.getSettings().e2eeEnable
                                fil = self.client.getSettings().privacyReceiveMessagesFromNotFriend
                                src = self.client.getSettings().privacySearchByUserid
                                nnm = self.client.getSettings().notificationNewMessage
                                ngi = self.client.getSettings().notificationGroupInvitation
                                nsm = self.client.getSettings().notificationShowMessage
                                nic = self.client.getSettings().notificationIncomingCall
                                psc = self.client.getSettings().privacySyncContacts
                                psbpn = self.client.getSettings().privacySearchByPhoneNumber
                                psbe = self.client.getSettings().privacySearchByEmail
                                pasddl = self.client.getSettings().privacyAllowSecondaryDeviceLogin
                                ppiptmh = self.client.getSettings().privacyProfileImagePostToMyhome
                                pan = self.client.getSettings().privacyAllowNearby
                                nm = self.client.getSettings().notificationMention
                                if src == True:alid = "ᴛʀᴜᴇ"
                                else:alid = "ғᴀʟsᴇ"
                                if seal == True:letsel = "ᴛʀᴜᴇ"
                                if seal == False:letsel = "ғᴀʟsᴇ"
                                if fil == True:fpes = "ғᴀʟsᴇ"
                                if fil == False:fpes = "ᴛʀᴜᴇ"
                                if nnm == True:notificationNewMessage = "ᴛʀᴜᴇ"
                                if nnm == False:notificationNewMessage = "ғᴀʟsᴇ"
                                if ngi == True:notificationGroupInvitation = "ᴛʀᴜᴇ"
                                if ngi == False:notificationGroupInvitation = "ғᴀʟsᴇ"
                                if nsm == True:notificationShowMessage = "ᴛʀᴜᴇ"
                                if nsm == False:notificationShowMessage = "ғᴀʟsᴇ"
                                if nic == True:notificationIncomingCall = "ᴛʀᴜᴇ"
                                if nic == False:notificationIncomingCall = "ғᴀʟsᴇ"
                                if psc == True:privacySyncContacts = "ᴛʀᴜᴇ"
                                if psc == False:privacySyncContacts = "ғᴀʟsᴇ"
                                if psbpn == True:privacySearchByPhoneNumber = "ᴛʀᴜᴇ"
                                if psbpn == False:privacySearchByPhoneNumber = "ғᴀʟsᴇ"
                                if psbe == True:privacySearchByEmail = "ᴛʀᴜᴇ"
                                if psbe == False:privacySearchByEmail = "ғᴀʟsᴇ"
                                if pasddl == True:privacyAllowSecondaryDeviceLogin = "ᴛʀᴜᴇ"
                                if pasddl == False:privacyAllowSecondaryDeviceLogin = "ғᴀʟsᴇ"
                                if ppiptmh == True:privacyProfileImagePostToMyhome = "ᴛʀᴜᴇ"
                                if ppiptmh == False:privacyProfileImagePostToMyhome = "ғᴀʟsᴇ"
                                if pan == True:privacyAllowNearby = "ᴛʀᴜᴇ"
                                if pan == False:privacyAllowNearby = "ғᴀʟsᴇ"
                                if nm == True:notificationMention = "ᴛʀᴜᴇ"
                                if nm == False:notificationMention = "ғᴀʟsᴇ"
                                ret_ = "\nᴀᴄᴄᴏᴜɴᴛ sᴛᴀᴛᴜs:"
                                ret_ += "\n\n  • ɴᴀᴍᴇ : {}".format(contact.displayName)
                                #ret_ += "\n🎲 LineId : {}".format(uid)
                                ret_ += "\n  • ɢʀᴏᴜᴘ : {}".format(str(len(grouplist)))
                                ret_ += "\n  • ɢᴘᴇɴᴅɪɴɢ : {}".format(str(len(pendinglist)))
                                ret_ += "\n  • ғʀɪᴇɴᴅ : {}".format(str(len(contactlist)))
                                ret_ += "\n  • ʙʟᴏᴄᴋᴇᴅ : {}".format(str(len(blockedlist)))
                                ret_ += "\n  • ᴀᴜᴛᴏʙʟᴏᴄᴋ : {}".format(str(len(autoblock)))
                                ret_ += "\n  • ᴄᴀɴᴄᴇʟ : {}".format(self.stats["cancelcount"])
                                ret_ += "\n  • ᴜɴsᴇɴᴅ : {}".format(self.stats["destrcount"])
                                ret_ += "\n  • ᴋɪᴄᴋ : {}".format(self.stats["kickcount"])
                                ret_ += "\n  • ɪɴᴠɪᴛᴇ : {}".format(self.stats["invtcount"])
                                ret_ += "\n  • ᴀᴄᴄᴇᴘᴛ : {}".format(self.stats["accpcount"])
                                ret_ += "\n  • ᴜᴘᴅᴀᴛᴇ : {}".format(self.stats["upprofile"])
                                ret_ += "\n  • ғᴏʟʟᴏᴡᴇʀ : {}".format(self.stats["follower"])
                                ret_ += "\n  • ғᴏʟʟᴏᴡɪɴɢ : {}".format(self.stats["following"])
                                ret_ += "\n  • ᴍᴇssᴀɢᴇ sᴇɴᴛ : {}".format(self.stats["sentcount"])
                                ret_ += "\n  • ᴍᴇssᴀɢᴇ ʀᴇᴄᴇɪᴠᴇᴅ : {}".format(self.stats["receivecount"])
                                ret_ += "\n  • ғɪʟᴛᴇʀ : {}".format(fpes)
                                ret_ += "\n  • ᴀʟʟᴏᴡ ɪᴅ ᴀᴅᴅ : {}".format(alid)
                                ret_ += "\n  • ʟᴀᴛᴛᴇʀ sᴇᴀʟɪɴɢ : {}".format(letsel)
                                ret_ += "\n  • ɴᴇᴡᴍᴇssᴀɢᴇ : {}".format(notificationNewMessage)
                                ret_ += "\n  • ɢʀᴏᴜᴘɪɴᴠɪᴛᴀᴛɪᴏɴ : {}".format(notificationGroupInvitation)
                                ret_ += "\n  • sʜᴏᴡᴍᴇssᴀɢᴇ : {}".format(notificationShowMessage)
                                ret_ += "\n  • ɪɴᴄᴏᴍɪɴɢᴄᴀʟʟ : {}".format(notificationIncomingCall)
                                ret_ += "\n  • sʏɴᴄᴄᴏɴᴛᴀᴄᴛs : {}".format(privacySyncContacts)
                                ret_ += "\n  • sᴇᴀʀᴄʜʙʏᴘɴᴜᴍʙᴇʀ : {}".format(privacySearchByPhoneNumber)
                                ret_ += "\n  • sᴇᴀʀᴄʜʙʏᴇᴍᴀɪʟ : {}".format(privacySearchByEmail)
                                ret_ += "\n  • ᴀʟʟᴏᴡᴅᴇᴠɪᴄᴇʟᴏɢɪɴ : {}".format(privacyAllowSecondaryDeviceLogin)
                                ret_ += "\n  • ᴘɪᴍᴀɢᴇᴘᴏsᴛᴛᴏᴍʏʜᴏᴍᴇ : {}".format(privacyProfileImagePostToMyhome)
                                ret_ += "\n  • ᴀʟʟᴏᴡɴᴇᴀʀʙʏ : {}".format(privacyAllowNearby)
                                ret_ += "\n  • ɴᴏᴛɪғᴍᴇɴᴛɪᴏɴ : {}".format(notificationMention)
                                ret_ += "\n  • ʀᴜɴɴɪɴɢ: {}".format(str(runtime))
                                self.sendTagg(to,umid,"sᴇɴᴅᴇʀ:",str(ret_))
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt == ".chatclear":
                            self.client.removeAllMessages(to)
                            self.client.sendText(to,"Succes clear all message")
                        #if txt == ".rchatgroup":
                            #group = self.client.getGroup(to)
                            #self.client.removeAllMessages(group)
                            #self.client.sendText(to,"Succes clear all message")
                        if txt.startswith('.leave'):
                            gid = self.client.getGroupIdsJoined()
                            selection = Archimed(txt.split(' ')[1],range(1,len(gid)+1))
                            k = len(gid)//100
                            for a in range(k+1):
                                if a == 0:eto='  「 Leave Group 」'
                                else:eto='  「 Leave Group 」'
                                text = ''
                                no = 0
                                for i in selection.parse()[a*100 : (a+1)*100]:
                                    self.client.leaveGroup(gid[i - 1])
                                    no+=1
                                    if no == len(selection.parse()):text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
                                    else:text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
                                if not silent:self.client.sendMessage(to,eto+text)
                        if txt.startswith('.keluar '):
                            name = txt.split()[1]
                            gid = self.client.getGroupIdsByName(name)
                            for i in range(len(gid)):
                                self.client.leaveGroup(gid[i])
                                time.sleep(0.5)
                            if not silent:self.client.sendMessage(to,"Succes leave group\n" + self.client.getGroup(gid[i]).name)
                        if txt.startswith(".contact"):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    self.client.sendReplyContact(msg.id,to,target)
                            elif txt == ".contact":
                                self.client.sendReplyContact(msg.id,to,of)
                            else:
                                try:
                                    tx = txt.split(":")
                                    num = int(tx[1])
                                    foo = int(tx[2])
                                    me = self.client.getContact(of)
                                    gid = self.client.getGroupIdsJoined()
                                    gs = self.client.getGroup(gid[num-0])
                                    nama = [o.mid for o in gs.members]
                                    if nama == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        anu = self.client.getContact(nama[foo-2])
                                        self.client.sendReplyContact(msg.id,to,nama[foo-2])
                                except:
                                    _name = "/".join(txt.split()[2:])
                                    gs = self.client.getGroup(to)
                                    targets = []
                                    for g in gs.members:
                                        if _name in g.displayName.lower():
                                            targets.append(g.mid)
                                    if targets == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        for target in targets:
                                            self.client.sendReplyContact(msg.id,to,target)
                        if txt == ".rename":
                            self.clear()
                            self.renamecon = True
                            if not silent:self.sendTagg(to,of,"• ","\nSend a contact nya.\nlalu ketik nama barunya")
                        if txt.startswith('.rename '):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    self.stats["rcon"].append(mention)
                                    self.backupData()
                                    self.rename = of
                        elif self.rename is not None:
                            if of in self.rename:
                                amount = len(self.stats["rcon"])
                                for uid in self.stats["rcon"]:
                                    self.client.findAndAddContactsByMid(uid)
                                    self.client.renameContact(uid,msg.text)
                                self.client.sendMessage(to,"rename %s contact to %s"%(amount,msg.text))
                                self.stats["rcon"] = []
                                self.backupData()
                                self.rename = None
                    elif msg.contentType == 1:
                        if to in self.stats['picture']:
                            xpath = self.client.downloadObjectMsg(msg.id)
                            self.client.updateProfilePicture(xpath)
                            self.client.sendText(to, "Done")
                            self.client.deleteFile(xpath)
                            del self.stats['picture'][to]
                        if self.imgcmd:
                            msgid = msg.id
                            #url = 'https://obs-de.line-apps.com/os/m/%s'%msgid
                            img = self.client.downloadObjectMsg(msgid)
                            self.imgcmds[self.imgcmd] = img
                            self.client.sendText(msg.to,"Image successfully added to command %s."%self.imgcmd)
                            self.backupData()
                            self.imgcmd = None
                        if self.welcomeimage:
                            self.welcomeimage = False
                            msgid = msg.id
                            img = self.client.downloadObjectMsg(msgid)
                            self.stats['welcomeimage'][to] = [True,img]
                            self.backupData()
                            self.client.sendText(to,"Welcome image set.")
                        if self.stats["bcimage"]:
                            msgid = msg.id
                            path = self.client.downloadObjectMsg(msgid)
                            self.stats["bcimage"] = False
                            gid = self.client.getGroupIdsJoined()
                            for gc in gid:
                                self.client.sendImage(gc,path)
                            else:
                                self.client.sendMessage(to, "Succes broascast image to "+str(len(gid)) +" groups")
                                self.client.deleteFile(path)
                        if to in self.stats['gpic']:
                            xpath = self.client.downloadObjectMsg(msg.id)
                            self.client.updateGroupPicture(to,xpath)
                            self.client.sendText(to,"Done")
                            self.client.deleteFile(xpath)
                            del self.stats['gpic'][to]
                            self.backupData()
                        if self.adc:
                            self.updateCover(msg)
                            self.backupData()
                        if self.stats['changeProfileVideo']['status'] == True:
                            path = self.client.downloadObjectMsg(msg.id, saveAs="tmp/pict.bin")
                            if self.stats['changeProfileVideo']['stage'] == 1:
                                self.stats['changeProfileVideo']['picture'] = path
                                self.client.sendMessage(to, "Please send video for update profile")
                                self.stats['changeProfileVideo']['stage'] = 2
                                self.backupData()
                            elif self.stats['changeProfileVideo']['stage'] == 2:
                                self.stats['changeProfileVideo']['picture'] = path
                                self.changeProfileVideo(to)
                                self.client.sendMessage(to, "Succes update video profile")
                                self.client.deleteFile(path)
                                self.backupData()


                    elif msg.contentType == 2:
                        if self.stats['changeProfileVideo']['status'] == True:
                            path = self.client.downloadObjectMsg(msg.id)
                            if self.stats['changeProfileVideo']['stage'] == 1:
                                self.stats['changeProfileVideo']['video'] = path
                                self.client.sendMessage(to, "Please send picture for update profile")
                                self.stats['changeProfileVideo']['stage'] = 2
                                self.backupData()
                            elif self.stats['changeProfileVideo']['stage'] == 2:
                                self.stats['changeProfileVideo']['video'] = path
                                self.changeProfileVideo(to)
                                self.client.deleteFile(path)
                                self.backupData()
                        if self.vidcmd:
                            msgid = msg.id
                            vid = self.client.downloadObjectMsg(msgid)
                            self.vidcmds[self.vidcmd] = vid
                            self.backupData()
                            self.client.sendText(msg.to,"Video successfully added to command %s."%self.vidcmd)
                            self.vidcmd = None
                            self.backupData()
                        if self.stats["bcvideo"]:
                            msgid = msg.id
                            path = self.client.downloadObjectMsg(msgid)
                            self.stats["bcvideo"] = False
                            gid = self.client.getGroupIdsJoined()
                            for gc in gid:
                                self.client.sendVideo(gc,path)
                            else:
                                self.client.sendMessage(to, "Succes broascast video to "+str(len(gid)) +" groups")
                                self.client.deleteFile(path)
                    elif msg.contentType == 3:
                        if self.audiocmd:
                            msgid = msg.id
                            audio = self.client.downloadObjectMsg(msgid)
                            self.audiocmds[self.audiocmd] = audio
                            self.backupData()
                            self.client.sendText(msg.to,"Audio successfully added to command %s."%self.audiocmd)
                            self.audiocmd = None
                            self.backupData()
                        if self.stats["bcaudio"]:
                            msgid = msg.id
                            path = self.client.downloadObjectMsg(msgid)
                            self.stats["bcaudio"] = False
                            gid = self.client.getGroupIdsJoined()
                            for gc in gid:
                                self.client.sendAudio(gc,path)
                            else:
                                self.client.sendMessage(to, "Succes broascast audio to "+str(len(gid)) +" groups")
                                self.client.deleteFile(path)

                    elif msg.contentType == 18:
                      if self.album["albumpro"] == True:
                          if msg._from not in self.stats["stafflist"]:
                              self.client.kickoutFromGroup(msg.to, [msg._from])
                              print(self.album)
                    
                    elif msg.contentType == 7:
                        if self.addstk:
                            stkr1 = msg.contentMetadata['STKID']
                            stkr2 = msg.contentMetadata['STKPKGID']
                            self.commands["stk"][self.stkcomand] = [stkr1,stkr2]
                            self.addstk = False
                            self.client.sendText(to,"Sticker successfully added to command %s."%self.stickercommand)
                            self.stkcomand = ""
                        if self.stickertemp:
                            sticker1 = msg.contentMetadata['STKID']
                            sticker2 = msg.contentMetadata['STKPKGID']
                            sticker3 = msg.contentMetadata['STKVER']
                            self.commands["tmpstickers"][self.stickercmd] = [sticker1,sticker2,sticker3]
                            self.stickertemp = False
                            self.backupData()
                            self.client.sendText(to,"Sticker successfully added to command %s."%self.stickercmd)
                            self.stickercmd = ""
                        if self.addsticker:
                            sticker1 = msg.contentMetadata['STKID']
                            sticker2 = msg.contentMetadata['STKPKGID']
                            sticker3 = msg.contentMetadata['STKVER']
                            self.commands["stickers"][self.stickercommand] = [sticker1,sticker2,sticker3]
                            self.addsticker = False
                            self.backupData()
                            self.client.sendText(to,"Sticker successfully added to command %s."%self.stickercommand)
                            self.stickercommand = ""
                        if self.cctvSTICKER:
                            sticker1 = msg.contentMetadata['STKID']
                            sticker2 = msg.contentMetadata['STKPKGID']
                            sticker3 = msg.contentMetadata['STKVER']
                            self.commands["cctvStickers"][to] = [sticker1,sticker2,sticker3]
                            self.cctvSTICKER = False
                            self.backupData()
                            self.client.sendText(to,"Cctv Sticker Actives")
                        if self.wcsticker:
                            sticker1 = msg.contentMetadata['STKID']
                            sticker2 = msg.contentMetadata['STKPKGID']
                            sticker3 = msg.contentMetadata['STKVER']
                            self.stats["welcomeStickers"][to] = [sticker1,sticker2,sticker3]
                            self.wcsticker = False
                            self.backupData()
                            self.client.sendText(to,"Welcome Sticker Active")
                        if self.leavesticker:
                            sticker1 = msg.contentMetadata['STKID']
                            sticker2 = msg.contentMetadata['STKPKGID']
                            sticker3 = msg.contentMetadata['STKVER']
                            self.stats["leaveStickers"][to] = [sticker1,sticker2,sticker3]
                            self.leavesticker = False
                            self.backupData()
                            self.client.sendText(to,"Leave Sticker Active")
                        if self.rsticker:
                            if to not in self.db['rsticker']:
                                self.db['rsticker'][to] = {}
                            self.db['rsticker'][to]['on'] = True
                            self.db['rsticker'][to]['sid'] = msg.contentMetadata['STKID']
                            self.db['rsticker'][to]['pid'] = msg.contentMetadata['STKPKGID']
                            self.db['rsticker'][to]['v'] = msg.contentMetadata['STKVER']
                            self.rsticker = False
                            self.client.sendText(to,'Response sticker set.')
                        if self.stickerban:
                            stk_id = msg.contentMetadata["STKID"]
                            if stk_id not in self.stats['stickerban']:
                                self.stats['stickerban'][to] = {}
                            self.stats['stickerban'][to]['on'] = True
                            self.stats['stickerban'][to]['sid'] = msg.contentMetadata['STKID']
                            self.stats['stickerban'][to]['pid'] = msg.contentMetadata['STKPKGID']
                            self.stats['stickerban'][to]['v'] = msg.contentMetadata['STKVER']
                            self.stickerban = False
                            self.client.sendText(to,'Sticker has been banned')
                        if self.staggpm:
                            self.stats['staggpm']['sid'] = msg.contentMetadata['STKID']
                            self.stats['staggpm']['pid'] = msg.contentMetadata['STKPKGID']
                            self.stats['staggpm']['v'] = msg.contentMetadata['STKVER']
                            self.staggpm = False
                            self.backupData()
                            self.client.sendText(to,'Sticker di set untuk tagpm')
                        #if self.replykick:
                            #self.stats['replykick']['sid'] = msg.contentMetadata['STKID']
                            #self.stats['replykick']['pid'] = msg.contentMetadata['STKPKGID']
                            #self.stats['replykick']['v'] = msg.contentMetadata['STKVER']
                            #self.replykick = False
                            #self.backupData()
                            #self.client.sendText(to,'Sticker di set untuk Replykick')
                    ######### STICKERTAGG ################
                    #elif msg.contentType == 7:
                        if self.stickertagg:
                            self.stats['stickertagg']['sid'] = msg.contentMetadata['STKID']
                            self.stats['stickertagg']['pid'] = msg.contentMetadata['STKPKGID']
                            self.stats['stickertagg']['v'] = msg.contentMetadata['STKVER']
                            self.stickertagg = False
                            self.backupData()
                            self.client.sendText(to,'Sticker di set untuk Tagall')
                        if self.settings['stickertagg'] == True:
                            stk_id = msg.contentMetadata['STKID']
                            stkku = self.stats['stickertagg']["pid"],self.stats['stickertagg']["sid"],self.stats['stickertagg']["v"]
                            if stk_id in stkku:
                                if msg._from in of:
                                    group = self.client.getGroup(to)
                                    members = [o.mid for o in group.members]
                                    k = len(members)//20
                                    for j in range(k+1):
                                        msg = Message(to=to)
                                        tst = u'ᴛᴀɢᴀʟʟ ᴍᴇᴍʙᴇʀs:\t\n\n'
                                        s=len(tst)
                                        d=[]
                                        for i in members[j*20 : (j+1)*20]:
                                            d.append({"S":str(s+3), "E" :str(s+7), "M":i})
                                            s += 8
                                            tst += u'⌬. @asu\n'
                                        msg.text = tst.rstrip()
                                        msg.contentMetadata = {u'MENTION':json.dumps({"MENTIONEES":d})}
                                        try:
                                            self.client.sendMessage(to,msg.text,msg.contentMetadata)
                                        except:
                                            print("[7] notified Stickertagg")
#                        if self.stickertagg:
#                            if to not in self.db['stickertagg']:
#                                self.db['stickertagg'][to] = {}
#                            self.db['stickertagg'][to]['on'] = False
#                            self.db['stickertagg'][to]['sid'] = msg.contentMetadata['STKID']
#                            self.db['stickertagg'][to]['pid'] = msg.contentMetadata['STKPKGID']
#                            self.stickertagg = False
#                            self.client.sendText(to,'Tagall sticker set.')
                        if self.stickerbye:
                            self.stats['stickerbye']['sid'] = msg.contentMetadata['STKID']
                            self.stats['stickerbye']['pid'] = msg.contentMetadata['STKPKGID']
                            self.stats['stickerbye']['v'] = msg.contentMetadata['STKVER']
                            self.stickerbye = False
                            self.backupData()
                            self.client.sendText(to,'Bye sticker set.')
                        if self.settings['stickerbye'] == True:
                            stk_id = msg.contentMetadata['STKID']
                            stkku = self.stats['stickerbye']['pid'],self.stats['stickerbye']['sid'],self.stats['stickerbye']['v']
                            if stk_id in stkku:
                                if msg._from in of:
                                    self.client.leaveGroup(to)
                                    print("[7] notified Sticker@bye")
                        if self.stickernook:
                            self.stats['stickernook']['sid'] = msg.contentMetadata['STKID']
                            self.stats['stickernook']['pid'] = msg.contentMetadata['STKPKGID']
                            self.stats['stickernook']['v'] = msg.contentMetadata['STKVER']
                            self.stickernook = False
                            self.backupData()
                            self.client.sendText(to,'Sticker di set untuk Bypass')
                        if self.settings['stickernook'] == True:
                            stk_id = msg.contentMetadata['STKID']
                            stkku = self.stats["stickernook"]['pid'],self.stats["stickernook"]['sid'],self.stats["stickernook"]['v']
                            if stk_id in stkku:
                                if msg._from in of:
                                    cmd = 'nook.js gid={} token={}'.format(to, self.client.authToken)
                                    g = self.client.getGroup(to)
                                    for m in g.members:
                                        if m.mid not in self.stats["botlist"] and m.mid not in self.stats["stafflist"]:
                                            cmd += ' uid={}'.format(m.mid)
                                    print(cmd)
                                    success = execute_js(cmd)
                                    self.client.sendMessage(to,"Success Execute")

#                        if self.stats['replykick']:
#                            stk_id = msg.contentMetadata['STKID']
#                            stkku = self.stats['replykick']["pid"],self.stats['replykick']["sid"],self.stats['replykick']["v"]
#                            if stk_id in stkku:
#                                if msg.messageRelationType == 3:
#                                   if msg.id not in self.stats["stafflist"] and msg.id not in self.master:
#                                      try:self.client.sendMessage(to, "Fuck up your Message")
#                                      except: pass
#                                      try:self.client.kickoutFromGroup(msg.to, [msg.id])
#                                      except: pass
#                                      print("[7] Notified Replykick")

                    elif msg.contentType == 13:
                        if self.addcommand:
                            uid = msg.contentMetadata['mid']
                            name = msg.contentMetadata['displayName']
                            if uid not in self.tempbots:
                                self.tempbots.append(uid)
                                self.tempnames.append(name)
                                self.client.findAndAddContactsByMid(uid)
                                self.backupData()
                                self.client.sendText(to,"Added %s to command %s."%(name,self.addcmd))
                            else:
                                self.client.sendText(to,"%s has already been added to command %s"%(name,self.addcmd))
                        elif self.stats['clone']:
                            uid = msg.contentMetadata['mid']
                            name = msg.contentMetadata['displayName']
                            if not self.stats["repeat"]:
                                self.stats["clone"] = False
                                profile = self.client.getContact(uid)
                                url = "http://dl.profile.line.naver.jp/"+profile.picturePath
                                path = self.client.downloadFileURL(url)
                                self.client.updateProfilePicture(path)
                                self.cloneProfile(uid)
                                self.client.copyCover(uid)
                                self.client.copyName(name)
                                self.client.copyStatus(uid.statusMessage)
                                if not silent:self.client.sendText(to, "Done")
                                self.client.deleteFile(path)
                        if self.stats["locate"]:
                            uid = msg.contentMetadata['mid']
                            name = msg.contentMetadata['displayName']
                            if not self.stats["repeat"]:
                                self.stats["locate"] = False
                                self.backupData()
                            groups = self.client.getGroupIdsJoined()
                            ingroups = []
                            for group in groups:
                                members = [o.mid for o in self.client.getGroup(group).members]
                                if uid in members:
                                    ingroups.append(self.client.getGroup(group).name)
                            if len(ingroups) > 0:
                                tst = "Found %s in %s groups:\n"%(name,len(ingroups))
                                for g in ingroups:
                                    tst += "\n⌬. %s"%g
                                self.client.sendText(to,tst)
                            else:
                                self.client.sendText(to,"User not found in any group.")
                        if self.stats["ban"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["ban"] = False 
                            if uid in self.master:
                                self.client.sendText(to,"Please try expel first.")
                            elif uid in self.stats["banned"]:
                                self.client.sendText(to,"%s is already Shitlisted."%name)
                            elif uid in self.stats["botlist"] or uid in self.stats["stafflist"]:
                                self.client.sendText(to,"Please try expel first.")
                            else:
                                self.stats["banned"].append(uid)
                                self.backupData()
                                self.client.sendText(to,"%s add to Shitlisted."%name)
                        if self.stats["mute"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["mute"] = False 
                            if uid in self.master:
                                self.client.sendText(to,"Please try expel first.")
                            elif uid in self.stats["mutelist"]:
                                self.client.sendText(to,"%s is already Mutelisted."%name)
                            elif uid in self.stats["botlist"] or uid in self.stats["stafflist"]:
                                self.client.sendText(to,"Please try expel first.")
                            else:
                                self.stats["mutelist"].append(uid)
                                self.backupData()
                                self.client.sendText(to,"%s add to Mutelisted."%name)
                        if self.stats['kick']:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["kick"] = False
                                self.backupData()
                                if uid not in self.stats["botlist"] or uid not in self.stats["stafflist"]:
                                    self.client.kickoutFromGroup(to,[uid])
                                else:
                                    self.client.sendText(to,"Please try expel first.")
                        if self.stats['invite']:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["invite"] = False
                                self.backupData()
                                if uid in self.stats['banned']:
                                    self.client.sendMessage(to,"Can't invite user banned")
                                else:
                                    self.client.findAndAddContactsByMid(uid)
                                    self.client.inviteIntoGroup(to,[uid])
                                    self.client.sendText(to,"Successfully invite %s"%name)
                        if self.stats["gift"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["gift"] = False
                                self.backupData()
                            if uid in self.master:
                                self.client.sendText(to,"Permission denied.")
                            else:
                                self.client.sendGift(uid,'2351','sticker')
                                self.client.sendText(to,"Gift sent.")
                        if self.stats["info"]:
                            if not self.stats["repeat"]:
                                self.stats["info"] = False
                            msg.contentType = 0
                            if 'displayName' in msg.contentMetadata:
                                contact = self.client.getContact(msg.contentMetadata["mid"])
                                cu = self.client.getProfileCoverURL(msg.contentMetadata["mid"])
                                path = str(cu)
                                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                self.client.sendText(to,"Nama :\n" + contact.displayName + "\n\nMid :\n" + msg.contentMetadata["mid"] + "\n\nBio :\n" + contact.statusMessage)
                                self.client.sendImageWithURL(to,image)
                                self.client.sendImageWithURL(to,path)
                        if self.set["mids"]:
                            if not self.stats["repeat"]:
                                self.set["mids"] = False
                            msg.contentType = 0
                            if 'displayName' in msg.contentMetadata:
                                contact = self.client.getContact(msg.contentMetadata["mid"])
                                #cu = self.client.getProfileCoverURL(msg.contentMetadata["mid"])
                                #path = str(cu)
                                #image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                self.client.sendText(to,msg.contentMetadata["mid"])
                                #self.client.sendImageWithURL(to,image)
                                #self.client.sendImageWithURL(to,path)
                        if self.stats["unban"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["unban"] = False
                            if uid in self.stats["banned"]:
                                self.stats["banned"].remove(uid)
                                self.backupData()
                                self.client.sendText(to,"%s has been unshit."%name)
                            else:
                                self.client.sendText(to,"%s is not shitlisted."%name)
                        if self.stats["unmute"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["unmute"] = False
                            if uid in self.stats["mutelist"]:
                                self.stats["mutelist"].remove(uid)
                                self.backupData()
                                self.client.sendText(to,"%s has been unmute."%name)
                            else:
                                self.client.sendText(to,"%s is not mutelisted."%name)
                        if self.stats["staff"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["staff"] = False
                                self.backupData()
                            if uid in self.stats["stafflist"]:
                                if not silent:self.client.sendText(to,"%s is already staff."%name)
                            elif uid in self.stats["banned"]:
                                self.stats["banned"].remove(uid)
                                self.stats["stafflist"].append(uid)
                                self.backupData()
                                if not silent:self.client.sendText(to,"%s has been added as staff."%name)
                            elif uid in self.stats["botlist"]:
                                self.stats["botlist"].remove(uid)
                                self.stats["stafflist"].append(uid)
                                self.backupData()
                                if not silent:self.client.sendText(to,"%s has been promoted from bot to staff."%name)
                            else:
                                self.stats["stafflist"].append(uid)
                                self.backupData()
                                if not silent:self.client.sendText(to,"%s has been added as staff."%name)
                        if self.stats["bot"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["bot"] = False
                                self.backupData()
                            if uid in self.stats["botlist"]:
                                self.client.sendText(to,"%s is already bots."%name)
                            elif uid in self.stats["banned"]:
                                self.stats["banned"].remove(uid)
                                self.stats["botlist"].append(uid)
                                self.backupData()
                                self.client.sendText(to,"%s has been added as bot."%name)
                            elif uid in self.stats["stafflist"]:
                                self.stats["stafflist"].remove(uid)
                                self.stats["botlist"].append(uid)
                                self.backupData()
                                if not silent:self.client.sendText(to,"%s has been promoted from staff to bot."%name)
                            else:
                                self.stats["botlist"].append(uid)
                                self.backupData()
                                self.client.sendText(to,"%s has been added as bot."%name)
                        if self.renamecon:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.renamecon = False
                            if uid in self.stats["rcon"]:
                                pass
                            else:
                                self.stats["rcon"].append(uid)
                                self.backupData()
                                self.rename = of
                                self.renamecon = False
                        if self.spam:
                            uid = msg.contentMetadata["mid"]
                            if uid not in self.sasaran:
                                self.sasaran.append(uid)
                                if not silent:self.client.sendMessage(to,"User %s added to spam list"%(self.client.getContact(uid).displayName))
                            else:
                                if not silent:self.client.sendMessage(to,"%s already on spam list"%(self.client.getContact(uid).displayName))
                    elif msg.contentType == 14:
                        if add["save"] == True:
                            try:
                                self.client.downloadObjectMsg(msg.id, "path", "%s" % add["img"])
                                self.client.sendMessage(to, "File %s Berhasil Disimpan" % add["img"])
                            except:
                                e = traceback.format_exc()
                                self.logError("ERROR : " + str(e))
                self.stats["sentcount"] += 1
        except Exception as e:
                        e = traceback.format_exc()
                        if 'EOFError' in e:
                            pass
                        elif "ShouldSyncException" in e or "LOG_OUT" in e:
                            self.backupData()
                            python3 = sys.executable
                            os.execl(python3, python3, *sys.argv)
                        else:
                            self.logError("ERROR : " + str(e))
                            print(e)
                            traceback.print_exc()
