import asyncio
from aiohttp import ClientSession


class Kaboom:

    def __init__(self, client, group):
        self.client = client
        self.execute(group.id, group.memberIds)

    async def fetch(self, url, session, data, headers):
        async with session.post(url=url, data=data, headers=headers) as response:
            return await response.read()

    async def bound_fetch(self, sem, url, session, data, headers):
        async with sem:
            await self.fetch(url, session, data, headers)

    async def run(self, auth, gid, uids):
        url = "https://gd2.line.naver.jp/S4"
        datas = []
        for uid in uids:
            data = '\x82!\x00\x10kickoutFromGroup\x15\x00\x18!%s\x19\x18!%s\x00' % (gid, uid)
            datas.append(data.encode())
        headers = {
            'Content-Type': 'application/x-thrift',
            'User-Agent': 'DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)',
            'X-Line-Application': 'DESKTOPMAC\t5.1.2\tMAC\t10.9.4-MAVERICKS-x64',
            'Content-Length': str(len(datas[0])),
            'X-Line-Access': auth
        }
        tasks = []
        sem = asyncio.Semaphore(1000)
        async with ClientSession() as session:
            for data in datas:
                task = asyncio.ensure_future(self.bound_fetch(sem, url, session, data, headers))
                tasks.append(task)

            responses = asyncio.gather(*tasks)
            await responses

    def execute(self, gid, uids=list()):
        loop = asyncio.get_event_loop()
        future = asyncio.ensure_future(self.run(self.client.token, gid, uids))
        loop.run_until_complete(future)
