# -*- coding: utf-8 -*-
from linepy import *
from akad.ttypes import OpType
from akad.ttypes import *
from akad.ttypes import ChatRoomAnnouncementContents
from akad import ttypes
from akad.ttypes import Message
from akad.ttypes import LoginRequest
from akad import ChannelService,TalkService,AuthService,AccountSupervisorService,BotService
from akad.AccountSupervisorService import *
from akad.ttypes import LoginRequest
from simplify import *
from difflib import SequenceMatcher
import unicodedata as udd
import livejson, requests
from io import BytesIO
from linepy.liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from googletrans import Translator
from collections import OrderedDict
import urllib.request
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil import parser
from random import randint
from bs4 import BeautifulSoup
from gtts import gTTS
from archimed import Archimed
from PIL import Image, ImageDraw, ImageFont
from ffmpy import FFmpeg
from multiprocessing import Pool, Process
from subprocess import Popen, PIPE
import platform
from ffmpy import FFmpeg
from youtube_dl import YoutubeDL
import youtube_dl
import threading
import wikipedia
import wiki
import pafy
from urllib.request import urlretrieve
from urllib.request import urlopen
from urllib.parse import urlencode,quote,urlparse,parse_qs,parse_qsl,urlunparse,urlsplit,urljoin,urldefrag,quote_plus,unquote
import html5lib, tempfile, goslate
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from Naked.toolshed.shell import execute_js
import timeago,LineService
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, base64, random, sys, json, codecs, threading, subprocess, glob, re, string, os, requests, six, ast, pytz, urllib, urllib3, urllib.parse, traceback, atexit, random, importlib
_session = requests.session()

mulai = time.time()
def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

add = {"img": {},"save": False,}
class selfbot():
    uid = None
    name = None
    client = None
    master = ["uba87449913e0ec7327510aa0c9345e43"]#
    help = "⌬⌬⌬⌬⌬⌬⌬⌬\t\n⌬ ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4 ⌬\t\n⌬⌬⌬⌬⌬⌬⌬⌬"
    duedate = None
    imgcmd = None
    vidcmd = None
    audiocmd = None
    rename = None
    pdfcmd = None
    musiccmd = None
    filecmd = None
    renamecon = False
    rcon = []
    rtext = ""
    imgprofile = False
    imgcover = False
    tempbots = []
    tempnames = []
    welcomeimage = False
    imgsender = ''
    invites = []
    stickercommand = ""
    stickercmd = ""
    addcmd = ""
    ceks = []
    yt = []
    stickertemp = False
    addsticker = False
    addcommand = False
    cctvSTICKER = False
    duedate = None
    imgsender = ''
    gtn = False
    gtnn = 0
    sider = {
        'readPoint':{},
        'readMember':{},
        'setTime':{},
        'ROM':{}}
    setTime = {}
    setTime = sider['setTime']
    sider2 = {
        'readPoint':{},
        'readMember':{},
        'setTime':{},
        'ROM':{}}
    setTime = {}
    setTime = sider2['setTime']
    with open("Cmd_data.json","r",encoding="utf_8_sig") as f:
        datas = json.loads(f.read(),object_pairs_hook=OrderedDict)
    reply = Simplify(client,datas=datas)

    def __init__(self,uid=None,name=None,client=None):
        self.uid = uid
        self.name = name
        self.client = client
        self.db = livejson.File("settings/%s.json"%uid)
        self.db1 = livejson.File("cctv/%s.json"%uid)
        self.db2 = livejson.File("sider/%s.json"%uid)
        self.nuker = livejson.File("nuker/%sjson"%uid)
        self.dxName = os.path.splitext(os.path.basename(__file__))[0]
        self.commands = {}
        self.perintah = {}
        keys = ['lastseen']
        for k in keys:
            if k not in self.db:
                self.db[k] = {}
        if 'ceksider' not in self.db1:
            self.db1['ceksider'] = {'on':[],'txt':'「 I see you 」'}
        if not "perintah" in self.db:
            self.db['perintah'] = self.perintah
            self.perintah = self.db["perintah"]
        else:
            self.perintah = self.db["perintah"]
        self.commands = {"chat":[],
                        "basic":[],
                        "protection":[],
                        "lists":[],
                        "stickers":{},
                        "cctvStickers":{},
                        "tmpstickers":{},
                        "invite":{},
                        "invitenames":{}}
        if not "commands" in self.db.keys():
            self.db['commands'] = self.commands
            self.commands = self.db["commands"]
        else:
            self.commands = self.db["commands"]
        self.imgcmds = {}
        if not "imgcmds" in self.db:
            self.db['imgcmds'] = self.imgcmds
            self.imgcmds = self.db["imgcmds"]
        else:
            self.imgcmds = self.db["imgcmds"]
        self.musiccmds = {}
        if not "musiccmds" in self.db:
            self.db['musiccmds'] = self.musiccmds
            self.musiccmds = self.db["musiccmds"]
        else:
            self.musiccmds = self.db["musiccmds"]
        self.audiocmds = {}
        if not "audiocmds" in self.db:
            self.db['audiocmds'] = self.audiocmds
            self.audiocmds = self.db["audiocmds"]
        else:
            self.audiocmds = self.db["audiocmds"]
        self.vidcmds = {}
        if not "vidcmds" in self.db:
            self.db['vidcmds'] = self.vidcmds
            self.vidcmds = self.db["vidcmds"]
        else:
            self.vidcmds = self.db["vidcmds"]
        self.settings = {"addmessage":None,
                         "reinvite":{},
                         "lurking":False,
                         "lurkers":[],
                         "lurkgroup":None,
                         "talkers":[],
                         "rname":[2,self.client.profile.displayName],
                         "sname":"default",
                         "protect":{},
                         "namelock":{},
                         "picon":{},
                         "allowban":{},
                         "autojoin":0,
                         "autolike":False,
                         "autoblock":False,
                         "autoread":False,
                         "autopurge":False,
                         "sleepmode":False,
                         "linkprotect":{},
                         "sleepmsg":"I'm not Online, please Pm later.",
                         "tagmessage":[False,"Stop tagging you retard."],
                         "buyer":"",
                         "sticker":{},
                         "author":{},
                         "chatbot":[],
                         "unsendMessage":False,
                         "learn":False,
                         "likemessage":"Autolike by ᴿᴳ_ˢᴱᴸᶠᴮᴼᵀˢ ᵛ.1.4",
                         "denyinvite":{}}
        if not "settings" in self.db:
            self.db['settings'] = self.settings
            self.settings = self.db["settings"]
        else:
            self.settings = self.db["settings"]
        self.wait = {'readPoint':{},
                     'readMember':{},
                     'setTime':{},
                     'ROM':{},
                     'cyduk':{},
                     'point':{},
                     'sidermem':{},
                     'stickermode':{}}
        if not "wait" in self.db1:
            self.db1['wait'] = self.wait
            self.wait = self.db1["wait"]
        else:
            self.wait = self.db1["wait"]
        self.stats = {"receivecount":0,
                      "sentcount":0,
                      "kickcount":0,
                      "cancelcount":0,
                      "follower":0,
                      "following":0,
                      "accpcount":0,
                      "destrcount":0,
                      "invtcount":0,
                      "upprofile":0,
                      "start":time.time(),
                      "reset":str(datetime.now).split()[0],
                      "ban":False,
                      "invite":False,
                      "kick":False,
                      "unban":False,
                      "bot":False,
                      "expel":False,
                      "repeat":False,
                      "mute":False,
                      "staff":False,
                      "gift":False,
                      "autoadd":True,
                      "locate":False,
                      "info":False,
                      "invitespam":False,
                      "clone":False,
                      "profilevid":False,
                      "profilepic":False,
                      "cctvPic":{},
                      "sticker":{},
                      "notag":[],
                      "wordban":[],
                      "banned":[],
                      "rcon":[],
                      "unmute":False,
                      "changeCover":False,
                      "changeProfileCover":"",
                      "welcomemsg":{},
                      "welcomeimage":{},
                      "picture":{},
                      "cover":{},
                      "video":{},
                      "gpic":{},
                      "stafflist":[],
                      "botlist":[],
                      "mutelist":[],
                      "changeProfileVideo":{
                              "picture":"",
                              "stage":0,
                              "status":False,
                              "video":""},
                      "changeVideo":False,
                      "pmDetail": {},
                      "pmID": {},
                      "pmText": {},
                      "duedate":str(datetime.now()+relativedelta(months=1))}
        if not "stats" in self.db:
            self.db['stats'] = self.stats
            self.stats = self.db["stats"]
        else:
            self.stats = self.db["stats"]
        if "gift" not in self.stats:
            self.stats["gift"] = False
        if "clone" not in self.stats:
            self.stats["clone"] = False
        self.duedate = parser.parse(self.stats["duedate"])
        self.pm = self.stats['pmID']
        self.listpm = list(self.pm)            

    def reset(self):
        if str(datetime.now()).split()[0] != self.stats['reset']:
            self.stats['receivecount'] = 0
            self.stats['sentcount'] = 0
            self.stats['kickcount'] = 0
            self.stats['cancelcount'] = 0
            self.stats['follower'] = 0
            self.stats['following'] = 0
            self.stats['accpcount'] = 0
            self.stats['destrcount'] = 0
            self.stats['invtcount'] = 0
            self.stats['upprofile'] = 0
            #self.stats['reset'] = str(datetime.now).split()[0]

    def get_soup(self,url,header):
        return BeautifulSoup(urllib.request.urlopen(urllib.request.Request(url,headers=header)), "html.parser")

    def clear(self):
        self.stats["ban"] = False
        self.stats["unban"] = False
        self.stats["staff"] = False
        self.stats["expel"] = False
        self.stats["mute"] = False
        self.stats["unmute"] = False
        self.stats["bot"] = False
        self.stats["locate"] = False
        self.stats["info"] = False
        self.stats["clone"] = False
        self.stats["invitespam"] = False
        self.stats["profilevid"] = False
        self.stats["profilepic"] = False

    def sendReplyMention(self,RynId, to, text="", mids=[]):
        arrData = ""
        arr = []
        mention = "@rynkings__ "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ""
            for mid in mids:
                textx += str(texts[mids.index(mid)])
                slen = len(textx)
                elen = len(textx) + 15
                arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ""
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        self.client.sendReplyMessage(RynId, to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        
    def sendTagProfile(self, to, mid, firstmessage, lastmessage, senderIcon="", senderName=""):
        try:
            arrData = ""
            text = "%s " %(str(firstmessage))
            arr = []
            mention = "@x "
            slen = str(len(text))
            elen = str(len(text) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':mid}
            arr.append(arrData)
            text += mention + str(lastmessage)
            self.client.sendMessage(to,"{}".format(str(text)),{'MSG_SENDER_ICON': senderIcon, 'MSG_SENDER_NAME': senderName, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')})
        except Exception as error:
            print(error)

    def restart_program(self):
        python = sys.executable
        os.execl(python, python, * sys.argv)

    def Tagall1(self, to, nama):
        aa = ""
        bb = ""
        strt = int(19)
        akh = int(19)
        nm = nama
        for mm in nm:
          akh = akh + 2
          aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
          strt = strt + 6
          akh = akh + 4
          bb += "⌬ @x \n"
        aa = (aa[:int(len(aa)-1)])
        msg = Message()
        msg.to = to
        tst = u'♬♬♬♬♬♬♬♬\t\n♬     Tagall      ♬\t\n♬♬♬♬♬♬♬♬\n\n'
        msg.text = "「Mention All」   \n"+bb + "    「 Total: " + str(len(nm)) +  " Mention 」"
        msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
        try:
           self.client.sendMessage(to,msg.text,msg.contentMetadata)
        except Exception as error:
           print(error)

    def logError(self,text):
      try:
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        timeHours = datetime.strftime(timeNow,"(%H:%M)")
        day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
        hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
        bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
        inihari = datetime.now(tz=tz)
        hr = inihari.strftime('%A')
        bln = inihari.strftime('%m')
        for i in range(len(day)):
            if hr == day[i]: hasil = hari[i]
        for k in range(0, len(bulan)):
            if bln == str(k): bln = bulan[k-1]
        time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
        with open("log/{}".format(self.dxName),"a") as error:
            error.write("\n[ {} ] {}".format(str(time), text))
      except Exception as e:
        traceback.print_tb(e.__traceback__)

    def sendMention(self, to, txt="", mids=[]):
        arrData = ""
        arr = []
        mention = "@dm"
        if mids == []:
            raise Exception("Invalid mids")
        elif "@!" in txt:
            if txt.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = txt.split("@!")
            textx = ""
            for mid in mids:
                textx += str(texts[mids.index(mid)])
                slen = len(textx)
                elen = len(textx) + 15
                arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ""
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(txt)
        self.client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

    def sendtag(self, to, text="",eto="", mids=[], isUnicode=False):
        arrData = ""
        arr = []
        mention = "@dv "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ""
            unicode = ""
            if isUnicode:
                for mid in mids:
                    unicode += str(texts[mids.index(mid)].encode('unicode-escape'))
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx) if unicode == textx else len(textx) + unicode.count('U0')
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            else:
                for mid in mids:
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx)
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            textx += str(texts[len(mids)])
        else:
            raise Exception("Invalid mention position")
        self.client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    def listdata(self,to,stats,text='',ps='',data=[]):
        k = len(data)//20
        for aa in range(k+1):
            if aa == 0:dd = ' 「 {} 」'.format(text,ps);no=aa
            else:dd = ' 「 {} 」'.format(text,ps);no=aa*20
            msgas = dd
            for i in data[aa*20 : (aa+1)*20]:
                no+=1
                if no == len(data):msgas+='\n{}• @!'.format(no)
                else:msgas+='\n{}• @!'.format(no)
            if data == []:pass
            else:self.sendtag(to, msgas,' 「 {} 」'.format(ps), data[aa*20: (aa+1)*20])

    def abort(self,to):
        self.stats["repeat"] = False
        if self.stats["ban"]:
            self.stats["ban"] = False
            self.client.sendText(to,"Ban aborted.")
        elif self.stats["locate"]:
            self.stats["locate"] = False
            self.client.sendText(to,"Locate aborted.")
        elif self.stats["info"]:
            self.stats["info"] = False
            self.client.sendText(to,"info aborted.")
        elif self.stats["invite"]:
            self.stats["invite"] = False
            self.client.sendText(to,"Invite aborted.")
        elif self.stats["kick"]:
            self.stats["kick"] = False
            self.client.sendText(to,"Kick aborted.")
        elif self.stats["unban"]:
            self.stats["unban"] = False
            self.client.sendText(to,"Unban aborted.")
        elif self.stats["staff"]:
            self.stats["staff"] = False
            self.client.sendText(to,"Unban aborted.")
        elif self.stats["expel"]:
            self.stats["expel"] = False
            self.client.sendText(to,"Expel aborted.")
        elif self.stats["bot"]:
            self.stats["bot"] = False
            self.client.sendText(to,"Bot aborted.")
        elif self.stats["gift"]:
            self.stats["gift"] = False
            self.client.sendText(to,"Gift aborted.")
        elif self.stats["clone"]:
            self.stats["clone"] = False
            self.client.sendText(to,"Clone aborted.")
        elif self.imgsender != '':
            self.imgsender = ''
            self.client.sendText(to,"Send image aborted.")
        else:
            self.client.sendText(to,"Nothing to abort.")

    def mention(self,msg,targets):
        if "MENTION" in msg.contentMetadata:
            msg.contentMetadata["MENTION"] = json.loads(msg.contentMetadata["MENTION"])
            for m in msg.contentMetadata["MENTION"]["MENTIONEES"]:
                targets.append(m["M"])

    def listcon(self,to,msg,num,stats,data=[]):
        if data == []:
            self.client.sendMessage(to, " 「 Empty List 」")
        else:
            nama = data
            no = 0
            targets = []
            selection = Archimed(num,range(1,len(nama)+1))
            for i in selection.parse():
                targets.append(nama[i-1])
            for target in targets:
                try:
                    self.client.sendContact(msg.to,target)
                except Exception as e:traceback.print_exc()
    def listinv(self,to,msg,num,stats,data=[]):
        if data == []:
            self.client.sendMessage(to, " 「 Empty List 」")
        else:
            nama = data
            no = 0
            targets = []
            selection = Archimed(num,range(1,len(nama)+1))
            for i in selection.parse():
                targets.append(nama[i-1])
            for target in targets:
                try:
                    self.client.inviteIntoGroup(msg.to,[target])
                except Exception as e:traceback.print_exc()
    def gcon(self,to,msg):
        data = msg.text.replace('.gcon',"")
        text = data.split(' ')
        com = str(text[1])
        gid = self.client.getGroupIdsJoined()
        gs = self.client.getGroup(to)
        nama = [contact.mid for contact in gs.members]
        no = 0
        targets = []
        selection = Archimed(com,range(1,len(nama)+1))
        for i in selection.parse():
            targets.append(nama[i-1])
        for target in targets:
            try:
                self.client.sendContact(msg.to,target)
            except Exception as e:print(e)

    def mentionmention(self,to,stats, text, dataMid=[], pl='', ps='',pg='',pt=[]):
        arr = []
        list_text=ps
        i=0
        no=pl
        if pg == 'MENTIONALLME':
            for l in dataMid:
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text+text
        if pg == 'DELFL':
            for l in dataMid:
                try:
                    self.client.deleteContact(l)
                    a = 'Remove Friend'
                except:
                    a = 'Not Friend User'
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=text+list_text
        if pg == 'ADDFL':
            lss = self.client.refreshContacts()
            for l in dataMid:
                if not l in self.uid and l not in lss:
                   self.client.findAndAddContactsByMid(l)
                no+=1
                list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDST':
            for l in dataMid:
              if not l in self.uid:
                if l in stats["stafflist"]:
                    a = 'Already Staff'
                else:
                    a = 'Add staff'
                    stats["stafflist"].append(l)
                    self.client.findAndAddContactsByMid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELST':
            for l in dataMid:
                if l not in stats["stafflist"]:
                    a = 'Not staff'
                else:
                    a = 'Remove staff'
                    stats["stafflist"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDBOT':
            for l in dataMid:
              if not l in self.uid:
                if l in stats["botlist"]:
                    a = 'Already Bot'
                else:
                    a = 'Add Bot'
                    stats["botlist"].append(l)
                    self.client.findAndAddContactsByMid(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELBOT':
            for l in dataMid:
                if l not in stats["botlist"]:
                    a = 'Not Bot'
                else:
                    a = 'Remove Bot'
                    stats["botlist"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDMUTE':
            for l in dataMid:
              if not l in self.uid:
                if l in stats["mutelist"]:
                    a = 'Already Mute'
                else:
                    a = 'Add Mute'
                    stats["mutelist"].append(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELMUTE':
            for l in dataMid:
                if l not in stats["mutelist"]:
                    a = 'Not Mute'
                else:
                    a = 'Remove Mute'
                    stats["mutelist"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'ADDBAN':
            for l in dataMid:
              if not l in self.uid:
                if l in stats["banned"]:
                    a = 'Already Banned'
                else:
                    a = 'Add Banned'
                    stats["banned"].append(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        if pg == 'DELBAN':
            for l in dataMid:
                if l not in stats["banned"]:
                    a = 'Not Banned'
                else:
                    a = 'Remove Banned'
                    stats["banned"].remove(l)
                no+=1
                if no == len(pt):list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                else:list_text+='\n'+str(no)+'• @[oup-'+str(i)+'] '
                i=i+1
            text=list_text
        i=0
        for l in dataMid:
            if l not in self.uid:
                mid=l
                name='@[oup-'+str(i)+']'
                ln_text=text.replace('\n',' ')
                if ln_text.find(name):
                    line_s=int( ln_text.index(name) )
                    line_e=(int(line_s)+int( len(name) ))
                arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
                arr.append(arrData)
                i=i+1
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        if pg == 'MENTIONALLUNSED':self.client.unsendMessage(self.client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}).id)
        else:self.client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')})

    def issueLiffView(self, to):
        az = LiffChatContext(to)
        ax = LiffContext(chat=az)
        lf = LiffViewRequest('1646011835-9MXEx20v', ax)
        return self.client.issueLiffView(lf)

    def m_exec_thread(self,msg):
        try:
            if msg.toType == 0: msg.to = msg.to
            sys.stdout = open("tmp/temp.txt","w")
            exec(msg.text.replace("!run","").replace("import os",""))
            sys.stdout.close()
            sys.stdout = sys.__stdout__
        except Exception as e:
            self.client.sendMessage(msg.to, str(e))

    def sendTemplate(self, to, data):
        token = self.issueLiffView(to)
        url = 'https://api.line.me/message/v3/share'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer %s' % token.accessToken
        }
        data = {
            'messages': [data]
        }
        res = requests.post(url, headers=headers, data=json.dumps(data))
        print(res.text)

    def translate(self, to_translate, to_language="auto", language="auto"):
        agent = {'user-Agent': "Mozilla/4.0(compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50/27; .NET CLR 3.0.04506.0)"}
        user_agent = "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)","Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0","Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0","Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5","Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0","Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0","Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0","Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
        base_link="http://translate.google.com/m?hl=%s&sl=%s&q=%s"
        if(six.PY2):
            link = base_link % (to_language, language, urllib.pathname2url(to_translate))
            request = urllib2.Request(link, headers=agent)
            page = urllib2.urlopen(request).read()
        else:
            link = base_link % (to_language, language, urllib.parse.quote(to_translate))
            request = urllib.request.Request(link, headers=agent)
            page = urllib.request.urlopen(request).read().decode('utf-8')
        expr = r'class="t0">(.*?)<'
        result = re.findall(expr,page)
        if(len(result)==0):
            return("")
        return(result[0])

    def changeVideoAndPictureProfile(self, pict, vids):
        try:
            files = {'file': open(vids, 'rb')}
            obs_params = self.client.genOBSParams({'oid': self.uid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
            data = {'params': obs_params}
            r_vp = self.client.server.postContent('{}/talk/vp/upload.nhn'.format(str(self.client.server.LINE_OBS_DOMAIN)), data=data, files=files)
            if r_vp.status_code != 201:
                return "Failed update profile"
            self.client.updateProfilePicture(pict, 'vp')
            return "Success update profile"
        except Exception as e:
            raise Exception("Error change video and picture profile {}".format(str(e)))

    def sendTagg(self, to, mid, firstmessage, lastmessage):
        try:
            arrData = ""
            text = "%s " %(str(firstmessage))
            arr = []
            mention = "@x "
            slen = str(len(text))
            elen = str(len(text) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':mid}
            arr.append(arrData)
            text += mention + str(lastmessage)
            self.client.sendMessage(to,"{}".format(str(text)),contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')})
        except Exception as error:
            print(error)

    def changeProfileVideo(self, to):
        if self.stats['changeProfileVideo']['picture'] == None:
            return self.client.sendText(to, "Foto tidak ditemukan")
        elif self.stats['changeProfileVideo']['video'] == None:
            return self.client.sendText(to, "Video tidak ditemukan")
        else:
            path = self.stats['changeProfileVideo']['video']
            files = {'file': open(path, 'rb')}
            obs_params = self.client.genOBSParams({'oid': self.client.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
            data = {'params': obs_params}
            r_vp = self.client.server.postContent('{}/talk/vp/upload.nhn'.format(str(self.client.server.LINE_OBS_DOMAIN)), data=data, files=files)
            if r_vp.status_code != 201:
                return self.client.sendText(to, "Failed update profile")
            path_p = self.stats['changeProfileVideo']['picture']
            self.stats['changeProfileVideo']['status'] = False
            self.client.updateProfilePicture(path_p, 'vp')

    def cloneProfile(self, mid):
        contact = self.client.getContact(mid)
        if contact.videoProfile == None:
            self.client.cloneContactProfile(mid)
        else:
            profile = self.client.getProfile()
            profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
            self.client.updateProfile(profile)
            pict = self.client.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
            vids = self.client.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
            self.changeVideoAndPictureProfile(pict, vids)
        coverId = self.client.getProfileDetail(mid)['result']['objectId']
        self.client.updateProfileCoverById(coverId)

    def receive_message(self,op):
        try:
            msg = op.message
            to = msg.to
            of = msg._from
            silent = False
            rname = self.settings["rnaame"][1].lower() + " "
            if msg.toType == 0:
                if msg.contentType == 0:
                    txt = msg.text.lower()
                    txt = " ".join(txt.split())
                    if of not in self.stats["pmID"]:
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        readTime = timeNow.strftime('%H.%M')
                        self.stats["pmDetail"][of] = self.client.getContact(of).displayName + "\nat time" + readTime
                        self.stats["pmText"][of] = "\n\n----[ Message ]----\n• At Time: " + readTime + " WIB\n• Text Message:\n" + msg.text
                        self.stats["pmID"][of] = True
                    else:
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        readTime = timeNow.strftime('%H.%M')
                        self.stats["pmText"][of] += "\n\n----[ Message ]----\n• At Time: " + readTime + " WIB\n• Text Message:\n" + msg.text
                    self.reset()
                if of not in self.master:
                    if self.settings["sleepmode"]:
                        if msg.text:
                            self.client.sendText(of,self.settings["sleepmsg"])

            if msg.toType == 2:
                if msg.text:
                    txt = " ".join(msg.text.lower().split())
                    if of in self.master:
                        if txt == rname + "rejectall":
                            gid = self.client.getGroupIdsInvited()
                            for i in gid:
                                self.client.rejectGroupInvitation(i)
                            self.client.sendMessage(to, "Succes rejectall groups")
                        if txt == "..addmonth" or txt == rname + "addmonth":
                            self.duedate = self.duedate + relativedelta(months=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.client.sendMessage(msg,"Time has been extended with 1 month.")
                        elif txt == "..delmonth" or txt == rname + "delmonth":
                            self.duedate = self.duedate - relativedelta(months=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.client.sendMessage(msg,"Time has been deducted with 1 month.")
                        elif txt == "..addweek" or txt == rname + "addweek":
                            self.duedate = self.duedate + relativedelta(weeks=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.client.sendMessage(msg,"Time has been extended with 1 week.")
                        elif txt == "..delweek" or txt == rname + "delweek":
                            self.duedate = self.duedate - relativedelta(weeks=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.client.sendMessage(msg,"Time has been deducted with 1 week.")
                        elif txt == "..addday" or txt == rname + "addday":
                            self.duedate = self.duedate + relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.client.sendMessage(msg,"Time has been extended with 1 day.")
                        elif txt == "..delday" or txt == rname + "delday":
                            self.duedate = self.duedate - relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            self.client.sendMessage(msg,"Time has been deducted with 1 day.")
                        elif txt == "..reduce date" or txt == rname + "reduce date":
                            self.duedate = self.duedate - relativedelta(months=1)
                            self.duedate = self.duedate - relativedelta(weeks=1)
                            self.duedate = self.duedate - relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            timeleft = self.duedate - datetime.now()
                            days, seconds = timeleft.days, timeleft.seconds
                            hours = seconds / 3600
                            minutes = (seconds / 60) % 60
                            mes = "Reduce date: %s days, %s hours, %s minutes"%(days,round(hours),round(minutes))
                            self.client.sendMessage(msg,mes)
                        elif txt == "..extend date" or txt == rname + "extend date":
                            self.duedate = self.duedate + relativedelta(months=1)
                            self.duedate = self.duedate + relativedelta(weeks=1)
                            self.duedate = self.duedate + relativedelta(days=1)
                            self.stats["duedate"] = str(self.duedate)
                            timeleft = self.duedate - datetime.now()
                            days, seconds = timeleft.days, timeleft.seconds
                            hours = seconds / 3600
                            minutes = (seconds / 60) % 60
                            mes = "Extend date: %s days, %s hours, %s minutes"%(days,round(hours),round(minutes))
                            self.client.sendMessage(msg,mes)
                        elif txt == "..duedate" or txt == rname + "duedate":
                            duedate = str(self.duedate).split()[0]
                            self.client.sendMessage(msg,duedate)
                        elif txt == "..timeleft":
                            timeleft = self.duedate - datetime.now()
                            days, seconds = timeleft.days, timeleft.seconds
                            hours = seconds / 3600
                            minutes = (seconds / 60) % 60
                            mes = "Time to due: %s days, %s hours, %s minutes"%(days,round(hours),round(minutes))
                            self.client.sendMessage(msg,mes)
                        elif txt == "...speed":
                            begin = time.time()
                            self.client.getProfile()
                            end = time.time() - begin
                            self.client.sendMessage(msg,"Time:\n%s"%round(end,5))
                if datetime.now() < self.duedate:
                    if self.settings["autoread"]:
                        if msg.toType == 0:
                            self.client.sendChatChecked(of,msg.id)
                        else:
                            self.client.sendChatChecked(to,msg.id)
                    if of in self.stats["mutelist"]:
                        a = self.client.getContact(of)
                        data = {"type":"text","text":"I said shut the fuck up..","sentBy":{"label":'{}'.format(str(a.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(of),"linkUrl":"line://ti/p/~regathb"}}
                        self.sendTemplate(to,data)
                        self.client.kickoutFromGroup(to,[of])
                    if msg.text in self.stats['wordban']:
                        if of not in self.stats['stafflist'] and of not in self.stats['botlist']:
                            a = self.client.getContact(of)
                            data = {"type":"text","text":"Please shut up the fuck up..","sentBy":{"label":'{}'.format(str(a.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(of),"linkUrl":"line://ti/p/~regathb"}}
                            self.sendTemplate(to,data)
                            self.client.kickoutFromGroup(to,[of])
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        if self.settings["tagmessage"][0]:
                            name = re.findall(r'@(\w+)', msg.text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            for mention in mentionees:
                                if mention['M'] in self.uid:
                                    uid = self.client.getContact(of).mid
                                    Name = self.client.getContact(of).displayName
                                    Text = self.settings["tagmessage"][1]
                                    try:
                                        self.client.mimictext(to,Text,uid,Name)
                                    except Exception as e:
                                        traceback.print_exc()
                                        self.logError("ERROR : " + str(e))
                    if msg.text:
                        txt = " ".join(msg.text.lower().split())
                        """""""""""""""
                        Member Commands
                        """""""""""""""
                        if to in self.settings["author"]:
                            if txt == 'responsenaaame' or txt == 'rnaaame':
                                if self.settings["rname"][0] == 2:
                                    self.client.sendText(to,self.settings["rname"][1])
                                elif self.settings["rname"][0] == 1:
                                    if of in self.stats["stafflist"]:
                                        self.client.sendText(to,self.settings["rname"][1])
                            if txt == rname + "meee" or txt == "meeee":a = self.client.getContact(of);b = self.client.profile.displayName;c = self.client.profile.userid;data = {"type": "flex","altText": b,"contents": {"type": "bubble","styles": {"body": {"backgroundColor": "#ffffff"},"footer": {"backgroundColor": "#ffffff"}},"hero": {"type": "image","url": "https://os.line.naver.jp/os/p/{}".format(of),"size": "full","aspectRatio": "20:13","aspectMode": "cover","action": {"type": "uri","uri": "line://ti/p/UeVAzuafAU"}},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": '{}'.format(str(a.displayName)),"weight": "bold","size": "xl"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Name","color": "#aaaaaa","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(a.displayName)),"color": "#aaaaaa","size": "sm","flex": 2}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Status","color": "#aaaaaa","size": "sm","flex": 1},{"type": "text","text": "{}".format(str(a.statusMessage if a.statusMessage != '' else 'line://ti/p/UeVAzuafAU')),"color": "#aaaaaa","wrap": True,"size": "sm","flex": 2}]}]}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Official Account","uri": "line://ti/p/~"+c}},{"type": "spacer","size": "sm",}],"flex": 0}}};self.sendTemplate(to,data)
                            if self.commands["stickers"] != {}:
                                if txt in self.commands["stickers"].keys():
                                    sticker = self.commands["stickers"][txt]
                                    self.client.generateReplyMessage(msg.id)
                                    sender = of
                                    asw = self.client.getContact(of).displayName
                                    self.client.sticker(msg.id,to, sender, asw, sticker[0],sticker[1],sticker[2])
                            if self.commands["tmpstickers"] != {}:
                                if txt in self.commands["tmpstickers"].keys():
                                    sticker = self.commands["tmpstickers"][txt]
                                    ids = sticker[0]
                                    ipg = sticker[1]
                                    a = self.client.shop.getProduct(packageID=int(ipg), language='ID', country='ID')
                                    if a.hasAnimation == True:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/IOS/sticker_animation@2x.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
                                    else:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/ANDROID/sticker.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
                            if txt in self.perintah:data = {"type":"text","text":self.perintah[txt],"sentBy":{"label":'{}'.format(str(self.client.profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(self.client.profile.mid),"linkUrl":"line://ti/p/~"+self.client.profile.userid}};self.sendTemplate(to,data)
                            if txt in self.imgcmds:self.client.sendImage(to,self.imgcmds[txt])                        
                            if txt in self.vidcmds:self.client.sendVideo(to,self.vidcmds[txt])
                            if txt in self.audiocmds:self.client.sendAudio(to,self.audiocmds[txt])
                            if txt in self.musiccmds:self.client.sendAudio(to,self.musiccmds[txt])
            self.stats["receivecount"] += 1
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    def send_message(self,op):
        try:
            msg = op.message
            to = msg.to
            of = msg._from
            silent = False
            #rcontact = list(self.stats['rcon'])
            if datetime.now() < self.duedate:
                if msg.toType == 0:
                    if msg.text:
                        txt = " ".join(msg.text.lower().split())
                        if '.!silent' in txt:
                            silent = True
                        if ".!remote:" in txt:
                            func = lambda s: s[:1].lower() + s[1:] if s else ''
                            if not "!remote: " in txt:
                                number = txt.split(".!remote:")[1]
                                number = number.split()[0]
                                gid = self.client.getGroupIdsJoined()
                                if number.isdigit():
                                    number = int(number)
                                    group = gid[number]
                                    to = group
                                txt = txt.replace("!remote:%s"%number,"").lstrip().rstrip()
                                if ".!remote:" in msg.text:
                                    msg.text = msg.text.replace("!remote:%s"%number,"").lstrip().rstrip()
                                    func(msg.text)
                                else:
                                    msg.text = msg.text.replace("!Remote:%s"%number,"").lstrip().rstrip()
                                    func(msg.text)
                                self.client.sendText(msg.to,"Succes remote for %s"%self.client.getGroup(group).name)
                        if self.commands["stickers"] != {}:
                                if txt in self.commands["stickers"].keys():
                                    sticker = self.commands["stickers"][txt]
                                    self.client.send_sticker(to,sticker[0],sticker[1],sticker[2])
                        if self.commands["tmpstickers"] != {}:
                                if txt in self.commands["tmpstickers"].keys():
                                    sticker = self.commands["tmpstickers"][txt]
                                    ids = sticker[0]
                                    ipg = sticker[1]
                                    a = self.client.shop.getProduct(packageID=int(ipg), language='ID', country='ID')
                                    if a.hasAnimation == True:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/IOS/sticker_animation@2x.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
                                    else:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/ANDROID/sticker.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
                        if txt in self.perintah:data = {"type":"text","text":self.perintah[txt],"sentBy":{"label":'{}'.format(str(self.client.profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(self.client.profile.mid),"linkUrl":"line://ti/p/~{}".format(self.client.profile.userid)}};self.sendTemplate(to,data)
                        if txt in self.imgcmds:self.client.sendImage(to,self.imgcmds[txt])                        
                        if txt in self.vidcmds:self.client.sendVideo(to,self.vidcmds[txt])
                        if txt in self.audiocmds:self.client.sendAudio(to,self.audiocmds[txt])
                        if txt in self.musiccmds:self.client.sendAudio(to,self.musiccmds[txt])
                        if txt == "..picture":profile = self.client.getContact(to);self.client.sendImageWithURL(to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                        if txt == "..cover":profile = self.client.getProfileCoverURL(to);self.client.sendImageWithURL(to,profile)
                        if txt == "!.lineid":self.client.sendText(to, self.client.profile.userid)
                        if txt == ".@":self.sendMention(to,".@!",[to])
######## EXC
#########################
                        if msg.text.startswith('!.run\n'):
                            try:
                                self.reply.addFuncInterrupt("m_exec_thread",self.m_exec_thread(msg))
                            except:
                                traceback.print_exc()
                        if txt == "!.stats":
                            umid = self.client.profile.mid
                            uid = self.client.profile.userid
                            try:
                                arr = []
                                timeNow = time.time()
                                runtime = timeNow - self.stats['start']
                                runtime = format_timespan(runtime)
                                contact = self.client.getContact(self.uid)
                                grouplist = self.client.getGroupIdsJoined()
                                pendinglist = self.client.getGroupIdsInvited()
                                contactlist = self.client.getAllContactIds()
                                blockedlist = self.client.getBlockedContactIds()
                                autoblock = self.client.talk.getBlockedRecommendationIds() + self.client.getBlockedContactIds()
                                seal = self.client.getSettings().e2eeEnable
                                fil = self.client.getSettings().privacyReceiveMessagesFromNotFriend
                                src = self.client.getSettings().privacySearchByUserid
                                if src == True:alid = "Enabled"
                                else:alid = "Disabled"
                                if seal == True:letsel = "Enabled"
                                if seal == False:letsel = "Disabled"
                                if fil == True:fpes = "Disabled"
                                if fil == False:fpes = "Enabled"
                                ret_ = "\nAccount Status:"
                                ret_ += "\n\n🎲 Name : {}".format(contact.displayName)
                                #ret_ += "\n🎲 LineId : {}".format(uid)
                                ret_ += "\n🎲 Group : {}".format(str(len(grouplist)))
                                ret_ += "\n🎲 Gpending : {}".format(str(len(pendinglist)))
                                ret_ += "\n🎲 Friend : {}".format(str(len(contactlist)))
                                ret_ += "\n🎲 Blocked : {}".format(str(len(blockedlist)))
                                ret_ += "\n🎲 AutoBlock : {}".format(str(len(autoblock)))
                                ret_ += "\n🎲 Cancel : {}".format(self.stats["cancelcount"])
                                ret_ += "\n🎲 Unsend : {}".format(self.stats["destrcount"])
                                ret_ += "\n🎲 Kick : {}".format(self.stats["kickcount"])
                                ret_ += "\n🎲 Invite : {}".format(self.stats["invtcount"])
                                ret_ += "\n🎲 Accept : {}".format(self.stats["accpcount"])
                                ret_ += "\n🎲 Updated : {}".format(self.stats["upprofile"])
                                ret_ += "\n🎲 Follower : {}".format(self.stats["follower"])
                                ret_ += "\n🎲 Following : {}".format(self.stats["following"])
                                ret_ += "\n🎲 Messages sent : {}".format(self.stats["sentcount"])
                                ret_ += "\n🎲 Messages received : {}".format(self.stats["receivecount"])
                                ret_ += "\n🎲 Filter Msg : {}".format(fpes)
                                ret_ += "\n🎲 Allow Id Add : {}".format(alid)
                                ret_ += "\n🎲 Latter Sealing : {}".format(letsel)
                                ret_ += "\n🎲 Running: {}".format(str(runtime))
                                self.sendTagg(to,umid,"Sender:",str(ret_))
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt.startswith("!gift"):
                            if txt == '!..gift':
                                self.client.sendGift(to,'2351','sticker')
                            else:
                                amount = txt.split()[1]
                                if amount.isdigit():
                                    amount = int(amount)
                                    if amount <= 20:
                                        for i in range(0,amount):
                                            self.client.sendGift(to,'2351','sticker')
                                    else:
                                        self.client.sendText(to,"Max: 20.")
                        if txt.startswith("!..rnaame "):
                            if '!.off' in txt:
                                self.settings["rnaame"][0] = 0
                                if not silent:self.client.sendText(to,"Responsename disabled.")
                            elif '!staff' in txt:
                                self.settings["rnaame"][0] = 1
                                if not silent:self.client.sendText(to,"Responsename enabled for staff only.")
                            elif '!.on' in txt:
                                self.settings["rname"][0] = 2
                                if not silent:self.client.sendText(to,"Responsename enabled.")
                            else:
                                rname = txt.replace("!rname","").lstrip().rstrip()
                                self.settings["rname"][1] = rname
                                if not silent:self.client.sendText(to,"Responsename updated to: %s."%rname)
                        if txt == "!..speed":
                            b = time.time()
                            for i in range(10):
                                self.client.getProfile()
                            end = time.time() - b
                            self.client.sendText(to,"Time:\n%s"%round(end/10,5))
                        if txt == "!.groups":
                            gid = self.client.getGroupIdsJoined()
                            tst = "Grouplist:"
                            count = 1
                            for group in gid:
                                Gname = self.client.getGroup(group).name
                                gc = self.client.getGroup(group)
                                tst += "\n%s - %s (%s)"%(count,Gname,len(gc.members))
                                count += 1
                            self.client.sendText(to,tst)
                        if txt.startswith("...xxx "):
                            start = time.time()
                            try:
                                proses = txt.split(" ")
                                urutan = txt.replace(proses[0] + " ","")
                                count = urutan.split("/")
                                search = str(count[0])
                                if search in [""," ",".xxx:","-xxx",".xxx",",xxx"]:
                                    self.client.sendText(to,"Format salah")
                                else:
                                    r = requests.get("https://api.avgle.com/v1/search/{}/1?limit=10".format(str(search)));data = json.loads(r.text);elapsed_time = time.time() - start
                                    if len(count) == 1:
                                        if data["response"]["videos"] == []:
                                            self.client.sendText(to,"Video tidak tersedia")
                                        else:
                                            no = 0
                                            hasil = "🎬 Result adult video\n"
                                            for aa in data["response"]["videos"]:
                                                no += 1
                                                hasil += "\n{}. {}".format(str(no), str(aa["title"]))
                                            hasil += "\n\n🎬 Total {} video".format(str(len(data["response"]["videos"])));hasil += "\nTime : {} Seconds".format(str(elapsed_time)) ;self.client.sendText(to,hasil);self.client.sendText(to,"🔍 Informasi detail :\n\nExample:\n.xxx {}/1".format(str(search)))
                                    elif len(count) == 2:
                                        try:
                                            num = int(count[1])
                                            b = data["response"]["videos"][num - 1]
                                            c = str(b["vid"]);d = requests.get("https://api.avgle.com/v1/video/"+str(c))
                                            data1 = json.loads(d.text)
                                            elapsed_time2 = time.time() - start;hasil = "🎬 "+str(data1["response"]["video"]["title"]);hasil += "\n\nDurasi : {}".format(str(data1["response"]["video"]["duration"]));hasil += "\nKualitas HD : "+str(data1["response"]["video"]["hd"]);hasil += "\nDitonton "+str(data1["response"]["video"]["viewnumber"]);hasil += "\nLink video : "+str(data1["response"]["video"]["video_url"]);hasil += "\nLink embed : "+str(data1["response"]["video"]["embedded_url"])
                                            hasil += "\n\nTime : {} Seconds".format(str(elapsed_time2))
                                            gambar = str(data1["response"]["video"]["preview_url"])
                                            review = str(data1["response"]["video"]["preview_video_url"])
                                            path = self.client.downloadFileURL(gambar)
                                            path1 = self.client.downloadFileURL(review);self.client.sendImage(to,path);self.client.sendVideo(to,path1);self.client.sendText(to,hasil);self.client.deleteFile(path);self.client.deleteFile(path1)
                                        except Exception as e:self.client.sendText(to,"{}".format(str(e)))
                            except Exception as e:
                                self.client.sendText(to,"{}".format(str(e)))
                        if txt == "!..me":self.client.sendContact(to,of);ticket = self.client.getUserTicket().id;user = self.client.getContact(of);name = user.displayName;bio = user.statusMessage;pic = "http://dl.profile.line-cdn.net//{}".format(str(user.pictureStatus));self.client.sendMessage(to, name, contentMetadata={'i-linkUri': str(ticket), 'id': 'mt000000000a6b79f9', 'countryCode': 'ID', 'previewUrl':str(pic), 'linkUri': str(ticket), 'ORGCONTP': 'MUSIC', 'a-linkUri': str(ticket), 'subText': "\n"+str(bio), 'type': 'mt','a-installUrl': str(ticket), 'a-packageName': 'com.spotify.music', 'text': str(name), 'i-installUrl': str(ticket)}, contentType=19)
                        if txt == '!..help':
                            tst = "%s\nCommands:\n\n"%self.help
                            cmds = ['me','mid','music','ymp3','ymp4',"unsend","picture","cover","@","gift","speed","groups","stats","silent","remote","syoutube","search youtube","ytmp3","ytmp4","lineid","xxx"]
                            tst += "  ⚙️ Pm ⚙️\n  —————"
                            for command in cmds:
                                tst += "\n   ⌬「%s」"%command
                            self.client.sendText(to,tst)
                        if txt == "!..mid":user = self.client.profile.mid;self.client.sendText(to,user)
                        if txt.startswith("!ymp3 "):
                            try:
                                quer = " ".join(txt.split()[1:]);query = urllib.parse.quote(quer)
                                url = "https://www.youtube.com/results?search_query=" + query;response = urllib.request.urlopen(url)
                                html = response.read();soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl);stream = vid.streams
                                for s in stream:
                                    vin = s.url;hasil = vid.title; hasil += '\n⌬ author : ' + str(vid.author) + '\n⌬ duration : ' + str(vid.duration) + '\n⌬ likes : ' + str(vid.likes) + '\n⌬ viewcount : ' + str(vid.viewcount) + '\n⌬ rating : ' + str(vid.rating) + '\n⌬ published : ' + str(vid.published)
                                self.client.sendText(msg.to,hasil);self.client.sendAudioWithURL(to,vin);print (" Yt-mp3 Succes")
                            except Exception as e:self.client.sendText(to,str(e))
                        if txt.startswith("!ymp4 "):
                            try:
                                quer = " ".join(txt.split()[1:])
                                query = urllib.parse.quote(quer)
                                url = "https://www.youtube.com/results?search_query=" + query;response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl);stream = vid.streams
                                for s in stream:
                                    vin = s.url;hasil = vid.title;hasil += '\n⌬ author : ' + str(vid.author) + '\n⌬ duration : ' + str(vid.duration) + '\n⌬ likes : ' + str(vid.likes) + '\n⌬ viewcount : ' + str(vid.viewcount) + '\n⌬ rating : ' + str(vid.rating) + '\n⌬ published : ' + str(vid.published)
                                self.client.sendText(msg.to,hasil);self.client.sendVideoWithURL(to,vin);print (" Yt-mp4 Succes")
                            except Exception as e:self.client.sendText(to,str(e))
                if msg.toType == 2:
                    if msg.text:
                        txt = " ".join(msg.text.lower().split())
                        if '!..silent' in txt:
                            silent = True
                        if "!..remote:" in txt:
                            func = lambda s: s[:1].lower() + s[1:] if s else ''
                            if not "!..remote: " in txt:
                                number = txt.split("!remote:")[1]
                                number = number.split()[0]
                                gid = self.client.getGroupIdsJoined()
                                if number.isdigit():
                                    number = int(number)
                                    group = gid[number]
                                    to = group
                                txt = txt.replace("!..remote:%s"%number,"").lstrip().rstrip()
                                if "!..remote:" in msg.text:
                                    msg.text = msg.text.replace("!remote:%s"%number,"").lstrip().rstrip()
                                    func(msg.text)
                                else:
                                    msg.text = msg.text.replace("!Remote:%s"%number,"").lstrip().rstrip()
                                    func(msg.text)
                                self.client.sendText(msg.to,"Succes remote for %s"%self.client.getGroup(group).name)
                        if msg.text.lower().startswith("!..r:"):
                            if not "!..r: " in msg.text.lower():
                                number = msg.text.lower().split("!r:")[1]
                                number = number.split()[0]
                                num = int(number)
                                gid = self.client.getGroupIdsJoined()
                                sumi = gid[num-1]
                                group = sumi
                                to = group
                                if not " & " in msg.text.lower():
                                   z = msg.text.lower().replace("!.r:%s "%number,"").lstrip().rstrip()
                                   cmds = [z]
                                   if not silent:self.client.sendMessage(msg.to,"Command '%s' sent to group %s."%(z.replace("!r:",""),self.client.getGroup(group).name))
                                else:
                                   z = msg.text.lower().replace("!.r:%s "%number,"").lstrip().rstrip()
                                   cmds = z.split(" & ")
                                   if not silent:self.client.sendMessage(msg.to,"Multi Command '%s' sent to group %s."%(z.replace("!r:",""),self.client.getGroup(group).name))
######## EXC
#########################
                        if of in self.master:
                            if msg.text.startswith('!..run\n'):
                                try:
                                    self.reply.addFuncInterrupt("m_exec_thread",self.m_exec_thread(msg))
                                except:
                                    traceback.print_exc()
                            if txt.startswith('#.. '):
                                    a=subprocess.getoutput(self.client.nyeplitin(msg.text))
                                    k = len(a)//10000
                                    for aa in range(k+1):
                                        try:self.client.sendMessage(to,'{}'.format(a[aa*10000 : (aa+1)*10000]))   
                                        except:self.client.sendMessage(to,'done')
                            if txt.startswith("!..savefile "):
                                    txt = msg.text.split("!savefile ")
                                    jmlh = str(txt[1])
                                    add["img"] = jmlh
                                    add["save"] = True
                                    self.client.sendMessage(to,"Kirim Berkasnya")
                            if txt.startswith('!..sfile ') or txt.startswith(' !sfile '):
                                    try:
                                        separate = msg.text.split("!sfile ")
                                        tos = msg.text.replace(separate[0] + "!sfile ","")
                                        self.client.sendFile(to,tos)
                                    except Exception as e:self.client.sendMessage(to, "「 File  "+ tos +" tidak ditemukan 」")
                            if txt.startswith('!..saudio '):
                                    try:
                                        separate = msg.text.split("!saudio ")
                                        tis = msg.text.replace(separate[0] + "!saudio ","")
                                        self.client.sendAudio(to,tis)
                                    except:self.client.sendMessage(to, "「 File  "+ tis +" tidak ditemukan 」")
                            if txt.startswith('!..simg '):
                                    try:
                                        separate = msg.text.split("!simg ")
                                        tex = msg.text.replace(separate[0] + "!simg ","")
                                        self.client.sendImage(to,tex)
                                    except:self.client.sendMessage(to, "「 File  "+ tex +" tidak ditemukan 」")
                            if txt.startswith('!svid '):
                                    try:
                                        separate = msg.text.split("!svid ")
                                        tus = msg.text.replace(separate[0] + "!svid ","")
                                        self.client.sendVideo(to,tus)
                                    except:self.client.sendMessage(to, "「 File  "+ tus +" tidak ditemukan 」")
######## EXC
#########################
                        if txt.startswith('?..help'):
                            All = ["sɪʟᴇɴᴛ","ʀᴇᴍᴏᴛᴇ:","ɢʀᴏᴜᴘs","sᴛᴀғғ","ʙᴏᴛ","ʙᴀɴ","ᴜɴʙᴀɴ","sᴛᴀғғʟɪsᴛ","ʙᴏᴛʟɪsᴛ","ʙᴀɴʟɪsᴛ","sᴛᴀғғᴄᴏɴ","ʙᴏᴛᴄᴏɴ","ʙᴀɴᴄᴏɴ","ᴛᴇᴍᴘsᴛᴋ","ᴜɴsᴇɴᴅ","ᴋᴇʏ","s","ᴄ/ʀᴠɪᴅᴇᴏ","ʀᴀᴅᴅ","ᴄᴅᴇʟ","ᴄ/ʀᴀᴜᴅɪᴏ","ʀᴇғʀᴇsʜ","ʟᴀsᴛsᴇᴇɴ","ɢɪғᴛ"]
                            Group = ["ɢᴄᴏɴ","ᴛᴀɢ","ᴋɪᴄᴋ","ᴄᴀɴᴄᴇʟ","sᴀʏ","ᴄʜᴀᴛʙᴏᴛ","ᴄʟᴇᴀʀ","ʟᴜʀᴋᴇʀs","ᴛᴀʀɢᴇᴛ","ᴛᴀɢᴍsɢ","ʟᴇᴀᴠᴇ","ɪᴍɢᴄᴄᴛᴠ","ᴠᴋɪᴄᴋ","ᴄᴄᴛᴠ","ʀᴇʙᴏᴏᴛ","ᴀᴛs","ɢᴇᴛ ᴛʟ"]
                            User = ["ᴍᴇ","ғʀɪᴇɴᴅs","ᴀᴅᴅᴄᴏɴ","ᴅᴇʟᴄᴏɴ","sᴛᴀᴛs","ᴀᴅᴅᴍᴇssᴀɢᴇ","ᴀᴜᴛᴏʙʟᴏᴄᴋ","ᴘɪᴄᴛᴜʀᴇ","ᴄᴏᴠᴇʀ","ᴜʀʟᴄᴏᴠʀ","ᴜʀʟᴘɪᴄ","ᴄᴏᴘʏ ᴄᴏᴠᴇʀ","ᴄᴏᴘʏ ᴘɪᴄ","ᴄʟᴏɴᴇ","ᴜᴘsᴛᴀᴛᴜs","ᴜᴘɴᴀᴍᴇ","ᴜᴘᴅᴜᴀʟ","ᴜᴘɪᴍᴀɢᴇ","sᴛᴀᴛᴜs","ᴜsᴇʀɪᴅ","ᴍɪᴅ","ᴘᴍʙᴏx","ɢᴇᴛᴠɪᴅᴇᴏ","ʀᴇɴᴀᴍᴇ","ᴄʀᴇᴀᴛᴇ","ʀᴇᴍᴏᴠᴇ","ᴄᴏᴍᴍᴀɴᴅ","gpending","accept"]
                            Media = ["sᴄʟᴏᴜᴅ","sʏᴏᴜᴛᴜʙᴇ","ʏᴏᴜᴛᴜʙᴇ","ʏᴛᴍᴘ3","ʏᴛᴍᴘ4","ɪɴsᴛᴀɢʀᴀᴍ","ᴛᴡɪᴛᴛᴇʀ","ɢɪᴛʜᴜʙ","sᴍᴜʟᴇ"]
                            if "!.media" in txt:
                                tst = "ʜᴇʟᴘ ᴍᴇᴅɪᴀ:\n"
                                for c in Media:
                                    tst += "\n   • %s"%(c)
                                data = {"type":"text","text":tst,"sentBy":{"label":'ʜᴇʟᴘ ᴍᴇᴅɪᴀ',"iconUrl":"https://os.line.naver.jp/os/p/{}".format(self.client.profile.mid),"linkUrl":"line://ti/p/~{}".format(self.client.profile.userid)}}
                                self.sendTemplate(to,data)
                            elif "!.group" in txt:
                                tst = "ʜᴇʟᴘ ɢʀᴏᴜᴘ:\n"
                                for c in Group:
                                    tst += "\n   • %s"%(c)
                                data = {"type":"text","text":tst,"sentBy":{"label":'ʜᴇʟᴘ ɢʀᴏᴜᴘ',"iconUrl":"https://os.line.naver.jp/os/p/{}".format(self.client.profile.mid),"linkUrl":"line://ti/p/~{}".format(self.client.profile.userid)}}
                                self.sendTemplate(to,data)
                            elif "!.user" in txt:
                                tst = "ʜᴇʟᴘ ᴜsᴇʀ:\n"
                                for c in User:
                                    tst += "\n   • %s"%(c)
                                data = {"type":"text","text":tst,"sentBy":{"label":'ʜᴇʟᴘ ᴜsᴇʀ',"iconUrl":"https://os.line.naver.jp/os/p/{}".format(self.client.profile.mid),"linkUrl":"line://ti/p/~{}".format(self.client.profile.userid)}}
                                self.sendTemplate(to,data)
                            elif "!.managing" in txt:
                                tst = "ʜᴇʟᴘ ᴍᴀɴᴀɢɪɴɢ:\n"
                                for c in All:
                                    tst += "\n   • %s"%(c)
                                data = {"type":"text","text":tst,"sentBy":{"label":'ʜᴇʟᴘ ᴍᴀɴᴀɢɪɴɢ',"iconUrl":"https://os.line.naver.jp/os/p/{}".format(self.client.profile.mid),"linkUrl":"line://ti/p/~{}".format(self.client.profile.userid)}}
                                self.sendTemplate(to,data)
                                #self.client.sendText(to,tst)
                            else:
                                tst = "\n\nType:「!」\n   • on/off\n   • add/del\n   • repeat\n   • query\n   • range"
                                self.sendTagg(to,of,"⌬","\nUsage:「!」\n   • media\n   • group\n   • user\n   • managing"+tst)
                        if txt.startswith(".!instagram"):
                            sep = txt.split(" ")
                            search = txt.replace(sep[0] + " ","")
                            r = requests.get("http://api.farzain.com/ig_profile.php?id={}&apikey=fn".format(search))
                            data = r.text
                            data = json.loads(data)
                            if data != []:
                                ret_ = "[ Profile Instagram ]"
                                ret_ += "\n\nNama : {}".format(str(data["info"]["full_name"]))
                                ret_ += "\nUsername : {}".format(str(data["info"]["username"]))
                                ret_ += "\nBio : {}".format(str(data["info"]["bio"]))
                                ret_ += "\nURL Bio : {}".format(str(data["info"]["url_bio"]))
                                ret_ += "\nFollowing : {}".format(str(data["count"]["following"]))
                                ret_ += "\nFollowers : {}".format(str(data["count"]["followers"]))
                                ret_ += "\nTotal Post : {}".format(str(data["count"]["post"]))
                                path = data["info"]["profile_pict"]
                                data = {"type": "template","altText": "Instagram","template": {"type": "buttons","thumbnailImageUrl": path,"imageSize": "contain","imageAspectRatio": "square","title": "{}".format(str(data["info"]["full_name"])),"text": 'Follower : {}\nFollowing: {}\nPost : {}'.format(str(data["count"]["followers"]), (data["count"]["following"]), (data["count"]["post"])),"actions": [{"type": "uri","label": "Instagram","uri": "https://www.instagram.com/{}".format(search)}]}}
                                self.sendTemplate(to,data)
                        if txt.startswith("!.twitter"):
                            separate = txt.split(" ")
                            key = txt.replace(separate[0] + " ","")
                            path = requests.get('https://api.farzain.com/twitter.php?id={}&apikey=fn'.format(key))
                            data = path.text
                            data = json.loads(data)
                            pp = str(data["result"]["profilepicture"])
                            data = {"type": "template","altText": "Twitter","template": {"type": "buttons","thumbnailImageUrl": pp,"imageSize": "contain","imageAspectRatio": "square","title": '{}'.format(str(data["result"]["name"])),"text": '{}\nFollower : {}\nFollowing : {}'.format(str(data["result"]["description"][:26]), str(data["result"]["followers"]), str(data["result"]["following"])),"actions": [{"type": "uri","label": "Twitter","uri": "https://www.twitter.com/{}".format(key)}]}}
                            self.sendTemplate(to,data)
                        if txt.startswith('!.github'):
                            sep = txt.split(" ")
                            users = txt.replace(sep[0] + " ","")
                            path = requests.get('https://api.github.com/users/{}'.format(users))
                            data = path.text
                            data = json.loads(data)
                            data = {"type": "template","altText": "Fn","template": {"type": "buttons","thumbnailImageUrl": "{}".format(str(data["avatar_url"])),"imageSize": "contain","imageAspectRatio": "square","title": '{}'.format(str(data["name"])),"text": 'Followers: {}\nFollowing: {}\nRepositories: {}'.format(str(data["followers"]), (data["following"]), (data["public_repos"])),"actions": [{"type": "uri","label": "Repositories","uri": "https://github.com/{}?tab=repositories".format(str(users))},{"type": "uri","label": "Go Page","uri": "https://github.com/{}".format(str(users))}]}}
                            self.sendTemplate(to,data)
                        if txt == "!smule":self.client.sendMessage(to,"Usage:\n!user\n!recor\n!download")
                        if txt.startswith('!smule !user'):self.client.searchusersmule(msg,msg.text,"FUCKER",to)
                        if txt.startswith('!smule !recor'):self.client.searchusersmulerecord(msg,self.settings,msg.text)
                        if txt.startswith('!smule !download'):self.client.smuledownloader(msg,self.settings,msg.text)

                        if txt == '!.refresh libs':
                                talk = sys.modules['linepy.talk']
                                servr = sys.modules['linepy.server']
                                mdl = sys.modules['linepy.models']
                                clien = sys.modules['linepy.client']
                                oepl = sys.modules['linepy.oepoll']
                                shop = sys.modules['linepy.shop']
                                ch = sys.modules['linepy.channel']
                                try:
                                    importlib.reload(talk)
                                    importlib.reload(servr)
                                    importlib.reload(mdl)
                                    importlib.reload(clien)
                                    importlib.reload(oepl)
                                    importlib.reload(shop)
                                    importlib.reload(ch)
                                    self.client.sendMessage(to,"Libs refreshed")
                                except Exception as e:e = traceback.format_exc();self.client.sendText(to, str(e))
                        if txt.startswith('.get tl') or txt.startswith(' !get tl'):self.client.gettl(to,msg,txt)
                        if txt == '.get tl' or txt == ' !get tl':self.client.gettimeline(msg,to,to)
                        if txt.startswith(".scloud "):a = threading.Thread(target=self.client.soundcloud, args=(msg,to,txt)).start()
                        if txt.startswith('!.clear'):
                            if "!..botlist" in txt:
                                length = len(self.stats["botlist"])
                                self.stats["botlist"] = []
                                if not silent:self.client.sendText(to,"Expelled %s bots."%length)
                            elif ".!stafflist" in txt:
                                length = len(self.stats["stafflist"])
                                self.stats["stafflist"] = []
                                if not silent:self.client.sendText(to,"Expelled %s staff."%length)
                            elif "!.ban" in txt:
                                length = len(self.stats["banned"])
                                self.stats["banned"] = []
                                if not silent:self.client.sendText(to,"Unbanned %s"%length)
                            elif "!..pmbox" in txt:
                                self.stats["pmID"] = {}
                                self.stats["pmDetail"] = {}
                                self.stats["pmText"] = {}
                                self.client.sendText(to,"Box message cleared.")
                            else:
                                self.client.sendText(to,"Usage:\n!botlist\n!stafflist\n!ban\n!pmbox")
                        if txt.startswith("..command"):
                                cmd = txt.replace("..!command","").lstrip().rstrip()
                                if cmd in self.commands["invite"].keys():
                                    names = self.commands["invitenames"][cmd]
                                    tst = "♬♬♬♬♬♬♬♬\t\n♬ Commands ♬\t\n♬♬♬♬♬♬♬♬\n♬ Cmd Name: %s\n♬ Count: %i\n"%(cmd,len(self.commands["invite"][str(cmd)]))
                                    for name in names:
                                        tst += "\n•. %s"%name
                                    self.client.sendText(to,tst)
                                else:
                                    self.client.sendText(to,"Command %s does not exist."%cmd)

                        if txt.startswith("!..create "):
                            if not self.addcommand:
                                #command = " ".join(txt.split()[2:])
                                command = txt.replace("!..create ","")
                                self.addcmd = command.lstrip().rstrip()
                                self.addcommand = True
                                if not silent:self.client.sendText(to,"Command %s created, now send contacts to be added."%command)
                                if not silent:self.client.sendText(to,"Type /!finish when you're done.\nType /!stop to cancel.")
                            else:
                                if not silent:self.client.sendText(to,"Command creation %s already in progress.\nType .abort to cancel."%self.addcmd)
                        if txt.startswith('!..remove'):
                            cmd = txt.replace("!remove","").lstrip().rstrip()
                            if cmd in self.commands["invite"].keys():
                                del self.commands["invite"][cmd]
                                del self.commands["invitenames"][cmd]
                                self.client.sendText(to,"Command %s has been removed."%cmd)
                            else:
                                self.client.sendText(to,"Command %s does not exist."%cmd)
                        if txt == '!..finish':
                            if self.addcommand:
                                self.commands["invite"][self.addcmd] = self.tempbots
                                self.commands["invitenames"][self.addcmd] = self.tempnames
                                if not silent:self.client.sendText(to,"Command creation of %s has been finished."%self.addcmd)
                                self.addcmd = ""
                                self.tempbots = []
                                self.tempnames = []
                                self.addcommand = False
                            else:
                                if not silent:self.client.sendText(to,"Nothing to finish.")
                        if txt == '..!stop':
                            if self.addcommand:
                                self.addcmd = ""
                                self.addcommand = False
                                self.tempbots = []
                                self.tempnames = []
                                if not silent:self.client.sendText(to,"Command creation aborted.")
                            else:
                                if not silent:self.client.sendText(to,"Nothing to abort.")
                        if txt == "!..speed":
                            b = time.time()
                            for i in range(10):
                                self.client.getProfile()
                            end = time.time() - b
                            self.client.sendText(to,"Time:\n%s"%round(end/10,5))
                        if txt == "!..debug":self.client.sendMessage(to,self.client.debug())
                        if self.commands["stickers"] != {}:
                                if txt in self.commands["stickers"].keys():
                                    sticker = self.commands["stickers"][txt]
                                    self.client.send_sticker(to,sticker[0],sticker[1],sticker[2])
                        if self.commands["tmpstickers"] != {}:
                                if txt in self.commands["tmpstickers"].keys():
                                    sticker = self.commands["tmpstickers"][txt]
                                    ids = sticker[0]
                                    ipg = sticker[1]
                                    a = self.client.shop.getProduct(packageID=int(ipg), language='ID', country='ID')
                                    if a.hasAnimation == True:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/IOS/sticker_animation@2x.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
                                    else:
                                        data = {"type": "template","altText": "{} sent a sticker".format(self.client.profile.displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(ids)+'/ANDROID/sticker.png',"action": {"type": "uri","uri": "line://shop/sticker/detail/{}".format(str(ipg)),"area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}
                                        print(data)
                                        self.sendTemplate(to,data)
                        if txt in self.perintah:data = {"type":"text","text":self.perintah[txt],"sentBy":{"label":'{}'.format(str(self.client.profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(self.client.profile.mid),"linkUrl":"line://ti/p/~{}".format(self.client.profile.userid)}};self.sendTemplate(to,data)
                        if txt in self.imgcmds:self.client.sendImage(to,self.imgcmds[txt])                        
                        if txt in self.vidcmds:self.client.sendVideo(to,self.vidcmds[txt])
                        if txt in self.audiocmds:self.client.sendAudio(to,self.audiocmds[txt])
                        if txt in self.musiccmds:self.client.sendAudio(to,self.musiccmds[txt])
                        if self.commands["invite"] != {}:
                            if txt in self.commands["invite"].keys():
                                inv = self.commands["invite"][txt]
                                self.client.inviteIntoGroup(to,inv)
                        if txt == "/..me":a = self.client.profile;b = self.client.profile.displayName;c = self.client.profile.userid;data = {"type": "flex","altText": b,"contents": {"type": "bubble","styles": {"body": {"backgroundColor": "#ffffff"},"footer": {"backgroundColor": "#ffffff"}},"hero": {"type": "image","url": "https://os.line.naver.jp/os/p/{}".format(of),"size": "full","aspectRatio": "20:13","aspectMode": "cover","action": {"type": "uri","uri": "line://ti/p/UeVAzuafAU"}},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": '{}'.format(str(a.displayName)),"weight": "bold","size": "xl"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Name","color": "#aaaaaa","size": "sm","flex": 1},{"type": "text","text": '{}'.format(str(a.displayName)),"color": "#aaaaaa","size": "sm","flex": 2}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Status","color": "#aaaaaa","size": "sm","flex": 1},{"type": "text","text": "{}".format(str(a.statusMessage if a.statusMessage != '' else 'line://ti/p/UeVAzuafAU')),"color": "#aaaaaa","wrap": True,"size": "sm","flex": 2}]}]}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Official Account","uri": "line://ti/p/~"+c}},{"type": "spacer","size": "sm",}],"flex": 0}}};self.sendTemplate(to,data)
                        if txt == "!..me":self.client.sendContact(to,of);ticket = self.client.getUserTicket().id;user = self.client.getContact(of);name = user.displayName;bio = user.statusMessage;pic = "http://dl.profile.line-cdn.net//{}".format(str(user.pictureStatus));self.client.sendMessage(to, name, contentMetadata={'i-linkUri': str(ticket), 'id': 'mt000000000a6b79f9', 'countryCode': 'ID', 'previewUrl':str(pic), 'linkUri': str(ticket), 'ORGCONTP': 'MUSIC', 'a-linkUri': str(ticket), 'subText': "\n"+str(bio), 'type': 'mt','a-installUrl': str(ticket), 'a-packageName': 'com.spotify.music', 'text': str(name), 'i-installUrl': str(ticket)}, contentType=19)
                        if txt.startswith("!staff !add") or txt.startswith("!staff!add"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                for target in targets:
                                    if target in self.stats["botlist"]:
                                        self.stats["botlist"].remove(target)
                                    if target in self.stats["banned"]:
                                        self.stats["banned"].remove(target)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 New Stafflist 」\n',pg='ADDST',pt=targets)
                            else:
                                self.clear()
                                self.stats["staff"] = True
                                if not silent:self.client.sendText(to,"Send a contact to make staff.")
                        if txt == "!..lurkers":
                            print ("Lurking Starting........")
                            if to in self.sider2['readPoint']:
                                if not silent:self.client.sendMessage(to, "╔════════════════\n║READCHAT IN GROUP\n╠════════════════%s\n║\n╚════════════════" % (self.sider2['readMember'][to]))
                                try:
                                    del self.sider2['readPoint'][to]
                                    del self.sider2['readPoint'][to]
                                except:
                                    pass
                                self.sider2['readPoint'][to] = msg.id
                                self.sider2['readMember'][to] = ""
                                self.sider2['ROM'][to] = {}
                                if not silent:self.client.sendMessage(to, "lurking started")
                            else:
                                try:
                                    del self.sider2['readPoint'][to]
                                    del self.sider2['readMember'][to]
                                except:
                                    pass
                                self.sider2['readPoint'][to] = msg.id
                                self.sider2['readMember'][to] = ""
                                self.sider2['ROM'][to] = {}
                                if not silent:self.client.sendMessage(to, "lurking started")

                        if txt == "!..lurkers2":
                            print ("Lurking2 Starting........")
                            if to in self.sider['readPoint']:
                                if self.sider["ROM"][to].items() == []:
                                    if not silent:self.client.sendMessage(to, "╔════════════════\n║READCHAT IN GROUP\n╠════════════════%s\n║\n╚════════════════" % (self.sider['readMember'][to]))
                                else:
                                    chiya = []
                                    for rom in self.sider["ROM"][to].items():
                                        chiya.append(rom[1])
                                    cmem = self.client.getContacts(chiya)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan = '***Lurkers V0.7***\n\n'
                                    for x in range(len(cmem)):
                                        xname = str(cmem[x].displayName)
                                        pesan = ''
                                        pesan2 = pesan+"@a\n"
                                        xlen = str(len(zxc)+len(xpesan))
                                        xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                        zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                                        zx2.append(zx)
                                        zxc += pesan2
                                    msg.contentType = 0
                                    print (zxc)
                                    msg.text = xpesan+ zxc + "\nLurking Set: %s\nLurking View: %s"%(self.sider['setTime'][to],datetime.now().strftime('%H:%M:%S'))
                                    lol ={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    print (lol)
                                    msg.contentMetadata = lol
                                    try:
                                        self.client.sendMessage(to,msg.text,lol)
                                    except Exception as error:
                                        print (error)
                            else:
                                try:
                                    del self.sider['readPoint'][to]
                                    del self.sider['readMember'][to]
                                except:
                                    pass
                                self.sider['readPoint'][to] = msg.id
                                self.sider['readMember'][to] = ""
                                self.sider['setTime'][to] = datetime.now().strftime('%H:%M:%S')
                                self.sider['ROM'][to] = {}
                                if not silent:self.client.sendMessage(to, "lurking started")
                        if txt.startswith("!..urlcovr"):
                            if txt == "!..urlcovr":
                                cu = self.client.getProfileCoverURL(of)
                                self.client.sendMessage(to,cu)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    cu = self.client.getProfileCoverURL(target)
                                    self.client.sendMessage(to,cu)
                        if txt.startswith("!urlpic"):
                            if txt == "!..urlpic":
                                profile = self.client.getContact(of)
                                self.client.sendMessage(to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    profile = self.client.getContact(target)
                                    self.client.sendMessage(to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                        if txt.startswith("!cover"):
                            if txt == "!cover":
                                profile = self.client.getContact(of)
                                cu = self.client.getProfileCoverURL(of)
                                self.client.sendImageWithURL(to,cu)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    cu = self.client.getProfileCoverURL(target)
                                    self.client.sendImageWithURL(to,cu)
                            else:
                                try:
                                    tx = txt.split(":")
                                    num = int(tx[1])
                                    foo = int(tx[2])
                                    me = self.client.getContact(of)
                                    gid = self.client.getGroupIdsJoined()
                                    gs = self.client.getGroup(gid[num-0])
                                    nama = [o.mid for o in gs.members]
                                    if nama == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        cu = self.client.getProfileCoverURL(nama[foo-2])
                                        self.client.sendImageWithURL(to,cu)
                                except:
                                    _name = "/..".join(txt.split()[1:])
                                    gs = self.client.getGroup(to)
                                    targets = []
                                    for g in gs.members:
                                        if _name in g.displayName.lower():
                                            targets.append(g.mid)
                                    if targets == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        for target in targets:
                                            cu = self.client.getProfileCoverURL(target)
                                            self.client.sendImageWithURL(to,cu)
                        if txt.startswith("!picture"):
                            if txt == "!picture":
                                profile = self.client.getContact(of)
                                data = {"type":"image","originalContentUrl":"https://os.line.naver.jp/os/p/{}".format(of),"previewImageUrl":"https://os.line.naver.jp/os/p/{}".format(of),"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(of),"linkUrl":"line://ti/p/~regathb"}}
                                self.sendTemplate(to,data)
                            elif 'group' in txt:
                                try:
                                    tx = txt.split(":")
                                    num = int(tx[1])
                                    gid = self.client.getGroupIdsJoined()
                                    gs = self.client.getGroup(gid[num-0])
                                    path = "http://dl.profile.line-cdn.net/" + gs.pictureStatus
                                    self.client.sendImageWithURL(to,path)
                                except:
                                    group = self.client.getGroup(to)
                                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                    self.client.sendImageWithURL(to,path)
                            elif 'MENTION' in msg.contentMetadata.keys()!=None:
                                targets = []
                                self.mention(msg,targets)
                                for target in targets:
                                    profile = self.client.getContact(target)
                                    data = {"type":"image","originalContentUrl":"https://os.line.naver.jp/os/p/{}".format(target),"previewImageUrl":"https://os.line.naver.jp/os/p/{}".format(target),"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(target),"linkUrl":"line://ti/p/~regathb"}}
                                    self.sendTemplate(to,data)
                            else:
                                try:
                                    tx = txt.split(":")
                                    num = int(tx[1])
                                    foo = int(tx[2])
                                    me = self.client.getContact(of)
                                    gid = self.client.getGroupIdsJoined()
                                    gs = self.client.getGroup(gid[num-0])
                                    nama = [o.mid for o in gs.members]
                                    if nama == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        profile = self.client.getContact(nama[foo-2])
                                        data = {"type":"image","originalContentUrl":"https://os.line.naver.jp/os/p/{}".format(nama[foo-2]),"previewImageUrl":"https://os.line.naver.jp/os/p/{}".format(nama[foo-2]),"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(nama[foo-2]),"linkUrl":"line://ti/p/~regathb"}}
                                        self.sendTemplate(to,data)
                                except:
                                    _name = "/..".join(txt.split()[1:])
                                    gs = self.client.getGroup(to)
                                    targets = []
                                    for g in gs.members:
                                        if _name in g.displayName.lower():
                                            targets.append(g.mid)
                                    if targets == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        for target in targets:
                                            profile = self.client.getContact(target)
                                            data = {"type":"image","originalContentUrl":"https://os.line.naver.jp/os/p/{}".format(target),"previewImageUrl":"https://os.line.naver.jp/os/p/{}".format(target),"animated":False,"extension":"jpg","sentBy":{"label":'{}'.format(str(profile.displayName)),"iconUrl":"https://os.line.naver.jp/os/p/{}".format(target),"linkUrl":"line://ti/p/~regathb"}}
                                            self.sendTemplate(to,data)
                        if txt.startswith("!.staff !.del") or txt.startswith("!staff!del"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 Remove staff 」\n',pg='DELST',pt=targets)
                            else:
                                data = txt.replace("!.staff !.del","")
                                text = data.split(' ')
                                com = str(text[1])
                                selection = Archimed(com,range(1,len(self.stats['stafflist'])+1))
                                k = len(self.stats['stafflist'])//100
                                d = []
                                for c in selection.parse():
                                    d.append(self.stats['stafflist'][int(c)-1])
                                for a in range(k+1):
                                    if a == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[:100],pl=-0,ps='「 Remove staff 」\n',pg='DELST',pt=d)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='「 Remove staff 」\n',pg='DELST',pt=d)
                        if txt.startswith("!.getvideo"):
                            if txt == "!.getvideo":
                                h = self.client.getContact(of)
                                if h.videoProfile == None:
                                    return client.sendMessage(to, "You have no video profile")
                                self.client.sendVideoWithURL(to,"http://dl.profile.line-cdn.net/" + h.pictureStatus + "/vp")
                            elif 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', txt)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = self.client.getContact(ls)
                                    if contact.videoProfile == None:
                                        continue
                                    path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp"
                                    self.client.sendVideoWithURL(to, str(path))
                        if txt.startswith("!..say "):
                            text = " ".join(txt.split()[1:])
                            if not silent:self.client.sendText(to,text)
                        if txt.startswith("!rname "):
                            if '!..off' in txt:
                                self.settings["rname"][0] = 0
                                if not silent:self.client.sendText(to,"Responsename disabled.")
                            elif '!..staff' in txt:
                                self.settings["rname"][0] = 1
                                if not silent:self.client.sendText(to,"Responsename enabled for staff only.")
                            elif '!..on' in txt:
                                self.settings["rname"][0] = 2
                                if not silent:self.client.sendText(to,"Responsename enabled.")
                            else:
                                rname = txt.replace("!.rname","").lstrip().rstrip()
                                self.settings["rname"][1] = rname
                                if not silent:self.client.sendText(to,"Responsename updated to: %s."%rname)
                        if txt.startswith("!..chatbot"):
                            if "!..on" in txt:
                                if to in self.settings['author']:
                                    if not silent:self.client.sendText(to,"Chatbot already enabled.")
                                else:
                                    self.settings['author'][to] = True
                                    if not silent:self.client.sendText(to,"I'm back!")
                            elif "!..off" in txt:
                                if to in self.settings['author']:
                                    if not silent:self.client.sendText(to,"Bye Bye..")
                                    del self.settings['author'][to]
                                else:
                                    if not silent:self.client.sendText(to,"Chatbot already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Usage:\n!on\n!off")
                        if txt.startswith(".cctv"):
                            if '.on' in txt:
                                if to in self.db1['ceksider']['on']:
                                    self.client.sendText(to, 'cctv already enabled.')
                                else:
                                    self.db1['ceksider']['on'].append(to)
                                    self.cctvSTICKER = True
                                    if not silent:self.client.sendMessage(to,"Please send Sticker for cctv")
                            elif '.off' in txt:
                                if to not in self.db1['ceksider']['on']:
                                    self.client.sendText(to, 'cctv already disabled.')
                                else:
                                    self.db1['ceksider']['on'].remove(to)
                                    del self.commands['cctvStickers'][to]
                                    self.ceks = []
                                    self.client.sendText(to, 'cctv disabled.')
                            elif txt.startswith(".cctv.up "):
                                rtext = " ".join(txt.split()[1:])
                                self.db1['ceksider']['txt'] = rtext
                                self.client.sendText(to, 'Text cctv updated to:\n{}'.format(rtext))
                            else:
                                self.client.sendText(to,"Usage:\n!on\n!off\n!up")
                        if txt.startswith("!.clone "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', txt)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                if len(lists) != []:
                                    ls = random.choice(lists)
                                    self.cloneProfile(ls)
                                    self.client.sendMessage(to,"Done")
                        if txt == "!cancel":
                            group = self.client.getGroup(to)
                            if group.invitee:
                                invitees = [o.mid for o in group.invitee]
                                for i in invitees:
                                      self.client.cancelGroupInvitation(to,[i])
                                      time.sleep(0.5)
                        if txt.startswith(".imgcctv"):
                            if ".on" in txt:
                                if to in self.stats['cctvPic']:
                                    if not silent:self.client.sendText(to,"Picture sider already enabled.")
                                else:
                                    self.stats['cctvPic'][to] = True
                                    if not silent:self.client.sendText(to,"Picture sider enabled.")
                            elif ".off" in txt:
                                if to in self.stats['cctvPic']:
                                    if not silent:self.client.sendText(to,"Picture sider disabled")
                                    del self.stats['cctvPic'][to]
                                else:
                                    if not silent:self.client.sendText(to,"Picture sider already disabled.")
                            else:
                                self.client.sendText(to,"Usage:\n!on\n!off")
                        if txt.startswith(".vkick "):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    if mention not in self.master:
                                        self.client.kickoutFromGroup(to,[mention])
                                        time.sleep(0.5)
                                        self.client.inviteIntoGroup(to,[mention])
                                        time.sleep(0.4)
                                        self.client.cancelGroupInvitation(to,[mention])
                                        time.sleep(0.3)
                                        self.client.inviteIntoGroup(to,[mention])
                                        time.sleep(0.2)
                                        self.client.cancelGroupInvitation(to,[mention])
                                    else:
                                        self.client.sendText(to,"Permission denied.")
                        if txt.startswith("!..upname "):
                            name = msg.text[msg.text.find(" !upname ")+len(" !upname "):].lstrip().rstrip()
                            self.client.updateName(name)
                            if not silent:self.client.sendText(to,"Name updated to: %s."%name)
                        if txt.startswith("!..upstatus "):
                            status = msg.text[msg.text.find(" !upstatus ")+len(" !upstatus "):].lstrip().rstrip()
                            self.client.updateStatus(status)
                            if not silent:self.client.sendText(to,"Status updated to: %s."%status)
                        if txt == '..updual':
                            self.imgsender = of
                            self.stats['changeProfileVideo']['status'] = True
                            self.stats['changeProfileVideo']['stage'] = 1
                            if not silent:self.client.sendText(to, "Please send video for update profile")
                        if txt == "..upimage":
                            self.imgsender = of
                            self.stats['picture'][to] = True
                            if not silent:self.client.sendText(to,"Send Pict")
                        if txt.startswith("!..kick "):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    if mention not in self.master:
                                        self.client.kickoutFromGroup(to,[mention])
                                    else:
                                        self.client.sendText(to,"Permission denied.")
                        if txt.startswith("!...pmbox"):
                            if "!pmbox" in txt:
                                ret_ = "🔰Message Box:"
                                num = 0
                                if len(self.stats["pmDetail"]) > 0:
                                    for love in self.stats["pmDetail"]:
                                        ret_ += "\n\n%s - "%num + self.stats["pmDetail"][love]
                                        sub = "\n\nTotal: {} Users\n.pmbox [ No ] to opened.".format(str(len(self.stats["pmDetail"])))
                                        num = (num+1)
                                    text = ret_ + sub
                                    self.client.sendMessage(to,"{}".format(str(text)))
                                else:
                                    self.client.sendText(msg.to,"Nothing messages")
                            else:
                                text = txt.split(" ")
                                num = text[1]
                                if num.isdigit():
                                    if int(num) < len(self.listpm) and int(num) >= 0:
                                        staffuid = self.listpm[int(num)]
                                        self.sendTagg(to, staffuid, "Message by:\n", self.stats["pmText"][staffuid])

                        if txt.startswith("!..lastseen"):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    if mention in self.db['lastseen']:
                                        t = time.time() - self.db['lastseen'][mention][0]
                                        m, s = divmod(t, 60)
                                        h, m = divmod(m, 60)
                                        if self.db['lastseen'][mention][1].startswith('u'):
                                            name = 'pm'
                                        else:
                                            name = self.client.getGroup(self.db['lastseen'][mention][1]).name
                                        n = self.client.getContact(mention).displayName
                                        text = "  Lastseen info\n⌬Name: %s\n⌬Time: %s hours, %s min, %s sec,\n⌬Active in: %s"%(n,round(h),round(m),round(s),name)
                                        self.client.sendMessage(to, text)
                                    else:
                                        self.client.sendText(to,'Unknown.')
                        if txt.startswith("..!gift"):
                            if txt == '..!gift':
                                self.client.sendGift(to,'2351','sticker')
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    self.client.sendGift(target,'2351','sticker')
                            else:
                                amount = txt.split()[1]
                                if amount.isdigit():
                                    amount = int(amount)
                                    if amount <= 20:
                                        for i in range(0,amount):
                                            self.client.sendGift(to,'2351','sticker')
                                    else:
                                        self.client.sendText(to,"Max: 20.")
                        if txt == '!..abort':
                            self.abort(to)
                        if txt.startswith("!copy pic "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', txt)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    profile = self.client.getContact(contact)
                                    url = "http://dl.profile.line.naver.jp"+profile.picturePath
                                    path = self.client.downloadFileURL(url)
                                    self.client.updateProfilePicture(path)
                                    if not silent:self.client.sendText(to, "Done")
                                    self.client.deleteFile(path)
                                except Exception as e:
                                    print(e)
                        if txt.startswith("!.copy cover "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', txt)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    self.client.copyCover(contact)
                                    if not silent:self.client.sendText(to, "Succes copy Cover")
                                except:
                                    if not silent:self.client.sendText(to, "Target Noting")
                        if txt == ".!staff .!repeat" or txt == "!.staff!.repeat":
                            self.clear()
                            self.stats["staff"] = True
                            self.stats["repeat"] = True
                            if not silent:self.client.sendText(to,"Send a contact to make staff.")
                        if txt.startswith("!.bot !.add") or txt.startswith("!.bot!.add"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                for target in targets:
                                    if target in self.stats["stafflist"]:
                                        self.stats["stafflist"].remove(target)
                                    if target in self.stats["banned"]:
                                        self.stats["banned"].remove(target)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 New Botlist 」\n',pg='ADDBOT',pt=targets)
                            else:
                                self.clear()
                                self.stats["bot"] = True
                                if not silent:self.client.sendText(to,"Send a contact to make bot.")
                        if txt == "!.bot !.repeat" or txt == "!.bot!.repeat":
                            self.clear()
                            self.stats["bot"] = True
                            self.stats["repeat"] = True
                            if not silent:self.client.sendText(to,"Send a contact to make bot.")
                        if txt.startswith("!.bot .!del") or txt.startswith("!.bot!.del"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 Remove bot 」\n',pg='DELBOT',pt=targets)
                            else:
                                data = txt.replace("!.bot .!del","")
                                text = data.split(' ')
                                com = str(text[1])
                                selection = Archimed(com,range(1,len(self.stats['botlist'])+1))
                                k = len(self.stats['botlist'])//100
                                d = []
                                for c in selection.parse():
                                    d.append(self.stats['botlist'][int(c)-1])
                                for a in range(k+1):
                                    if a == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[:100],pl=-0,ps='「 Remove bot 」\n',pg='DELBOT',pt=d)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='「 Remove bot 」\n',pg='DELBOT',pt=d)
                        if txt.startswith("!.ban") or txt.startswith("!.ban"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                for target in targets:
                                    if target in self.stats["stafflist"]:
                                        self.stats["stafflist"].remove(target)
                                    if target in self.stats["botlist"]:
                                        self.stats["botlist"].remove(target)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 New Banned 」\n',pg='ADDBAN',pt=targets)
                            else:
                                self.clear()
                                self.stats["banned"] = True
                                if not silent:self.client.sendText(to,"Send a contact to make banned.")
                        if txt == "!.ban !.repeat" or txt == "!.ban!.repeat":
                            self.clear()
                            self.stats["banned"] = True
                            self.stats["repeat"] = True
                            if not silent:self.client.sendText(to,"Send a contact to make banned.")
                        if txt.startswith("!unban"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 Remove ban 」\n',pg='DELBAN',pt=targets)
                            else:
                                data = txt.replace("!.unban","")
                                text = data.split(' ')
                                com = str(text[1])
                                selection = Archimed(com,range(1,len(self.stats['banned'])+1))
                                k = len(self.stats['banned'])//100
                                d = []
                                for c in selection.parse():
                                    d.append(self.stats['banned'][int(c)-1])
                                for a in range(k+1):
                                    if a == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[:100],pl=-0,ps='「 Remove ban 」\n',pg='DELBAN',pt=d)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='「 Remove bot 」\n',pg='DELBAN',pt=d)
                        if txt == "!.stafflist":
                            if self.stats['stafflist']:
                                self.listdata(to,self.stats,'Stafflist','staff',self.stats['stafflist'])
                            else:
                                if not silent:self.client.sendMessage(to,"List is empty.")
                        if txt == "!.botlist":
                            if self.stats['botlist']:
                                self.listdata(to,self.stats,'botlist:','bot',self.stats['botlist'])
                            else:
                                if not silent:self.client.sendMessage(to,"List is empty.")
                        if txt == "!.banlist":
                            if self.stats['banned']:
                                self.listdata(to,self.stats,'Banlist:','bot',self.stats['banned'])
                            else:
                                if not silent:self.client.sendMessage(to,"List is empty.")
                        if txt.startswith("!.addcon"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 New Friend 」\n',pg='ADDFL',pt=targets)
                        if txt.startswith("!.delcon"):
                            targets = []
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                self.mention(msg,targets)
                                self.mentionmention(to=to,stats=self.stats,text='',dataMid=targets,pl=0,ps='「 Remove Friend 」\n',pg='DELFL',pt=targets)
                            else:
                                split = txt.replace("!.delcon ","")   
                                nama = self.client.refreshContacts()
                                selection = Archimed(split,range(1,len(nama)+1))
                                k = len(nama)//100
                                d = []
                                for c in selection.parse():
                                    d.append(nama[int(c)-1])
                                for a in range(k+1):
                                    if a == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[:100],pl=-0,ps='   「 Remove friends 」\n',pg='DELFL',pt=d)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=d[a*100 : (a+1)*100],pl=a*100,ps='   「 Remove friends 」\n',pg='DELFL',pt=d)
                        if txt.startswith(".!inv "):
                            a = self.client.refreshContacts()
                            data = txt.replace(".!inv","")
                            text = data.split(' ')
                            num = str(text[1])
                            self.listinv(to,msg,num,self.stats,a)
                        if txt.startswith("!.friends ") or txt == "!.friends":
                            if txt.startswith('!.friends '):
                                a = self.client.refreshContacts()
                                data = txt.replace("friends","")
                                text = data.split(' ')
                                num = str(text[1])
                                self.listcon(to,msg,num,self.stats,a)
                            else:
                                a = self.client.refreshContacts()
                                k = len(a)//20
                                for aa in range(k+1):
                                    if aa == 0:self.mentionmention(to=to,stats=self.stats,text='',dataMid=a[:20],pl=0,ps='「 Friends: 」',pg='MENTIONALLME',pt=a)
                                    else:self.mentionmention(to=to,stats=self.stats,text='',dataMid=a[aa*20 : (aa+1)*20],pl=aa*20,ps='「 Friends: 」',pg='MENTIONALLME',pt=a)
                        if txt.startswith("!.staffcon"):
                            data = txt.replace("!.staffcon","")
                            text = data.split(' ')
                            num = str(text[1])
                            self.listcon(to,msg,num,self.stats,self.stats["stafflist"])
                        if txt.startswith("!.botcon"):
                            data = txt.replace("!.botcon","")
                            text = data.split(' ')
                            num = str(text[1])
                            self.listcon(to,msg,num,self.stats,self.stats["botlist"])
                        if txt.startswith("!.bancon"):
                            data = txt.replace("!.bancon","")
                            text = data.split(' ')
                            num = str(text[1])
                            self.listcon(to,msg,num,self.stats,self.stats["banned"])
                        if txt.startswith("!.membercon"):
                            data = txt.replace("!.membercon","")
                            text = data.split(' ')
                            num = str(text[1])
                            gs = self.client.getGroup(to) 
                            nama = [contact.mid for contact in gs.members]
                            num = str(text[1])
                            self.listcon(to,msg,num,self.stats,nama)
                        if txt == "!.groups":
                            gid = self.client.getGroupIdsJoined()
                            tst = "Grouplist:"
                            count = 1
                            for group in gid:
                                Gname = self.client.getGroup(group).name
                                gc = self.client.getGroup(group)
                                tst += "\n%s - %s (%s)"%(count,Gname,len(gc.members))
                                count += 1
                            self.client.sendText(to,tst)
                        if txt.startswith("!.groups "):
                            number = txt.split()[1]
                            num=1
                            if number.isdigit():
                                gid = self.client.getGroupIdsJoined()
                                number = int(number)
                                group = gid[number]
                                tst = "⌬⌬⌬⌬⌬⌬⌬⌬\t\n⌬    MEMBER INFO     ⌬\t\n⌬⌬⌬⌬⌬⌬⌬⌬\nGROUP: %s\n"%(self.client.getGroup(group).name)
                                num=(num+1)
                                for member in self.client.getGroup(group).members:
                                    tst += "\n     %i- %s"%(num, member.displayName)
                                    num=(num+1)
                                self.client.sendText(to,tst)
                        if txt.startswith("!.gmem"):
                            tx = txt.split(" ")
                            num = int(tx[1])
                            com = str(tx[2])
                            gid = self.client.getGroupIdsJoined()
                            gs = self.client.getGroup(gid[num-0])
                            nama = [contact.mid for contact in gs.members]
                            no = 0
                            mids = []
                            selection = Archimed(com,range(1,len(nama)+1))
                            k = len(nama)//20
                            for a in range(k+1):
                                if a == 0:eto='「 Mentiones 」\n'
                                else:eto='「 Mentiones 」\n'
                                b=[]
                                text = ''
                                mids = []
                                no = 0
                                for i in selection.parse()[a*500 : (a+1)*500]:
                                    mids.append(nama[i-1])
                                self.listdata(to,self.stats,'Mentiones','tag',mids)
                        if txt.startswith('!.tag'):
                            tt = txt.split(' ')
                            com = str(tt[1])
                            gs = self.client.getGroup(to)
                            nama = [contact.mid for contact in gs.members]
                            no = 0
                            mids = []
                            selection = Archimed(com,range(1,len(nama)+1))
                            k = len(nama)//20
                            for a in range(k+1):
                                if a == 0:eto='「 Mentiones 」\n'
                                else:eto='「 Mentiones 」\n'
                                b=[]
                                text = ''
                                mids = []
                                no = 0
                                for i in selection.parse()[a*500 : (a+1)*500]:
                                    mids.append(nama[i-1])
                                self.listdata(to,self.stats,'Mentiones','tag',mids)
                        if txt == "!..key":
                            tst = "%s\nCreate Menu:\n\n🎃 Stickers 🎃\n  —————————"%self.help
                            if self.commands["stickers"] != {}:
                                for command in self.commands["stickers"].keys():
                                    tst += "\n   •「%s」"%command
                            if self.commands["invite"] != {}:
                                tst += "\n\n💰 Invite 💰\n  ———————"
                                for command in self.commands["invite"].keys():
                                    tst += "\n   •「%s」"%command
                            if len(self.perintah) > 0 :
                                tst += "\n\n🗒 Text command 🗒\n  ———————"
                            if len(self.perintah) > 0:
                                for cmd in self.perintah:
                                    tst += "\n   •「%s」"%cmd
                            if len(self.imgcmds) > 0:
                                tst += "\n\n📸 Image command 📸\n  ———————"
                            if len(self.imgcmds) > 0:
                                for cmd in self.imgcmds:
                                    tst += "\n   •「%s」"%cmd
                            if len(self.vidcmds) > 0:
                                tst += "\n\n🎬 Video command 🎬\n  ———————"
                            if len(self.vidcmds) > 0:
                                for cmd in self.vidcmds:
                                    tst += "\n   •「%s」"%cmd
                            if len(self.audiocmds) > 0:
                                tst += "\n\n🎵 Audio command 🎵\n  ———————"
                            if len(self.audiocmds) > 0:
                                for cmd in self.audiocmds:
                                    tst += "\n   •「%s」"%cmd
                            self.client.sendMessage(to,"{}".format(str(tst)))

                        if txt.startswith("!..s "):
                            if '!..add' in txt:
                                cmd = txt.split('!..add',1)[1].lstrip().rstrip()
                                if cmd not in self.commands["stickers"].keys():
                                    self.addsticker = True
                                    self.stickercommand = cmd
                                    if not silent:self.client.sendText(to,"Send a sticker to add to command %s."%cmd)
                                else:
                                    self.client.sendText(to,"Sticker for command %s has already been set."%cmd)
                            elif '!..del' in txt:
                                cmd = txt.split('!..del',1)[1].lstrip().rstrip()
                                if cmd in self.commands["stickers"].keys():
                                    del self.commands["stickers"][cmd]
                                    if not silent:self.client.sendText(to,"Sticker command %s has been removed."%cmd)
                                else:
                                    if not silent:self.client.sendText(to,"Sticker command %s does not exist"%cmd)
                            elif '!..list' in txt:
                                tst = "♬♬♬♬♬♬♬♬♬\t\n♬ Sticker List ♬\t\n♬♬♬♬♬♬♬♬♬\n"
                                if len(self.commands["stickers"].keys()) > 0:
                                    for cmd in self.commands["stickers"].keys():
                                        tst += "\n⌬. %s"%cmd
                                    self.client.sendText(to,tst)
                                else:
                                    self.client.sendText(to,"Stickerlist is empty!")
                            else:
                                self.client.sendText(to,"Usage:\n⌬ !add\n⌬ !del\n⌬ !list")
                        if txt.startswith("!..radd "):
                            cmdname = txt.split()[1]
                            if cmdname not in self.perintah:
                                perintah = msg.text[len("!radd ") + len(cmdname):]
                                if len(perintah.lstrip().rstrip()) > 0:
                                    self.perintah[cmdname] = perintah.lstrip().rstrip()
                                    if not silent:self.client.sendText(to,"Command %s created."%cmdname)
                                else:
                                    self.imgcmd = cmdname
                                    if not silent:self.client.sendText(to,"Send an image to add to command %s."%cmdname)
                            else:
                                self.client.sendText(to,"Image for command %s has already been set."%cmdname)
                        if txt.startswith("!..cdel "):
                            cmdname = txt.split()[1]
                            if cmdname in self.perintah:
                                del self.perintah[cmdname]
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            elif cmdname in self.imgcmds:
                                self.client.deleteFile(self.imgcmds[cmdname])
                                del self.imgcmds[cmdname]
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            else:
                                if not silent:self.client.sendText(to,"Command %s does not exist."%cmdname)
                        if txt.startswith("!..cvideo "):
                            cmdname = txt.split()[1]
                            if cmdname not in self.perintah:
                                perintah = msg.text[len("!..cvideo ") + len(cmdname):]
                                self.vidcmd = cmdname
                                if not silent:self.client.sendText(to,"Send an video to add to command %s."%cmdname)
                            else:
                                self.client.sendText(to,"Video for command %s has already been set."%cmdname)
                        if txt.startswith("!..rvideo "):
                            cmdname = txt.split()[1]
                            if cmdname in self.vidcmds:
                                self.client.deleteFile(self.vidcmds[cmdname])
                                del self.vidcmds[cmdname]
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            else:
                                if not silent:self.client.sendText(to,"Command %s does not exist."%cmdname)
                        if txt.startswith("!..cmusic "):
                            cmdname = txt.split()[1]
                            if cmdname not in self.perintah:
                                perintah = msg.text[len("!cmusic ") + len(cmdname):]
                                self.musiccmd = cmdname
                                if not silent:self.client.sendText(to,"Send an Music to add to command %s."%cmdname)
                            else:
                                self.client.sendText(to,"Music for command %s has already been set."%cmdname)
                        if txt.startswith("!..rmusic "):
                            cmdname = txt.split()[1]
                            if cmdname in self.musiccmds:
                                self.client.deleteFile(self.musiccmds[cmdname])
                                del self.musiccmds[cmdname]
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            else:
                                if not silent:self.client.sendText(to,"Command %s does not exist."%cmdname)
                        if txt.startswith("!..caudio "):
                            cmdname = txt.split()[1]
                            if cmdname not in self.perintah:
                                perintah = msg.text[len("!..caudio ") + len(cmdname):]
                                self.audiocmd = cmdname
                                if not silent:self.client.sendText(to,"Send an audio to add to command %s."%cmdname)
                            else:
                                self.client.sendText(to,"Audio for command %s has already been set."%cmdname)
                        if txt.startswith("!..raudio "):
                            cmdname = txt.split()[1]
                            if cmdname in self.audiocmds:
                                self.client.deleteFile(self.audiocmds[cmdname])
                                del self.audiocmds[cmdname]
                                if not silent:self.client.sendText(to,"Command %s has been removed."%cmdname)
                            else:
                                if not silent:self.client.sendText(to,"Command %s does not exist."%cmdname)

                        if txt.startswith("...ats"):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    group = self.client.getGroup(to)
                                    members = [contact.mid for contact in group.members]
                                    nama = self.client.getContact(mention).displayName
                                    tags = []
                                    for i in range(0, len(members), 20):
                                        tags.append(list(members[i:i+20]))
                                    for t in tags:
                                        msg = ttypes.Message(to=msg.to)
                                        tst ="%s\n\n"%group.name
                                        tst += u''
                                        s=len(tst)
                                        d=[]
                                        for i in range(len(t)):
                                            d.append({"S":str(s), "E" :str(s+4), "M":t[i]})
                                            s += 5
                                            tst +=u'@oup\n'
                                        msg.text = tst.rstrip() 
                                        msg.contentMetadata = {'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+mention, 'MSG_SENDER_NAME': nama,u'MENTION':json.dumps({"MENTIONEES":d})}
                                        self.client.talk.sendMessage(0,msg)

                        if txt == "!...ats":
                            group = self.client.getGroup(msg.to)
                            members = [contact.mid for contact in group.members]
                            tags = []
                            for i in range(0, len(members), 20):
                                tags.append(list(members[i:i+20]))
                            for t in tags:
                                msg = ttypes.Message(to=msg.to)
                                tst ="%s\n\n"%group.name
                                tst += u''
                                s=len(tst)
                                d=[]
                                for i in range(len(t)):
                                    d.append({"S":str(s), "E" :str(s+4), "M":t[i]})
                                    s += 5
                                    tst +=u'@oup\n'
                                msg.text = tst.rstrip() 
                                msg.contentMetadata = {u'MENTION':json.dumps({"MENTIONEES":d})}
                                self.client.talk.sendMessage(0,msg)

                        if txt == "/...ats":
                            group = self.client.getGroup(msg.to)
                            UID =  self.settings["buyer"]
                            nama = self.client.getContact(UID).displayName
                            members = [contact.mid for contact in group.members]
                            tags = []
                            for i in range(0, len(members), 20):
                                tags.append(list(members[i:i+20]))
                            for t in tags:
                                msg = ttypes.Message(to=msg.to)
                                tst ="%s\n\n"%group.name
                                tst += u''
                                s=len(tst)
                                d=[]
                                for i in range(len(t)):
                                    d.append({"S":str(s), "E" :str(s+4), "M":t[i]})
                                    s += 5
                                    tst +=u'@oup\n'
                                msg.text = tst.rstrip() 
                                msg.contentMetadata = {'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+UID, 'MSG_SENDER_NAME': nama,u'MENTION':json.dumps({"MENTIONEES":d})}
                                self.client.talk.sendMessage(0,msg)
                        if txt.startswith("!..tempstk "):
                            if '!.add' in txt:
                                cmd = txt.split('!.add',1)[1].lstrip().rstrip()
                                if cmd not in self.commands["tmpstickers"].keys():
                                    self.stickertemp = True
                                    self.stickercmd = cmd
                                    if not silent:self.client.sendText(to,"Send a sticker to add to command %s."%cmd)
                                else:
                                    self.client.sendText(to,"Templstk for command %s has already been set."%cmd)
                            elif '!.del' in txt:
                                cmd = txt.split('!.del',1)[1].lstrip().rstrip()
                                if cmd in self.commands["tmpstickers"].keys():
                                    del self.commands["tmpstickers"][cmd]
                                    if not silent:self.client.sendText(to,"Templstk command %s has been removed."%cmd)
                                else:
                                    if not silent:self.client.sendText(to,"Sticker command %s does not exist"%cmd)
                            elif '!.list' in txt:
                                tst = "♬♬♬♬♬♬♬♬♬\t\n♬ Template Sticker ♬\t\n♬♬♬♬♬♬♬♬♬\n"
                                if len(self.commands["tmpstickers"].keys()) > 0:
                                    for cmd in self.commands["tmpstickers"].keys():
                                        tst += "\n⌬. %s"%cmd
                                    self.client.sendText(to,tst)
                                else:
                                    self.client.sendText(to,"Stickerlist is empty!")
                            else:
                                self.client.sendText(to,"Usage:\n⌬ !add\n⌬ !del\n⌬ !list")
                        if txt.startswith("!..youtube"):
                            try:
                                sep = msg.text.split(" ")
                                search = msg.text.replace(sep[0] + " ","")
                                params = {"search_query": search}
                                r = requests.get("https://www.youtube.com/results",params=params)
                                soup = BeautifulSoup(r.content, "html5lib")
                                self.yt.clear()
                                ret_ = "[ Youtube Result ]\n"
                                datas = [] 
                                no = 0
                                for data in soup.select(".yt-lockup-title > a[title]"):
                                    if "&lists" not in data["href"]:
                                        datas.append(data)
                                        self.yt.append("https://www.youtube.com{}".format(str(data["href"])))
                                for data in datas:
                                    no += 1
                                    ret_ += "\n{}. {}".format(str(no), str(data["title"]))
                                    ret_ += "\nhttps://www.youtube.com{}\n".format(str(data["href"]))
                                self.client.sendMessage(to, str(ret_))
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt.startswith("!..syoutube"):
                            try:
                                sep = msg.text.split(" ")
                                search = msg.text.replace(sep[0] + " ","")
                                r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=20&q={}&type=video&key=AIzaSyAF-_5PLCt8DwhYc7LBskesUnsm1gFHSP8".format(str(search)))
                                self.yt.clear()
                                data = r.text
                                a = json.loads(data)
                                if a["items"] != []:
                                    ret_ = []
                                    for music in a["items"]:
                                        ret_.append({"thumbnailImageUrl": 'https://i.ytimg.com/vi/{}/maxresdefault.jpg'.format(music['id']['videoId']),"imageSize": "contain","imageAspectRatio": "square","title": '{}'.format(str(music['snippet']['title'][:40])),"text": '{}'.format(str(music['snippet']['channelTitle'][:15])),"actions": [{"type": "uri","label": "Go Page","uri": 'https://www.youtube.com/watch?v=' +music['id']['videoId']}]})
                                        self.yt.append("https://www.youtube.com/watch?v={}".format(str(music['id']["videoId"])))
                                    k = len(ret_)//10 
                                    for aa in range(k+1):
                                        data = {"type": "template","altText": " Hackbot","template": {"type": "carousel","columns": ret_[aa*10 : (aa+1)*10]}}
                                        self.sendTemplate(to,data)
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt.startswith("!..ytmp4"):
                            try:
                                separate = msg.text.split(" ")
                                no = msg.text.replace(separate[0] + " ","")
                                na = int(no)-1
                                subprocess.getoutput('youtube-dl --format mp4 --output video.mp4 {}'.format(self.yt[na]))
                                self.client.sendVideo(to, "video.mp4")
                                time.sleep(1)
                                os.remove("video.mp4")
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt.startswith("!..ytmp3"):
                            try:
                                separate = msg.text.split(" ")
                                no = msg.text.replace(separate[0] + " ","")
                                na = int(no)-1
                                subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output audio.mp3 {}'.format(self.yt[na]))
                                self.client.sendAudio(to, "audio.mp3")
                                time.sleep(1)
                                os.remove("audio.mp3")
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt.startswith("!...ymp3 "):
                            try:
                                quer = " ".join(txt.split()[1:]);query = urllib.parse.quote(quer)
                                url = "https://www.youtube.com/results?search_query=" + query;response = urllib.request.urlopen(url)
                                html = response.read();soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl);stream = vid.streams
                                for s in stream:
                                    vin = s.url;hasil = vid.title; hasil += '\n⌬ author : ' + str(vid.author) + '\n⌬ duration : ' + str(vid.duration) + '\n⌬ likes : ' + str(vid.likes) + '\n⌬ viewcount : ' + str(vid.viewcount) + '\n⌬ rating : ' + str(vid.rating) + '\n⌬ published : ' + str(vid.published)
                                self.client.sendText(msg.to,hasil);self.client.sendAudioWithURL(to,vin);print (" Yt-mp3 Succes")
                            except Exception as e:self.client.sendText(to,str(e))
                        if txt.startswith("!...ymp4 "):
                            try:
                                quer = " ".join(txt.split()[1:])
                                query = urllib.parse.quote(quer)
                                url = "https://www.youtube.com/results?search_query=" + query;response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl);stream = vid.streams
                                for s in stream:
                                    vin = s.url;hasil = vid.title;hasil += '\n⌬ author : ' + str(vid.author) + '\n⌬ duration : ' + str(vid.duration) + '\n⌬ likes : ' + str(vid.likes) + '\n⌬ viewcount : ' + str(vid.viewcount) + '\n⌬ rating : ' + str(vid.rating) + '\n⌬ published : ' + str(vid.published)
                                self.client.sendText(msg.to,hasil);self.client.sendVideoWithURL(to,vin);print (" Yt-mp4 Succes")
                            except Exception as e:self.client.sendText(to,str(e))
                        if txt.startswith("!.addmessage "):
                            if '!.off' in txt:
                                self.settings["addmessage"] = None
                                if not silent:self.client.sendText(to,"Addmessage disabled.")
                            else:
                                if '!.addmessage' in msg.text:
                                    addmessage = msg.text.replace("!.addmessage","").lstrip().rstrip()
                                else:
                                    addmessage = msg.text.replace("!.Addmessage","").lstrip().rstrip()
                                if len(addmessage) > 0:
                                    self.settings["addmessage"] = addmessage
                                    if not silent:self.client.sendText(to,"Addmessage has been set to:\n%s"%self.settings["addmessage"])
                                else:
                                    self.client.sendText(to,"Given message is too short!")
                        if txt.startswith("!.target "):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    buyer = mention
                                    group = self.client.getGroup(to)
                                    for member in group.members:
                                        if buyer == member.mid:
                                            name = member.displayName
                                    self.settings["buyer"] = buyer
                                    self.client.sendText(to,"Done.")
                        if txt.startswith("..tagmsg "):
                            if '!.off' in txt:
                                if self.settings["tagmessage"][0]:
                                    self.settings["tagmessage"][0] = False
                                    if not silent:self.client.sendText(to,"Tagmessage disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Tagmessage already disabled.")
                            elif '!..on' in txt:
                                if not self.settings["tagmessage"][0]:
                                    self.settings["tagmessage"][0] = True
                                    if not silent:self.client.sendText(to,"Tagmessage enabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Tagmessage already enabled.")
                            else:
                                if '!.tagmsg' in msg.text:
                                    tagmessage = msg.text.replace("!.tagmsg","").lstrip().rstrip()
                                else:
                                    tagmessage = msg.text.replace("!.tagmsg","").lstrip().rstrip()
                                self.settings["tagmessage"][1] = tagmessage
                                if not silent:self.client.sendText(to,"Tagmessage set to:\n%s"%tagmessage)
                        if txt.startswith('!.gcon'):self.gcon(to,msg)
                        if txt.startswith(".autoblock "):
                            if '.on' in txt:
                                if not self.settings["autoblock"]:
                                    self.settings["autoblock"] = True
                                    if not silent:self.client.sendText(to,"Autoblock enabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Autoblock already enabled.")
                            elif '.off' in txt:
                                if self.settings["autoblock"]:
                                    self.settings["autoblock"] = False
                                    if not silent:self.client.sendText(to,"Autoblock disabled.")
                                else:
                                    if not silent:self.client.sendText(to,"Autoblock already disabled.")
                            else:
                                if not silent:self.client.sendText(to,"Usage:\n⌬. !on\n⌬. !off")
                        if txt == ".reboot":
                            self.client.sendText(to, "Rebooting....")
                            self.restart_program()
                        if txt == "!.lineid":self.client.sendText(to, self.client.profile.userid)
                        if txt.startswith("!mid"):
                            if txt == '!.mid':
                                user = self.client.profile.mid
                                self.client.sendText(to, user)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    self.client.sendText(to, target)
                                else:
                                    pass
                        if txt.startswith("!.status"):
                            if txt == '!.status':
                                user = self.client.profile.statusMessage
                                self.client.sendText(to,"⌬Status:\n\n" + user)
                            elif msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    user = self.client.getContact(target).statusMessage
                                    self.client.sendText(to,"⌬Status:\n\n" + user)
                                else:
                                    pass
                        if txt.startswith("!.userid "):
                            id = " ".join(txt.split()[1:])
                            conn = self.client.findContactsByUserid(id)
                            if True:                                      
                                self.client.sendContact(to,conn.mid)
                        if txt.startswith("!.gpending"):
                            try:
                                if "!.naame" in txt:
                                    gid = self.client.getGroupIdsInvited()
                                    tst = "Invited:\n"
                                    count = 0
                                    for group in gid:
                                        Gname = self.client.getGroup(group).name
                                        gc = self.client.getGroup(group)
                                        tst += "\n%s - %s (%s)"%(count,Gname,len(gc.members))
                                        count += 1
                                    self.client.sendText(to,tst)
                                else:
                                    gid = self.client.getGroupIdsInvited()
                                    tst = "Invited:\n"
                                    self.client.sendMessage(to,"Total: %s Invited"%str(len(gid)))
                            except:
                                traceback.print_exc()
                        if txt.startswith("!.accept"):
                            if "!...all" in txt:
                                gid = self.client.getGroupIdsInvited()
                                for group in gid:
                                    self.acceptGroupInvitation(group)
                                self.client.sendText(to,"Succes accept %s group invited"%str(len(gid)))
                            else:
                                gid = self.client.getGroupIdsInvited()
                                selection = Archimed(txt.split(' ')[1],range(1,len(gid)+1))
                                k = len(gid)//100
                                for a in range(k+1):
                                    if a == 0:eto='  「 Accept Group 」'
                                    else:eto='  「 Accept Group 」'
                                    text = ''
                                    no = 0
                                    for i in selection.parse()[a*100 : (a+1)*100]:
                                        self.client.acceptGroupInvitation(gid[i - 1])
                                        no+=1
                                        if no == len(selection.parse()):text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
                                        else:text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
                                    self.client.sendMessage(to,eto+text)
                        if txt == "!.gid":
                            self.client.sendMessage(to,msg.to)
                        if txt.startswith(".unsend "):
                            args = txt.replace(".unsend ","").lstrip().rstrip()
                            mes = 0
                            try:
                                mes = int(args)
                            except:
                                mes = 1
                            M = self.client.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == self.client.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                self.client.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                        if txt.startswith(".unsend"):
                            args = txt.replace(".unsend","").lstrip().rstrip()
                            ginfo = self.client.getGroup(to)
                            start = time.time()
                            mes = 0
                            try:
                                mes = int(args[1])
                            except:
                                mes = 1
                            M = self.client.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == self.client.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                self.client.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                            begin = time.time() - start
                            #hasil = "Type: unsend\n⌬.Group: " + ginfo.name + "\n⌬.Time: "+ str(begin) + "\n⌬.Total: " + str(len(MId))
                            if not silent:self.client.sendMessage(to,"{}".format(str(hasil)))

                        if txt == "!.logs":
                            a=subprocess.getoutput('cat log/{}'.format(self.dxName))
                            k = len(a)//10000
                            for aa in range(k+1):
                                self.client.sendMessage(to,'{}'.format(a[aa*10000 : (aa+1)*10000]))
                            try:
                                os.remove('log/{}'.format(self.dxName))
                            except:pass

                        if txt == "!.stats":
                            umid = self.client.profile.mid
                            uid = self.client.profile.userid
                            try:
                                arr = []
                                timeNow = time.time()
                                runtime = timeNow - self.stats['start']
                                runtime = format_timespan(runtime)
                                contact = self.client.getContact(self.uid)
                                grouplist = self.client.getGroupIdsJoined()
                                pendinglist = self.client.getGroupIdsInvited()
                                contactlist = self.client.getAllContactIds()
                                blockedlist = self.client.getBlockedContactIds()
                                autoblock = self.client.talk.getBlockedRecommendationIds() + self.client.getBlockedContactIds()
                                seal = self.client.getSettings().e2eeEnable
                                fil = self.client.getSettings().privacyReceiveMessagesFromNotFriend
                                src = self.client.getSettings().privacySearchByUserid
                                nnm = self.client.getSettings().notificationNewMessage
                                ngi = self.client.getSettings().notificationGroupInvitation
                                nsm = self.client.getSettings().notificationShowMessage
                                nic = self.client.getSettings().notificationIncomingCall
                                psc = self.client.getSettings().privacySyncContacts
                                psbpn = self.client.getSettings().privacySearchByPhoneNumber
                                psbe = self.client.getSettings().privacySearchByEmail
                                pasddl = self.client.getSettings().privacyAllowSecondaryDeviceLogin
                                ppiptmh = self.client.getSettings().privacyProfileImagePostToMyhome
                                pan = self.client.getSettings().privacyAllowNearby
                                nm = self.client.getSettings().notificationMention
                                if src == True:alid = "True"
                                else:alid = "False"
                                if seal == True:letsel = "True"
                                if seal == False:letsel = "False"
                                if fil == True:fpes = "False"
                                if fil == False:fpes = "True"
                                if nnm == True:notificationNewMessage = "True"
                                if nnm == False:notificationNewMessage = "False"
                                if ngi == True:notificationGroupInvitation = "True"
                                if ngi == False:notificationGroupInvitation = "False"
                                if nsm == True:notificationShowMessage = "True"
                                if nsm == False:notificationShowMessage = "False"
                                if nic == True:notificationIncomingCall = "True"
                                if nic == False:notificationIncomingCall = "False"
                                if psc == True:privacySyncContacts = "True"
                                if psc == False:privacySyncContacts = "False"
                                if psbpn == True:privacySearchByPhoneNumber = "True"
                                if psbpn == False:privacySearchByPhoneNumber = "False"
                                if psbe == True:privacySearchByEmail = "True"
                                if psbe == False:privacySearchByEmail = "False"
                                if pasddl == True:privacyAllowSecondaryDeviceLogin = "True"
                                if pasddl == False:privacyAllowSecondaryDeviceLogin = "False"
                                if ppiptmh == True:privacyProfileImagePostToMyhome = "True"
                                if ppiptmh == False:privacyProfileImagePostToMyhome = "False"
                                if pan == True:privacyAllowNearby = "True"
                                if pan == False:privacyAllowNearby = "False"
                                if nm == True:notificationMention = "True"
                                if nm == False:notificationMention = "False"
                                ret_ = "\nAccount Status:"
                                ret_ += "\n\n  • Name : {}".format(contact.displayName)
                                #ret_ += "\n🎲 LineId : {}".format(uid)
                                ret_ += "\n  • Group : {}".format(str(len(grouplist)))
                                ret_ += "\n  • Gpending : {}".format(str(len(pendinglist)))
                                ret_ += "\n  • Friend : {}".format(str(len(contactlist)))
                                ret_ += "\n  • Blocked : {}".format(str(len(blockedlist)))
                                ret_ += "\n  • AutoBlock : {}".format(str(len(autoblock)))
                                ret_ += "\n  • Cancel : {}".format(self.stats["cancelcount"])
                                ret_ += "\n  • Unsend : {}".format(self.stats["destrcount"])
                                ret_ += "\n  • Kick : {}".format(self.stats["kickcount"])
                                ret_ += "\n  • Invite : {}".format(self.stats["invtcount"])
                                ret_ += "\n  • Accept : {}".format(self.stats["accpcount"])
                                ret_ += "\n  • Updated : {}".format(self.stats["upprofile"])
                                ret_ += "\n  • Follower : {}".format(self.stats["follower"])
                                ret_ += "\n  • Following : {}".format(self.stats["following"])
                                ret_ += "\n  • Messages sent : {}".format(self.stats["sentcount"])
                                ret_ += "\n  • Messages received : {}".format(self.stats["receivecount"])
                                ret_ += "\n  • Filter Msg : {}".format(fpes)
                                ret_ += "\n  • Allow Id Add : {}".format(alid)
                                ret_ += "\n  • Latter Sealing : {}".format(letsel)
                                ret_ += "\n  • NewMessage : {}".format(notificationNewMessage)
                                ret_ += "\n  • GroupInvitation : {}".format(notificationGroupInvitation)
                                ret_ += "\n  • ShowMessage : {}".format(notificationShowMessage)
                                ret_ += "\n  • IncomingCall : {}".format(notificationIncomingCall)
                                ret_ += "\n  • SyncContacts : {}".format(privacySyncContacts)
                                ret_ += "\n  • SearchByPNumber : {}".format(privacySearchByPhoneNumber)
                                ret_ += "\n  • SearchByEmail : {}".format(privacySearchByEmail)
                                ret_ += "\n  • AllowDeviceLogin : {}".format(privacyAllowSecondaryDeviceLogin)
                                ret_ += "\n  • PImagePostToMyhome : {}".format(privacyProfileImagePostToMyhome)
                                ret_ += "\n  • AllowNearby : {}".format(privacyAllowNearby)
                                ret_ += "\n  • NotifMention : {}".format(notificationMention)
                                ret_ += "\n  • Running: {}".format(str(runtime))
                                self.sendTagg(to,umid,"Sender:",str(ret_))
                            except Exception as e:
                                traceback.print_exc()
                                self.logError("ERROR : " + str(e))
                        if txt.startswith('!.leave'):
                            gid = self.client.getGroupIdsJoined()
                            selection = Archimed(txt.split(' ')[1],range(1,len(gid)+1))
                            k = len(gid)//100
                            for a in range(k+1):
                                if a == 0:eto='  「 Leave Group 」'
                                else:eto='  「 Leave Group 」'
                                text = ''
                                no = 0
                                for i in selection.parse()[a*100 : (a+1)*100]:
                                    self.client.leaveGroup(gid[i - 1])
                                    no+=1
                                    if no == len(selection.parse()):text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
                                    else:text+= "\n{}. {}".format(i,self.client.getGroup(gid[i - 1]).name)
                                if not silent:self.client.sendMessage(to,eto+text)
                        if txt.startswith("!.contact"):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    self.client.sendContact(to,target)
                            elif txt == "!.contact":
                                self.client.sendContact(to,of)
                            else:
                                try:
                                    tx = txt.split(":")
                                    num = int(tx[1])
                                    foo = int(tx[2])
                                    me = self.client.getContact(of)
                                    gid = self.client.getGroupIdsJoined()
                                    gs = self.client.getGroup(gid[num-0])
                                    nama = [o.mid for o in gs.members]
                                    if nama == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        anu = self.client.getContact(nama[foo-2])
                                        self.client.sendContact(to,nama[foo-2])
                                except:
                                    _name = "/".join(txt.split()[2:])
                                    gs = self.client.getGroup(to)
                                    targets = []
                                    for g in gs.members:
                                        if _name in g.displayName.lower():
                                            targets.append(g.mid)
                                    if targets == []:
                                        self.client.sendText(to,"Not found.")
                                    else:
                                        for target in targets:
                                            self.client.sendContact(to,target)
                        if txt == "!.renaame":
                            self.clear()
                            self.renamecon = True
                            if not silent:self.sendTagg(to,of,"• ","\nSend a contact to Rename.\nEnter Rename Name")
                        if txt.startswith('!renaame '):
                            if msg.contentMetadata:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for mention in targets:
                                    self.stats["rcon"].append(mention)
                                    self.rename = of
                        elif self.rename is not None:
                            if of in self.rename:
                                amount = len(self.stats["rcon"])
                                for uid in self.stats["rcon"]:
                                    self.client.findAndAddContactsByMid(uid)
                                    self.client.renameContact(uid,msg.text)
                                self.client.sendMessage(to,"rename %s contact to %s"%(amount,msg.text))
                                self.stats["rcon"] = []
                                self.rename = None
                    elif msg.contentType == 1:
                        if to in self.stats['picture']:
                            xpath = self.client.downloadObjectMsg(msg.id)
                            self.client.updateProfilePicture(xpath)
                            self.client.sendText(to, "Done")
                            self.client.deleteFile(xpath)
                            del self.stats['picture'][to]
                        if self.imgcmd:
                            msgid = msg.id
                            #url = 'https://obs-de.line-apps.com/os/m/%s'%msgid
                            img = self.client.downloadObjectMsg(msgid)
                            self.imgcmds[self.imgcmd] = img
                            self.client.sendText(msg.to,"Image successfully added to command %s."%self.imgcmd)
                            self.imgcmd = None
                        if self.welcomeimage:
                            self.welcomeimage = False
                            msgid = msg.id
                            img = self.client.downloadObjectMsg(msgid)
                            self.stats['welcomeimage'][to] = [True,img]
                            self.client.sendText(to,"Welcome image set.")
                        if to in self.stats['gpic']:
                            xpath = self.client.downloadObjectMsg(msg.id)
                            self.client.updateGroupPicture(to,xpath)
                            self.client.sendText(to,"Done")
                            self.client.deleteFile(xpath)
                            del self.stats['gpic'][to]
                        if self.stats['changeProfileVideo']['status'] == True:
                            path = self.client.downloadObjectMsg(msg.id, saveAs="tmp/pict.bin")
                            if self.stats['changeProfileVideo']['stage'] == 1:
                                self.stats['changeProfileVideo']['picture'] = path
                                self.client.sendMessage(to, "Please send video for update profile")
                                self.stats['changeProfileVideo']['stage'] = 2
                            elif self.stats['changeProfileVideo']['stage'] == 2:
                                self.stats['changeProfileVideo']['picture'] = path
                                self.changeProfileVideo(to)
                                self.client.sendMessage(to, "Succes update video profile")
                                self.client.deleteFile(path)
                    elif msg.contentType == 2:
                        if self.stats['changeProfileVideo']['status'] == True:
                            path = self.client.downloadObjectMsg(msg.id)
                            if self.stats['changeProfileVideo']['stage'] == 1:
                                self.stats['changeProfileVideo']['video'] = path
                                self.client.sendMessage(to, "Please send picture for update profile")
                                self.stats['changeProfileVideo']['stage'] = 2
                            elif self.stats['changeProfileVideo']['stage'] == 2:
                                self.stats['changeProfileVideo']['video'] = path
                                self.changeProfileVideo(to)
                                self.client.deleteFile(path)
                        if self.vidcmd:
                            msgid = msg.id
                            vid = self.client.downloadObjectMsg(msgid)
                            self.vidcmds[self.vidcmd] = vid
                            self.client.sendText(msg.to,"Video successfully added to command %s."%self.vidcmd)
                            self.vidcmd = None
                    elif msg.contentType == 3:
                        if self.audiocmd:
                            msgid = msg.id
                            audio = self.client.downloadObjectMsg(msgid)
                            self.audiocmds[self.audiocmd] = audio
                            self.client.sendText(msg.to,"Audio successfully added to command %s."%self.audiocmd)
                            self.audiocmd = None
                    elif msg.contentType == 16:
                        if self.musiccmd:
                            msgid = msg.id
                            music = self.client.downloadObjectMsg(msgid)
                            self.musiccmds[self.musiccmd] = music
                            self.client.sendText(msg.to,"Music successfully added to command %s."%self.musiccmd)
                            self.musiccmd = None
                    elif msg.contentType == 7:
                        if self.stickertemp:
                            sticker1 = msg.contentMetadata['STKID']
                            sticker2 = msg.contentMetadata['STKPKGID']
                            sticker3 = msg.contentMetadata['STKVER']
                            self.commands["tmpstickers"][self.stickercmd] = [sticker1,sticker2,sticker3]
                            self.stickertemp = False
                            self.client.sendText(to,"Sticker successfully added to command %s."%self.stickercmd)
                            self.stickercmd = ""
                        if self.addsticker:
                            sticker1 = msg.contentMetadata['STKID']
                            sticker2 = msg.contentMetadata['STKPKGID']
                            sticker3 = msg.contentMetadata['STKVER']
                            self.commands["stickers"][self.stickercommand] = [sticker1,sticker2,sticker3]
                            self.addsticker = False
                            self.client.sendText(to,"Sticker successfully added to command %s."%self.stickercommand)
                            self.stickercommand = ""
                        if self.cctvSTICKER:
                            sticker1 = msg.contentMetadata['STKID']
                            sticker2 = msg.contentMetadata['STKPKGID']
                            sticker3 = msg.contentMetadata['STKVER']
                            self.commands["cctvStickers"][to] = [sticker1,sticker2,sticker3]
                            self.cctvSTICKER = False
                            self.client.sendText(to,"Cctv Actives")
                    elif msg.contentType == 13:
                        if self.addcommand:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if uid not in self.tempbots:
                                self.tempbots.append(uid)
                                self.tempnames.append(name)
                                self.client.findAndAddContactsByMid(uid)
                                self.client.sendText(to,"Added %s to command %s."%(name,self.addcmd))
                            else:
                                self.client.sendText(to,"%s has already been added to command %s"%(name,self.addcmd))
                        if self.stats["locate"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["locate"] = False
                            groups = self.client.getGroupIdsJoined()
                            ingroups = []
                            for group in groups:
                                members = [o.mid for o in self.client.getGroup(group).members]
                                if uid in members:
                                    ingroups.append(self.client.getGroup(group).name)
                            if len(ingroups) > 0:
                                tst = "Found %s in %s groups:\n"%(name,len(ingroups))
                                for g in ingroups:
                                    tst += "\n⌬. %s"%g
                                self.client.sendText(to,tst)
                            else:
                                self.client.sendText(to,"User not found in any group.")
                        if self.stats["ban"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["ban"] = False 
                            if uid in self.master:
                                self.client.sendText(to,"Please try expel first.")
                            elif uid in self.stats["banned"]:
                                self.client.sendText(to,"%s is already Shitlisted."%name)
                            elif uid in self.stats["botlist"] or uid in self.stats["stafflist"]:
                                self.client.sendText(to,"Please try expel first.")
                            else:
                                self.stats["banned"].append(uid)
                                self.client.sendText(to,"%s add to Shitlisted."%name)
                        if self.stats['kick']:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["kick"] = False
                                if uid not in self.stats["botlist"] or uid not in self.stats["stafflist"]:
                                    self.client.kickoutFromGroup(to,[uid])
                                    time.sleep(0.5)
                                else:
                                    self.client.sendText(to,"Please try expel first.")
                        if self.stats['invite']:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["invite"] = False
                                if uid in self.stats['banned']:
                                    self.client.sendMessage(to,"Can't invite user banned")
                                else:
                                    self.client.findAndAddContactsByMid(uid)
                                    self.client.inviteIntoGroup(to,[uid])
                                    self.client.sendText(to,"Successfully invite %s"%name)
                        if self.stats["gift"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["gift"] = False
                            if uid in self.master:
                                self.client.sendText(to,"Permission denied.")
                            else:
                                self.client.sendGift(uid,'2351','sticker')
                                self.client.sendText(to,"Gift sent.")
                        if self.stats["unban"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["unban"] = False
                            if uid in self.stats["banned"]:
                                self.stats["banned"].remove(uid)
                                self.client.sendText(to,"%s has been unshit."%name)
                            else:
                                self.client.sendText(to,"%s is not shitlisted."%name)
                        if self.stats["staff"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["staff"] = False
                            if uid in self.stats["stafflist"]:
                                if not silent:self.client.sendText(to,"%s is already staff."%name)
                            elif uid in self.stats["banned"]:
                                self.stats["banned"].remove(uid)
                                self.stats["stafflist"].append(uid)
                                if not silent:self.client.sendText(to,"%s has been added as staff."%name)
                            elif uid in self.stats["botlist"]:
                                self.stats["botlist"].remove(uid)
                                self.stats["stafflist"].append(uid)
                                if not silent:self.client.sendText(to,"%s has been promoted from bot to staff."%name)
                            else:
                                self.stats["stafflist"].append(uid)
                                if not silent:self.client.sendText(to,"%s has been added as staff."%name)
                        if self.stats["bot"]:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.stats["bot"] = False
                            if uid in self.stats["botlist"]:
                                self.client.sendText(to,"%s is already bots."%name)
                            elif uid in self.stats["banned"]:
                                self.stats["banned"].remove(uid)
                                self.stats["botlist"].append(uid)
                                self.client.sendText(to,"%s has been added as bot."%name)
                            elif uid in self.stats["stafflist"]:
                                self.stats["stafflist"].remove(uid)
                                self.stats["botlist"].append(uid)
                                if not silent:self.client.sendText(to,"%s has been promoted from staff to bot."%name)
                            else:
                                self.stats["botlist"].append(uid)
                                self.client.sendText(to,"%s has been added as bot."%name)
                        if self.renamecon:
                            name = msg.contentMetadata['displayName']
                            uid = msg.contentMetadata['mid']
                            if not self.stats["repeat"]:
                                self.renamecon = False
                            if uid in self.stats["rcon"]:
                                pass
                            else:
                                self.stats["rcon"].append(uid)
                                self.rename = of
                                self.renamecon = False
                    elif msg.contentType == 14:
                        if add["save"] == True:
                            try:
                                self.client.downloadObjectMsg(msg.id, "path", "%s" % add["img"])
                                self.client.sendMessage(to, "File %s Berhasil Disimpan" % add["img"])
                            except:
                                e = traceback.format_exc()
                                self.logError("ERROR : " + str(e))
                self.stats["sentcount"] += 1
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    def notified_accept_group_invitation(self,op):
        try:
            if op.param1 in self.stats["welcomemsg"]:
                if self.stats["welcomemsg"][op.param1][0]:
                    if op.param2 not in self.stats["botlist"]:
                        self.client.sendText(op.param1,self.stats["welcomemsg"][op.param1][1])
            if op.param1 in self.stats["welcomeimage"]:
                if self.stats["welcomeimage"][op.param1][0]:
                    if op.param2 not in self.stats["botlist"]:
                        self.client.sendImage(op.param1,self.stats["welcomeimage"][op.param1][1])
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    def notified_add_contact(self,op):
        self.stats["follower"] += 1
        try:
            if self.settings["addmessage"]:
                Uid = self.client.getContact(op.param1).mid
                Name = self.client.getContact(op.param1).displayName
                self.sendTagProfile(op.param1,Uid,"◕ ","\n"+self.settings["addmessage"],"https://os.line.naver.jp/os/p/"+Uid,Name)
            if self.settings['autoblock']:
                self.client.blockContact(op.param1)
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    def add_contact(self,op):
        self.stats["following"] += 1
        pass
    def notified_cancel_invitation_group(self,op):
        pass
    def cancel_invitation_group(self,op):
        self.stats["cancelcount"] += 1
        pass
    def notified_invite_into_group(self,op):
        try:
            invites = op.param3.split("\x1e")
            inviter = op.param2
            if self.uid in invites:
                if self.settings["autojoin"] == 2:
                    self.client.acceptGroupInvitation(op.param1)
                elif self.settings["autojoin"] == 1:
                    if inviter in self.stats["stafflist"] or inviter in self.stats["botlist"]:
                        self.client.acceptGroupInvitation(op.param1)
                    else:
                        self.client.rejectGroupInvitation(op.param1)
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    def invite_into_group(self,op):
        self.stats["invtcount"] += 1
        pass
    def notified_kickout_from_group(self,op):
        pass
    def kickout_from_group(self,op):
        self.stats["kickcount"] += 1
        pass
    def notified_leave_group(self,op):
        pass
    def notified_read_message(self,op):
        try:
            self.db['lastseen'][op.param2] = [time.time(),op.param1]
            if op.param1 in self.sider['readPoint']:
                if op.param2 in self.sider['readMember'][op.param1]:
                    pass
                else:
                    self.sider['readMember'][op.param1] += op.param2
                    self.sider['ROM'][op.param1][op.param2] = op.param2
            if op.param1 in self.sider2['readPoint']:
                Name = self.client.getContact(op.param2).displayName
                if Name in self.sider2['readMember'][op.param1]:
                    pass
                else:
                    self.sider2['readMember'][op.param1] += "\n╠・" + Name
            if op.param1 in self.db1['ceksider']['on']:
                if op.param2 not in self.ceks:
                    Uid = self.client.getContact(op.param2).mid
                    Name = self.client.getContact(op.param2).displayName
                    User = self.db1['ceksider']['txt']
                    self.sendTagProfile(op.param1,Uid,"◕ ","\n"+User,"https://os.line.naver.jp/os/p/"+Uid,Name)
                    self.ceks.append(op.param2)
                    if op.param1 in self.stats['cctvPic']:
                        Picture = self.client.getContact(op.param2).pictureStatus
                        self.client.sendImageWithURL(op.param1,"http://dl.profile.line.naver.jp/"+Picture)
                    else:
                        sticker = self.commands["cctvStickers"][op.param1]
                        self.client.send_sticker(op.param1,sticker[0],sticker[1],sticker[2])
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    def notified_reject_group_invitation(self,op):
        pass
    def notified_unregister_user(self,op):
        pass
    def notified_update_group(self,op):
        pass
    def update_profile(self,op):
        self.stats["upprofile"] += 1
        pass
    def notified_update_profile(self,op):
        pass
    def accept_group_invitation(self,op):
        self.stats["accpcount"] += 1
        try:
            if self.settings["autopurge"]:
                group = self.client.getGroup(op.param1)
                members = [o.mid for o in group.members]
                if not set(members).isdisjoint(self.stats["banned"]):
                    band = set(members).intersection(self.stats["banned"])
                    self.client.kickoutFromGroup(op.param1,band)
        except Exception as e:
            traceback.print_exc()
            self.logError("ERROR : " + str(e))
    def destroy_message(self,op):
        self.stats["destrcount"] += 1
        pass
    def notified_destroy_message(self,op):
        pass