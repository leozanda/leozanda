import os, glob, requests, shutil, pafy
import urllib.request, urllib.parse, re

def download(song, return_url=False):
    query_string = urllib.parse.urlencode({"search_query" : song})
    html_content = urllib.request.urlopen("http://www.youtube.com/results?" + query_string)
    search_results = re.findall(r'href=\"\/watch\?v=(.{11})', html_content.read().decode())
    link = "http://www.youtube.com/watch?v=" + search_results[0]
    if return_url:
        return link
    vid = pafy.new(link)
    stream = vid.streams
    for s in stream:
        link = s.url

    session = requests.session()

    r = session.get(link, stream=True, headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/58.0.3029.110 Safari/537.36'})
    with open('{}.mp4'.format(song),"wb") as f:
        shutil.copyfileobj(r.raw, f)
    return '{}.mp4'.format(song)
